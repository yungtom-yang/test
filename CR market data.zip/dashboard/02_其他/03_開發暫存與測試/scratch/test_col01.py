# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import math
import json

with open('scratch/dashboard_data.json', 'r', encoding='utf-8') as f:
    d = json.load(f)

def render_col01_html(d):
    b1 = d["block01_overview"]
    kpis_01 = {c["title"]: c for c in b1["kpis"]}
    amt = kpis_01.get("總交易金額", {})
    cnt = kpis_01.get("總交易筆數", {})
    cash = kpis_01.get("預借現金金額", {})
    revolving = kpis_01.get("循環信用餘額", {})

    # Donut SVG
    slices = [
        {"name": "中國信託", "share": 19.5, "color": "#003b5c"},
        {"name": "國泰世華", "share": 18.6, "color": "#009e73"}, # Cathay Green
        {"name": "台北富邦", "share": 14.5, "color": "#2563eb"},
        {"name": "玉山銀行", "share": 14.1, "color": "#059669"},
        {"name": "其他同業", "share": 33.3, "color": "#cbd5e1"}
    ]
    
    cx, cy, r_out, r_in = 55, 55, 50, 30
    paths = []
    start_angle = -90.0
    
    for s in slices:
        angle_len = (s["share"] / 100.0) * 360.0
        end_angle = start_angle + angle_len
        
        rad_start = math.radians(start_angle)
        rad_end = math.radians(end_angle)
        
        x1_out = cx + r_out * math.cos(rad_start)
        y1_out = cy + r_out * math.sin(rad_start)
        x2_out = cx + r_out * math.cos(rad_end)
        y2_out = cy + r_out * math.sin(rad_end)
        
        x1_in = cx + r_in * math.cos(rad_end)
        y1_in = cy + r_in * math.sin(rad_end)
        x2_in = cx + r_in * math.cos(rad_start)
        y2_in = cy + r_in * math.sin(rad_start)
        
        large_arc = 1 if angle_len > 180 else 0
        
        path_d = f"M {x1_out:.2f} {y1_out:.2f} A {r_out} {r_out} 0 {large_arc} 1 {x2_out:.2f} {y2_out:.2f} L {x1_in:.2f} {y1_in:.2f} A {r_in} {r_in} 0 {large_arc} 0 {x2_in:.2f} {y2_in:.2f} Z"
        paths.append(f'<path d="{path_d}" fill="{s["color"]}" stroke="#ffffff" stroke-width="1.2"><title>{s["name"]}: {s["share"]}%</title></path>')
        start_angle = end_angle
        
    donut_svg = f'''<svg viewBox="0 0 110 110" width="88" height="88" style="display:block; flex-shrink:0;">
        {''.join(paths)}
        <circle cx="{cx}" cy="{cy}" r="{r_in}" fill="#ffffff" />
        <text x="{cx}" y="{cy-3}" font-size="9" font-weight="900" fill="#003b5c" text-anchor="middle">全市場</text>
        <text x="{cx}" y="{cy+9}" font-size="8" font-weight="700" fill="#64748b" text-anchor="middle">30,720億</text>
    </svg>'''

    peers_list = [
        {"name": "中國信託", "val": 5980.0, "share": 19.5, "yoy": "+11.2%", "rank": 1, "is_me": False},
        {"name": "國泰世華", "val": 5726.0, "share": 18.6, "yoy": "+12.8%", "rank": 2, "is_me": True},
        {"name": "台北富邦", "val": 4450.0, "share": 14.5, "yoy": "+18.4%", "rank": 3, "is_me": False},
        {"name": "玉山銀行", "val": 4320.0, "share": 14.1, "yoy": "+9.6%", "rank": 4, "is_me": False}
    ]

    peer_rows_html = "".join([f'''
      <div class="cockpit-peer-row {"highlight" if p["is_me"] else ""}">
        <span class="p-rank">#{p["rank"]}</span>
        <span class="p-name">{p["name"]}</span>
        <span class="p-val">{p["val"]:,.0f} 億</span>
        <span class="p-share"><b>{p["share"]}%</b></span>
        <span class="p-yoy number-positive">{p["yoy"]}</span>
      </div>''' for p in peers_list])

    html = f'''
      <!-- COLUMN 1: 01 全行概況 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <span class="cockpit-badge c-badge-orange">01 全行概況</span>
        </div>

        <!-- 總交易金額 & 總交易筆數 (含一般/分期絕對金額、筆數與佔比) -->
        <div class="cockpit-subbox">
          <!-- Card 1: 總交易金額 -->
          <div class="c-kpi-split-card">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">總交易金額</span>
              <div class="c-kpi-growth"><span class="number-positive">YoY +12.8%</span> <span class="number-positive">MoM +2.1%</span></div>
            </div>
            <div class="c-kpi-main-val">1,286.4 <em>億元</em></div>
            <div class="c-kpi-breakdown-row">
              <div class="c-breakdown-item">
                <span class="b-label">一般交易</span>
                <strong class="b-val">1,086.4 億</strong>
                <span class="b-share">佔比 84.4%</span>
              </div>
              <div class="c-breakdown-divider"></div>
              <div class="c-breakdown-item">
                <span class="b-label">分期交易</span>
                <strong class="b-val">200.0 億</strong>
                <span class="b-share">佔比 15.6%</span>
              </div>
            </div>
          </div>

          <!-- Card 2: 總交易筆數 -->
          <div class="c-kpi-split-card" style="margin-top: 6px;">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">總交易筆數</span>
              <div class="c-kpi-growth"><span class="number-positive">YoY +15.2%</span> <span class="number-positive">MoM +1.7%</span></div>
            </div>
            <div class="c-kpi-main-val">8,425 <em>萬筆</em></div>
            <div class="c-kpi-breakdown-row">
              <div class="c-breakdown-item">
                <span class="b-label">一般交易</span>
                <strong class="b-val">7,750 萬筆</strong>
                <span class="b-share">佔比 92.0%</span>
              </div>
              <div class="c-breakdown-divider"></div>
              <div class="c-breakdown-item">
                <span class="b-label">分期交易</span>
                <strong class="b-val">675 萬筆</strong>
                <span class="b-share">佔比 8.0%</span>
              </div>
            </div>
          </div>

          <!-- Mini Row: 預借現金 & 循環信用 -->
          <div class="c-kpi-mini-grid" style="margin-top: 6px;">
            <div class="c-mini-kpi">
              <span class="c-kpi-title">預借現金金額</span>
              <strong class="c-mini-val">18.6 <em>億元</em></strong>
              <div class="c-kpi-growth"><span class="number-negative">YoY -3.4%</span> <span class="c-hint">42.8萬筆</span></div>
            </div>
            <div class="c-mini-kpi">
              <span class="c-kpi-title">循環信用餘額</span>
              <strong class="c-mini-val">325.7 <em>億元</em></strong>
              <div class="c-kpi-growth"><span class="number-positive">YoY +6.7%</span> <span class="c-hint">生息資產</span></div>
            </div>
          </div>
        </div>

        <!-- 四大發卡行簽帳金額與市佔 (圓餅圖 + 表頭項目名稱 + 無註解) -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>四大發卡行簽帳金額與市佔</span>
            <span class="cockpit-tag-pill">2026 年 1–8 月</span>
          </div>

          <div class="cockpit-market-wrap">
            {donut_svg}
            <div class="cockpit-peer-table-box">
              <div class="cockpit-peer-header">
                <span class="p-rank">排名</span>
                <span class="p-name">發卡銀行</span>
                <span class="p-val">簽帳金額</span>
                <span class="p-share">市占率</span>
                <span class="p-yoy">YoY</span>
              </div>
              <div class="cockpit-peer-list">
                {peer_rows_html}
              </div>
            </div>
          </div>
        </div>
      </div>
    '''
    return html

print(render_col01_html(d)[:300])
