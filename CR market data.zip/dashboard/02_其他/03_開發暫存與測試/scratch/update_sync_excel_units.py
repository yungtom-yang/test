import re, sys
sys.stdout.reconfigure(encoding='utf-8')

fp = "01_儀表板執行環境/sync_excel.py"
with open(fp, "r", encoding="utf-8") as f:
    content = f.read()

count = content.count("千元")
print(f"Found {count} occurrences of '千元' in {fp}")

new_content = content.replace("千元", "億元")

with open(fp, "w", encoding="utf-8") as f:
    f.write(new_content)

print(f"Successfully replaced all occurrences of '千元' with '億元' in {fp}!")
