# Script to systematically map dashboard_data_inventory.md against 現有資料欄位內容.md
import re

with open('dashboard_data_inventory.md', 'r', encoding='utf-8') as f:
    inv = f.read()

with open('現有資料欄位內容.md', 'r', encoding='utf-8') as f:
    exist = f.read()

print("Both files loaded successfully.")
print("Inventory length:", len(inv))
print("Existing fields doc length:", len(exist))
