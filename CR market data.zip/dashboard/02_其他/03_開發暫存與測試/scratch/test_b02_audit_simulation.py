import openpyxl
import os
import shutil
import subprocess

# Copy to temporary excel
test_xlsx = "01_儀表板執行環境/test_audit.xlsx"
shutil.copyfile("01_儀表板執行環境/dashboard_data.xlsx", test_xlsx)

wb = openpyxl.load_workbook(test_xlsx)

# In 02_收單月度指標:
# Clear Row 5 (acq_amt_total) value (D5), so it must be derived from D6 (185) + D7 (100) = 285!
ws = wb["02_收單月度指標"]
print("D5 before:", ws["D5"].value)
ws["D5"].value = None

# Clear Row 18 (twqr_avg_ticket) value (D18), so it must be derived from tx_amt / tx_cnt = 692!
print("D18 before:", ws["D18"].value)
ws["D18"].value = None

# Clear Row 14 (acq_penetration_rate) value (D14) and YoY (F14) - this is non-derivable, so it should report missing!
print("D14 before:", ws["D14"].value)
ws["D14"].value = None
ws["F14"].value = None

# In 02_收單線上交易分析:
# Clear Row 5 (EPOS - 雲端) avg_ticket (D5) - derivable from 55.0 / 275 * 10000 = 2000!
ws2 = wb["02_收單線上交易分析"]
print("ws2 D5 before:", ws2["D5"].value)
ws2["D5"].value = None

# In 02_特店產業結構分布:
# Clear Row 5 (百貨零售) avg_amount_per_mcht (E5) - derivable from 78.5 * 10000 / 14200 = 55.3!
ws3 = wb["02_特店產業結構分布"]
print("ws3 E5 before:", ws3["E5"].value)
ws3["E5"].value = None

wb.save(test_xlsx)

# Run a test audit function using test_xlsx
# Let's load sync_excel logic on test_xlsx
import sys
sys.path.insert(0, "01_儀表板執行環境")
import sync_excel
sync_excel.EXCEL_FILE = os.path.abspath(test_xlsx)
sync_excel.JSON_FILE = os.path.abspath("01_儀表板執行環境/test_out.json")
sync_excel.JS_FILE = os.path.abspath("01_儀表板執行環境/test_out.js")

data = sync_excel.load_data_from_excel()

# Clean up test files
if os.path.exists(test_xlsx): os.remove(test_xlsx)
if os.path.exists("01_儀表板執行環境/test_out.json"): os.remove("01_儀表板執行環境/test_out.json")
if os.path.exists("01_儀表板執行環境/test_out.js"): os.remove("01_儀表板執行環境/test_out.js")
