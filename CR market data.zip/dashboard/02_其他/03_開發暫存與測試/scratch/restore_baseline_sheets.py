# -*- coding: utf-8 -*-
"""
Populate all 7 sheets in dashboard_data.xlsx with their full baseline data.
"""
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

wb = openpyxl.load_workbook("01_儀表板執行環境/dashboard_data.xlsx")

# Styles
header_font = Font(name="Microsoft JhengHei", size=11, bold=True, color="FFFFFF")
header_fill_blue = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
header_fill_green = PatternFill(start_color="065F46", end_color="065F46", fill_type="solid")
header_fill_orange = PatternFill(start_color="C2410C", end_color="C2410C", fill_type="solid")

data_font = Font(name="Microsoft JhengHei", size=10)
bold_data_font = Font(name="Microsoft JhengHei", size=10, bold=True)

thin_border = Border(
    left=Side(style='thin', color='E2E8F0'),
    right=Side(style='thin', color='E2E8F0'),
    top=Side(style='thin', color='E2E8F0'),
    bottom=Side(style='thin', color='E2E8F0')
)

align_center = Alignment(horizontal="center", vertical="center")
align_left = Alignment(horizontal="left", vertical="center")
align_right = Alignment(horizontal="right", vertical="center")

# 1. 01_全行月度指標
ws1 = wb["01_全行月度指標"]
rows1 = [
    ["總交易金額", "amt_total", "總交易金額", 1286.4, "千元", 12.8, 2.1, 100.0, "核心指標；留空則自動累加一般+分期"],
    ["總交易金額", "amt_general", "一般交易金額", 1086.4, "千元", 10.5, 1.4, 84.4, "系統可自動計算佔比 (1086.4 / 1286.4)"],
    ["總交易金額", "amt_installment", "分期交易金額", 200.0, "千元", 27.3, 8.7, 15.6, "系統可自動計算佔比 (200.0 / 1286.4)"],
    ["總交易筆數", "cnt_total", "總交易筆數", 8425, "萬筆", 15.2, 1.7, 100.0, "核心指標；留空則自動累加一般+分期"],
    ["總交易筆數", "cnt_general", "一般交易筆數", 7750, "萬筆", 14.1, 1.2, 92.0, "系統可自動計算佔比 (7750 / 8425)"],
    ["總交易筆數", "cnt_installment", "分期交易筆數", 675, "萬筆", 29.8, 7.9, 8.0, "系統可自動計算佔比 (675 / 8425)"],
    ["活卡表現", "card_active", "有效卡數", 741, "張", 1.8, 0.3, 86.4, "YoY/MoM 為百分點(pp)；活卡率自動除算"],
    ["活卡表現", "card_issued", "流通卡數", 858, "張", None, None, 100.0, "母體總卡數；未動用卡數(117張)自動推導"],
    ["信用業務", "rev_balance", "循環信用餘額", 325.7, "千元", 6.7, 0.9, None, "次要業務指標 (月指標卡片右上方)"],
    ["信用業務", "cash_amount", "預借現金金額", 18.6, "千元", -3.4, -0.8, None, "次要業務指標 (月指標卡片右下方)"],
    ["信用業務", "cash_count", "預借現金筆數", 42.8, "萬筆", None, None, None, "顯示於預借現金增長率旁之筆數標籤"]
]
for r_idx, row in enumerate(rows1, start=5):
    for c_idx, val in enumerate(row, start=1):
        cell = ws1.cell(row=r_idx, column=c_idx, value=val)
        cell.font = bold_data_font if c_idx in [1, 3, 4] else data_font
        cell.border = thin_border
        if c_idx in [1, 2, 5]:
            cell.alignment = align_center
        elif c_idx in [4, 6, 7, 8]:
            cell.alignment = align_right
            if val is not None and isinstance(val, (int, float)):
                cell.number_format = "#,##0.0" if isinstance(val, float) else "#,##0"
        else:
            cell.alignment = align_left

# 2. 01_五大行簽帳市占
ws2 = wb["01_五大行簽帳市占"]
rows2 = [
    ["中國信託", 5980, 25.0, 11.2, "#003b5c", "否", "第一大行"],
    ["國泰世華", 5726, 23.9, 12.8, "#009e73", "是", "本行 (綠色高亮顯示)"],
    ["台北富邦", 4450, 18.6, 18.4, "#2563eb", "否", "Costco 卡主力"],
    ["玉山銀行", 4320, 18.0, 9.6, "#059669", "否", "第四大行"],
    ["台新銀行", 3480, 14.5, 11.8, "#ea580c", "否", "第五大行 (Richart/玫瑰卡主力)"]
]
for r_idx, row in enumerate(rows2, start=5):
    for c_idx, val in enumerate(row, start=1):
        cell = ws2.cell(row=r_idx, column=c_idx, value=val)
        cell.font = bold_data_font if c_idx in [1, 2] else data_font
        cell.border = thin_border
        if c_idx in [1, 5, 6]:
            cell.alignment = align_center
        elif c_idx in [2, 3, 4]:
            cell.alignment = align_right
            if isinstance(val, (int, float)):
                cell.number_format = "#,##0.0" if isinstance(val, float) else "#,##0"
        else:
            cell.alignment = align_left

# 3. 01_同業對標明細
ws3 = wb["01_同業對標明細"]
rows3 = [
    ['消費經營', '簽帳金額', '千元', 'up', 5726, 17.1, 6457, 25.9, 3894, 6.4, 4705, 18.4, 3480, 11.8],
    ['卡量經營', '有效卡數', '張', 'up', 741, 1.8, 812, 5.2, 598, 8.4, 624, 3.1, 482, 4.0],
    ['卡量經營', '流通卡數', '張', 'up', 858, 2.1, 980, 4.5, 762, 9.1, 745, 2.8, 620, 3.5],
    ['卡量經營', '活卡率', '%', 'up', 86.4, -0.3, 82.9, 0.5, 78.5, -0.5, 83.8, 0.2, 77.7, 0.4],
    ['信用業務', '循環信用餘額', '千元', 'up', 325.7, 6.7, 340.2, 7.8, 168.4, 4.2, 145.6, 3.8, 110.5, 2.9],
    ['信用業務', '預借現金金額', '千元', 'up', 18.6, -3.4, 28.5, 1.2, 14.2, -2.1, 16.8, -0.5, 12.4, -1.8],
    ['資產品質', '備抵呆帳提足率', '%', 'up', 287, 12.0, 276, 8.0, 238, 6.0, 252, 4.0, 245, 5.0],
    ['資產品質', '轉銷呆帳', '千元', 'down', 1.1, -0.2, 1.4, 0.1, 1.2, 0.1, 1.3, 0.2, 1.3, -0.1]
]
for r_idx, row in enumerate(rows3, start=5):
    for c_idx, val in enumerate(row, start=1):
        cell = ws3.cell(row=r_idx, column=c_idx, value=val)
        cell.font = bold_data_font if c_idx in [1, 2, 5] else data_font
        cell.border = thin_border
        if c_idx in [1, 3, 4]:
            cell.alignment = align_center
        elif c_idx >= 5:
            cell.alignment = align_right
            if isinstance(val, (int, float)):
                cell.number_format = "#,##0.0" if isinstance(val, float) else "#,##0"
        else:
            cell.alignment = align_left

wb.save("01_儀表板執行環境/dashboard_data.xlsx")
print("Successfully repopulated all baseline sheets in dashboard_data.xlsx!")
