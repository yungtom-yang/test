# -*- coding: utf-8 -*-
"""
Inject IDs and renderBlock02FromData into credit_card_full_dashboard.html.
Preserves all HTML/CSS layout, styling, and classes with zero alterations.
"""

with open("01_儀表板執行環境/credit_card_full_dashboard.html", "r", encoding="utf-8") as f:
    html = f.read()

# ==============================================================================
# 1. Update Cockpit Column 2 (00 戰情室)
# ==============================================================================
old_cockpit_col2 = """      <!-- COLUMN 2: 02 收單業務 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <span class="cockpit-badge c-badge-blue">02 收單業務</span>
        </div>

        <!-- 自行收單核心概況 (金額、筆數、特店總數) -->
        <div class="cockpit-subbox" style="cursor: pointer;" onclick="drillToAcqKpi()" title="點擊前往 02 收單業務 ➔ 自行收單核心概況">
          <!-- Card 1: 自行收單交易金額 -->
          <div class="c-kpi-split-card">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">自行收單交易金額</span>
              <div class="c-kpi-growth"><span class="number-positive">YoY +12.8%</span> <span class="number-positive">MoM +2.1%</span></div>
            </div>
            <div class="c-kpi-main-val">285.0 <em>億元</em></div>
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-phys" style="width: 65%;" title="實體收單: 65% (185.0 億)"></div>
                <div class="c-ratio-seg seg-onl" style="width: 35%;" title="線上 EPOS+PH: 35% (100.0 億)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys">(65%)</span></span>
                <strong class="r-val">185.0<em>億</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl">(35%)</span></span>
                <strong class="r-val">100.0<em>億</em></strong>
              </div>
            </div>
          </div>

          <!-- Card 2: 自行收單交易筆數 -->
          <div class="c-kpi-split-card" style="margin-top: 3px;">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">自行收單交易筆數</span>
              <div class="c-kpi-growth"><span class="number-positive">YoY +15.2%</span> <span class="number-positive">MoM +1.8%</span></div>
            </div>
            <div class="c-kpi-main-val">1,850 <em>萬筆</em></div>
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-phys" style="width: 70%;" title="實體收單: 70% (1,295 萬筆)"></div>
                <div class="c-ratio-seg seg-onl" style="width: 30%;" title="線上 EPOS+PH: 30% (555 萬筆)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys">(70%)</span></span>
                <strong class="r-val">1,295<em>萬筆</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl">(30%)</span></span>
                <strong class="r-val">555<em>萬筆</em></strong>
              </div>
            </div>
          </div>

          <!-- Card 3: 收單特店總數 -->
          <div class="c-kpi-split-card" style="margin-top: 3px;">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">收單特店總數</span>
              <div class="c-kpi-growth"><span class="number-positive">YoY +8.5%</span> <span class="c-hint">(活店率 83.0%)</span></div>
            </div>
            <div class="c-kpi-main-val">48,500 <em>家</em></div>
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-phys" style="width: 80%;" title="實體特店: 80% (38,800 家)"></div>
                <div class="c-ratio-seg seg-onl" style="width: 20%;" title="線上特店: 20% (9,700 家)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-phys"></span>實體特店 <span class="r-pct r-pct-phys">(80%)</span></span>
                <strong class="r-val">38,800<em>家</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-onl"></span>線上特店 <span class="r-pct r-pct-onl">(20%)</span></span>
                <strong class="r-val">9,700<em>家</em></strong>
              </div>
            </div>
          </div>
        </div>

        <!-- TWQR 業務發展概況 -->
        <div class="cockpit-subbox flex-grow" style="cursor: pointer;" onclick="drillToAcqTwqr()" title="點擊前往 02 收單業務 ➔ TWQR 業務分析專區">
          <div class="cockpit-box-title">
            <span>TWQR業務發展概況</span>
          </div>

          <!-- TWQR Top Block: 特店進件分析 -->
          <div class="twqr-cockpit-section">
            <div class="twqr-subhead">
              <b>特店進件分析</b>
            </div>
            <div class="c-twqr-stat-grid three-col">
              <div class="c-twqr-cell">
                <span>當月申請進件數</span>
                <strong>3,850 <em>件</em></strong>
              </div>
              <div class="c-twqr-cell">
                <span>當月新增特店家數</span>
                <strong>3,511 <em>家</em></strong>
                <b class="number-positive">審查通過率 91.2%</b>
              </div>
              <div class="c-twqr-cell">
                <span>累計特店家數</span>
                <strong>22,100 <em>家</em></strong>
                <b class="number-positive">MoM +5.8%</b>
              </div>
            </div>
          </div>

          <!-- TWQR Bottom Block: 交易狀態分析 -->
          <div class="twqr-cockpit-section" style="margin-top: 8px;">
            <div class="twqr-subhead">
              <b>交易狀態分析</b>
            </div>
            <div class="c-twqr-stat-grid three-col">
              <div class="c-twqr-cell">
                <span>當月交易金額</span>
                <strong>14.8 <em>億</em></strong>
                <b class="number-positive">MoM +18.5%</b>
              </div>
              <div class="c-twqr-cell">
                <span>當月交易筆數</span>
                <strong>185 <em>萬筆</em></strong>
                <b class="number-positive">MoM +16.2%</b>
              </div>
              <div class="c-twqr-cell">
                <span>動用特店率</span>
                <strong>68.2<em>%</em></strong>
                <b class="number-positive">實際產生交易</b>
              </div>
            </div>
          </div>
        </div>
      </div>"""

new_cockpit_col2 = """      <!-- COLUMN 2: 02 收單業務 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <span class="cockpit-badge c-badge-blue">02 收單業務</span>
        </div>

        <!-- 自行收單核心概況 (金額、筆數、特店總數) -->
        <div class="cockpit-subbox" style="cursor: pointer;" onclick="drillToAcqKpi()" title="點擊前往 02 收單業務 ➔ 自行收單核心概況">
          <!-- Card 1: 自行收單交易金額 -->
          <div class="c-kpi-split-card">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">自行收單交易金額</span>
              <div class="c-kpi-growth" id="c00-acq-amt-growth"><span class="number-positive">YoY +12.8%</span> <span class="number-positive">MoM +2.1%</span></div>
            </div>
            <div class="c-kpi-main-val" id="c00-acq-amt-val">285.0 <em>億元</em></div>
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-phys" id="c00-acq-amt-seg-phys" style="width: 65%;" title="實體收單: 65% (185.0 億)"></div>
                <div class="c-ratio-seg seg-onl" id="c00-acq-amt-seg-onl" style="width: 35%;" title="線上 EPOS+PH: 35% (100.0 億)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys" id="c00-acq-amt-phys-pct">(65%)</span></span>
                <strong class="r-val" id="c00-acq-amt-phys-val">185.0<em>億</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl" id="c00-acq-amt-onl-pct">(35%)</span></span>
                <strong class="r-val" id="c00-acq-amt-onl-val">100.0<em>億</em></strong>
              </div>
            </div>
          </div>

          <!-- Card 2: 自行收單交易筆數 -->
          <div class="c-kpi-split-card" style="margin-top: 3px;">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">自行收單交易筆數</span>
              <div class="c-kpi-growth" id="c00-acq-cnt-growth"><span class="number-positive">YoY +15.2%</span> <span class="number-positive">MoM +1.8%</span></div>
            </div>
            <div class="c-kpi-main-val" id="c00-acq-cnt-val">1,850 <em>萬筆</em></div>
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-phys" id="c00-acq-cnt-seg-phys" style="width: 70%;" title="實體收單: 70% (1,295 萬筆)"></div>
                <div class="c-ratio-seg seg-onl" id="c00-acq-cnt-seg-onl" style="width: 30%;" title="線上 EPOS+PH: 30% (555 萬筆)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys" id="c00-acq-cnt-phys-pct">(70%)</span></span>
                <strong class="r-val" id="c00-acq-cnt-phys-val">1,295<em>萬筆</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl" id="c00-acq-cnt-onl-pct">(30%)</span></span>
                <strong class="r-val" id="c00-acq-cnt-onl-val">555<em>萬筆</em></strong>
              </div>
            </div>
          </div>

          <!-- Card 3: 收單特店總數 -->
          <div class="c-kpi-split-card" style="margin-top: 3px;">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">收單特店總數</span>
              <div class="c-kpi-growth" id="c00-acq-mcht-growth"><span class="number-positive">YoY +8.5%</span> <span class="c-hint" id="c00-acq-mcht-hint">(活店率 83.0%)</span></div>
            </div>
            <div class="c-kpi-main-val" id="c00-acq-mcht-val">48,500 <em>家</em></div>
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-phys" id="c00-acq-mcht-seg-phys" style="width: 80%;" title="實體特店: 80% (38,800 家)"></div>
                <div class="c-ratio-seg seg-onl" id="c00-acq-mcht-seg-onl" style="width: 20%;" title="線上特店: 20% (9,700 家)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-phys"></span>實體特店 <span class="r-pct r-pct-phys" id="c00-acq-mcht-phys-pct">(80%)</span></span>
                <strong class="r-val" id="c00-acq-mcht-phys-val">38,800<em>家</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-onl"></span>線上特店 <span class="r-pct r-pct-onl" id="c00-acq-mcht-onl-pct">(20%)</span></span>
                <strong class="r-val" id="c00-acq-mcht-onl-val">9,700<em>家</em></strong>
              </div>
            </div>
          </div>
        </div>

        <!-- TWQR 業務發展概況 -->
        <div class="cockpit-subbox flex-grow" style="cursor: pointer;" onclick="drillToAcqTwqr()" title="點擊前往 02 收單業務 ➔ TWQR 業務分析專區">
          <div class="cockpit-box-title">
            <span>TWQR業務發展概況</span>
          </div>

          <!-- TWQR Top Block: 特店進件分析 -->
          <div class="twqr-cockpit-section">
            <div class="twqr-subhead">
              <b>特店進件分析</b>
            </div>
            <div class="c-twqr-stat-grid three-col">
              <div class="c-twqr-cell">
                <span>當月申請進件數</span>
                <strong id="c00-twqr-apply-cnt">3,850 <em>件</em></strong>
              </div>
              <div class="c-twqr-cell">
                <span>當月新增特店家數</span>
                <strong id="c00-twqr-new-mcht">1,210 <em>家</em></strong>
                <b class="number-positive" id="c00-twqr-pass-rate">審查通過率 91.2%</b>
              </div>
              <div class="c-twqr-cell">
                <span>累計特店家數</span>
                <strong id="c00-twqr-total-mcht">22,100 <em>家</em></strong>
                <b class="number-positive" id="c00-twqr-total-mom">MoM +5.8%</b>
              </div>
            </div>
          </div>

          <!-- TWQR Bottom Block: 交易狀態分析 -->
          <div class="twqr-cockpit-section" style="margin-top: 8px;">
            <div class="twqr-subhead">
              <b>交易狀態分析</b>
            </div>
            <div class="c-twqr-stat-grid three-col">
              <div class="c-twqr-cell">
                <span>當月交易金額</span>
                <strong id="c00-twqr-tx-amt">12.8 <em>億</em></strong>
                <b class="number-positive" id="c00-twqr-amt-mom">MoM +18.5%</b>
              </div>
              <div class="c-twqr-cell">
                <span>當月交易筆數</span>
                <strong id="c00-twqr-tx-cnt">185 <em>萬筆</em></strong>
                <b class="number-positive" id="c00-twqr-cnt-mom">MoM +22.1%</b>
              </div>
              <div class="c-twqr-cell">
                <span>動用特店率</span>
                <strong id="c00-twqr-active-rate">78.5<em>%</em></strong>
                <b class="number-positive">實際產生交易</b>
              </div>
            </div>
          </div>
        </div>
      </div>"""

assert old_cockpit_col2 in html, "Failed to match old_cockpit_col2"
html = html.replace(old_cockpit_col2, new_cockpit_col2)

# ==============================================================================
# 2. Update Section 02 Primary & Secondary KPIs (2A)
# ==============================================================================
old_sec02_kpis = """      <!-- 2A Primary (3 Cards formatted exactly like Block 01) -->
      <div class="monthly-kpi-layout-3" id="acq-kpis">

        <article class="monthly-kpi monthly-primary">
          <div class="monthly-kpi-title">自行收單交易金額</div>
          <div class="monthly-kpi-value">285.0<em>億元</em></div>
          <div class="monthly-growth">
            <span class="number-positive"><b>YoY</b>+12.8%</span><span class="number-positive"><b>MoM</b>+2.1%</span>
          </div>
          <div class="monthly-ratio-box">
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-phys" style="width: 65.0%;" title="實體收單: 65.0% (185.0 億)"></div>
                <div class="c-ratio-seg seg-onl" style="width: 35.0%;" title="線上 EPOS+PH: 35.0% (100.0 億)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys">(65.0%)</span></span>
                <strong class="r-val">185.0<em>億</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl">(35.0%)</span></span>
                <strong class="r-val">100.0<em>億</em></strong>
              </div>
            </div>
          </div>
        </article>
        <article class="monthly-kpi monthly-primary">
          <div class="monthly-kpi-title">自行收單交易筆數</div>
          <div class="monthly-kpi-value">1,850<em>萬筆</em></div>
          <div class="monthly-growth">
            <span class="number-positive"><b>YoY</b>+15.2%</span><span class="number-positive"><b>MoM</b>+1.8%</span>
          </div>
          <div class="monthly-ratio-box">
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-phys" style="width: 70.0%;" title="實體收單: 70.0% (1,295 萬筆)"></div>
                <div class="c-ratio-seg seg-onl" style="width: 30.0%;" title="線上 EPOS+PH: 30.0% (555 萬筆)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys">(70.0%)</span></span>
                <strong class="r-val">1,295<em>萬筆</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl">(30.0%)</span></span>
                <strong class="r-val">555<em>萬筆</em></strong>
              </div>
            </div>
          </div>
        </article>
        <article class="monthly-kpi monthly-primary">
          <div class="monthly-kpi-title">收單特店總數</div>
          <div class="monthly-kpi-value">48,500<em>家</em></div>
          <div class="monthly-growth">
            <span class="number-positive"><b>YoY</b>+8.5%</span><span class="number-positive"><b>MoM</b>+0.7%</span>
          </div>
          <div class="monthly-ratio-box">
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-phys" style="width: 80.0%;" title="實體特店: 80.0% (38,800 家)"></div>
                <div class="c-ratio-seg seg-onl" style="width: 20.0%;" title="線上特店: 20.0% (9,700 家)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-phys"></span>實體特店 <span class="r-pct r-pct-phys">(80.0%)</span></span>
                <strong class="r-val">38,800<em>家</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-onl"></span>線上特店 <span class="r-pct r-pct-onl">(20.0%)</span></span>
                <strong class="r-val">9,700<em>家</em></strong>
              </div>
            </div>
          </div>
        </article>
      </div>

      <!-- 2A Secondary (4 Cards formatted exactly like Block 01) -->
      <div class="monthly-kpi-layout-4">

        <article class="monthly-kpi monthly-secondary" style="min-height: 158px;">
          <div class="monthly-kpi-title">自行收單滲透率</div>
          <div class="monthly-kpi-value">24.5%</div>
          <div class="monthly-growth">
            <span class="number-positive"><b>YoY</b>+1.8pp</span><span class="number-positive"><b>MoM</b>+0.3pp</span>
          </div>
          <span class="secondary-note" title="跨售動能強勁" style="bottom: 9px; right: 18px;">自行收單一般交易 ÷ 全行一般交易</span>
        </article>
        <article class="monthly-kpi monthly-secondary" style="min-height: 158px;">
          <div class="monthly-kpi-title">活躍自行特店數</div>
          <div class="monthly-kpi-value">40,250<em>家</em></div>
          <div class="monthly-growth">
            <span class="number-positive"><b>YoY</b>+6.2%</span><span class="number-positive"><b>活店率</b>83.0%</span>
          </div>
          <span class="secondary-note" title="動用率維持 83% 以上高檔" style="bottom: 9px; right: 18px;">當月有實質請款交易之特店</span>
        </article>
        <article class="monthly-kpi monthly-secondary" style="min-height: 158px;">
          <div class="monthly-kpi-title">電子對帳單覆蓋率</div>
          <div class="monthly-kpi-value">92.4%</div>
        </article>
        <article class="monthly-kpi monthly-secondary" style="min-height: 158px;">
          <div class="monthly-kpi-title">收單手續費收入</div>
          <div class="monthly-kpi-value">4.52<em>億元</em></div>
          <div class="monthly-growth">
            <span class="number-positive"><b>YoY</b>+11.5%</span>
          </div>
        </article>
      </div>"""

new_sec02_kpis = """      <!-- 2A Primary (3 Cards formatted exactly like Block 01) -->
      <div class="monthly-kpi-layout-3" id="acq-kpis">

        <article class="monthly-kpi monthly-primary">
          <div class="monthly-kpi-title">自行收單交易金額</div>
          <div class="monthly-kpi-value" id="b02-amt-val">285.0<em>億元</em></div>
          <div class="monthly-growth" id="b02-amt-growth">
            <span class="number-positive"><b>YoY</b>+12.8%</span><span class="number-positive"><b>MoM</b>+2.1%</span>
          </div>
          <div class="monthly-ratio-box">
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-phys" id="b02-amt-seg-phys" style="width: 65.0%;" title="實體收單: 65.0% (185.0 億)"></div>
                <div class="c-ratio-seg seg-onl" id="b02-amt-seg-onl" style="width: 35.0%;" title="線上 EPOS+PH: 35.0% (100.0 億)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys" id="b02-amt-phys-pct">(65.0%)</span></span>
                <strong class="r-val" id="b02-amt-phys-val">185.0<em>億</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl" id="b02-amt-onl-pct">(35.0%)</span></span>
                <strong class="r-val" id="b02-amt-onl-val">100.0<em>億</em></strong>
              </div>
            </div>
          </div>
        </article>
        <article class="monthly-kpi monthly-primary">
          <div class="monthly-kpi-title">自行收單交易筆數</div>
          <div class="monthly-kpi-value" id="b02-cnt-val">1,850<em>萬筆</em></div>
          <div class="monthly-growth" id="b02-cnt-growth">
            <span class="number-positive"><b>YoY</b>+15.2%</span><span class="number-positive"><b>MoM</b>+1.8%</span>
          </div>
          <div class="monthly-ratio-box">
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-phys" id="b02-cnt-seg-phys" style="width: 70.0%;" title="實體收單: 70.0% (1,295 萬筆)"></div>
                <div class="c-ratio-seg seg-onl" id="b02-cnt-seg-onl" style="width: 30.0%;" title="線上 EPOS+PH: 30.0% (555 萬筆)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys" id="b02-cnt-phys-pct">(70.0%)</span></span>
                <strong class="r-val" id="b02-cnt-phys-val">1,295<em>萬筆</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl" id="b02-cnt-onl-pct">(30.0%)</span></span>
                <strong class="r-val" id="b02-cnt-onl-val">555<em>萬筆</em></strong>
              </div>
            </div>
          </div>
        </article>
        <article class="monthly-kpi monthly-primary">
          <div class="monthly-kpi-title">收單特店總數</div>
          <div class="monthly-kpi-value" id="b02-mcht-val">48,500<em>家</em></div>
          <div class="monthly-growth" id="b02-mcht-growth">
            <span class="number-positive"><b>YoY</b>+8.5%</span><span class="number-positive"><b>MoM</b>+0.7%</span>
          </div>
          <div class="monthly-ratio-box">
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-phys" id="b02-mcht-seg-phys" style="width: 80.0%;" title="實體特店: 80.0% (38,800 家)"></div>
                <div class="c-ratio-seg seg-onl" id="b02-mcht-seg-onl" style="width: 20.0%;" title="線上特店: 20.0% (9,700 家)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-phys"></span>實體特店 <span class="r-pct r-pct-phys" id="b02-mcht-phys-pct">(80.0%)</span></span>
                <strong class="r-val" id="b02-mcht-phys-val">38,800<em>家</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-onl"></span>線上特店 <span class="r-pct r-pct-onl" id="b02-mcht-onl-pct">(20.0%)</span></span>
                <strong class="r-val" id="b02-mcht-onl-val">9,700<em>家</em></strong>
              </div>
            </div>
          </div>
        </article>
      </div>

      <!-- 2A Secondary (4 Cards formatted exactly like Block 01) -->
      <div class="monthly-kpi-layout-4">

        <article class="monthly-kpi monthly-secondary" style="min-height: 158px;">
          <div class="monthly-kpi-title">自行收單滲透率</div>
          <div class="monthly-kpi-value" id="b02-penetration-val">24.5%</div>
          <div class="monthly-growth" id="b02-penetration-growth">
            <span class="number-positive"><b>YoY</b>+1.8pp</span><span class="number-positive"><b>MoM</b>+0.3pp</span>
          </div>
          <span class="secondary-note" title="跨售動能強勁" style="bottom: 9px; right: 18px;">自行收單一般交易 ÷ 全行一般交易</span>
        </article>
        <article class="monthly-kpi monthly-secondary" style="min-height: 158px;">
          <div class="monthly-kpi-title">活躍自行特店數</div>
          <div class="monthly-kpi-value" id="b02-active-mcht-val">40,250<em>家</em></div>
          <div class="monthly-growth" id="b02-active-mcht-growth">
            <span class="number-positive"><b>YoY</b>+6.2%</span><span class="number-positive"><b>活店率</b>83.0%</span>
          </div>
          <span class="secondary-note" title="動用率維持 83% 以上高檔" style="bottom: 9px; right: 18px;">當月有實質請款交易之特店</span>
        </article>
        <article class="monthly-kpi monthly-secondary" style="min-height: 158px;">
          <div class="monthly-kpi-title">電子對帳單覆蓋率</div>
          <div class="monthly-kpi-value" id="b02-estatement-val">92.4%</div>
        </article>
        <article class="monthly-kpi monthly-secondary" style="min-height: 158px;">
          <div class="monthly-kpi-title">收單手續費收入</div>
          <div class="monthly-kpi-value" id="b02-fee-val">4.52<em>億元</em></div>
          <div class="monthly-growth" id="b02-fee-growth">
            <span class="number-positive"><b>YoY</b>+11.5%</span>
          </div>
        </article>
      </div>"""

assert old_sec02_kpis in html, "Failed to match old_sec02_kpis"
html = html.replace(old_sec02_kpis, new_sec02_kpis)

# ==============================================================================
# 3. Update 2B TAB 0 (線上交易分析)
# ==============================================================================
old_tab0 = """        <!-- 2B Tab 0: 線上交易分析 -->
        <div id="acq-tab-0" class="tab-content active">
          <div class="structure-bar">
            <div style="background:#003b5c; width:58.3%;" title="EPOS - 雲端 (58.3%)">
              <span>EPOS - 雲端 (58.3%)</span>
            </div>
            <div style="background:#3b82f6; width:26.1%;" title="EPOS - 地端 (26.1%)">
              <span>EPOS - 地端 (26.1%)</span>
            </div>
            <div style="background:#ea580c; width:15.6%;" title="Payment Hub掃碼交易 (15.6%)">
              <span>Payment Hub掃碼 (15.6%)</span>
            </div>
          </div>

          <div class="compact-table" style="margin-bottom:14px;">
            <table>
              <thead>
                <tr>
                  <th>交易類型</th>
                  <th style="text-align:right;">交易金額</th>
                  <th style="text-align:right;">交易金額YOY</th>
                  <th style="text-align:right;">交易筆數</th>
                  <th style="text-align:right;">交易筆數YOY</th>
                  <th style="text-align:right;">平均客單價</th>
                  <th style="text-align:right;">平均客單價YOY</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><strong>EPOS - 雲端</strong></td>
                  <td style="text-align:right;"><strong style="color:var(--blue-dark); font-size:15.5px;">69.1 億元</strong></td>
                  <td style="text-align:right;" class="number-positive"><strong>+32.5%</strong></td>
                  <td style="text-align:right;">345 萬筆</td>
                  <td style="text-align:right;" class="number-positive"><strong>+35.1%</strong></td>
                  <td style="text-align:right;">2,002 元</td>
                  <td style="text-align:right;" class="number-negative"><strong>-1.9%</strong></td>
                </tr>
                <tr>
                  <td><strong>EPOS - 地端</strong></td>
                  <td style="text-align:right;"><strong style="color:var(--blue-dark); font-size:15.5px;">30.9 億元</strong></td>
                  <td style="text-align:right;" class="number-negative"><strong>-4.2%</strong></td>
                  <td style="text-align:right;">210 萬筆</td>
                  <td style="text-align:right;" class="number-negative"><strong>-1.8%</strong></td>
                  <td style="text-align:right;">1,471 元</td>
                  <td style="text-align:right;" class="number-negative"><strong>-2.5%</strong></td>
                </tr>
                <tr>
                  <td><strong>Payment Hub掃碼交易</strong></td>
                  <td style="text-align:right;"><strong style="color:var(--blue-dark); font-size:15.5px;">18.5 億元</strong></td>
                  <td style="text-align:right;" class="number-positive"><strong>+38.2%</strong></td>
                  <td style="text-align:right;">240 萬筆</td>
                  <td style="text-align:right;" class="number-positive"><strong>+42.0%</strong></td>
                  <td style="text-align:right;">770 元</td>
                  <td style="text-align:right;" class="number-negative"><strong>-2.8%</strong></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>"""

new_tab0 = """        <!-- 2B Tab 0: 線上交易分析 -->
        <div id="acq-tab-0" class="tab-content active">
          <div class="structure-bar" id="b02-online-struct-bar">
            <div style="background:#003b5c; width:58.3%;" title="EPOS - 雲端 (58.3%)">
              <span>EPOS - 雲端 (58.3%)</span>
            </div>
            <div style="background:#3b82f6; width:26.1%;" title="EPOS - 地端 (26.1%)">
              <span>EPOS - 地端 (26.1%)</span>
            </div>
            <div style="background:#ea580c; width:15.6%;" title="Payment Hub掃碼交易 (15.6%)">
              <span>Payment Hub掃碼 (15.6%)</span>
            </div>
          </div>

          <div class="compact-table" style="margin-bottom:14px;">
            <table>
              <thead>
                <tr>
                  <th>交易類型</th>
                  <th style="text-align:right;">交易金額</th>
                  <th style="text-align:right;">交易金額YOY</th>
                  <th style="text-align:right;">交易筆數</th>
                  <th style="text-align:right;">交易筆數YOY</th>
                  <th style="text-align:right;">平均客單價</th>
                  <th style="text-align:right;">平均客單價YOY</th>
                </tr>
              </thead>
              <tbody id="b02-online-table-body">
                <tr>
                  <td><strong>EPOS - 雲端</strong></td>
                  <td style="text-align:right;"><strong style="color:var(--blue-dark); font-size:15.5px;">69.1 億元</strong></td>
                  <td style="text-align:right;" class="number-positive"><strong>+32.5%</strong></td>
                  <td style="text-align:right;">345 萬筆</td>
                  <td style="text-align:right;" class="number-positive"><strong>+35.1%</strong></td>
                  <td style="text-align:right;">2,002 元</td>
                  <td style="text-align:right;" class="number-negative"><strong>-1.9%</strong></td>
                </tr>
                <tr>
                  <td><strong>EPOS - 地端</strong></td>
                  <td style="text-align:right;"><strong style="color:var(--blue-dark); font-size:15.5px;">30.9 億元</strong></td>
                  <td style="text-align:right;" class="number-negative"><strong>-4.2%</strong></td>
                  <td style="text-align:right;">210 萬筆</td>
                  <td style="text-align:right;" class="number-negative"><strong>-1.8%</strong></td>
                  <td style="text-align:right;">1,471 元</td>
                  <td style="text-align:right;" class="number-negative"><strong>-2.5%</strong></td>
                </tr>
                <tr>
                  <td><strong>Payment Hub掃碼交易</strong></td>
                  <td style="text-align:right;"><strong style="color:var(--blue-dark); font-size:15.5px;">18.5 億元</strong></td>
                  <td style="text-align:right;" class="number-positive"><strong>+38.2%</strong></td>
                  <td style="text-align:right;">240 萬筆</td>
                  <td style="text-align:right;" class="number-positive"><strong>+42.0%</strong></td>
                  <td style="text-align:right;">770 元</td>
                  <td style="text-align:right;" class="number-negative"><strong>-2.8%</strong></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>"""

assert old_tab0 in html, "Failed to match old_tab0"
html = html.replace(old_tab0, new_tab0)

# ==============================================================================
# 4. Update 2B TAB 1 (特店集中度與 2x2 矩陣)
# ==============================================================================
old_tab1_top = """                <!-- Top 10 Macro Concentration Highlight Bar -->
                <div style="background:#f4f9f7; border:1px solid #d4eae3; border-left:4px solid var(--blue-dark); border-radius:6px; padding:10px 14px; margin-bottom:14px; display:flex; justify-content:space-between; align-items:center;">
                  <div style="display:flex; align-items:center; gap:8px;">
                    <span style="font-size:13.5px; font-weight:800; color:var(--ink);">Top 10 特店請款佔比</span>
                    <small style="color:#64748b; font-size:12px; font-weight:600;">(全行大盤集中度)</small>
                  </div>
                  <div style="display:flex; align-items:baseline; gap:8px;">
                    <strong style="font-size:21px; font-weight:900; color:var(--blue-dark); line-height:1;">48.2%</strong>
                    <span class="number-positive" style="font-size:12.5px; font-weight:800;">YoY +1.5pp</span>
                  </div>
                </div>

                <div class="merchant-progress-list" style="display:flex; flex-direction:column; gap:13px;">"""

new_tab1_top = """                <!-- Top 10 Macro Concentration Highlight Bar -->
                <div style="background:#f4f9f7; border:1px solid #d4eae3; border-left:4px solid var(--blue-dark); border-radius:6px; padding:10px 14px; margin-bottom:14px; display:flex; justify-content:space-between; align-items:center;">
                  <div style="display:flex; align-items:center; gap:8px;">
                    <span style="font-size:13.5px; font-weight:800; color:var(--ink);">Top 10 特店請款佔比</span>
                    <small style="color:#64748b; font-size:12px; font-weight:600;">(全行大盤集中度)</small>
                  </div>
                  <div style="display:flex; align-items:baseline; gap:8px;">
                    <strong style="font-size:21px; font-weight:900; color:var(--blue-dark); line-height:1;" id="b02-top10-share">48.2%</strong>
                    <span class="number-positive" style="font-size:12.5px; font-weight:800;" id="b02-top10-yoy">YoY +1.5pp</span>
                  </div>
                </div>

                <div class="merchant-progress-list" id="b02-top-merchants-list" style="display:flex; flex-direction:column; gap:13px;">"""

assert old_tab1_top in html, "Failed to match old_tab1_top"
html = html.replace(old_tab1_top, new_tab1_top)

# Update matrix reps
old_matrix_reps = """                    <div style="margin-top:8px;">
                      <strong style="color:var(--ink); font-size:13.5px; font-weight:800;">代表：特店 E 等</strong>
                    </div>
                  </div>

                  <!-- Quadrant 1: 核心成長區 (Top-Right) -->
                  <div style="grid-column:3; grid-row:1; background:#ecfdf5; border:1px solid #86efac; border-radius:8px; padding:12px 14px; display:flex; flex-direction:column; justify-content:space-between;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                      <b style="color:#047857; font-size:15px; font-weight:900;">核心成長區 ⭐</b>
                      <span style="font-size:11px; font-weight:800; background:#d1fae5; color:#065f46; padding:2px 7px; border-radius:4px;">高成長 × 高佔比</span>
                    </div>
                    <div style="margin-top:8px;">
                      <strong style="color:var(--ink); font-size:13.5px; font-weight:800;">代表：特店 A、特店 B</strong>
                    </div>
                  </div>

                  <!-- Quadrant 3: 一般維護區 (Bottom-Left) -->
                  <div style="grid-column:2; grid-row:2; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:12px 14px; display:flex; flex-direction:column; justify-content:space-between;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                      <b style="color:#475569; font-size:15px; font-weight:900;">一般維護區</b>
                      <span style="font-size:11px; font-weight:800; background:#f1f5f9; color:#475569; padding:2px 7px; border-radius:4px;">低成長 × 低佔比</span>
                    </div>
                    <div style="margin-top:8px;">
                      <strong style="color:var(--ink); font-size:13.5px; font-weight:800;">代表：長尾特店群</strong>
                    </div>
                  </div>

                  <!-- Quadrant 4: 重點維繫區 (Bottom-Right) -->
                  <div style="grid-column:3; grid-row:2; background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:12px 14px; display:flex; flex-direction:column; justify-content:space-between;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                      <b style="color:#b45309; font-size:15px; font-weight:900;">重點維繫區 ⚠</b>
                      <span style="font-size:11px; font-weight:800; background:#fef3c7; color:#92400e; padding:2px 7px; border-radius:4px;">低成長 × 高佔比</span>
                    </div>
                    <div style="margin-top:8px;">
                      <strong style="color:var(--ink); font-size:13.5px; font-weight:800;">代表：特店 C、特店 D</strong>
                    </div>"""

new_matrix_reps = """                    <div style="margin-top:8px;">
                      <strong style="color:var(--ink); font-size:13.5px; font-weight:800;" id="b02-rep-potential">代表：特店 E 等</strong>
                    </div>
                  </div>

                  <!-- Quadrant 1: 核心成長區 (Top-Right) -->
                  <div style="grid-column:3; grid-row:1; background:#ecfdf5; border:1px solid #86efac; border-radius:8px; padding:12px 14px; display:flex; flex-direction:column; justify-content:space-between;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                      <b style="color:#047857; font-size:15px; font-weight:900;">核心成長區 ⭐</b>
                      <span style="font-size:11px; font-weight:800; background:#d1fae5; color:#065f46; padding:2px 7px; border-radius:4px;">高成長 × 高佔比</span>
                    </div>
                    <div style="margin-top:8px;">
                      <strong style="color:var(--ink); font-size:13.5px; font-weight:800;" id="b02-rep-core">代表：特店 A、特店 B</strong>
                    </div>
                  </div>

                  <!-- Quadrant 3: 一般維護區 (Bottom-Left) -->
                  <div style="grid-column:2; grid-row:2; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:12px 14px; display:flex; flex-direction:column; justify-content:space-between;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                      <b style="color:#475569; font-size:15px; font-weight:900;">一般維護區</b>
                      <span style="font-size:11px; font-weight:800; background:#f1f5f9; color:#475569; padding:2px 7px; border-radius:4px;">低成長 × 低佔比</span>
                    </div>
                    <div style="margin-top:8px;">
                      <strong style="color:var(--ink); font-size:13.5px; font-weight:800;" id="b02-rep-general">代表：長尾特店群</strong>
                    </div>
                  </div>

                  <!-- Quadrant 4: 重點維繫區 (Bottom-Right) -->
                  <div style="grid-column:3; grid-row:2; background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:12px 14px; display:flex; flex-direction:column; justify-content:space-between;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                      <b style="color:#b45309; font-size:15px; font-weight:900;">重點維繫區 ⚠</b>
                      <span style="font-size:11px; font-weight:800; background:#fef3c7; color:#92400e; padding:2px 7px; border-radius:4px;">低成長 × 高佔比</span>
                    </div>
                    <div style="margin-top:8px;">
                      <strong style="color:var(--ink); font-size:13.5px; font-weight:800;" id="b02-rep-maintain">代表：特店 C、特店 D</strong>
                    </div>"""

assert old_matrix_reps in html, "Failed to match old_matrix_reps"
html = html.replace(old_matrix_reps, new_matrix_reps)

# ==============================================================================
# 5. Update 2B TAB 2 (蝴蝶圖容器)
# ==============================================================================
old_butterfly_list = '<div class="acq-butterfly-list">'
new_butterfly_list = '<div class="acq-butterfly-list" id="b02-butterfly-list">'
assert old_butterfly_list in html, "Failed to match old_butterfly_list"
html = html.replace(old_butterfly_list, new_butterfly_list, 1)

# ==============================================================================
# 6. Update TWQR Panel
# ==============================================================================
old_twqr_panel = """      <!-- TWQR 業務分析專區 (Panel Directly Leads, Zero Clutter) -->
      <article class="panel ytd-panel" id="acq-twqr-panel" style="margin-top: 14px;">
        <div class="ytd-heading">
          <div>
            <h3 style="margin:0;">TWQR 業務推展與交易動能</h3>
          </div>
        </div>
        <div class="twqr-grid" style="display:grid; grid-template-columns: 3fr 5fr; gap:14px; margin-top:14px;">
          <section style="padding:14px; background:#fff; border:1px solid #d8e6e1; border-radius:10px;">
            <h4 style="margin:0 0 12px; color:var(--blue-dark); font-size:15px; font-weight:900;">特店進件分析</h4>
            <div class="twqr-stats" style="display:grid; grid-template-columns: repeat(3, 1fr); gap:8px;">
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月申請進件數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;">3,850 件</strong>
                <b class="" style="font-size:11.5px; font-weight:800; color:#64748b;">審查通過率 91.2%</b>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月新增特店家數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;">1,210 家</strong>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">累計特店家數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;">22,100 家</strong>
                <b class="is-good" style="font-size:11.5px; font-weight:800; color:#047857;">MoM +5.8%</b>
              </div>
            </div>
          </section>
          <section style="padding:14px; background:#fff; border:1px solid #d8e6e1; border-radius:10px;">
            <h4 style="margin:0 0 12px; color:var(--blue-dark); font-size:15px; font-weight:900;">交易狀態分析</h4>
            <div class="twqr-stats four" style="display:grid; grid-template-columns: repeat(5, 1fr); gap:8px;">
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月交易金額</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;">12.8 億</strong>
                <b class="is-good" style="font-size:11.5px; font-weight:800; color:#047857;">MoM +18.5%</b>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月交易筆數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;">185 萬筆</strong>
                <b class="is-good" style="font-size:11.5px; font-weight:800; color:#047857;">MoM +22.1%</b>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">平均每筆客單</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;">692 元</strong>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">店均交易金額</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;">5.79 萬元</strong>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">動用特店比率</span>
                <strong style="font-size:22px; font-weight:800; color:var(--blue-dark); margin:4px 0; display:block;">78.5%</strong>
              </div>
            </div>
          </section>
        </div>"""

new_twqr_panel = """      <!-- TWQR 業務分析專區 (Panel Directly Leads, Zero Clutter) -->
      <article class="panel ytd-panel" id="acq-twqr-panel" style="margin-top: 14px;">
        <div class="ytd-heading">
          <div>
            <h3 style="margin:0;">TWQR 業務推展與交易動能</h3>
          </div>
        </div>
        <div class="twqr-grid" style="display:grid; grid-template-columns: 3fr 5fr; gap:14px; margin-top:14px;">
          <section style="padding:14px; background:#fff; border:1px solid #d8e6e1; border-radius:10px;">
            <h4 style="margin:0 0 12px; color:var(--blue-dark); font-size:15px; font-weight:900;">特店進件分析</h4>
            <div class="twqr-stats" style="display:grid; grid-template-columns: repeat(3, 1fr); gap:8px;">
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月申請進件數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-apply-cnt">3,850 件</strong>
                <b class="" style="font-size:11.5px; font-weight:800; color:#64748b;" id="b02-twqr-pass-rate">審查通過率 91.2%</b>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月新增特店家數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-new-mcht">1,210 家</strong>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">累計特店家數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-total-mcht">22,100 家</strong>
                <b class="is-good" style="font-size:11.5px; font-weight:800; color:#047857;" id="b02-twqr-total-mom">MoM +5.8%</b>
              </div>
            </div>
          </section>
          <section style="padding:14px; background:#fff; border:1px solid #d8e6e1; border-radius:10px;">
            <h4 style="margin:0 0 12px; color:var(--blue-dark); font-size:15px; font-weight:900;">交易狀態分析</h4>
            <div class="twqr-stats four" style="display:grid; grid-template-columns: repeat(5, 1fr); gap:8px;">
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月交易金額</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-tx-amt">12.8 億</strong>
                <b class="is-good" style="font-size:11.5px; font-weight:800; color:#047857;" id="b02-twqr-amt-mom">MoM +18.5%</b>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月交易筆數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-tx-cnt">185 萬筆</strong>
                <b class="is-good" style="font-size:11.5px; font-weight:800; color:#047857;" id="b02-twqr-cnt-mom">MoM +22.1%</b>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">平均每筆客單</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-avg-ticket">692 元</strong>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">店均交易金額</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-mcht-avg-amt">5.79 萬元</strong>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">動用特店比率</span>
                <strong style="font-size:22px; font-weight:800; color:var(--blue-dark); margin:4px 0; display:block;" id="b02-twqr-active-rate">78.5%</strong>
              </div>
            </div>
          </section>
        </div>"""

assert old_twqr_panel in html, "Failed to match old_twqr_panel"
html = html.replace(old_twqr_panel, new_twqr_panel)

# ==============================================================================
# 7. Add renderBlock02FromData function & hook to DOMContentLoaded
# ==============================================================================
render_b02_code = """
  // ============================================================================
  // 動態渲染 02 收單業務 (Block 02) 數據引擎
  // ============================================================================
  function renderBlock02FromData(data) {
    if (!data || !data.block02) return;
    const b2 = data.block02;
    const kpi = b2.monthly_kpis || {};
    const twqr = b2.twqr || {};

    const isValidNum = (v) => v !== null && v !== undefined && !isNaN(Number(v));
    const fmtNum = (v, d = 1) => isValidNum(v) ? Number(v).toLocaleString(undefined, { minimumFractionDigits: d, maximumFractionDigits: d }) : "-";
    const fmtSign = (v, s = "%") => {
      if (!isValidNum(v)) return "-";
      const n = Number(v);
      return `${n > 0 ? "+" : ""}${n.toFixed(1)}${s}`;
    };
    const semCls = (v) => {
      if (!isValidNum(v)) return "number-neutral";
      return Number(v) >= 0 ? "number-positive" : "number-negative";
    };

    // 1. 自行收單交易金額
    const amt = kpi.acq_amt || {};
    const amtPhys = amt.physical || {};
    const amtOnl = amt.online || {};

    const amtValHtml = isValidNum(amt.total) ? `${fmtNum(amt.total, 1)}<em>${amt.unit || '億元'}</em>` : `-`;
    const amtGrowthHtml = `
      <span class="${semCls(amt.yoy)}"><b>YoY</b>${fmtSign(amt.yoy)}</span>
      <span class="${semCls(amt.mom)}"><b>MoM</b>${fmtSign(amt.mom)}</span>
    `;

    // Cockpit Col 2: Card 1
    const c00AmtVal = document.getElementById("c00-acq-amt-val");
    if (c00AmtVal) c00AmtVal.innerHTML = isValidNum(amt.total) ? `${fmtNum(amt.total, 1)} <em>${amt.unit || '億元'}</em>` : `-`;
    const c00AmtGrowth = document.getElementById("c00-acq-amt-growth");
    if (c00AmtGrowth) {
      c00AmtGrowth.innerHTML = `
        <span class="${semCls(amt.yoy)}">YoY ${fmtSign(amt.yoy)}</span>
        <span class="${semCls(amt.mom)}">MoM ${fmtSign(amt.mom)}</span>
      `;
    }
    const c00AmtSegPhys = document.getElementById("c00-acq-amt-seg-phys");
    if (c00AmtSegPhys) {
      c00AmtSegPhys.style.width = isValidNum(amtPhys.share) ? `${amtPhys.share}%` : `0%`;
      c00AmtSegPhys.title = isValidNum(amtPhys.share) ? `實體收單: ${amtPhys.share}% (${fmtNum(amtPhys.amount, 1)} 億)` : `實體收單: -`;
    }
    const c00AmtSegOnl = document.getElementById("c00-acq-amt-seg-onl");
    if (c00AmtSegOnl) {
      c00AmtSegOnl.style.width = isValidNum(amtOnl.share) ? `${amtOnl.share}%` : `0%`;
      c00AmtSegOnl.title = isValidNum(amtOnl.share) ? `線上 EPOS+PH: ${amtOnl.share}% (${fmtNum(amtOnl.amount, 1)} 億)` : `線上 EPOS+PH: -`;
    }
    const c00AmtPhysPct = document.getElementById("c00-acq-amt-phys-pct");
    if (c00AmtPhysPct) c00AmtPhysPct.textContent = isValidNum(amtPhys.share) ? `(${amtPhys.share}%)` : `(-%)`;
    const c00AmtPhysVal = document.getElementById("c00-acq-amt-phys-val");
    if (c00AmtPhysVal) c00AmtPhysVal.innerHTML = isValidNum(amtPhys.amount) ? `${fmtNum(amtPhys.amount, 1)}<em>億</em>` : `-`;
    const c00AmtOnlPct = document.getElementById("c00-acq-amt-onl-pct");
    if (c00AmtOnlPct) c00AmtOnlPct.textContent = isValidNum(amtOnl.share) ? `(${amtOnl.share}%)` : `(-%)`;
    const c00AmtOnlVal = document.getElementById("c00-acq-amt-onl-val");
    if (c00AmtOnlVal) c00AmtOnlVal.innerHTML = isValidNum(amtOnl.amount) ? `${fmtNum(amtOnl.amount, 1)}<em>億</em>` : `-`;

    // 02 Section: Primary Card 1
    const b02AmtVal = document.getElementById("b02-amt-val");
    if (b02AmtVal) b02AmtVal.innerHTML = amtValHtml;
    const b02AmtGrowth = document.getElementById("b02-amt-growth");
    if (b02AmtGrowth) b02AmtGrowth.innerHTML = amtGrowthHtml;
    const b02AmtSegPhys = document.getElementById("b02-amt-seg-phys");
    if (b02AmtSegPhys) {
      b02AmtSegPhys.style.width = isValidNum(amtPhys.share) ? `${amtPhys.share}%` : `0%`;
      b02AmtSegPhys.title = isValidNum(amtPhys.share) ? `實體收單: ${amtPhys.share}% (${fmtNum(amtPhys.amount, 1)} 億)` : `實體收單: -`;
    }
    const b02AmtSegOnl = document.getElementById("b02-amt-seg-onl");
    if (b02AmtSegOnl) {
      b02AmtSegOnl.style.width = isValidNum(amtOnl.share) ? `${amtOnl.share}%` : `0%`;
      b02AmtSegOnl.title = isValidNum(amtOnl.share) ? `線上 EPOS+PH: ${amtOnl.share}% (${fmtNum(amtOnl.amount, 1)} 億)` : `線上 EPOS+PH: -`;
    }
    const b02AmtPhysPct = document.getElementById("b02-amt-phys-pct");
    if (b02AmtPhysPct) b02AmtPhysPct.textContent = isValidNum(amtPhys.share) ? `(${amtPhys.share}%)` : `(-%)`;
    const b02AmtPhysVal = document.getElementById("b02-amt-phys-val");
    if (b02AmtPhysVal) b02AmtPhysVal.innerHTML = isValidNum(amtPhys.amount) ? `${fmtNum(amtPhys.amount, 1)}<em>億</em>` : `-`;
    const b02AmtOnlPct = document.getElementById("b02-amt-onl-pct");
    if (b02AmtOnlPct) b02AmtOnlPct.textContent = isValidNum(amtOnl.share) ? `(${amtOnl.share}%)` : `(-%)`;
    const b02AmtOnlVal = document.getElementById("b02-amt-onl-val");
    if (b02AmtOnlVal) b02AmtOnlVal.innerHTML = isValidNum(amtOnl.amount) ? `${fmtNum(amtOnl.amount, 1)}<em>億</em>` : `-`;

    // 2. 自行收單交易筆數
    const cnt = kpi.acq_cnt || {};
    const cntPhys = cnt.physical || {};
    const cntOnl = cnt.online || {};

    const cntValHtml = isValidNum(cnt.total) ? `${Number(cnt.total).toLocaleString()}<em>${cnt.unit || '萬筆'}</em>` : `-`;
    const cntGrowthHtml = `
      <span class="${semCls(cnt.yoy)}"><b>YoY</b>${fmtSign(cnt.yoy)}</span>
      <span class="${semCls(cnt.mom)}"><b>MoM</b>${fmtSign(cnt.mom)}</span>
    `;

    // Cockpit Col 2: Card 2
    const c00CntVal = document.getElementById("c00-acq-cnt-val");
    if (c00CntVal) c00CntVal.innerHTML = isValidNum(cnt.total) ? `${Number(cnt.total).toLocaleString()} <em>${cnt.unit || '萬筆'}</em>` : `-`;
    const c00CntGrowth = document.getElementById("c00-acq-cnt-growth");
    if (c00CntGrowth) {
      c00CntGrowth.innerHTML = `
        <span class="${semCls(cnt.yoy)}">YoY ${fmtSign(cnt.yoy)}</span>
        <span class="${semCls(cnt.mom)}">MoM ${fmtSign(cnt.mom)}</span>
      `;
    }
    const c00CntSegPhys = document.getElementById("c00-acq-cnt-seg-phys");
    if (c00CntSegPhys) {
      c00CntSegPhys.style.width = isValidNum(cntPhys.share) ? `${cntPhys.share}%` : `0%`;
      c00CntSegPhys.title = isValidNum(cntPhys.share) ? `實體收單: ${cntPhys.share}% (${fmtNum(cntPhys.count, 0)} 萬筆)` : `實體收單: -`;
    }
    const c00CntSegOnl = document.getElementById("c00-acq-cnt-seg-onl");
    if (c00CntSegOnl) {
      c00CntSegOnl.style.width = isValidNum(cntOnl.share) ? `${cntOnl.share}%` : `0%`;
      c00CntSegOnl.title = isValidNum(cntOnl.share) ? `線上 EPOS+PH: ${cntOnl.share}% (${fmtNum(cntOnl.count, 0)} 萬筆)` : `線上 EPOS+PH: -`;
    }
    const c00CntPhysPct = document.getElementById("c00-acq-cnt-phys-pct");
    if (c00CntPhysPct) c00CntPhysPct.textContent = isValidNum(cntPhys.share) ? `(${cntPhys.share}%)` : `(-%)`;
    const c00CntPhysVal = document.getElementById("c00-acq-cnt-phys-val");
    if (c00CntPhysVal) c00CntPhysVal.innerHTML = isValidNum(cntPhys.count) ? `${Number(cntPhys.count).toLocaleString()}<em>萬筆</em>` : `-`;
    const c00CntOnlPct = document.getElementById("c00-acq-cnt-onl-pct");
    if (c00CntOnlPct) c00CntOnlPct.textContent = isValidNum(cntOnl.share) ? `(${cntOnl.share}%)` : `(-%)`;
    const c00CntOnlVal = document.getElementById("c00-acq-cnt-onl-val");
    if (c00CntOnlVal) c00CntOnlVal.innerHTML = isValidNum(cntOnl.count) ? `${Number(cntOnl.count).toLocaleString()}<em>萬筆</em>` : `-`;

    // 02 Section: Primary Card 2
    const b02CntVal = document.getElementById("b02-cnt-val");
    if (b02CntVal) b02CntVal.innerHTML = cntValHtml;
    const b02CntGrowth = document.getElementById("b02-cnt-growth");
    if (b02CntGrowth) b02CntGrowth.innerHTML = cntGrowthHtml;
    const b02CntSegPhys = document.getElementById("b02-cnt-seg-phys");
    if (b02CntSegPhys) {
      b02CntSegPhys.style.width = isValidNum(cntPhys.share) ? `${cntPhys.share}%` : `0%`;
      b02CntSegPhys.title = isValidNum(cntPhys.share) ? `實體收單: ${cntPhys.share}% (${fmtNum(cntPhys.count, 0)} 萬筆)` : `實體收單: -`;
    }
    const b02CntSegOnl = document.getElementById("b02-cnt-seg-onl");
    if (b02CntSegOnl) {
      b02CntSegOnl.style.width = isValidNum(cntOnl.share) ? `${cntOnl.share}%` : `0%`;
      b02CntSegOnl.title = isValidNum(cntOnl.share) ? `線上 EPOS+PH: ${cntOnl.share}% (${fmtNum(cntOnl.count, 0)} 萬筆)` : `線上 EPOS+PH: -`;
    }
    const b02CntPhysPct = document.getElementById("b02-cnt-phys-pct");
    if (b02CntPhysPct) b02CntPhysPct.textContent = isValidNum(cntPhys.share) ? `(${cntPhys.share}%)` : `(-%)`;
    const b02CntPhysVal = document.getElementById("b02-cnt-phys-val");
    if (b02CntPhysVal) b02CntPhysVal.innerHTML = isValidNum(cntPhys.count) ? `${Number(cntPhys.count).toLocaleString()}<em>萬筆</em>` : `-`;
    const b02CntOnlPct = document.getElementById("b02-cnt-onl-pct");
    if (b02CntOnlPct) b02CntOnlPct.textContent = isValidNum(cntOnl.share) ? `(${cntOnl.share}%)` : `(-%)`;
    const b02CntOnlVal = document.getElementById("b02-cnt-onl-val");
    if (b02CntOnlVal) b02CntOnlVal.innerHTML = isValidNum(cntOnl.count) ? `${Number(cntOnl.count).toLocaleString()}<em>萬筆</em>` : `-`;

    // 3. 收單特店總數
    const mcht = kpi.acq_mcht || {};
    const mchtPhys = mcht.physical || {};
    const mchtOnl = mcht.online || {};

    const mchtValHtml = isValidNum(mcht.total) ? `${Number(mcht.total).toLocaleString()}<em>${mcht.unit || '家'}</em>` : `-`;
    const mchtGrowthHtml = `
      <span class="${semCls(mcht.yoy)}"><b>YoY</b>${fmtSign(mcht.yoy)}</span>
      <span class="${semCls(mcht.mom)}"><b>MoM</b>${fmtSign(mcht.mom)}</span>
    `;

    // Cockpit Col 2: Card 3
    const c00MchtVal = document.getElementById("c00-acq-mcht-val");
    if (c00MchtVal) c00MchtVal.innerHTML = isValidNum(mcht.total) ? `${Number(mcht.total).toLocaleString()} <em>${mcht.unit || '家'}</em>` : `-`;
    const c00MchtGrowth = document.getElementById("c00-acq-mcht-growth");
    if (c00MchtGrowth) {
      c00MchtGrowth.innerHTML = `<span class="${semCls(mcht.yoy)}">YoY ${fmtSign(mcht.yoy)}</span> <span class="c-hint" id="c00-acq-mcht-hint">(活店率 ${isValidNum(mcht.active_rate) ? mcht.active_rate + '%' : '-'})</span>`;
    }
    const c00MchtSegPhys = document.getElementById("c00-acq-mcht-seg-phys");
    if (c00MchtSegPhys) {
      c00MchtSegPhys.style.width = isValidNum(mchtPhys.share) ? `${mchtPhys.share}%` : `0%`;
      c00MchtSegPhys.title = isValidNum(mchtPhys.share) ? `實體特店: ${mchtPhys.share}% (${fmtNum(mchtPhys.count, 0)} 家)` : `實體特店: -`;
    }
    const c00MchtSegOnl = document.getElementById("c00-acq-mcht-seg-onl");
    if (c00MchtSegOnl) {
      c00MchtSegOnl.style.width = isValidNum(mchtOnl.share) ? `${mchtOnl.share}%` : `0%`;
      c00MchtSegOnl.title = isValidNum(mchtOnl.share) ? `線上特店: ${mchtOnl.share}% (${fmtNum(mchtOnl.count, 0)} 家)` : `線上特店: -`;
    }
    const c00MchtPhysPct = document.getElementById("c00-acq-mcht-phys-pct");
    if (c00MchtPhysPct) c00MchtPhysPct.textContent = isValidNum(mchtPhys.share) ? `(${mchtPhys.share}%)` : `(-%)`;
    const c00MchtPhysVal = document.getElementById("c00-acq-mcht-phys-val");
    if (c00MchtPhysVal) c00MchtPhysVal.innerHTML = isValidNum(mchtPhys.count) ? `${Number(mchtPhys.count).toLocaleString()}<em>家</em>` : `-`;
    const c00MchtOnlPct = document.getElementById("c00-acq-mcht-onl-pct");
    if (c00MchtOnlPct) c00MchtOnlPct.textContent = isValidNum(mchtOnl.share) ? `(${mchtOnl.share}%)` : `(-%)`;
    const c00MchtOnlVal = document.getElementById("c00-acq-mcht-onl-val");
    if (c00MchtOnlVal) c00MchtOnlVal.innerHTML = isValidNum(mchtOnl.count) ? `${Number(mchtOnl.count).toLocaleString()}<em>家</em>` : `-`;

    // 02 Section: Primary Card 3
    const b02MchtVal = document.getElementById("b02-mcht-val");
    if (b02MchtVal) b02MchtVal.innerHTML = mchtValHtml;
    const b02MchtGrowth = document.getElementById("b02-mcht-growth");
    if (b02MchtGrowth) b02MchtGrowth.innerHTML = mchtGrowthHtml;
    const b02MchtSegPhys = document.getElementById("b02-mcht-seg-phys");
    if (b02MchtSegPhys) {
      b02MchtSegPhys.style.width = isValidNum(mchtPhys.share) ? `${mchtPhys.share}%` : `0%`;
      b02MchtSegPhys.title = isValidNum(mchtPhys.share) ? `實體特店: ${mchtPhys.share}% (${fmtNum(mchtPhys.count, 0)} 家)` : `實體特店: -`;
    }
    const b02MchtSegOnl = document.getElementById("b02-mcht-seg-onl");
    if (b02MchtSegOnl) {
      b02MchtSegOnl.style.width = isValidNum(mchtOnl.share) ? `${mchtOnl.share}%` : `0%`;
      b02MchtSegOnl.title = isValidNum(mchtOnl.share) ? `線上特店: ${mchtOnl.share}% (${fmtNum(mchtOnl.count, 0)} 家)` : `線上特店: -`;
    }
    const b02MchtPhysPct = document.getElementById("b02-mcht-phys-pct");
    if (b02MchtPhysPct) b02MchtPhysPct.textContent = isValidNum(mchtPhys.share) ? `(${mchtPhys.share}%)` : `(-%)`;
    const b02MchtPhysVal = document.getElementById("b02-mcht-phys-val");
    if (b02MchtPhysVal) b02MchtPhysVal.innerHTML = isValidNum(mchtPhys.count) ? `${Number(mchtPhys.count).toLocaleString()}<em>家</em>` : `-`;
    const b02MchtOnlPct = document.getElementById("b02-mcht-onl-pct");
    if (b02MchtOnlPct) b02MchtOnlPct.textContent = isValidNum(mchtOnl.share) ? `(${mchtOnl.share}%)` : `(-%)`;
    const b02MchtOnlVal = document.getElementById("b02-mcht-onl-val");
    if (b02MchtOnlVal) b02MchtOnlVal.innerHTML = isValidNum(mchtOnl.count) ? `${Number(mchtOnl.count).toLocaleString()}<em>家</em>` : `-`;

    // 4. 次要指標 (4 Cards)
    const sec = kpi.secondary || {};
    const pen = sec.penetration_rate || {};
    const actMcht = sec.active_mcht || {};
    const estmt = sec.estatement_rate || {};
    const fee = sec.fee_income || {};

    const b02PenVal = document.getElementById("b02-penetration-val");
    if (b02PenVal) b02PenVal.textContent = isValidNum(pen.value) ? `${pen.value}%` : `-`;
    const b02PenGrowth = document.getElementById("b02-penetration-growth");
    if (b02PenGrowth) {
      b02PenGrowth.innerHTML = `
        <span class="${semCls(pen.yoy)}"><b>YoY</b>${fmtSign(pen.yoy, "pp")}</span>
        <span class="${semCls(pen.mom)}"><b>MoM</b>${fmtSign(pen.mom, "pp")}</span>
      `;
    }

    const b02ActMchtVal = document.getElementById("b02-active-mcht-val");
    if (b02ActMchtVal) b02ActMchtVal.innerHTML = isValidNum(actMcht.count) ? `${Number(actMcht.count).toLocaleString()}<em>${actMcht.unit || '家'}</em>` : `-`;
    const b02ActMchtGrowth = document.getElementById("b02-active-mcht-growth");
    if (b02ActMchtGrowth) {
      b02ActMchtGrowth.innerHTML = `
        <span class="${semCls(actMcht.yoy)}"><b>YoY</b>${fmtSign(actMcht.yoy)}</span>
        <span class="number-positive"><b>活店率</b>${isValidNum(actMcht.active_rate) ? actMcht.active_rate + '%' : '-'}</span>
      `;
    }

    const b02EstmtVal = document.getElementById("b02-estatement-val");
    if (b02EstmtVal) b02EstmtVal.textContent = isValidNum(estmt.value) ? `${estmt.value}%` : `-`;

    const b02FeeVal = document.getElementById("b02-fee-val");
    if (b02FeeVal) b02FeeVal.innerHTML = isValidNum(fee.value) ? `${fmtNum(fee.value, 2)}<em>${fee.unit || '億元'}</em>` : `-`;
    const b02FeeGrowth = document.getElementById("b02-fee-growth");
    if (b02FeeGrowth) {
      b02FeeGrowth.innerHTML = `<span class="${semCls(fee.yoy)}"><b>YoY</b>${fmtSign(fee.yoy)}</span>`;
    }

    // 5. 2B TAB 0: 線上交易型態
    const channels = b2.online_channels || [];
    if (channels.length > 0) {
      const structBar = document.getElementById("b02-online-struct-bar");
      if (structBar) {
        const colors = ["#003b5c", "#3b82f6", "#ea580c"];
        structBar.innerHTML = channels.map((c, idx) => `
          <div style="background:${colors[idx % colors.length]}; width:${isValidNum(c.amount_share) ? c.amount_share : 0}%;" title="${c.name} (${isValidNum(c.amount_share) ? c.amount_share + '%' : '-'})">
            <span>${c.name} (${isValidNum(c.amount_share) ? c.amount_share + '%' : '-'})</span>
          </div>
        `).join("");
      }

      const tableBody = document.getElementById("b02-online-table-body");
      if (tableBody) {
        tableBody.innerHTML = channels.map(c => `
          <tr>
            <td><strong>${c.name}</strong></td>
            <td style="text-align:right;"><strong style="color:var(--blue-dark); font-size:15.5px;">${isValidNum(c.amount) ? fmtNum(c.amount, 1) + ' 億元' : '-'}</strong></td>
            <td style="text-align:right;" class="${semCls(c.amount_yoy)}"><strong>${fmtSign(c.amount_yoy)}</strong></td>
            <td style="text-align:right;">${isValidNum(c.count) ? Number(c.count).toLocaleString() + ' 萬筆' : '-'}</td>
            <td style="text-align:right;" class="${semCls(c.count_yoy)}"><strong>${fmtSign(c.count_yoy)}</strong></td>
            <td style="text-align:right;">${isValidNum(c.avg_ticket) ? Number(c.avg_ticket).toLocaleString() + ' 元' : '-'}</td>
            <td style="text-align:right;" class="${semCls(c.avg_ticket_yoy)}"><strong>${fmtSign(c.avg_ticket_yoy)}</strong></td>
          </tr>
        `).join("");
      }
    }

    // 6. 2B TAB 1: 特店集中度與 2x2 矩陣
    const conc = b2.merchant_concentration || {};
    const top10ShareElem = document.getElementById("b02-top10-share");
    if (top10ShareElem) top10ShareElem.textContent = isValidNum(conc.top10_share) ? `${conc.top10_share}%` : `-`;
    const top10YoyElem = document.getElementById("b02-top10-yoy");
    if (top10YoyElem) top10YoyElem.textContent = isValidNum(conc.top10_yoy) ? `YoY ${fmtSign(conc.top10_yoy, 'pp')}` : `YoY -`;

    const topMchts = conc.top_merchants || [];
    const topMchtList = document.getElementById("b02-top-merchants-list");
    if (topMchtList && topMchts.length > 0) {
      const maxMchtAmt = Math.max(...topMchts.map(m => Number(m.amount) || 0), 1);
      topMchtList.innerHTML = topMchts.map(m => {
        const amtNum = Number(m.amount) || 0;
        const widthPct = isValidNum(m.amount) && maxMchtAmt > 0 ? ((amtNum / maxMchtAmt) * 100).toFixed(1) : 0;
        const isNeg = Number(m.yoy) < 0;
        const grad = isNeg ? 'linear-gradient(90deg, #d97706, #f59e0b)' : 'linear-gradient(90deg, #003b5c, #0284c7)';
        return `
          <div style="display:grid; grid-template-columns: 150px 1fr 130px; gap:12px; align-items:center;">
            <span style="font-size:14px; font-weight:800; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${m.name}（${m.sub}）">${m.name} <small style="color:#64748b; font-weight:600; font-size:12.5px;">(${m.sub})</small></span>
            <div style="height:11px; background:#e8eeee; border-radius:6px; overflow:hidden;">
              <div style="width:${widthPct}%; height:100%; background:${grad}; border-radius:6px;"></div>
            </div>
            <div style="text-align:right; white-space:nowrap;">
              <strong style="font-size:15px; font-weight:800; color:var(--blue-dark);">${isValidNum(m.amount) ? fmtNum(m.amount, 1) + ' 億' : '-'}</strong>
              <span class="${semCls(m.yoy)}" style="font-size:12.5px; font-weight:800; margin-left:4px;">${fmtSign(m.yoy)}</span>
            </div>
          </div>
        `;
      }).join("");
    }

    const reps = conc.matrix_reps || {};
    const repCore = document.getElementById("b02-rep-core");
    if (repCore && reps.core) repCore.textContent = reps.core;
    const repPot = document.getElementById("b02-rep-potential");
    if (repPot && reps.potential) repPot.textContent = reps.potential;
    const repMain = document.getElementById("b02-rep-maintain");
    if (repMain && reps.maintain) repMain.textContent = reps.maintain;
    const repGen = document.getElementById("b02-rep-general");
    if (repGen && reps.general) repGen.textContent = reps.general;

    // 7. 2B TAB 2: 特店產業結構蝴蝶圖
    const indList = b2.industry_structure || [];
    const butterflyWrap = document.getElementById("b02-butterfly-list");
    if (butterflyWrap && indList.length > 0) {
      const maxMchtCount = Math.max(...indList.map(i => Number(i.merchant_count) || 0), 1);
      const maxAmount = Math.max(...indList.map(i => Number(i.amount) || 0), 1);

      butterflyWrap.innerHTML = indList.map(i => {
        const leftWidth = isValidNum(i.merchant_count) && maxMchtCount > 0 ? ((Number(i.merchant_count) / maxMchtCount) * 100).toFixed(1) : 0;
        const rightWidth = isValidNum(i.amount) && maxAmount > 0 ? ((Number(i.amount) / maxAmount) * 100).toFixed(1) : 0;
        return `
          <div class="acq-butterfly-row">
            <div class="acq-b-left-wing">
              <span class="acq-b-val-left">${isValidNum(i.merchant_count) ? Number(i.merchant_count).toLocaleString() + ' 家' : '-'} (${isValidNum(i.merchant_share) ? i.merchant_share + '%' : '-'})</span>
              <div class="acq-b-bar-track-left">
                <div class="acq-b-bar-fill-left" style="width: ${leftWidth}%; background:${i.color || '#003b5c'};"></div>
              </div>
            </div>
            <div class="acq-b-center-axis">
              <span class="acq-b-axis-title">${i.label || i.name}</span>
            </div>
            <div class="acq-b-right-wing">
              <div class="acq-b-bar-track-right">
                <div class="acq-b-bar-fill-right" style="width: ${rightWidth}%; background:${i.color || '#003b5c'};"></div>
              </div>
              <span class="acq-b-val-right">${isValidNum(i.amount) ? fmtNum(i.amount, 1) + ' 億' : '-'} (${isValidNum(i.amount_share) ? i.amount_share + '%' : '-'})</span>
            </div>
            <div class="acq-b-avg-col">
              <span class="acq-b-avg-badge">${isValidNum(i.avg_per_merchant) ? fmtNum(i.avg_per_merchant, 1) + ' 萬/店' : '-'}</span>
            </div>
          </div>
        `;
      }).join("");
    }

    // 8. TWQR 業務數據更新
    const c00TwApply = document.getElementById("c00-twqr-apply-cnt");
    if (c00TwApply) c00TwApply.innerHTML = isValidNum(twqr.apply_count) ? `${Number(twqr.apply_count).toLocaleString()} <em>件</em>` : `-`;
    const c00TwPass = document.getElementById("c00-twqr-pass-rate");
    if (c00TwPass) c00TwPass.textContent = isValidNum(twqr.pass_rate) ? `審查通過率 ${twqr.pass_rate}%` : `-`;
    const c00TwNew = document.getElementById("c00-twqr-new-mcht");
    if (c00TwNew) c00TwNew.innerHTML = isValidNum(twqr.new_merchants) ? `${Number(twqr.new_merchants).toLocaleString()} <em>家</em>` : `-`;
    const c00TwTotM = document.getElementById("c00-twqr-total-mcht");
    if (c00TwTotM) c00TwTotM.innerHTML = isValidNum(twqr.total_merchants) ? `${Number(twqr.total_merchants).toLocaleString()} <em>家</em>` : `-`;
    const c00TwTotMom = document.getElementById("c00-twqr-total-mom");
    if (c00TwTotMom) c00TwTotMom.textContent = isValidNum(twqr.total_merchants_mom) ? `MoM ${fmtSign(twqr.total_merchants_mom)}` : `-`;

    const c00TwAmt = document.getElementById("c00-twqr-tx-amt");
    if (c00TwAmt) c00TwAmt.innerHTML = isValidNum(twqr.tx_amount) ? `${fmtNum(twqr.tx_amount, 1)} <em>億</em>` : `-`;
    const c00TwAmtMom = document.getElementById("c00-twqr-amt-mom");
    if (c00TwAmtMom) c00TwAmtMom.textContent = isValidNum(twqr.tx_amount_mom) ? `MoM ${fmtSign(twqr.tx_amount_mom)}` : `-`;
    const c00TwCnt = document.getElementById("c00-twqr-tx-cnt");
    if (c00TwCnt) c00TwCnt.innerHTML = isValidNum(twqr.tx_count) ? `${Number(twqr.tx_count).toLocaleString()} <em>萬筆</em>` : `-`;
    const c00TwCntMom = document.getElementById("c00-twqr-cnt-mom");
    if (c00TwCntMom) c00TwCntMom.textContent = isValidNum(twqr.tx_count_mom) ? `MoM ${fmtSign(twqr.tx_count_mom)}` : `-`;
    const c00TwActRate = document.getElementById("c00-twqr-active-rate");
    if (c00TwActRate) c00TwActRate.innerHTML = isValidNum(twqr.active_mcht_rate) ? `${twqr.active_mcht_rate}<em>%</em>` : `-`;

    // 02 Section: TWQR Panel
    const b02TwApply = document.getElementById("b02-twqr-apply-cnt");
    if (b02TwApply) b02TwApply.textContent = isValidNum(twqr.apply_count) ? `${Number(twqr.apply_count).toLocaleString()} 件` : `-`;
    const b02TwPass = document.getElementById("b02-twqr-pass-rate");
    if (b02TwPass) b02TwPass.textContent = isValidNum(twqr.pass_rate) ? `審查通過率 ${twqr.pass_rate}%` : `-`;
    const b02TwNew = document.getElementById("b02-twqr-new-mcht");
    if (b02TwNew) b02TwNew.textContent = isValidNum(twqr.new_merchants) ? `${Number(twqr.new_merchants).toLocaleString()} 家` : `-`;
    const b02TwTotM = document.getElementById("b02-twqr-total-mcht");
    if (b02TwTotM) b02TwTotM.textContent = isValidNum(twqr.total_merchants) ? `${Number(twqr.total_merchants).toLocaleString()} 家` : `-`;
    const b02TwTotMom = document.getElementById("b02-twqr-total-mom");
    if (b02TwTotMom) b02TwTotMom.textContent = isValidNum(twqr.total_merchants_mom) ? `MoM ${fmtSign(twqr.total_merchants_mom)}` : `-`;

    const b02TwAmt = document.getElementById("b02-twqr-tx-amt");
    if (b02TwAmt) b02TwAmt.textContent = isValidNum(twqr.tx_amount) ? `${fmtNum(twqr.tx_amount, 1)} 億` : `-`;
    const b02TwAmtMom = document.getElementById("b02-twqr-amt-mom");
    if (b02TwAmtMom) b02TwAmtMom.textContent = isValidNum(twqr.tx_amount_mom) ? `MoM ${fmtSign(twqr.tx_amount_mom)}` : `-`;
    const b02TwCnt = document.getElementById("b02-twqr-tx-cnt");
    if (b02TwCnt) b02TwCnt.textContent = isValidNum(twqr.tx_count) ? `${Number(twqr.tx_count).toLocaleString()} 萬筆` : `-`;
    const b02TwCntMom = document.getElementById("b02-twqr-cnt-mom");
    if (b02TwCntMom) b02TwCntMom.textContent = isValidNum(twqr.tx_count_mom) ? `MoM ${fmtSign(twqr.tx_count_mom)}` : `-`;
    const b02TwAvgTicket = document.getElementById("b02-twqr-avg-ticket");
    if (b02TwAvgTicket) b02TwAvgTicket.textContent = isValidNum(twqr.avg_ticket) ? `${Number(twqr.avg_ticket).toLocaleString()} 元` : `-`;
    const b02TwMchtAvgAmt = document.getElementById("b02-twqr-mcht-avg-amt");
    if (b02TwMchtAvgAmt) b02TwMchtAvgAmt.textContent = isValidNum(twqr.mcht_avg_amount) ? `${fmtNum(twqr.mcht_avg_amount, 2)} 萬元` : `-`;
    const b02TwActRate = document.getElementById("b02-twqr-active-rate");
    if (b02TwActRate) b02TwActRate.textContent = isValidNum(twqr.active_mcht_rate) ? `${twqr.active_mcht_rate}%` : `-`;
  }
"""

# Insert renderBlock02FromData right before document.addEventListener
assert 'document.addEventListener("DOMContentLoaded",' in html, "Cannot find DOMContentLoaded"
html = html.replace('document.addEventListener("DOMContentLoaded",', render_b02_code + '\n  document.addEventListener("DOMContentLoaded",')

# Inside DOMContentLoaded, call renderBlock02FromData
old_dom_listener = 'if (window.DASHBOARD_DATA) { renderBlock01FromData(window.DASHBOARD_DATA); }'
new_dom_listener = """if (window.DASHBOARD_DATA) {
      renderBlock01FromData(window.DASHBOARD_DATA);
      renderBlock02FromData(window.DASHBOARD_DATA);
    }"""
assert old_dom_listener in html, "Cannot find old_dom_listener"
html = html.replace(old_dom_listener, new_dom_listener)

with open("01_儀表板執行環境/credit_card_full_dashboard.html", "w", encoding="utf-8") as f:
    f.write(html)

print("Successfully injected Block 02 engine into credit_card_full_dashboard.html!")
