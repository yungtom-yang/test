// -*- coding: utf-8 -*-
const fs = require('fs');

// Load html
const html = fs.readFileSync('credit_card_full_dashboard.html', 'utf-8');

// Mock a lightweight DOM
const elementMap = {};
function MockElement(id) {
  this.id = id;
  this.innerHTML = '';
  this.textContent = '';
  this.style = {};
  this.title = '';
}

const mockDocument = {
  getElementById: (id) => {
    if (!elementMap[id]) {
      elementMap[id] = new MockElement(id);
    }
    return elementMap[id];
  }
};

global.document = mockDocument;
global.window = global;

// Mock peerCategories and renderYtd
global.peerCategories = [];
global.renderYtd = () => {
  // console.log("renderYtd called! Categories count:", global.peerCategories.length);
};

// Load data
require('../dashboard_data.js');

// Extract renderBlock01FromData from HTML
const fnMatch = html.match(/function renderBlock01FromData\(data\) \{([\s\S]*?)\n  \}/);
if (!fnMatch) {
  console.error("Could not extract renderBlock01FromData!");
  process.exit(1);
}

const renderBlock01FromData = new Function('data', fnMatch[1]);

// 1. Initial render
renderBlock01FromData(window.DASHBOARD_DATA);

console.log("=== TEST 1: Initial Data Render ===");
console.log("c00-amt-val:", elementMap['c00-amt-val'].innerHTML);
console.log("b01-amt-val:", elementMap['b01-amt-val'].innerHTML);
console.log("c00-amt-seg-gen width:", elementMap['c00-amt-seg-gen'].style.width);
console.log("b01-active-val:", elementMap['b01-active-val'].innerHTML);
console.log("b01-active-seg-gen width:", elementMap['b01-active-seg-gen'].style.width);
console.log("c00-cashadv-growth:", elementMap['c00-cashadv-growth'].innerHTML);
console.log("c00-top4-hint:", elementMap['c00-top4-hint'].textContent);

// 2. Modify data in memory (simulate user changing dashboard_data.js)
console.log("\n=== TEST 2: User changes total_amount to 1,500.0 (general 1,200, installment 300) ===");
window.DASHBOARD_DATA.block01.monthly_kpis.total_amount.general.amount = 1200.0;
window.DASHBOARD_DATA.block01.monthly_kpis.total_amount.installment.amount = 300.0;
delete window.DASHBOARD_DATA.block01.monthly_kpis.total_amount.value;
delete window.DASHBOARD_DATA.block01.monthly_kpis.total_amount.general.share;
delete window.DASHBOARD_DATA.block01.monthly_kpis.total_amount.installment.share;

renderBlock01FromData(window.DASHBOARD_DATA);
console.log("Updated c00-amt-val:", elementMap['c00-amt-val'].innerHTML);
console.log("Updated b01-amt-val:", elementMap['b01-amt-val'].innerHTML);
console.log("Auto-calculated c00-amt-seg-gen width:", elementMap['c00-amt-seg-gen'].style.width);
console.log("Auto-calculated c00-amt-seg-inst width:", elementMap['c00-amt-seg-inst'].style.width);
console.log("Auto-calculated c00-amt-gen-pct:", elementMap['c00-amt-gen-pct'].textContent);
console.log("Auto-calculated c00-amt-inst-pct:", elementMap['c00-amt-inst-pct'].textContent);

console.log("\n=== ALL TESTS PASSED SUCCESSFULLY! ===");
