import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('01_儀表板執行環境/dashboard_data.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

benchmarks = data['block01']['peer_benchmark']
print(f"Total categories: {len(benchmarks)}")
for cat in benchmarks:
    print(f"\n=== Category: {cat['label']} ({len(cat['metrics'])} metrics) ===")
    for m in cat['metrics']:
        print(f"  Metric: {m['label']} | Unit: {m['unit']} | Dir: {m['positiveDirection']} | Mode: {m['summaryMode']}")
        for p in m['peers']:
            print(f"    - {p['bank']}: {p['value']} (YoY: {p['yoy']})")
