import openpyxl
import subprocess
import json

wb = openpyxl.load_workbook("01_儀表板執行環境/dashboard_data.xlsx")
# Let's inspect sheet names
print("Sheet names:", wb.sheetnames)

# Check 02_收單月度指標
ws = wb["02_收單月度指標"]
print("\nSample values from 02_收單月度指標:")
for r in range(1, 15):
    row_vals = [ws.cell(r, c).value for c in range(1, 8)]
    if any(v is not None for v in row_vals):
        print(f"Row {r}: {row_vals}")
