# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import math
import re

with open('scratch/build_dashboard.py', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Update get_cockpit_donut_svg to a nicely proportioned 96px x 96px
new_donut_svg_fn = '''def get_cockpit_donut_svg():
    slices = [
        {"name": "中國信託", "share": 19.5, "color": "#003b5c"},
        {"name": "國泰世華", "share": 18.6, "color": "#009e73"},
        {"name": "台北富邦", "share": 14.5, "color": "#2563eb"},
        {"name": "玉山銀行", "share": 14.1, "color": "#059669"},
        {"name": "其他同業", "share": 33.3, "color": "#cbd5e1"}
    ]
    cx, cy, r_out, r_in = 60, 60, 52, 32
    paths = []
    start_angle = -90.0
    for s in slices:
        angle_len = (s["share"] / 100.0) * 360.0
        end_angle = start_angle + angle_len
        rad_start = math.radians(start_angle)
        rad_end = math.radians(end_angle)
        x1_out = cx + r_out * math.cos(rad_start)
        y1_out = cy + r_out * math.sin(rad_start)
        x2_out = cx + r_out * math.cos(rad_end)
        y2_out = cy + r_out * math.sin(rad_end)
        x1_in = cx + r_in * math.cos(rad_end)
        y1_in = cy + r_in * math.sin(rad_end)
        x2_in = cx + r_in * math.cos(rad_start)
        y2_in = cy + r_in * math.sin(rad_start)
        large_arc = 1 if angle_len > 180 else 0
        path_d = f"M {x1_out:.2f} {y1_out:.2f} A {r_out} {r_out} 0 {large_arc} 1 {x2_out:.2f} {y2_out:.2f} L {x1_in:.2f} {y1_in:.2f} A {r_in} {r_in} 0 {large_arc} 0 {x2_in:.2f} {y2_in:.2f} Z"
        paths.append(f'<path d="{path_d}" fill="{s["color"]}" stroke="#ffffff" stroke-width="1.5"><title>{s["name"]}: {s["share"]}%</title></path>')
        start_angle = end_angle
    return f\'\'\'<svg viewBox="0 0 120 120" width="96" height="96" style="display:block; margin:0 auto;">
        {''.join(paths)}
        <circle cx="{cx}" cy="{cy}" r="{r_in}" fill="#ffffff" />
        <text x="{cx}" y="{cy-3}" font-size="9.5" font-weight="900" fill="#003b5c" text-anchor="middle">全市場</text>
        <text x="{cx}" y="{cy+9}" font-size="8.5" font-weight="700" fill="#64748b" text-anchor="middle">30,720億</text>
    </svg>\'\'\''''

# Replace get_cockpit_donut_svg
d_start = text.find('def get_cockpit_donut_svg():')
d_end = text.find('def render_cockpit_section(d):')
if d_start != -1 and d_end != -1:
    text = text[:d_start] + new_donut_svg_fn + "\n\n" + text[d_end:]
    print("Updated get_cockpit_donut_svg!")

# 2. Fix CSS: remove duplicate peer table rules and stop stretching
# Search for .cockpit-peer-header in CSS
old_css_chunk = '''.cockpit-peer-header {
  display: grid;
  grid-template-columns: 72px 1fr 46px 50px;
  align-items: center;
  font-size: 10px;
  font-weight: 800;
  color: #64748b;
  padding: 2px 6px;
  border-bottom: 1px solid #e2e8f0;
  margin-bottom: 2px;
}
.cockpit-peer-header .p-name { text-align: left; }
.cockpit-peer-header .p-val { text-align: right; }
.cockpit-peer-header .p-share { text-align: right; }
.cockpit-peer-header .p-yoy { text-align: right; }

.cockpit-peer-row {
  display: grid;
  grid-template-columns: 72px 1fr 46px 50px;
  align-items: center;
  font-size: 10.5px;
  padding: 3px 6px;
  border-radius: 4px;
  background: #fff;
  border: 1px solid #edf2f0;
}'''

new_css_chunk = '''.cockpit-peer-table-box {
  width: 100%;
}
.cockpit-peer-header {
  display: grid;
  grid-template-columns: 66px 1fr 46px 48px;
  align-items: center;
  font-size: 10px;
  font-weight: 800;
  color: #64748b;
  padding: 2px 6px;
  border-bottom: 1px solid #e2e8f0;
  margin-bottom: 2px;
}
.cockpit-peer-header .p-name { text-align: left; }
.cockpit-peer-header .p-val { text-align: right; }
.cockpit-peer-header .p-share { text-align: right; }
.cockpit-peer-header .p-yoy { text-align: right; }

.cockpit-peer-list {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.cockpit-peer-row {
  display: grid;
  grid-template-columns: 66px 1fr 46px 48px;
  align-items: center;
  font-size: 10px;
  padding: 2.5px 6px;
  border-radius: 4px;
  background: #fff;
  border: 1px solid #edf2f0;
}
.cockpit-peer-row.highlight {
  background: #f0f9f5;
  border-color: #b5e4d2;
  font-weight: 800;
  color: var(--green);
}
.cockpit-peer-row .p-name { font-weight: 700; color: var(--ink); text-align: left; }
.cockpit-peer-row .p-val { text-align: right; color: #4b5d66; font-variant-numeric: tabular-nums; }
.cockpit-peer-row .p-share { text-align: right; color: var(--ink); }
.cockpit-peer-row .p-yoy { text-align: right; font-size: 9.5px; font-weight: 700; }'''

if old_css_chunk in text:
    text = text.replace(old_css_chunk, new_css_chunk)
    print("Replaced old CSS chunk with unified peer table CSS!")
else:
    print("WARNING: old_css_chunk not found!")

# Remove the duplicate old rules at lines ~900-960
dup_target = '''/* Peer Market Share Stacked Bar */
.market-stacked-bar {
  display: flex;
  height: 12px;
  border-radius: 6px;
  overflow: hidden;
  background: #e2e8f0;
  margin: 4px 0;
}
.market-bar-seg {
  height: 100%;
  transition: width 0.3s;
}
.market-bar-seg:nth-child(1) { background: #003b5c; }
.market-bar-seg:nth-child(2) { background: var(--green); }
.market-bar-seg:nth-child(3) { background: #5d7a88; }
.market-bar-seg:nth-child(4) { background: #94a3b8; }
.market-bar-seg:nth-child(5) { background: #cbd5e1; }

.cockpit-peer-list {
  display: flex;
  flex-direction: column;
  gap: 3px;
  margin-top: 4px;
}
.cockpit-peer-row {
  display: grid;
  grid-template-columns: 20px 58px 1fr 42px 46px;
  align-items: center;
  font-size: 11px;
  padding: 3px 6px;
  border-radius: 4px;
  background: #fff;
  border: 1px solid #edf2f0;
}
.cockpit-peer-row.highlight {
  background: #f0f9f5;
  border-color: #b5e4d2;
  font-weight: 800;
  color: var(--green);
}
.p-rank { font-weight: 800; color: #62757d; font-size: 10px; }
.p-name { font-weight: 700; color: var(--ink); }
.p-val { text-align: right; color: #4b5d66; font-variant-numeric: tabular-nums; }
.p-share { text-align: right; color: var(--ink); }
.p-yoy { text-align: right; font-size: 10px; font-weight: 700; }'''

if dup_target in text:
    text = text.replace(dup_target, "/* Removed duplicate peer table styles */")
    print("Removed duplicate peer table styles!")
else:
    print("WARNING: dup_target not found!")

# Also fix .cockpit-subbox.flex-grow to NOT stretch with space-between
old_fg = '''.cockpit-subbox.flex-grow {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}'''
new_fg = '''.cockpit-subbox.flex-grow {
  display: flex;
  flex-direction: column;
  gap: 4px;
}'''
if old_fg in text:
    text = text.replace(old_fg, new_fg)
    print("Fixed .cockpit-subbox.flex-grow to avoid vertical stretching!")

with open('scratch/build_dashboard.py', 'w', encoding='utf-8') as f:
    f.write(text)

print("Saved updated build_dashboard.py!")
