# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

transcript_path = "C:/Users/詠棠/.gemini/antigravity/brain/b95ecca9-971a-489b-ab53-ec5e0dbbb3cb/.system_generated/logs/transcript_full.jsonl"

with open(transcript_path, "r", encoding="utf-8") as f:
    for line in f:
        obj = json.loads(line)
        if obj.get("type") == "TOOL_RESPONSE":
            c = obj.get("content", "")
            if "Total Lines: 2374" in c or "Total Lines: 2455" in c or "Total Lines: 2522" in c:
                idx = obj.get("step_index")
                print(f"Tool response at step {idx} has build_dashboard.py chunk!")
                # check which lines were viewed
                for l in c.splitlines()[:5]:
                    print("  ", l)
