import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('01_儀表板執行環境/credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print("=== Lines 2390 to 2510 (Cockpit Column 2: 02 收單業務) ===")
for i in range(2389, min(2510, len(lines))):
    print(f"{i+1}: {lines[i].rstrip()}")
