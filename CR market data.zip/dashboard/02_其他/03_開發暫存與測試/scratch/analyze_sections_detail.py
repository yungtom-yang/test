# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import re

with open('scratch/page.tsx', 'r', encoding='utf-8', errors='ignore') as f:
    text = f.read()

for m in re.finditer(r'<section[^>]*>', text):
    start = max(0, m.start() - 100)
    end = min(len(text), m.end() + 200)
    print("--- Section context ---")
    print(text[start:end])
