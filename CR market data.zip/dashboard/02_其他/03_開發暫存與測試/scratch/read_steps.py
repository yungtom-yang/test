import json

with open(r'C:\Users\user\.gemini\antigravity\brain\4de23884-60e4-461e-b182-40c7dba003f4\.system_generated\logs\transcript.jsonl', 'r', encoding='utf-8') as f:
    with open(r'C:\Users\user\.gemini\antigravity\brain\4de23884-60e4-461e-b182-40c7dba003f4\scratch\steps_output.txt', 'w', encoding='utf-8') as out:
        for line in f:
            obj = json.loads(line)
            idx = obj.get('step_index')
            if obj.get('type') == 'USER_INPUT' and idx >= 48:
                out.write(f"=== STEP {idx} (USER_INPUT) ===\n")
                out.write(obj.get('content', '') + "\n\n")
