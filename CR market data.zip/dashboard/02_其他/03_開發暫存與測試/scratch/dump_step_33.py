# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

transcript_path = "C:/Users/詠棠/.gemini/antigravity/brain/b95ecca9-971a-489b-ab53-ec5e0dbbb3cb/.system_generated/logs/transcript_full.jsonl"

with open(transcript_path, "r", encoding="utf-8") as f:
    for line in f:
        obj = json.loads(line)
        if obj.get("step_index") == 33:
            print("Step 33 type:", obj.get("type"))
            calls = obj.get("tool_calls", [])
            for c in calls:
                print("Tool call name:", c.get("name"))
                args = c.get("args", {})
                tf = args.get("TargetFile", "")
                print("Target file:", tf)
                content = args.get("CodeContent", "")
                if content:
                    print(f"CodeContent length: {len(content)}")
                    with open("scratch/step33_build_dashboard.py", "w", encoding="utf-8") as out:
                        out.write(content)
                    print("Saved to scratch/step33_build_dashboard.py!")
