# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

transcript_path = "C:/Users/詠棠/.gemini/antigravity/brain/b95ecca9-971a-489b-ab53-ec5e0dbbb3cb/.system_generated/logs/transcript_full.jsonl"

with open(transcript_path, "r", encoding="utf-8") as f:
    for line in f:
        obj = json.loads(line)
        idx = obj.get("step_index")
        if idx in [11, 29, 101]:
            print(f"=== STEP {idx} ===")
            c = obj.get("content", "")
            for call in obj.get("tool_calls", []):
                args = call.get("args", {})
                for k, v in args.items():
                    if isinstance(v, str) and "issuing-section" in v:
                        print(f"Tool call arg {k}:")
                        print(v[:1000])
            if "issuing-section" in c:
                print("Content:")
                lines = [l for l in c.splitlines() if "section" in l or "class" in l or "background" in l or "font" in l]
                for l in lines[:20]:
                    print("  ", l)
