import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('01_儀表板執行環境/credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    text = f.read()

# Let's inspect acq section
acq_start = text.find('<section id="section-acquiring"')
acq_end = text.find('</section>', acq_start)
acq_html = text[acq_start:acq_end]

import re
ids = re.findall(r'id=["\']([^"\']+)["\']', acq_html)
print("IDs in section-acquiring:", ids)

# Cockpit col 2
col2_start = text.find('<!-- COLUMN 2: 02 收單業務 -->')
col2_end = text.find('<!-- COLUMN 3: 03 發卡業務 -->')
col2_html = text[col2_start:col2_end]
ids_col2 = re.findall(r'id=["\']([^"\']+)["\']', col2_html)
print("IDs in Cockpit Column 2:", ids_col2)
