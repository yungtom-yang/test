# -*- coding: utf-8 -*-
with open('credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    html = f.read()

required_ids = [
    'c00-card-amt', 'c00-amt-val', 'c00-amt-growth', 'c00-amt-seg-gen', 'c00-amt-seg-inst',
    'c00-amt-gen-pct', 'c00-amt-gen-val', 'c00-amt-inst-pct', 'c00-amt-inst-val',
    'c00-card-cnt', 'c00-cnt-val', 'c00-cnt-growth', 'c00-cnt-seg-gen', 'c00-cnt-seg-inst',
    'c00-cnt-gen-pct', 'c00-cnt-gen-val', 'c00-cnt-inst-pct', 'c00-cnt-inst-val',
    'c00-cashadv-val', 'c00-cashadv-growth', 'c00-revolving-val', 'c00-revolving-growth',
    'c00-donut-wrap', 'c00-market-val', 'c00-market-yoy', 'c00-top4-hint', 'c00-peer-list',
    'b01-card-amt', 'b01-amt-val', 'b01-amt-growth', 'b01-amt-seg-gen', 'b01-amt-seg-inst',
    'b01-amt-gen-pct', 'b01-amt-gen-val', 'b01-amt-inst-pct', 'b01-amt-inst-val',
    'b01-card-cnt', 'b01-cnt-val', 'b01-cnt-growth', 'b01-cnt-seg-gen', 'b01-cnt-seg-inst',
    'b01-cnt-gen-pct', 'b01-cnt-gen-val', 'b01-cnt-inst-pct', 'b01-cnt-inst-val',
    'b01-card-active', 'b01-active-val', 'b01-active-growth', 'b01-active-seg-gen', 'b01-active-seg-inact',
    'b01-active-gen-pct', 'b01-active-act-val', 'b01-active-iss-val',
    'b01-revolving-val', 'b01-revolving-growth', 'b01-cashadv-val', 'b01-cashadv-growth',
    'overview-peer-benchmark', 'ytd-category-tabs', 'ytd-metric-selector', 'peer-chart-rows', 'peer-insights'
]

missing = [elem_id for elem_id in required_ids if f'id="{elem_id}"' not in html]
print('Missing IDs count:', len(missing))
if missing:
    print('Missing IDs:', missing)
else:
    print('SUCCESS: All', len(required_ids), 'DOM elements for Block 00 (Col 1) and Block 01 are 100% matched and present!')
