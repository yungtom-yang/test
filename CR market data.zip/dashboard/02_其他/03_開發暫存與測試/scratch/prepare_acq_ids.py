# -*- coding: utf-8 -*-
"""
Helper script to inject IDs into Cockpit Col 2 and Section 02 in credit_card_full_dashboard.html.
Ensures zero visual changes.
"""

with open("01_儀表板執行環境/credit_card_full_dashboard.html", "r", encoding="utf-8") as f:
    content = f.read()

# Verify that cockpit col 2 exists
assert "<!-- COLUMN 2: 02 收單業務 -->" in content
assert '<section id="section-acquiring"' in content

print("Successfully verified HTML landmarks.")
