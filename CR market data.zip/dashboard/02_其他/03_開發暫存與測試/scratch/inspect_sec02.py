import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('01_儀表板執行環境/credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print("=== Lines 3045 to 3250 (Section 02 Top & KPIs) ===")
for i in range(3045, min(3250, len(lines))):
    print(f"{i+1}: {lines[i].rstrip()}")
