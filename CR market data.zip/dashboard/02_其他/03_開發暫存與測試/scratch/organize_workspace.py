# -*- coding: utf-8 -*-
"""
organize_workspace.py
Reorganizes directory structure without deleting any file:
- Moves backup files out of 01_儀表板執行環境 into 02_其他/02_歷史備份與原型/
- Moves loose root duplicate files into 02_其他/02_歷史備份與原型/20261002_根目錄備份/
- Leaves 01_儀表板執行環境 as a pure, standalone deliverable package.
"""
import os
import shutil

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, "..", "..", ".."))

ENV_DIR = os.path.join(PROJECT_ROOT, "01_儀表板執行環境")
ARCHIVE_BASE = os.path.join(PROJECT_ROOT, "02_其他", "02_歷史備份與原型")

# 1. Target folders in 02_歷史備份與原型
BAK_SPLIT_DIR = os.path.join(ARCHIVE_BASE, "20261002_拆分前備份")
BAK_ROOT_DIR = os.path.join(ARCHIVE_BASE, "20261002_根目錄備份")

os.makedirs(BAK_SPLIT_DIR, exist_ok=True)
os.makedirs(BAK_ROOT_DIR, exist_ok=True)

# 2. Move 01_儀表板執行環境/.bak to BAK_SPLIT_DIR
env_bak = os.path.join(ENV_DIR, "credit_card_full_dashboard.html.bak")
if os.path.exists(env_bak):
    target = os.path.join(BAK_SPLIT_DIR, "credit_card_full_dashboard.html.bak")
    shutil.move(env_bak, target)
    print(f"Moved: {env_bak} -> {target}")

# 3. Move loose root files to BAK_ROOT_DIR
root_files_to_move = [
    "credit_card_full_dashboard.html",
    "credit_card_full_dashboard.html.bak",
    "dashboard.css",
    "dashboard_app.js",
    "dashboard_data.js",
    "dashboard_data.json",
    "dashboard_data.xlsx",
    "sync_excel.py"
]

for fname in root_files_to_move:
    fpath = os.path.join(PROJECT_ROOT, fname)
    if os.path.exists(fpath):
        target = os.path.join(BAK_ROOT_DIR, fname)
        shutil.move(fpath, target)
        print(f"Moved: {fpath} -> {target}")

print("Workspace reorganization completed successfully! ZERO files deleted.")
