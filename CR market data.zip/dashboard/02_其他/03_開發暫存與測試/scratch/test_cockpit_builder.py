# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

with open('scratch/dashboard_data.json', 'r', encoding='utf-8') as f:
    d = json.load(f)

with open('scratch/peer_data.json', 'r', encoding='utf-8') as f:
    peer_data = json.load(f)

def render_block00_html(d, peer_data):
    b1 = d["block01_overview"]
    b2 = d["block02_acquiring"]
    b3 = d["block03_issuing"]
    b4 = d["block04_resilience"]

    # 1. Block 01 Data
    kpis_01 = {c["title"]: c for c in b1["kpis"]}
    amt = kpis_01.get("總交易金額", {})
    cnt = kpis_01.get("總交易筆數", {})
    cash = kpis_01.get("預借現金金額", {})
    revolving = kpis_01.get("循環信用餘額", {})

    # Peer market share for 簽帳金額
    # Peers: 中國信託 5980, 國泰世華 5726, 台北富邦 4450, 玉山 4320. Market total 30720
    peers_list = [
        {"name": "中國信託", "val": 5980.0, "share": 19.5, "yoy": "+11.2%", "rank": 1, "is_me": False},
        {"name": "國泰世華", "val": 5726.0, "share": 18.6, "yoy": "+12.8%", "rank": 2, "is_me": True},
        {"name": "台北富邦", "val": 4450.0, "share": 14.5, "yoy": "+18.4%", "rank": 3, "is_me": False},
        {"name": "玉山銀行", "val": 4320.0, "share": 14.1, "yoy": "+9.6%", "rank": 4, "is_me": False},
        {"name": "其他同業", "val": 10244.0, "share": 33.3, "yoy": "+8.9%", "rank": 5, "is_me": False}
    ]

    peer_bars_html = "".join([f"""
      <div class="market-bar-seg {'highlight' if p['is_me'] else ''}" style="width: {p['share']}%;" title="{p['name']}: {p['val']:,.0f} 億 ({p['share']}%)">
      </div>""" for p in peers_list])

    peer_rows_html = "".join([f"""
      <div class="cockpit-peer-row {'highlight' if p['is_me'] else ''}">
        <span class="p-rank">#{p['rank']}</span>
        <span class="p-name">{p['name']}</span>
        <span class="p-val">{p['val']:,.0f} 億</span>
        <span class="p-share"><b>{p['share']}%</b></span>
        <span class="p-yoy number-positive">{p['yoy']}</span>
      </div>""" for p in peers_list[:4]])

    # 2. Block 02 Data (TWQR Focus)
    twqr = b2.get("twqr", {})
    acq_pri = b2.get("kpis_primary", [])
    acq_amt = acq_pri[0] if len(acq_pri) > 0 else {}

    # 3. Block 03 Data
    sankey = b3.get("tab0_sankey", {})
    points = b3.get("tab2_tree_points", {})
    sec_03 = {c["title"]: c for c in b3.get("kpis_secondary", [])}
    bill = sec_03.get("信用卡電子帳單率", {})

    # 4. Block 04 Data
    pri_04 = {c["title"]: c for c in b4.get("kpis_primary", [])}
    cardpool = pri_04.get("CardPool 授權核心主機", {})
    fraud_tab = b4.get("tab2_fraud", {})
    fraud_cards = {c["title"]: c for c in fraud_tab.get("cards", [])}
    fraud_app = fraud_cards.get("申請詐欺防堵 (SFM)", {})
    fraud_3ds = fraud_cards.get("3DS 線上驗證防堵", {})
    fraud_tx = fraud_cards.get("交易詐欺防堵 (SFM)", {})

    cockpit_html = f"""
  <!-- ========================================================
       SECTION 00: 決策指揮總覽 (SINGLE-VIEWPORT NO-SCROLL COCKPIT)
       ======================================================== -->
  <section id="section-cockpit" class="dashboard-section main-section active">
    <div class="section-title section-orange">
      <span>00</span>
      <h2>信用卡營運與系統決策總覽</h2>
      <i></i>
    </div>

    <div class="cockpit-grid">
      <!-- COLUMN 1: 01 全行概況 & 市場對標 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <div class="c-header-left">
            <span class="cockpit-badge c-badge-orange">01 全行營運</span>
            <h3>核心指標與市場地位</h3>
          </div>
          <button type="button" class="cockpit-link-btn" onclick="switchMainSection('section-overview')" title="查看完整全行數據">詳情 →</button>
        </div>

        <!-- 2x2 Mini KPI Cards -->
        <div class="cockpit-subbox">
          <div class="cockpit-kpi-quad">
            <div class="c-kpi-card highlight-glow">
              <span class="c-kpi-title">{amt.get('title', '總交易金額')}</span>
              <div class="c-kpi-val">{amt.get('value', '1,286.4')}<em>億元</em></div>
              <div class="c-kpi-growth"><span class="number-positive">YoY {amt.get('yoy', '+12.8%')}</span> <span class="number-positive">MoM {amt.get('mom', '+2.1%')}</span></div>
            </div>
            <div class="c-kpi-card">
              <span class="c-kpi-title">{cnt.get('title', '總交易筆數')}</span>
              <div class="c-kpi-val">{cnt.get('value', '8,425')}<em>萬筆</em></div>
              <div class="c-kpi-growth"><span class="number-positive">YoY {cnt.get('yoy', '+15.2%')}</span> <span class="number-positive">MoM {cnt.get('mom', '+1.7%')}</span></div>
            </div>
            <div class="c-kpi-card">
              <span class="c-kpi-title">{cash.get('title', '預借現金金額')}</span>
              <div class="c-kpi-val">{cash.get('value', '18.6')}<em>億元</em></div>
              <div class="c-kpi-growth"><span class="number-negative">YoY {cash.get('yoy', '-3.4%')}</span> <span class="c-kpi-sub">42.8 萬筆</span></div>
            </div>
            <div class="c-kpi-card">
              <span class="c-kpi-title">{revolving.get('title', '循環信用餘額')}</span>
              <div class="c-kpi-val">{revolving.get('value', '325.7')}<em>億元</em></div>
              <div class="c-kpi-growth"><span class="number-positive">YoY {revolving.get('yoy', '+6.7%')}</span> <span class="c-kpi-sub">生息資產</span></div>
            </div>
          </div>
        </div>

        <!-- 與他行簽帳占比全新製圖 -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>四大發卡行簽帳金額與市占率</span>
            <span class="cockpit-tag-pill">市場總計 30,720 億</span>
          </div>
          <!-- Stacked Bar -->
          <div class="market-stacked-bar">
            {peer_bars_html}
          </div>
          <!-- Peer Ranked Rows -->
          <div class="cockpit-peer-list">
            {peer_rows_html}
          </div>
          <div class="cockpit-foot-note">
            <span>本行簽帳穩居市場<b>第二</b>，與榜首差距僅 <b>0.8pp</b></span>
          </div>
        </div>
      </div>

      <!-- COLUMN 2: 02 收單業務 & TWQR 專區 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <div class="c-header-left">
            <span class="cockpit-badge c-badge-blue">02 收單動能</span>
            <h3>自行收單與 TWQR 拓點</h3>
          </div>
          <button type="button" class="cockpit-link-btn" onclick="switchMainSection('section-acquiring')" title="查看完整收單數據">詳情 →</button>
        </div>

        <!-- 自行收單核心概況 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>自行收單大盤</span>
            <span class="c-tag-green">活店率 83.0%</span>
          </div>
          <div class="c-mini-stat-banner">
            <div>
              <small>收單總金額</small>
              <strong>285.0<em>億</em></strong>
              <b class="number-positive">YoY +12.8%</b>
            </div>
            <div class="divider-v"></div>
            <div>
              <small>實體 / 線上 EPOS</small>
              <div class="c-split-bar">
                <span class="bar-phys" style="width: 65%;">65% 實體</span>
                <span class="bar-onl" style="width: 35%;">35% 線上</span>
              </div>
              <small class="c-foot-hint">平均客單：1,540 元（+1.2%）</small>
            </div>
          </div>
        </div>

        <!-- TWQR 業務分析專區 (特店進件 + 交易造血) -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>TWQR 國家共同標準業務分析</span>
            <span class="cockpit-tag-pill primary">特店拓點特刊</span>
          </div>

          <!-- TWQR Top Block: 特店進件分析 -->
          <div class="twqr-cockpit-section">
            <div class="twqr-subhead">
              <b>拓展 Pipeline</b>
              <span>通過率 91.2%</span>
            </div>
            <div class="c-twqr-stat-grid">
              <div class="c-twqr-cell">
                <span>當月申請進件數</span>
                <strong>3,850 <em>件</em></strong>
                <b class="number-positive">審查通過率 91.2%</b>
              </div>
              <div class="c-twqr-cell">
                <span>累計特店家數</span>
                <strong>22,100 <em>家</em></strong>
                <b class="number-positive">MoM +5.8% (+1,210家)</b>
              </div>
            </div>
          </div>

          <!-- TWQR Bottom Block: 交易狀態造血動能 -->
          <div class="twqr-cockpit-section" style="margin-top: 8px;">
            <div class="twqr-subhead">
              <b>交易造血動能</b>
              <span>動用特店率 68.2%</span>
            </div>
            <div class="c-twqr-stat-grid three-col">
              <div class="c-twqr-cell">
                <span>當月交易金額</span>
                <strong>14.8 <em>億</em></strong>
                <b class="number-positive">MoM +18.5%</b>
              </div>
              <div class="c-twqr-cell">
                <span>當月交易筆數</span>
                <strong>185 <em>萬筆</em></strong>
                <b class="number-positive">MoM +16.2%</b>
              </div>
              <div class="c-twqr-cell">
                <span>平均客單價</span>
                <strong>800 <em>元</em></strong>
                <b class="number-positive">MoM +2.0%</b>
              </div>
            </div>
          </div>

          <div class="cockpit-foot-note">
            <span>TWQR 累計活店數達 <b>15,070 家</b>，小額高頻通路拓點動能強勁</span>
          </div>
        </div>
      </div>

      <!-- COLUMN 3: 03 發卡進件、帳單與小樹點水庫 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <div class="c-header-left">
            <span class="cockpit-badge c-badge-orange">03 發卡動能</span>
            <h3>進件中樞、帳單與小樹點</h3>
          </div>
          <button type="button" class="cockpit-link-btn" onclick="switchMainSection('section-issuing')" title="查看完整發卡數據">詳情 →</button>
        </div>

        <!-- 徵審進件中樞 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>徵審進件中樞自動化</span>
            <span class="c-tag-green">STP 核准率 76.5%</span>
          </div>
          <div class="c-stat-row">
            <div class="c-stat-item">
              <small>當月申辦總量</small>
              <strong>85,400 <em>件</em></strong>
              <span>舊戶 4.7 萬 ｜ 新戶 3.84 萬</span>
            </div>
            <div class="c-stat-item highlight-box">
              <small>自動直接核准</small>
              <strong style="color:var(--green);">65,300 <em>件</em></strong>
              <span>綜合自動核准率 76.5%</span>
            </div>
          </div>
          <div class="c-progress-bar-wrap">
            <div class="c-progress-fill" style="width: 76.5%;">自動核准 76.5%</div>
            <div class="c-progress-rest" style="width: 23.5%;">人工 23.5%</div>
          </div>
        </div>

        <!-- 信用卡電子帳單數據 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>帳單數據與數位降本</span>
            <span class="cockpit-tag-pill">覆蓋率 91.8%</span>
          </div>
          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>電子帳單總本數</small>
              <strong>520.0 <em>萬本</em></strong>
              <span class="number-positive">YoY +6.8%</span>
            </div>
            <div class="c-stat-item">
              <small>紙本帳單節約</small>
              <strong>42.6 <em>萬本</em></strong>
              <span class="number-positive">YoY −8.0%</span>
            </div>
          </div>
        </div>

        <!-- 小樹點概況 (TAB 3 水庫循環) -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>小樹點水庫循環概況 (TAB 3)</span>
            <span class="c-tag-green">兌換率 84.2%</span>
          </div>
          <div class="c-twqr-stat-grid three-col">
            <div class="c-twqr-cell">
              <span>水庫流通累積</span>
              <strong>48.2 <em>億點</em></strong>
              <b class="number-positive">活水循環</b>
            </div>
            <div class="c-twqr-cell">
              <span>當月贈送點數</span>
              <strong>3.8 <em>億點</em></strong>
              <b class="number-positive">YoY +18.7%</b>
            </div>
            <div class="c-twqr-cell">
              <span>當月兌換點數</span>
              <strong>3.2 <em>億點</em></strong>
              <b class="number-positive">YoY +23.1%</b>
            </div>
          </div>
          <div class="cockpit-foot-note">
            <span>流通兌換率達 <b>84.2%</b> (YoY +3.5pp)，點數高頻抵用成效顯著</span>
          </div>
        </div>
      </div>

      <!-- COLUMN 4: 04 核心主機韌性與資安防詐 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <div class="c-header-left">
            <span class="cockpit-badge c-badge-dark">04 系統韌性</span>
            <h3>核心雙主機與三大防詐</h3>
          </div>
          <button type="button" class="cockpit-link-btn" onclick="switchMainSection('section-resilience')" title="查看完整系統數據">詳情 →</button>
        </div>

        <!-- CardPool 授權核心主機 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>CardPool 授權核心主機</span>
            <span class="c-tag-green">可用率 99.999%</span>
          </div>
          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>交易響應時間</small>
              <strong style="color:var(--green);">85 <em>ms</em></strong>
              <span class="number-positive">零超時 (0筆)</span>
            </div>
            <div class="c-stat-item">
              <small>月授權交易量</small>
              <strong>6,820 <em>萬筆</em></strong>
              <span>成功率 98.8%</span>
            </div>
          </div>
        </div>

        <!-- Cardlink 核心帳務主機 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>Cardlink 核心帳務主機</span>
            <span class="c-tag-green">SLA 100% 達標</span>
          </div>
          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>月帳務處理量</small>
              <strong>1.42 <em>億筆</em></strong>
              <span>高可靠運作</span>
            </div>
            <div class="c-stat-item">
              <small>系統可用率 / 峰值</small>
              <strong>100.0%</strong>
              <span>峰值 4,850 TPS</span>
            </div>
          </div>
        </div>

        <!-- 三大資安防詐防線成果 (SFM & 3DS) -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>三大資安防詐成果 (SFM & 3DS)</span>
            <span class="cockpit-tag-pill warning">全月防堵 4,280 萬</span>
          </div>

          <!-- Total Banner -->
          <div class="fraud-total-cockpit-bar">
            <div>
              <span>全月總防堵金額</span>
              <strong>4,280 <em>萬元</em></strong>
            </div>
            <div class="divider-v"></div>
            <div>
              <span>阻斷冒用卡數</span>
              <strong>2,684 <em>張</em></strong>
            </div>
          </div>

          <!-- 3-line Breakdown -->
          <div class="fraud-lines-list">
            <div class="f-line-item">
              <span class="f-tag sfm">SFM</span>
              <span class="f-name">申請詐欺防堵</span>
              <span class="f-amt">1,150 萬元</span>
              <span class="f-cnt">842 張</span>
            </div>
            <div class="f-line-item">
              <span class="f-tag tds">3DS</span>
              <span class="f-name">線上交易防堵</span>
              <span class="f-amt">860 萬元</span>
              <span class="f-cnt">620 張</span>
            </div>
            <div class="f-line-item">
              <span class="f-tag sfm">SFM</span>
              <span class="f-name">交易詐欺防堵</span>
              <span class="f-amt">2,270 萬元</span>
              <span class="f-cnt">1,222 張</span>
            </div>
          </div>

          <div class="cockpit-foot-note">
            <span>覆蓋進件審查、線上 3DS 驗證與特店交易，阻斷冒用風險</span>
          </div>
        </div>
      </div>
    </div>
  </section>
"""
    return cockpit_html

print("HTML Generator compiled cleanly.")
