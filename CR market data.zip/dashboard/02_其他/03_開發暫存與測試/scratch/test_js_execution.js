const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('01_儀表板執行環境/credit_card_full_dashboard.html', 'utf-8');
const scriptMatches = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)];

console.log(`Found ${scriptMatches.length} script tags in HTML.`);

// Create mock DOM environment
const elements = {};
const mockDoc = {
  getElementById: (id) => {
    if (!elements[id]) {
      elements[id] = {
        id,
        innerHTML: '',
        textContent: '',
        style: {},
        title: '',
        classList: {
          add: () => {},
          remove: () => {},
          contains: () => false
        },
        getBoundingClientRect: () => ({ width: 1920, height: 1080, top: 0, left: 0, right: 1920, bottom: 1080 })
      };
    }
    return elements[id];
  },
  addEventListener: (event, handler) => {
    console.log(`Registered event listener for: ${event}`);
    if (event === 'DOMContentLoaded') {
      setTimeout(() => {
        try {
          handler();
          console.log('DOMContentLoaded handler executed successfully!');
        } catch (e) {
          console.error('Error in DOMContentLoaded handler:', e);
        }
      }, 10);
    }
  }
};

const sandbox = {
  window: {
    addEventListener: () => {}
  },
  document: mockDoc,
  console: console,
  setTimeout: setTimeout,
  clearTimeout: clearTimeout,
  Number: Number,
  Math: Math,
  JSON: JSON
};

// Load dashboard_data.js first
const jsData = fs.readFileSync('01_儀表板執行環境/dashboard_data.js', 'utf-8');
vm.createContext(sandbox);
vm.runInContext(jsData, sandbox);
console.log('dashboard_data.js loaded successfully. Block01 exists:', !!sandbox.window.DASHBOARD_DATA?.block01, 'Block02 exists:', !!sandbox.window.DASHBOARD_DATA?.block02);

// Now execute the scripts (supporting both inline and external src)
const scriptTagRegex = /<script\b([^>]*)>([\s\S]*?)<\/script>/gi;
let scriptIdx = 0;
for (const match of html.matchAll(scriptTagRegex)) {
  scriptIdx++;
  const attrs = match[1];
  let code = match[2];
  const srcMatch = attrs.match(/src=["']([^"']+)["']/i);
  if (srcMatch) {
    const srcFile = srcMatch[1];
    if (srcFile === 'dashboard_data.js') {
      // Already loaded as data
      continue;
    }
    const srcPath = '01_儀表板執行環境/' + srcFile;
    if (fs.existsSync(srcPath)) {
      code = fs.readFileSync(srcPath, 'utf-8');
      console.log(`Loaded external script tag #${scriptIdx}: ${srcFile}`);
    } else {
      console.error(`External script not found: ${srcPath}`);
      process.exit(1);
    }
  }
  if (!code.trim()) continue;
  try {
    vm.runInContext(code, sandbox);
    console.log(`Script tag #${scriptIdx} executed successfully without syntax error.`);
  } catch (err) {
    console.error(`Script tag #${scriptIdx} failed:`, err);
    process.exit(1);
  }
}

// Wait for DOMContentLoaded
setTimeout(() => {
  console.log('Total mock elements touched:', Object.keys(elements).length);
  // Check some sampled values in Block 02
  console.log('Sample c00-acq-amt-val:', elements['c00-acq-amt-val']?.innerHTML);
  console.log('Sample b02-amt-val:', elements['b02-amt-val']?.innerHTML);
  console.log('Sample b02-top10-share:', elements['b02-top10-share']?.textContent);
  console.log('Sample b02-twqr-pass-rate:', elements['b02-twqr-pass-rate']?.textContent);
  console.log('Sample b02-twqr-tx-amt:', elements['b02-twqr-tx-amt']?.textContent);
  console.log('Sample b02-twqr-tx-cnt:', elements['b02-twqr-tx-cnt']?.textContent);
  console.log('Sample b02-twqr-avg-ticket:', elements['b02-twqr-avg-ticket']?.textContent);

  // Check some sampled values in Block 03
  console.log('Sample c00-iss-apply-val:', elements['c00-iss-apply-val']?.innerHTML);
  console.log('Sample b03-apply-val:', elements['b03-apply-val']?.innerHTML);
  console.log('Sample b03-ebill-growth:', elements['b03-ebill-growth']?.innerHTML?.replace(/\s+/g, ' '));
  console.log('Sample b03-bonus-rate-growth:', elements['b03-bonus-rate-growth']?.innerHTML?.replace(/\s+/g, ' '));
  console.log('Sample b03-bonus-bal-val:', elements['b03-bonus-bal-val']?.innerHTML);
  console.log('Sample c00-iss-bonus-tag:', elements['c00-iss-bonus-tag']?.textContent);
  console.log('Sample b03-bonus-net-pill:', elements['b03-bonus-net-pill']?.textContent);
  console.log('Sample b03-bonus-redeem-pill:', elements['b03-bonus-redeem-pill']?.textContent);
  console.log('Sample b03-inst-val:', elements['b03-inst-val']?.innerHTML);
  console.log('Sample b03-app-rate-val:', elements['b03-app-rate-val']?.textContent);
  console.log('Sample b03-bill-tot-val:', elements['b03-bill-tot-val']?.innerHTML);
  console.log('Sample b03-tab0-pass-tot-val:', elements['b03-tab0-pass-tot-val']?.innerHTML);
  console.log('Sample b03-tab0-old-pass-rate:', elements['b03-tab0-old-pass-rate']?.textContent);
  console.log('Sample b03-tab0-new-pass-rate:', elements['b03-tab0-new-pass-rate']?.textContent);
  console.log('Sample b03-inst-p1-amt:', elements['b03-inst-p1-amt']?.textContent);
  console.log('Sample c00-iss-bill-card-head:', elements['c00-iss-bill-card-head']?.textContent);
  console.log('Sample c00-iss-bill-card-dig-val:', elements['c00-iss-bill-card-dig-val']?.innerHTML);
  console.log('Sample c00-iss-bill-card-phy-val:', elements['c00-iss-bill-card-phy-val']?.innerHTML);
  console.log('Sample c00-iss-bill-bank-head:', elements['c00-iss-bill-bank-head']?.textContent);
  console.log('Sample c00-iss-bill-bank-dig-val:', elements['c00-iss-bill-bank-dig-val']?.innerHTML);
  console.log('Sample c00-iss-bill-bank-phy-val:', elements['c00-iss-bill-bank-phy-val']?.innerHTML);
  console.log('Sample c00-iss-bill-tag:', elements['c00-iss-bill-tag']?.textContent);
  console.log('Sample b03-loss-net-val:', elements['b03-loss-net-val']?.textContent);

  // Check some sampled values in Block 04
  console.log('Sample c00-cp-resp-val:', elements['c00-cp-resp-val']?.innerHTML);
  console.log('Sample b04-cp-resp-val:', elements['b04-cp-resp-val']?.innerHTML);
  console.log('Sample b04-cp-vol-val:', elements['b04-cp-vol-val']?.innerHTML);
  console.log('Sample b04-cl-time-val:', elements['b04-cl-time-val']?.innerHTML);
  console.log('Sample c00-fr-amt-val:', elements['c00-fr-amt-val']?.innerHTML);
  console.log('Sample b04-fr-amt-val:', elements['b04-fr-amt-val']?.innerHTML);
  console.log('Sample b04-fr-sfm-amt:', elements['b04-fr-sfm-amt']?.innerHTML);
  console.log('Sample c00-bms-c1-val:', elements['c00-bms-c1-val']?.innerHTML);
  console.log('Sample b04-ms-c1-val:', elements['b04-ms-c1-val']?.innerHTML);
  console.log('Sample b04-events-table-body length:', elements['b04-events-table-body']?.innerHTML?.length);
  console.log('Sample b04-fraud-table-body length:', elements['b04-fraud-table-body']?.innerHTML?.length);
  console.log('Sample b04-fraud-svg-wrapper length:', elements['b04-fraud-svg-wrapper']?.innerHTML?.length);
  console.log('Sample b04-ms-bars-svg-wrapper length:', elements['b04-ms-bars-svg-wrapper']?.innerHTML?.length);
  console.log('Sample b04-tps-rank-list length:', elements['b04-tps-rank-list']?.innerHTML?.length);

  // Stress-test: Call renderBlock03FromData with empty block03
  try {
    sandbox.renderBlock03FromData({ block03: { monthly_kpis: {}, application_approval: {}, billing_center: {}, bonus_points: {}, installment_structure: {}, collection_asset: {} } });
    console.log('Null-fallback stress test Block 03 passed! Sample empty b03-apply-val:', elements['b03-apply-val']?.innerHTML);
    console.log('Sample empty b03-loss-net-val:', elements['b03-loss-net-val']?.textContent);

    sandbox.renderBlock04FromData({ block04: { monthly_kpis: {}, cloud_events: [], fraud_defense: {}, microservices: {} } });
    console.log('Null-fallback stress test Block 04 passed! Sample empty b04-cp-resp-val:', elements['b04-cp-resp-val']?.innerHTML);
    console.log('Sample empty b04-fr-amt-val:', elements['b04-fr-amt-val']?.innerHTML);
    console.log('Sample empty b04-ms-c1-val:', elements['b04-ms-c1-val']?.innerHTML);
  } catch (err) {
    console.error('Error during null-fallback stress test:', err);
    process.exit(1);
  }

  console.log('Simulation completed with ZERO ERRORS!');
}, 50);
