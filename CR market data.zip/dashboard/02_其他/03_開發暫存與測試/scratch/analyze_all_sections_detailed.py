import sys
from bs4 import BeautifulSoup

with open('credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    soup = BeautifulSoup(f, 'html.parser')

def analyze_section(sec_id, output_path):
    sec = soup.find('section', id=sec_id)
    if not sec:
        print(f"Not found: {sec_id}")
        return
    with open(output_path, 'w', encoding='utf-8') as out:
        out.write(f"=== FULL DETAILED ANALYSIS OF {sec_id} ===\n\n")
        # Find all cards, panels, tabs, tables
        # Let's inspect all elements that contain text
        for el in sec.find_all(True):
            cls = ' '.join(el.get('class', []))
            # If tag has direct text
            direct_text = ' '.join([c.strip() for c in el.contents if isinstance(c, str) and c.strip()])
            title = el.get('title', '')
            data_target = el.get('data-target', '')
            
            # Write key elements
            if direct_text or title:
                out.write(f"<{el.name} class='{cls}'")
                if title:
                    out.write(f" title='{title}'")
                if data_target:
                    out.write(f" data-target='{data_target}'")
                out.write(f">: {direct_text}\n")

analyze_section('section-overview', 'scratch/sec01_detail.txt')
analyze_section('section-acquiring', 'scratch/sec02_detail.txt')
analyze_section('section-issuing', 'scratch/sec03_detail.txt')
analyze_section('section-resilience', 'scratch/sec04_detail.txt')
print("Analyzed all 4 sections!")
