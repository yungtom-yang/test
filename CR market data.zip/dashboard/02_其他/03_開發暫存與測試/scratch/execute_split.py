# -*- coding: utf-8 -*-
"""
execute_split.py
Safely performs the 1:1 physical extraction of CSS into dashboard.css
and JS into dashboard_app.js, updating credit_card_full_dashboard.html.
"""
import os
import shutil

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, "..", "..", ".."))
ENV_DIR = os.path.join(PROJECT_ROOT, "01_儀表板執行環境")

HTML_SOURCE = os.path.join(ENV_DIR, "credit_card_full_dashboard.html")

with open(HTML_SOURCE, "r", encoding="utf-8") as f:
    lines = f.readlines()

# Locate <style> and </style>
style_start = None
style_end = None
for i, line in enumerate(lines):
    if "<style>" in line and style_start is None:
        style_start = i
    if "</style>" in line and style_end is None and style_start is not None:
        style_end = i
        break

assert style_start is not None, "Could not find <style> tag"
assert style_end is not None, "Could not find </style> tag"
print(f"CSS detected from line {style_start + 1} to {style_end + 1}")

# Locate <script> (after </main>) and </script>
script_start = None
script_end = None
for i in range(style_end + 1, len(lines)):
    if "<script>" in lines[i] and script_start is None:
        script_start = i
    if "</script>" in lines[i] and script_start is not None:
        script_end = i

assert script_start is not None, "Could not find inline <script> tag"
assert script_end is not None, "Could not find inline </script> tag"
print(f"JS detected from line {script_start + 1} to {script_end + 1}")

# Extract CSS
css_lines = lines[style_start + 1:style_end]
css_content = "".join(css_lines)

# Extract JS
js_lines = lines[script_start + 1:script_end]
js_content = "".join(js_lines)

# Build refactored HTML
# 1. Before style
part1 = lines[:style_start]
# 2. Link tag
link_line = ['  <link rel="stylesheet" href="dashboard.css" />\n']
# 3. Between style and script
part2 = lines[style_end + 1:script_start]
# 4. Script tag
script_line = ['<script src="dashboard_app.js"></script>\n']
# 5. After script
part3 = lines[script_end + 1:]

refactored_html_lines = part1 + link_line + part2 + script_line + part3
refactored_html_content = "".join(refactored_html_lines)

print(f"Original HTML total lines: {len(lines)}")
print(f"Extracted CSS total lines: {len(css_lines)}")
print(f"Extracted JS total lines:  {len(js_lines)}")
print(f"Refactored HTML total lines: {len(refactored_html_lines)}")

# Save to 01_儀表板執行環境
css_env_path = os.path.join(ENV_DIR, "dashboard.css")
js_env_path = os.path.join(ENV_DIR, "dashboard_app.js")
html_env_path = os.path.join(ENV_DIR, "credit_card_full_dashboard.html")

with open(css_env_path, "w", encoding="utf-8") as f:
    f.write(css_content)

with open(js_env_path, "w", encoding="utf-8") as f:
    f.write(js_content)

with open(html_env_path, "w", encoding="utf-8") as f:
    f.write(refactored_html_content)

# Mirror to root directory
css_root_path = os.path.join(PROJECT_ROOT, "dashboard.css")
js_root_path = os.path.join(PROJECT_ROOT, "dashboard_app.js")
html_root_path = os.path.join(PROJECT_ROOT, "credit_card_full_dashboard.html")

shutil.copyfile(css_env_path, css_root_path)
shutil.copyfile(js_env_path, js_root_path)
shutil.copyfile(html_env_path, html_root_path)

print("SUCCESS: Splitting completed and mirrored to both directories!")
