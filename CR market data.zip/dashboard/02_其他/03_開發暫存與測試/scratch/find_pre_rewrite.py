# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

transcript_path = 'C:/Users/詠棠/.gemini/antigravity/brain/b95ecca9-971a-489b-ab53-ec5e0dbbb3cb/.system_generated/logs/transcript_full.jsonl'
with open(transcript_path, 'r', encoding='utf-8') as f:
    for line in f:
        obj = json.loads(line)
        idx = obj.get('step_index')
        calls = obj.get('tool_calls', [])
        for c in calls:
            args = c.get('args', {})
            content = args.get('CodeContent', '')
            if 'SECTION 01:' in content and idx < 350:
                print(f"Step {idx} has full build_dashboard.py!")
                for l in content.splitlines()[:100]:
                    print(l)
