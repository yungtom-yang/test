# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import re

with open('scratch/page.tsx', 'r', encoding='utf-8', errors='ignore') as f:
    text = f.read()

for m in re.finditer(r'<div className="block-label[^"]*">.*?</div></div>', text):
    print(m.group(0))

print("\n--- Check all labels and headers in page.tsx ---")
for m in re.finditer(r'<(div|header|section|h2|h3)[^>]*>(.*?)<\/\1>', text):
    s = m.group(0)
    if any(k in s for k in ['01', '02', '03', '1A', '1B', '2A', '2B', '2C', '3A', '3B', '3C']):
        print(s[:100])
