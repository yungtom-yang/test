# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

transcript_path = 'C:/Users/詠棠/.gemini/antigravity/brain/b95ecca9-971a-489b-ab53-ec5e0dbbb3cb/.system_generated/logs/transcript_full.jsonl'
with open(transcript_path, 'r', encoding='utf-8') as f:
    for line in f:
        obj = json.loads(line)
        idx = obj.get('step_index')
        calls = obj.get('tool_calls', [])
        for c in calls:
            args = c.get('args', {})
            content = args.get('CodeContent', '') or args.get('ReplacementContent', '')
            if 'block-label' in content:
                for l in content.splitlines():
                    if 'block-label' in l or '<span>1A' in l or '<span>2A' in l or '<span>3A' in l or '<span>4A' in l:
                        print(f"Step {idx}: {l.strip()}")
