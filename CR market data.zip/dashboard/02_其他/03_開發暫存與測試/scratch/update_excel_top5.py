# -*- coding: utf-8 -*-
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

EXCEL_FILE = "01_儀表板執行環境/dashboard_data.xlsx"
wb = openpyxl.load_workbook(EXCEL_FILE)

# Identify sheet 2
target_sheet = None
for sname in wb.sheetnames:
    if "四大行" in sname or "五大行" in sname or sname == wb.sheetnames[1]:
        target_sheet = wb[sname]
        break

if target_sheet is None:
    target_sheet = wb.sheetnames[1]

target_sheet.title = "01_五大行簽帳市占"
ws = target_sheet

# Formatting definitions
title_font = Font(name="Microsoft JhengHei", size=14, bold=True, color="1E3A8A")
note_font = Font(name="Microsoft JhengHei", size=9, italic=True, color="64748B")
header_font = Font(name="Microsoft JhengHei", size=11, bold=True, color="FFFFFF")
header_fill_green = PatternFill(start_color="065F46", end_color="065F46", fill_type="solid")

data_font = Font(name="Microsoft JhengHei", size=10)
bold_data_font = Font(name="Microsoft JhengHei", size=10, bold=True)

thin_border = Border(
    left=Side(style='thin', color='E2E8F0'),
    right=Side(style='thin', color='E2E8F0'),
    top=Side(style='thin', color='E2E8F0'),
    bottom=Side(style='thin', color='E2E8F0')
)

align_center = Alignment(horizontal="center", vertical="center")
align_left = Alignment(horizontal="left", vertical="center")
align_right = Alignment(horizontal="right", vertical="center")

# Clear existing content
for r in range(1, 20):
    for c in range(1, 10):
        cell = ws.cell(row=r, column=c)
        cell.value = None
        cell.fill = PatternFill(fill_type=None)
        cell.border = Border()

# Set Header rows
ws['A1'] = "國泰世華銀行 信用卡營運儀表板 - 五大發卡行簽帳金額 (戰情室圓餅圖)"
ws['A1'].font = title_font
ws['A2'] = "說明：維護五大發卡行（中信、國泰、富邦、玉山、台新）簽帳金額與成長率。五大行簽帳總額由系統自動加總，並計算五大行佔比與繪製 SVG 圓餅圖。無全市場與其他同業。"
ws['A2'].font = note_font

headers = ["發卡銀行", "簽帳金額 (億元)", "佔比 (%)", "YoY (%)", "代表色碼 (HEX)", "是否為本行", "備註"]
for col_num, h_text in enumerate(headers, 1):
    cell = ws.cell(row=4, column=col_num, value=h_text)
    cell.font = header_font
    cell.fill = header_fill_green
    cell.alignment = align_center
    cell.border = thin_border

rows_data = [
    ["中國信託", 5980, 25.0, 11.2, "#003b5c", "否", "第一大行"],
    ["國泰世華", 5726, 23.9, 12.8, "#009e73", "是", "本行 (綠色高亮顯示)"],
    ["台北富邦", 4450, 18.6, 18.4, "#2563eb", "否", "Costco 卡主力"],
    ["玉山銀行", 4320, 18.0, 9.6, "#059669", "否", "第四大行"],
    ["台新銀行", 3480, 14.5, 11.8, "#ea580c", "否", "第五大行 (Richart/玫瑰卡主力)"]
]

for r_idx, row in enumerate(rows_data, start=5):
    for c_idx, val in enumerate(row, start=1):
        cell = ws.cell(row=r_idx, column=c_idx, value=val)
        cell.font = bold_data_font if c_idx in [1, 2] else data_font
        cell.border = thin_border
        if c_idx in [1, 5, 6]:
            cell.alignment = align_center
        elif c_idx in [2, 3, 4]:
            cell.alignment = align_right
            if isinstance(val, (int, float)):
                cell.number_format = "#,##0.0" if isinstance(val, float) else "#,##0"
        else:
            cell.alignment = align_left

col_widths = {1: 16, 2: 18, 3: 14, 4: 14, 5: 18, 6: 14, 7: 36}
for col_idx, width in col_widths.items():
    ws.column_dimensions[get_column_letter(col_idx)].width = width

wb.save(EXCEL_FILE)
print("Successfully updated Sheet 2 in dashboard_data.xlsx to '01_五大行簽帳市占' with 5 major banks!")
