import re

with open('credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Check JS functions and element IDs
called_ids = re.findall(r'getElementById\(["\']([^"\']+)["\']\)', html)
query_selectors = re.findall(r'querySelectorAll\(["\']([^"\']+)["\']\)', html)

print('IDs accessed by getElementById:')
for cid in set(called_ids):
    exists = f'id="{cid}"' in html or f"id='{cid}'" in html
    print(f'  - {cid}: {"EXISTS" if exists else "MISSING!"}')

# Check tabs
print('\nMain section targets in nav-tab-btn:')
targets = re.findall(r'data-target=["\']([^"\']+)["\']', html)
for t in set(targets):
    exists = f'id="{t}"' in html
    print(f'  - {t}: {"EXISTS" if exists else "MISSING!"}')

# Check onclick targets
onclicks = re.findall(r'switchMainSection\(["\']([^"\']+)["\']\)', html)
print('\nswitchMainSection call targets:')
for oc in set(onclicks):
    exists = f'id="{oc}"' in html
    print(f'  - {oc}: {"EXISTS" if exists else "MISSING!"}')

print('\nCheck tabs for each block:')
for block, count, prefix in [('Acquiring', 3, 'acq-tab-'), ('Issuing', 4, 'iss-tab-'), ('System', 3, 'sys-tab-')]:
    print(f'Checking {block} tabs (count={count}):')
    for i in range(count):
        tab_id = f'{prefix}{i}'
        exists = f'id="{tab_id}"' in html
        print(f'  - {tab_id}: {"EXISTS" if exists else "MISSING!"}')

