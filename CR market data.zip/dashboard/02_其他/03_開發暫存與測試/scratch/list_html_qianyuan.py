import re, sys
sys.stdout.reconfigure(encoding='utf-8')

with open('01_儀表板執行環境/credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    for i, line in enumerate(f, 1):
        if '千元' in line:
            print(f"L{i}: {line.strip()}")
