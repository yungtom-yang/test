import re

with open('01_儀表板執行環境/credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Extract renderBlock02FromData body
func_match = re.search(r'function renderBlock02FromData\(data\)\s*\{(.*?)\n  \}', html, re.DOTALL)
if not func_match:
    print('Could not find renderBlock02FromData')
    exit(1)

func_body = func_match.group(1)
ids_in_func = sorted(list(set(re.findall(r'document\.getElementById\(["\']([^"\']+)["\']\)', func_body))))
print(f'Total unique IDs accessed by renderBlock02FromData: {len(ids_in_func)}')

missing_ids = [i for i in ids_in_func if f'id="{i}"' not in html]
print(f'Missing IDs in HTML: {len(missing_ids)}')
if missing_ids:
    print('Missing:', missing_ids)
else:
    print('ALL IDs ACCESSED BY renderBlock02FromData EXIST IN HTML! PERFECT!')

for idx, i in enumerate(ids_in_func, 1):
    print(f"  {idx}. {i}")
