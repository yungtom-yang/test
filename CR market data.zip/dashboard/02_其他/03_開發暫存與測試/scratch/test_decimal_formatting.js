const sampleStrings = [
  '1,286.4 億元',
  'YoY +12.8% MoM +2.1%',
  '(84.4%)',
  '1,086.4億',
  '(15.6%)',
  '200.0億',
  '8,425 萬筆',
  '(92.0%)',
  '7,750萬筆',
  '18.6 億元',
  'YoY -3.4% (42.8萬筆)',
  '325.7 億元',
  'YoY +6.7%',
  '24,262 億元',
  'YoY +16.8%',
  '26.6%',
  '+25.9%',
  '239.41 億元',
  '審查通過率 91.2%',
  'MoM +5.8%',
  '130,620 元',
  '78.5%',
  '468.6 萬份 (佔 88.2%)',
  '318.3萬份',
  '淨增存量 +0.6 百萬點',
  '淨增存量 +1537.6 百萬點',
  '15.2',
  '17.9',
  '+2.4',
  '-3.2',
  '1.42 億筆',
  '100.0%',
  '峰值 4,850 TPS',
  '11,516.57 萬次',
  '85 ms'
];

sampleStrings.forEach(text => {
  // Only match numbers that are NOT followed by % or pp
  const regex = /(\d+)\.(\d+)(?!\s*(%|pp))/g;
  let res = '';
  let lastIndex = 0;
  let match;
  while ((match = regex.exec(text)) !== null) {
    const matchStart = match.index;
    const intPart = match[1];
    const decDigits = match[2];
    res += text.substring(lastIndex, matchStart) + intPart + `<span class="decimal-part">.${decDigits}</span>`;
    lastIndex = regex.lastIndex;
  }
  res += text.substring(lastIndex);
  console.log(text, '-->', res);
});
