import sys
from bs4 import BeautifulSoup
import re

with open('credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    soup = BeautifulSoup(f, 'html.parser')

def analyze_section_blocks(sec_id, out_name):
    sec = soup.find('section', id=sec_id)
    if not sec:
        print(f"Missing {sec_id}")
        return
    with open(out_name, 'w', encoding='utf-8') as out:
        out.write(f"=== {sec_id} NUMBERS & SPANS ===\n")
        # walk through children
        for tag in sec.find_all(True):
            title = tag.get('title', '')
            t = tag.get_text(strip=True)
            # find all leaf nodes or nodes with direct text
            direct_text = ' '.join([c.strip() for c in tag.contents if isinstance(c, str) and c.strip()])
            cls = ' '.join(tag.get('class', []))
            
            # If tag is a leaf or has direct text or has title
            if title or direct_text:
                if re.search(r'\d', direct_text) or re.search(r'\d', title) or any(k in cls for k in ['title', 'label', 'badge', 'note', 'hint', 'growth', 'val', 'name', 'status']):
                    out.write(f"[{tag.name}.{cls}] text='{direct_text}' | title='{title}' | full='{t[:60]}'\n")

analyze_section_blocks('section-cockpit', 'scratch/scan_cockpit.txt')
analyze_section_blocks('section-overview', 'scratch/scan_01.txt')
analyze_section_blocks('section-acquiring', 'scratch/scan_02.txt')
analyze_section_blocks('section-issuing', 'scratch/scan_03.txt')
analyze_section_blocks('section-resilience', 'scratch/scan_04.txt')
print("Scan complete!")
