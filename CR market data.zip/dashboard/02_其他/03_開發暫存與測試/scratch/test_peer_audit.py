import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('01_儀表板執行環境/dashboard_data.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

benchmarks = data['block01']['peer_benchmark']

print("=" * 80)
print(f"{'指標名稱':<12} | {'模式':<8} | {'本行數據':<14} | {'五家基準(平均/YoY)':<18} | {'差距/Gap':<12} | {'佔比/變化':<12}")
print("=" * 80)

for cat in benchmarks:
    for metric in cat['metrics']:
        label = metric['label']
        unit = metric['unit']
        is_quality = (metric['summaryMode'] == 'quality')
        peers = metric['peers']
        cathay = next((p for p in peers if p['bank'] == '國泰世華'), None)
        valid_peers = [p for p in peers if p['value'] is not None]

        if is_quality:
            dec = metric.get('decimals', 1)
            if dec is None: dec = 1
            cathay_val = f"{cathay['value']:.{dec}f}{unit}"
            five_avg_num = sum(p['value'] for p in valid_peers) / len(valid_peers)
            five_avg = f"{five_avg_num:.{dec}f}{unit}"
            diff_num = cathay['value'] - five_avg_num
            diff = f"{'+' if diff_num > 0 else ''}{diff_num:.{dec}f}{'pp' if unit == '%' else unit}"
            yoy_chg = f"{'+' if cathay['yoy'] > 0 else ''}{cathay['yoy']:.1f}pp"
            print(f"{label:<12} | {'Quality':<8} | 本行: {cathay_val:<9} | 五家均: {five_avg:<12} | 差距: {diff:<8} | YoY: {yoy_chg:<8}")
        else:
            cathay_yoy = f"{'+' if cathay['yoy'] > 0 else ''}{cathay['yoy']:.1f}%"
            # 5-bank weighted YoY:
            five_total = sum(p['value'] for p in valid_peers)
            five_prev = sum(p['value'] / (1 + p['yoy'] / 100) for p in valid_peers)
            five_yoy_num = ((five_total - five_prev) / five_prev) * 100
            five_yoy = f"{'+' if five_yoy_num > 0 else ''}{five_yoy_num:.1f}%"
            gap_num = cathay['yoy'] - five_yoy_num
            gap = f"{'+' if gap_num > 0 else ''}{gap_num:.1f}pp"
            share_num = (cathay['value'] / five_total) * 100
            share = f"{share_num:.1f}%"
            print(f"{label:<12} | {'Growth':<8} | YoY: {cathay_yoy:<10} | 五家YoY: {five_yoy:<10} | Gap: {gap:<9} | 佔比: {share:<8}")
print("=" * 80)
