# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')

# Read current build_dashboard.py
with open('scratch/build_dashboard.py', 'r', encoding='utf-8') as f:
    code = f.read()

# 1. Define Cockpit CSS
cockpit_css = """
/* SECTION 00: COCKPIT VIEWPORT STYLING (ZERO SCROLL FIT) */
#section-cockpit {
  padding-bottom: 0;
}
.cockpit-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
  padding: 12px;
  background: var(--orange-soft);
  border: 1px solid var(--line);
  border-radius: 12px;
  height: calc(100vh - 165px);
  min-height: 600px;
  box-sizing: border-box;
}

@media (max-height: 800px) {
  .cockpit-grid {
    height: auto;
    min-height: 560px;
  }
}

.cockpit-col {
  background: #ffffff;
  border: 1px solid #d8e5e0;
  border-radius: 8px;
  padding: 10px 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  box-shadow: 0 1px 4px rgba(0,0,0,0.03);
}

.cockpit-col-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #e5ece9;
  padding-bottom: 6px;
}
.c-header-left {
  display: flex;
  align-items: center;
  gap: 6px;
}
.cockpit-badge {
  font-size: 11px;
  font-weight: 800;
  padding: 2px 6px;
  border-radius: 4px;
  color: #fff;
  letter-spacing: 0.02em;
}
.c-badge-orange { background: var(--orange); }
.c-badge-blue { background: var(--blue); }
.c-badge-dark { background: var(--blue-dark); }

.cockpit-col-header h3 {
  font-size: 13.5px;
  margin: 0;
  color: var(--ink);
  font-weight: 800;
  letter-spacing: -0.01em;
}
.cockpit-link-btn {
  background: none;
  border: 1px solid #cbd9df;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 700;
  color: var(--blue);
  padding: 2px 7px;
  cursor: pointer;
  transition: all 0.15s ease;
}
.cockpit-link-btn:hover {
  background: var(--blue);
  color: #fff;
  border-color: var(--blue);
}

.cockpit-subbox {
  background: #f8fafb;
  border: 1px solid #e6eeec;
  border-radius: 6px;
  padding: 8px 10px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.cockpit-subbox.flex-grow {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.cockpit-box-title {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 11.5px;
  font-weight: 800;
  color: #43555f;
}
.cockpit-tag-pill {
  font-size: 10px;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 10px;
  background: #e8eff2;
  color: #43555f;
}
.cockpit-tag-pill.primary { background: #eef5ff; color: var(--blue); }
.cockpit-tag-pill.warning { background: #fff7e7; color: #b8781c; }
.c-tag-green {
  font-size: 10.5px;
  font-weight: 800;
  color: var(--green);
  background: #eaf7f2;
  padding: 1px 5px;
  border-radius: 4px;
}

.cockpit-kpi-quad {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
}
.c-kpi-card {
  background: #ffffff;
  border: 1px solid #e1ebe7;
  border-radius: 5px;
  padding: 6px 8px;
  display: flex;
  flex-direction: column;
}
.c-kpi-card.highlight-glow {
  border-color: #b5e4d2;
  background: #fafdfc;
}
.c-kpi-title {
  font-size: 11px;
  color: #5a6d75;
  font-weight: 700;
}
.c-kpi-val {
  font-size: 18px;
  font-weight: 900;
  color: var(--ink);
  line-height: 1.15;
  margin: 2px 0;
  font-variant-numeric: tabular-nums;
}
.c-kpi-val em {
  font-size: 11px;
  font-weight: 600;
  font-style: normal;
  color: #72848c;
  margin-left: 2px;
}
.c-kpi-growth {
  font-size: 10.5px;
  display: flex;
  gap: 4px;
  align-items: center;
}
.c-kpi-sub {
  color: #7d8f96;
  font-size: 10.5px;
}

/* Peer Market Share Stacked Bar */
.market-stacked-bar {
  display: flex;
  height: 12px;
  border-radius: 6px;
  overflow: hidden;
  background: #e2e8f0;
  margin: 4px 0;
}
.market-bar-seg {
  height: 100%;
  transition: width 0.3s;
}
.market-bar-seg:nth-child(1) { background: #003b5c; }
.market-bar-seg:nth-child(2) { background: var(--green); }
.market-bar-seg:nth-child(3) { background: #5d7a88; }
.market-bar-seg:nth-child(4) { background: #94a3b8; }
.market-bar-seg:nth-child(5) { background: #cbd5e1; }

.cockpit-peer-list {
  display: flex;
  flex-direction: column;
  gap: 3px;
  margin-top: 4px;
}
.cockpit-peer-row {
  display: grid;
  grid-template-columns: 20px 58px 1fr 42px 46px;
  align-items: center;
  font-size: 11px;
  padding: 3px 6px;
  border-radius: 4px;
  background: #fff;
  border: 1px solid #edf2f0;
}
.cockpit-peer-row.highlight {
  background: #f0f9f5;
  border-color: #b5e4d2;
  font-weight: 800;
  color: var(--green);
}
.p-rank { font-weight: 800; color: #62757d; font-size: 10px; }
.p-name { font-weight: 700; color: var(--ink); }
.p-val { text-align: right; color: #4b5d66; font-variant-numeric: tabular-nums; }
.p-share { text-align: right; color: var(--ink); }
.p-yoy { text-align: right; font-size: 10px; font-weight: 700; }

.cockpit-foot-note {
  font-size: 10.5px;
  color: #61737a;
  background: #ffffff;
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid #e5ece9;
  text-align: center;
  margin-top: 4px;
}
.cockpit-foot-note b { color: var(--orange-dark); }

.c-mini-stat-banner {
  display: flex;
  align-items: center;
  justify-content: space-around;
  background: #fff;
  border: 1px solid #e2ebe6;
  border-radius: 5px;
  padding: 6px 8px;
}
.c-mini-stat-banner small {
  font-size: 10px;
  color: #61737a;
  display: block;
}
.c-mini-stat-banner strong {
  font-size: 16px;
  font-weight: 900;
  color: var(--ink);
  display: block;
  margin: 1px 0;
}
.c-mini-stat-banner strong em {
  font-size: 10.5px;
  font-style: normal;
  color: #72848c;
}
.divider-v {
  width: 1px;
  height: 32px;
  background: #e2ebe6;
  margin: 0 6px;
}
.c-split-bar {
  display: flex;
  height: 15px;
  border-radius: 3px;
  overflow: hidden;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  text-align: center;
  line-height: 15px;
  margin: 2px 0;
}
.bar-phys { background: var(--blue); }
.bar-onl { background: var(--orange); }
.c-foot-hint { font-size: 9.5px; color: #72848c; display: block; text-align: center; }

.twqr-cockpit-section {
  background: #fff;
  border: 1px solid #e2ebe6;
  border-radius: 5px;
  padding: 6px 8px;
}
.twqr-subhead {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 10.5px;
  color: var(--blue-dark);
  font-weight: 800;
  margin-bottom: 4px;
}
.c-twqr-stat-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
}
.c-twqr-stat-grid.three-col {
  grid-template-columns: 1fr 1fr 1fr;
}
.c-twqr-cell {
  background: #f8fafb;
  border: 1px solid #edf2f0;
  border-radius: 4px;
  padding: 4px 6px;
  text-align: center;
}
.c-twqr-cell span {
  font-size: 9.5px;
  color: #6b7e86;
  display: block;
  font-weight: 700;
  white-space: nowrap;
}
.c-twqr-cell strong {
  font-size: 14.5px;
  font-weight: 900;
  color: var(--ink);
  display: block;
  margin: 1px 0;
  font-variant-numeric: tabular-nums;
}
.c-twqr-cell strong em {
  font-size: 9.5px;
  font-style: normal;
  color: #7c8e96;
  font-weight: 600;
}
.c-twqr-cell b {
  font-size: 9.5px;
  font-weight: 800;
  display: block;
  white-space: nowrap;
}

.c-stat-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
}
.c-stat-row.compact {
  gap: 4px;
}
.c-stat-item {
  background: #fff;
  border: 1px solid #e2ebe6;
  border-radius: 5px;
  padding: 5px 7px;
}
.c-stat-item.highlight-box {
  background: #f5fcf9;
  border-color: #b5e4d2;
}
.c-stat-item small {
  font-size: 9.5px;
  color: #667982;
  display: block;
  font-weight: 700;
}
.c-stat-item strong {
  font-size: 14.5px;
  font-weight: 900;
  color: var(--ink);
  display: block;
  margin: 1px 0;
  font-variant-numeric: tabular-nums;
}
.c-stat-item strong em {
  font-size: 9.5px;
  font-style: normal;
  color: #7c8e96;
  font-weight: 600;
}
.c-stat-item span {
  font-size: 9.5px;
  color: #62757d;
  font-weight: 600;
  display: block;
}

.c-progress-bar-wrap {
  display: flex;
  height: 13px;
  border-radius: 3px;
  overflow: hidden;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  text-align: center;
  line-height: 13px;
  margin-top: 3px;
}
.c-progress-fill { background: var(--green); }
.c-progress-rest { background: #cbd5e1; color: #475569; }

.fraud-total-cockpit-bar {
  display: flex;
  align-items: center;
  justify-content: space-around;
  border: 1px solid #fed7aa;
  border-radius: 5px;
  padding: 5px 8px;
  background: #fffcf8;
}
.fraud-total-cockpit-bar span {
  font-size: 9.5px;
  color: #78350f;
  font-weight: 700;
  display: block;
}
.fraud-total-cockpit-bar strong {
  font-size: 15.5px;
  font-weight: 900;
  color: #c2410c;
  display: block;
  margin-top: 1px;
}
.fraud-total-cockpit-bar strong em {
  font-size: 9.5px;
  font-style: normal;
  font-weight: 600;
}
.fraud-lines-list {
  display: flex;
  flex-direction: column;
  gap: 3px;
  margin-top: 3px;
}
.f-line-item {
  display: grid;
  grid-template-columns: 28px 1fr 62px 46px;
  align-items: center;
  font-size: 10px;
  padding: 3px 5px;
  background: #fff;
  border: 1px solid #edf2f0;
  border-radius: 4px;
}
.f-tag {
  font-size: 8.5px;
  font-weight: 900;
  padding: 1px 3px;
  border-radius: 2px;
  text-align: center;
  color: #fff;
}
.f-tag.sfm { background: var(--orange-dark); }
.f-tag.tds { background: var(--blue); }
.f-name { font-weight: 700; color: var(--ink); padding-left: 3px; }
.f-amt { text-align: right; font-weight: 800; color: var(--orange-dark); }
.f-cnt { text-align: right; color: #62757d; font-size: 9.5px; }
"""

# Insert cockpit_css into extra_css
marker_css = '/* Unified Bottom Insights 4-Card Strip (Block 01, 04) */'
if marker_css in code:
    code = code.replace(marker_css, cockpit_css + "\n" + marker_css)
else:
    print("WARNING: marker_css not found!")

# 2. Add render_cockpit_section function
render_fn = '''
def render_cockpit_section(d):
    b1 = d["block01_overview"]
    b2 = d["block02_acquiring"]
    b3 = d["block03_issuing"]
    b4 = d["block04_resilience"]

    kpis_01 = {c["title"]: c for c in b1["kpis"]}
    amt = kpis_01.get("總交易金額", {})
    cnt = kpis_01.get("總交易筆數", {})
    cash = kpis_01.get("預借現金金額", {})
    revolving = kpis_01.get("循環信用餘額", {})

    peers_list = [
        {"name": "中國信託", "val": 5980.0, "share": 19.5, "yoy": "+11.2%", "rank": 1, "is_me": False},
        {"name": "國泰世華", "val": 5726.0, "share": 18.6, "yoy": "+12.8%", "rank": 2, "is_me": True},
        {"name": "台北富邦", "val": 4450.0, "share": 14.5, "yoy": "+18.4%", "rank": 3, "is_me": False},
        {"name": "玉山銀行", "val": 4320.0, "share": 14.1, "yoy": "+9.6%", "rank": 4, "is_me": False},
        {"name": "其他同業", "val": 10244.0, "share": 33.3, "yoy": "+8.9%", "rank": 5, "is_me": False}
    ]

    peer_bars_html = "".join([f\'\'\'
      <div class="market-bar-seg" style="width: {p["share"]}%;" title="{p["name"]}: {p["val"]:,.0f} 億 ({p["share"]}%)"></div>\'\'\' for p in peers_list])

    peer_rows_html = "".join([f\'\'\'
      <div class="cockpit-peer-row {\'highlight\' if p[\'is_me\'] else \'\'}">
        <span class="p-rank">#{p[\'rank\']}</span>
        <span class="p-name">{p[\'name\']}</span>
        <span class="p-val">{p[\'val\']:,.0f} 億</span>
        <span class="p-share"><b>{p[\'share\']}%</b></span>
        <span class="p-yoy number-positive">{p[\'yoy\']}</span>
      </div>\'\'\' for p in peers_list[:4]])

    return f\'\'\'
  <!-- ========================================================
       SECTION 00: 決策指揮總覽 (SINGLE-VIEWPORT NO-SCROLL COCKPIT)
       ======================================================== -->
  <section id="section-cockpit" class="dashboard-section main-section active">
    <div class="section-title section-orange">
      <span>00</span>
      <h2>信用卡營運與系統決策總覽</h2>
      <i></i>
    </div>

    <div class="cockpit-grid">
      <!-- COLUMN 1: 01 全行概況 & 市場對標 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <div class="c-header-left">
            <span class="cockpit-badge c-badge-orange">01 全行營運</span>
            <h3>核心指標與市場地位</h3>
          </div>
          <button type="button" class="cockpit-link-btn" onclick="switchMainSection(\\'section-overview\\')" title="查看完整全行數據">詳情 →</button>
        </div>

        <!-- 2x2 Mini KPI Cards -->
        <div class="cockpit-subbox">
          <div class="cockpit-kpi-quad">
            <div class="c-kpi-card highlight-glow">
              <span class="c-kpi-title">{amt.get(\\'title\\', \\'總交易金額\\')}</span>
              <div class="c-kpi-val">{amt.get(\\'value\\', \\'1,286.4\\')}<em>億元</em></div>
              <div class="c-kpi-growth"><span class="number-positive">YoY {amt.get(\\'yoy\\', \\'+12.8%\\')}</span> <span class="number-positive">MoM {amt.get(\\'mom\\', \\'+2.1%\\')}</span></div>
            </div>
            <div class="c-kpi-card">
              <span class="c-kpi-title">{cnt.get(\\'title\\', \\'總交易筆數\\')}</span>
              <div class="c-kpi-val">{cnt.get(\\'value\\', \\'8,425\\')}<em>萬筆</em></div>
              <div class="c-kpi-growth"><span class="number-positive">YoY {cnt.get(\\'yoy\\', \\'+15.2%\\')}</span> <span class="number-positive">MoM {cnt.get(\\'mom\\', \\'+1.7%\\')}</span></div>
            </div>
            <div class="c-kpi-card">
              <span class="c-kpi-title">{cash.get(\\'title\\', \\'預借現金金額\\')}</span>
              <div class="c-kpi-val">{cash.get(\\'value\\', \\'18.6\\')}<em>億元</em></div>
              <div class="c-kpi-growth"><span class="number-negative">YoY {cash.get(\\'yoy\\', \\'-3.4%\\')}</span> <span class="c-kpi-sub">42.8 萬筆</span></div>
            </div>
            <div class="c-kpi-card">
              <span class="c-kpi-title">{revolving.get(\\'title\\', \\'循環信用餘額\\')}</span>
              <div class="c-kpi-val">{revolving.get(\\'value\\', \\'325.7\\')}<em>億元</em></div>
              <div class="c-kpi-growth"><span class="number-positive">YoY {revolving.get(\\'yoy\\', \\'+6.7%\\')}</span> <span class="c-kpi-sub">生息資產</span></div>
            </div>
          </div>
        </div>

        <!-- 與他行簽帳占比全新製圖 -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>四大發卡行簽帳金額與市占率</span>
            <span class="cockpit-tag-pill">市場總計 30,720 億</span>
          </div>
          <!-- Stacked Bar -->
          <div class="market-stacked-bar">
            {peer_bars_html}
          </div>
          <!-- Peer Ranked Rows -->
          <div class="cockpit-peer-list">
            {peer_rows_html}
          </div>
          <div class="cockpit-foot-note">
            <span>本行簽帳穩居市場<b>第二</b>，與榜首差距僅 <b>0.8pp</b></span>
          </div>
        </div>
      </div>

      <!-- COLUMN 2: 02 收單業務 & TWQR 專區 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <div class="c-header-left">
            <span class="cockpit-badge c-badge-blue">02 收單動能</span>
            <h3>自行收單與 TWQR 拓點</h3>
          </div>
          <button type="button" class="cockpit-link-btn" onclick="switchMainSection(\\'section-acquiring\\')" title="查看完整收單數據">詳情 →</button>
        </div>

        <!-- 自行收單核心概況 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>自行收單大盤</span>
            <span class="c-tag-green">活店率 83.0%</span>
          </div>
          <div class="c-mini-stat-banner">
            <div>
              <small>收單總金額</small>
              <strong>285.0<em>億</em></strong>
              <b class="number-positive">YoY +12.8%</b>
            </div>
            <div class="divider-v"></div>
            <div>
              <small>實體 / 線上 EPOS</small>
              <div class="c-split-bar">
                <span class="bar-phys" style="width: 65%;">65% 實體</span>
                <span class="bar-onl" style="width: 35%;">35% 線上</span>
              </div>
              <small class="c-foot-hint">平均客單：1,540 元（+1.2%）</small>
            </div>
          </div>
        </div>

        <!-- TWQR 業務分析專區 (特店進件 + 交易造血) -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>TWQR 國家共同標準業務分析</span>
            <span class="cockpit-tag-pill primary">特店拓點特刊</span>
          </div>

          <!-- TWQR Top Block: 特店進件分析 -->
          <div class="twqr-cockpit-section">
            <div class="twqr-subhead">
              <b>拓展 Pipeline</b>
              <span>通過率 91.2%</span>
            </div>
            <div class="c-twqr-stat-grid">
              <div class="c-twqr-cell">
                <span>當月申請進件數</span>
                <strong>3,850 <em>件</em></strong>
                <b class="number-positive">審查通過率 91.2%</b>
              </div>
              <div class="c-twqr-cell">
                <span>累計特店家數</span>
                <strong>22,100 <em>家</em></strong>
                <b class="number-positive">MoM +5.8% (+1,210家)</b>
              </div>
            </div>
          </div>

          <!-- TWQR Bottom Block: 交易狀態造血動能 -->
          <div class="twqr-cockpit-section" style="margin-top: 8px;">
            <div class="twqr-subhead">
              <b>交易造血動能</b>
              <span>動用特店率 68.2%</span>
            </div>
            <div class="c-twqr-stat-grid three-col">
              <div class="c-twqr-cell">
                <span>當月交易金額</span>
                <strong>14.8 <em>億</em></strong>
                <b class="number-positive">MoM +18.5%</b>
              </div>
              <div class="c-twqr-cell">
                <span>當月交易筆數</span>
                <strong>185 <em>萬筆</em></strong>
                <b class="number-positive">MoM +16.2%</b>
              </div>
              <div class="c-twqr-cell">
                <span>平均客單價</span>
                <strong>800 <em>元</em></strong>
                <b class="number-positive">MoM +2.0%</b>
              </div>
            </div>
          </div>

          <div class="cockpit-foot-note">
            <span>TWQR 累計活店數達 <b>15,070 家</b>，小額高頻通路拓點動能強勁</span>
          </div>
        </div>
      </div>

      <!-- COLUMN 3: 03 發卡進件、帳單與小樹點水庫 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <div class="c-header-left">
            <span class="cockpit-badge c-badge-orange">03 發卡動能</span>
            <h3>進件中樞、帳單與小樹點</h3>
          </div>
          <button type="button" class="cockpit-link-btn" onclick="switchMainSection(\\'section-issuing\\')" title="查看完整發卡數據">詳情 →</button>
        </div>

        <!-- 徵審進件中樞 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>徵審進件中樞自動化</span>
            <span class="c-tag-green">STP 核准率 76.5%</span>
          </div>
          <div class="c-stat-row">
            <div class="c-stat-item">
              <small>當月申辦總量</small>
              <strong>85,400 <em>件</em></strong>
              <span>舊戶 4.7 萬 ｜ 新戶 3.84 萬</span>
            </div>
            <div class="c-stat-item highlight-box">
              <small>自動直接核准</small>
              <strong style="color:var(--green);">65,300 <em>件</em></strong>
              <span>綜合自動核准率 76.5%</span>
            </div>
          </div>
          <div class="c-progress-bar-wrap">
            <div class="c-progress-fill" style="width: 76.5%;">自動核准 76.5%</div>
            <div class="c-progress-rest" style="width: 23.5%;">人工 23.5%</div>
          </div>
        </div>

        <!-- 信用卡電子帳單數據 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>帳單數據與數位降本</span>
            <span class="cockpit-tag-pill">覆蓋率 91.8%</span>
          </div>
          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>電子帳單總本數</small>
              <strong>520.0 <em>萬本</em></strong>
              <span class="number-positive">YoY +6.8%</span>
            </div>
            <div class="c-stat-item">
              <small>紙本帳單節約</small>
              <strong>42.6 <em>萬本</em></strong>
              <span class="number-positive">YoY −8.0%</span>
            </div>
          </div>
        </div>

        <!-- 小樹點概況 (TAB 3 水庫循環) -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>小樹點水庫循環概況 (TAB 3)</span>
            <span class="c-tag-green">兌換率 84.2%</span>
          </div>
          <div class="c-twqr-stat-grid three-col">
            <div class="c-twqr-cell">
              <span>水庫流通累積</span>
              <strong>48.2 <em>億點</em></strong>
              <b class="number-positive">活水循環</b>
            </div>
            <div class="c-twqr-cell">
              <span>當月贈送點數</span>
              <strong>3.8 <em>億點</em></strong>
              <b class="number-positive">YoY +18.7%</b>
            </div>
            <div class="c-twqr-cell">
              <span>當月兌換點數</span>
              <strong>3.2 <em>億點</em></strong>
              <b class="number-positive">YoY +23.1%</b>
            </div>
          </div>
          <div class="cockpit-foot-note">
            <span>流通兌換率達 <b>84.2%</b> (YoY +3.5pp)，點數高頻抵用成效顯著</span>
          </div>
        </div>
      </div>

      <!-- COLUMN 4: 04 核心主機韌性與資安防詐 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <div class="c-header-left">
            <span class="cockpit-badge c-badge-dark">04 系統韌性</span>
            <h3>核心雙主機與三大防詐</h3>
          </div>
          <button type="button" class="cockpit-link-btn" onclick="switchMainSection(\\'section-resilience\\')" title="查看完整系統數據">詳情 →</button>
        </div>

        <!-- CardPool 授權核心主機 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>CardPool 授權核心主機</span>
            <span class="c-tag-green">可用率 99.999%</span>
          </div>
          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>交易響應時間</small>
              <strong style="color:var(--green);">85 <em>ms</em></strong>
              <span class="number-positive">零超時 (0筆)</span>
            </div>
            <div class="c-stat-item">
              <small>月授權交易量</small>
              <strong>6,820 <em>萬筆</em></strong>
              <span>成功率 98.8%</span>
            </div>
          </div>
        </div>

        <!-- Cardlink 核心帳務主機 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>Cardlink 核心帳務主機</span>
            <span class="c-tag-green">SLA 100% 達標</span>
          </div>
          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>月帳務處理量</small>
              <strong>1.42 <em>億筆</em></strong>
              <span>高可靠運作</span>
            </div>
            <div class="c-stat-item">
              <small>系統可用率 / 峰值</small>
              <strong>100.0%</strong>
              <span>峰值 4,850 TPS</span>
            </div>
          </div>
        </div>

        <!-- 三大資安防詐防線成果 (SFM & 3DS) -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>三大資安防詐成果 (SFM & 3DS)</span>
            <span class="cockpit-tag-pill warning">全月防堵 4,280 萬</span>
          </div>

          <!-- Total Banner -->
          <div class="fraud-total-cockpit-bar">
            <div>
              <span>全月總防堵金額</span>
              <strong>4,280 <em>萬元</em></strong>
            </div>
            <div class="divider-v"></div>
            <div>
              <span>阻斷冒用卡數</span>
              <strong>2,684 <em>張</em></strong>
            </div>
          </div>

          <!-- 3-line Breakdown -->
          <div class="fraud-lines-list">
            <div class="f-line-item">
              <span class="f-tag sfm">SFM</span>
              <span class="f-name">申請詐欺防堵</span>
              <span class="f-amt">1,150 萬元</span>
              <span class="f-cnt">842 張</span>
            </div>
            <div class="f-line-item">
              <span class="f-tag tds">3DS</span>
              <span class="f-name">線上交易防堵</span>
              <span class="f-amt">860 萬元</span>
              <span class="f-cnt">620 張</span>
            </div>
            <div class="f-line-item">
              <span class="f-tag sfm">SFM</span>
              <span class="f-name">交易詐欺防堵</span>
              <span class="f-amt">2,270 萬元</span>
              <span class="f-cnt">1,222 張</span>
            </div>
          </div>

          <div class="cockpit-foot-note">
            <span>覆蓋進件審查、線上 3DS 驗證與特店交易，阻斷冒用風險</span>
          </div>
        </div>
      </div>
    </div>
  </section>
\'\'\'
'''

# Add render_cockpit_section function and call
marker_b1 = '# Render Block 01'
code = code.replace(marker_b1, render_fn + "\n" + "b0_cockpit_html = render_cockpit_section(d)\n\n" + marker_b1)

# 3. Update Subnav in HTML template
old_subnav = '''  <nav class="subnav">
    <div class="nav-links">
      <button type="button" class="nav-tab-btn active" data-target="section-overview" onclick="switchMainSection('section-overview')">
        <span class="nav-num">01</span> 全行概況
      </button>'''

new_subnav = '''  <nav class="subnav">
    <div class="nav-links">
      <button type="button" class="nav-tab-btn active" data-target="section-cockpit" onclick="switchMainSection('section-cockpit')">
        <span class="nav-num">00</span> 決策總覽
      </button>
      <button type="button" class="nav-tab-btn" data-target="section-overview" onclick="switchMainSection('section-overview')">
        <span class="nav-num">01</span> 全行概況
      </button>'''

code = code.replace(old_subnav, new_subnav)

# 4. Insert section-cockpit right before Section 01, and remove active from section-overview
old_s01 = '''  <!-- ========================================================
       SECTION 01: 全行概況 (OVERVIEW BASELINE)
       ======================================================== -->
  <section id="section-overview" class="dashboard-section main-section active">'''

new_s01 = '''  {b0_cockpit_html}

  <!-- ========================================================
       SECTION 01: 全行概況 (OVERVIEW BASELINE)
       ======================================================== -->
  <section id="section-overview" class="dashboard-section main-section">'''

code = code.replace(old_s01, new_s01)

# Write back to build_dashboard.py
with open('scratch/build_dashboard.py', 'w', encoding='utf-8') as f:
    f.write(code)

print("build_dashboard.py updated with Cockpit Section 00!")
