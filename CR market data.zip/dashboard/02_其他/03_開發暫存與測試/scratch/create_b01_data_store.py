# -*- coding: utf-8 -*-
import json
import os

dashboard_data = {
  "meta": {
    "title": "國泰世華銀行 信用卡營運整合數據儀表板",
    "year": "2026",
    "month": "08",
    "period_label": "營運月報",
    "brand": "國泰世華"
  },
  "block01": {
    "section_title": "信用卡整體經營概況",
    "section_num": "01",
    "monthly_kpis": {
      "total_amount": {
        "title": "總交易金額",
        "value": 1286.4,
        "unit": "億元",
        "yoy": 12.8,
        "mom": 2.1,
        "general": {
          "label": "一般交易",
          "amount": 1086.4,
          "unit": "億",
          "share": 84.4,
          "yoy": 10.5,
          "mom": 1.4
        },
        "installment": {
          "label": "分期交易",
          "amount": 200.0,
          "unit": "億",
          "share": 15.6,
          "yoy": 27.3,
          "mom": 8.7
        }
      },
      "total_count": {
        "title": "總交易筆數",
        "value": 8425,
        "unit": "萬筆",
        "yoy": 15.2,
        "mom": 1.7,
        "general": {
          "label": "一般交易",
          "count": 7750,
          "unit": "萬筆",
          "share": 92.0,
          "yoy": 14.1,
          "mom": 1.2
        },
        "installment": {
          "label": "分期交易",
          "count": 675,
          "unit": "萬筆",
          "share": 8.0,
          "yoy": 29.8,
          "mom": 7.9
        }
      },
      "active_card": {
        "title": "活卡率",
        "rate": 86.4,
        "unit": "%",
        "yoy_pp": 1.8,
        "mom_pp": 0.3,
        "active_cards": 741,
        "active_cards_unit": "萬卡",
        "active_share": 86.4,
        "issued_cards": 858,
        "issued_cards_unit": "萬卡",
        "inactive_cards": 117,
        "inactive_cards_unit": "萬卡",
        "inactive_share": 13.6
      },
      "credit_business": {
        "revolving": {
          "title": "循環信用餘額",
          "balance": 325.7,
          "unit": "億元",
          "yoy": 6.7,
          "mom": 0.9
        },
        "cash_advance": {
          "title": "預借現金金額",
          "amount": 18.6,
          "unit": "億元",
          "yoy": -3.4,
          "mom": -0.8,
          "count_wan": 42.8,
          "count_hint": "(42.8萬筆)"
        }
      }
    },
    "cockpit_peer_donut": {
      "title": "四大發卡行簽帳金額與市佔",
      "period_label": "2026 年 1–8 月",
      "market_total": 30720,
      "unit": "億元",
      "market_yoy": 14.3,
      "top4_share": 66.7,
      "top4_hint": "四大行佔 66.7%",
      "peers": [
        { "name": "中國信託", "amount": 5980, "unit": "億", "share": 19.5, "yoy": 11.2, "color": "#003b5c", "is_cathay": False },
        { "name": "國泰世華", "amount": 5726, "unit": "億", "share": 18.6, "yoy": 12.8, "color": "#009e73", "is_cathay": True },
        { "name": "台北富邦", "amount": 4450, "unit": "億", "share": 14.5, "yoy": 18.4, "color": "#2563eb", "is_cathay": False },
        { "name": "玉山銀行", "amount": 4320, "unit": "億", "share": 14.1, "yoy": 9.6, "color": "#059669", "is_cathay": False },
        { "name": "其他同業", "amount": 10244, "unit": "億", "share": 33.3, "yoy": 17.4, "color": "#cbd5e1", "is_cathay": False }
      ]
    },
    "peer_benchmark": [
      {
        "label": "消費經營",
        "metrics": [
          {
            "label": "簽帳金額",
            "unit": "億元",
            "positiveDirection": "up",
            "marketValue": 30740,
            "marketYoy": 14.3,
            "peers": [
              { "bank": "中國信託", "value": 6457, "yoy": 25.9 },
              { "bank": "國泰世華", "value": 5726, "yoy": 17.1 },
              { "bank": "玉山", "value": 4705, "yoy": 18.4 },
              { "bank": "台北富邦", "value": 3894, "yoy": 6.4 },
              { "bank": "台新銀行", "value": 3480, "yoy": 11.8 }
            ]
          }
        ]
      },
      {
        "label": "卡量經營",
        "metrics": [
          {
            "label": "有效卡數",
            "unit": "萬卡",
            "positiveDirection": "up",
            "marketValue": 4528,
            "marketYoy": 4.8,
            "peers": [
              { "bank": "中國信託", "value": 786, "yoy": 6.2 },
              { "bank": "國泰世華", "value": 741, "yoy": 5.7 },
              { "bank": "玉山", "value": 612, "yoy": 3.8 },
              { "bank": "台北富邦", "value": 548, "yoy": 4.5 },
              { "bank": "台新銀行", "value": 468, "yoy": 4.2 }
            ]
          },
          {
            "label": "流通卡數",
            "unit": "萬卡",
            "positiveDirection": "up",
            "marketValue": 5440,
            "marketYoy": 3.1,
            "peers": [
              { "bank": "中國信託", "value": 912, "yoy": 4.2 },
              { "bank": "國泰世華", "value": 858, "yoy": 3.5 },
              { "bank": "玉山", "value": 726, "yoy": 3.3 },
              { "bank": "台北富邦", "value": 685, "yoy": 2.9 },
              { "bank": "台新銀行", "value": 654, "yoy": 3.1 }
            ]
          },
          {
            "label": "活卡率",
            "unit": "%",
            "decimals": 1,
            "positiveDirection": "up",
            "marketAverage": 82.3,
            "summaryMode": "quality",
            "peers": [
              { "bank": "國泰世華", "value": 86.4, "yoy": 1.8 },
              { "bank": "中國信託", "value": 86.2, "yoy": 1.6 },
              { "bank": "玉山", "value": 84.3, "yoy": 0.4 },
              { "bank": "台北富邦", "value": 80.0, "yoy": 1.2 },
              { "bank": "台新銀行", "value": 71.6, "yoy": 0.8 }
            ]
          }
        ]
      },
      {
        "label": "信貸業務",
        "metrics": [
          {
            "label": "循環信用餘額",
            "unit": "億元",
            "positiveDirection": "up",
            "marketValue": 1223,
            "marketYoy": 5.1,
            "peers": [
              { "bank": "中國信託", "value": 358, "yoy": 7.8 },
              { "bank": "國泰世華", "value": 326, "yoy": 6.7 },
              { "bank": "玉山", "value": 221, "yoy": 3.1 },
              { "bank": "台北富邦", "value": 194, "yoy": 2.8 },
              { "bank": "台新銀行", "value": 152, "yoy": 4.5 }
            ]
          },
          {
            "label": "未到期分期付款餘額",
            "unit": "億元",
            "positiveDirection": "up",
            "marketValue": 1940,
            "marketYoy": 8.3,
            "peers": [
              { "bank": "國泰世華", "value": 462, "yoy": 10.2 },
              { "bank": "中國信託", "value": 448, "yoy": 9.1 },
              { "bank": "玉山", "value": 311, "yoy": 7.5 },
              { "bank": "台北富邦", "value": 282, "yoy": 5.9 },
              { "bank": "台新銀行", "value": 235, "yoy": 6.8 }
            ]
          }
        ]
      },
      {
        "label": "資產品質",
        "metrics": [
          {
            "label": "備抵呆帳提足率",
            "unit": "%",
            "decimals": 0,
            "positiveDirection": "up",
            "marketAverage": 260,
            "summaryMode": "quality",
            "peers": [
              { "bank": "國泰世華", "value": 287, "yoy": 12 },
              { "bank": "中國信託", "value": 276, "yoy": 8 },
              { "bank": "玉山", "value": 252, "yoy": 4 },
              { "bank": "台新銀行", "value": 245, "yoy": 5 },
              { "bank": "台北富邦", "value": 238, "yoy": 6 }
            ]
          },
          {
            "label": "轉銷呆帳",
            "unit": "億元",
            "decimals": 1,
            "positiveDirection": "down",
            "marketAverage": 1.3,
            "summaryMode": "quality",
            "peers": [
              { "bank": "國泰世華", "value": 1.1, "yoy": -0.2 },
              { "bank": "台北富邦", "value": 1.2, "yoy": 0.1 },
              { "bank": "台新銀行", "value": 1.3, "yoy": -0.1 },
              { "bank": "玉山", "value": 1.3, "yoy": 0.2 },
              { "bank": "中國信託", "value": 1.4, "yoy": 0.1 }
            ]
          }
        ]
      }
    ]
  }
}

# 1. Output JSON
with open('dashboard_data.json', 'w', encoding='utf-8') as f:
    json.dump(dashboard_data, f, ensure_ascii=False, indent=2)

# 2. Output JS with window.DASHBOARD_DATA
js_content = "window.DASHBOARD_DATA = " + json.dumps(dashboard_data, ensure_ascii=False, indent=2) + ";\n"
with open('dashboard_data.js', 'w', encoding='utf-8') as f:
    f.write(js_content)

print("Generated dashboard_data.json and dashboard_data.js successfully!")
