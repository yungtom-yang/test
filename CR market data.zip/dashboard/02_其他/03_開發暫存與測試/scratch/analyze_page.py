# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import re

with open('scratch/page.tsx', 'r', encoding='utf-8', errors='ignore') as f:
    text = f.read()

print("Length of page.tsx:", len(text))
matches = re.findall(r'<section[^>]*>|<div className="([^"]*)"', text)
for m in matches[:40]:
    if m:
        print("Class:", m)

print("\n--- Sections in page.tsx ---")
for m in re.finditer(r'<section[^>]*>', text):
    print(m.group(0))
