# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

transcript_path = 'C:/Users/詠棠/.gemini/antigravity/brain/b95ecca9-971a-489b-ab53-ec5e0dbbb3cb/.system_generated/logs/transcript_full.jsonl'
with open(transcript_path, 'r', encoding='utf-8') as f:
    for line in f:
        obj = json.loads(line)
        idx = obj.get('step_index')
        calls = obj.get('tool_calls', [])
        for c in calls:
            if c.get('name') == 'view_file':
                args = c.get('args', {})
                if 'build_dashboard.py' in args.get('AbsolutePath', ''):
                    print(f"Step {idx}: view_file {args.get('AbsolutePath')} lines {args.get('StartLine')}-{args.get('EndLine')}")
