# -*- coding: utf-8 -*-
import openpyxl

EXCEL_FILE = "01_儀表板執行環境/dashboard_data.xlsx"
wb = openpyxl.load_workbook(EXCEL_FILE)

for sname in ["01_五大行簽帳市占", "01_四大行簽帳市占"]:
    if sname in wb.sheetnames:
        wb.remove(wb[sname])
        print(f"Removed redundant sheet '{sname}' from {EXCEL_FILE}")

wb.save(EXCEL_FILE)
print("Remaining sheets:", wb.sheetnames)
