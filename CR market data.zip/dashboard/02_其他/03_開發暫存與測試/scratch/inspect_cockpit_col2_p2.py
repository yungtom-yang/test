import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('01_儀表板執行環境/credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print("=== Lines 2511 to 2560 ===")
for i in range(2510, min(2560, len(lines))):
    print(f"{i+1}: {lines[i].rstrip()}")
