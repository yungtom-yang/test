import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('01_儀表板執行環境/credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print("=== Search for Section tags ===")
for i, line in enumerate(lines):
    if 'id="section-' in line or "id='section-" in line:
        print(f"Line {i+1}: {line.strip()[:100]}")

print("\n=== Search for 收單 ===")
for i, line in enumerate(lines):
    if '收單' in line:
        print(f"Line {i+1}: {line.strip()[:100]}")
