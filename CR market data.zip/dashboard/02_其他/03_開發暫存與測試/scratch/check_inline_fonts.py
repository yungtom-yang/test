import re

with open(r'C:\Users\user\.gemini\antigravity\brain\4de23884-60e4-461e-b182-40c7dba003f4\credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    text = f.read()

body = text[text.find('<body>'):]
pattern = re.compile(r'style="[^"]*font-size:\s*(?:10|11)px[^"]*"')
matches = list(pattern.finditer(body))
print(f"Total inline 10px/11px matches in body: {len(matches)}")
for m in matches[:15]:
    start = max(0, m.start() - 40)
    end = min(len(body), m.end() + 40)
    print(body[start:end].replace('\n', ' '))
