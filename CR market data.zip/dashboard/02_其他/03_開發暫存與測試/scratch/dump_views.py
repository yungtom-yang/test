# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

transcript_path = 'C:/Users/詠棠/.gemini/antigravity/brain/b95ecca9-971a-489b-ab53-ec5e0dbbb3cb/.system_generated/logs/transcript_full.jsonl'
with open(transcript_path, 'r', encoding='utf-8') as f:
    for line in f:
        obj = json.loads(line)
        idx = obj.get('step_index')
        if idx in [33, 406, 408]:  # response steps after 32, 405, 407
            c = obj.get('content', '')
            print(f"=== Step {idx} ===")
            print(c[:1500])
