# -*- coding: utf-8 -*-
"""
Generate a beautifully formatted dashboard_data.xlsx workbook
that acts as the single source of truth for the dashboard.
"""
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

wb = openpyxl.Workbook()
# Remove default sheet
wb.remove(wb.active)

# Styles
header_font = Font(name="Microsoft JhengHei", size=11, bold=True, color="FFFFFF")
header_fill_blue = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
header_fill_green = PatternFill(start_color="065F46", end_color="065F46", fill_type="solid")
header_fill_orange = PatternFill(start_color="C2410C", end_color="C2410C", fill_type="solid")

title_font = Font(name="Microsoft JhengHei", size=13, bold=True, color="1E293B")
data_font = Font(name="Microsoft JhengHei", size=10)
bold_data_font = Font(name="Microsoft JhengHei", size=10, bold=True)
note_font = Font(name="Microsoft JhengHei", size=9, italic=True, color="64748B")

thin_border = Border(
    left=Side(style='thin', color='E2E8F0'),
    right=Side(style='thin', color='E2E8F0'),
    top=Side(style='thin', color='E2E8F0'),
    bottom=Side(style='thin', color='E2E8F0')
)

align_center = Alignment(horizontal="center", vertical="center")
align_left = Alignment(horizontal="left", vertical="center")
align_right = Alignment(horizontal="right", vertical="center")

# ==========================================
# SHEET 1: 01_全行月度指標
# ==========================================
ws1 = wb.create_sheet(title="01_全行月度指標")
ws1.views.sheetView[0].showGridLines = True

# Title block
ws1['A1'] = "國泰世華銀行 信用卡營運儀表板 - 01 全行月度指標維護表"
ws1['A1'].font = title_font
ws1['A2'] = "說明：直接修改下方「當月數值」與「YoY / MoM」。佔比與活卡率若留空，系統會自動依分子/分母計算；亦可直接手動填入。"
ws1['A2'].font = note_font

headers1 = ["指標分類", "指標代碼", "指標名稱", "當月數值", "單位", "YoY (%)", "MoM (%)", "佔比/活卡率(%)", "備註 / 計算規則"]
ws1.append([]) # row 3 blank
ws1.append(headers1) # row 4

for col_num in range(1, len(headers1) + 1):
    cell = ws1.cell(row=4, column=col_num)
    cell.font = header_font
    cell.fill = header_fill_blue
    cell.alignment = align_center

rows1 = [
    ["總交易金額", "amt_total", "總交易金額", 1286.4, "億元", 12.8, 2.1, 100.0, "核心指標；留空則自動累加一般+分期"],
    ["總交易金額", "amt_general", "一般交易金額", 1086.4, "億元", 10.5, 1.4, 84.4, "系統可自動計算佔比 (1086.4 / 1286.4)"],
    ["總交易金額", "amt_installment", "分期交易金額", 200.0, "億元", 27.3, 8.7, 15.6, "系統可自動計算佔比 (200.0 / 1286.4)"],
    ["總交易筆數", "cnt_total", "總交易筆數", 8425, "萬筆", 15.2, 1.7, 100.0, "核心指標；留空則自動累加一般+分期"],
    ["總交易筆數", "cnt_general", "一般交易筆數", 7750, "萬筆", 14.1, 1.2, 92.0, "系統可自動計算佔比 (7750 / 8425)"],
    ["總交易筆數", "cnt_installment", "分期交易筆數", 675, "萬筆", 29.8, 7.9, 8.0, "系統可自動計算佔比 (675 / 8425)"],
    ["活卡表現", "card_active", "有效卡數", 741, "萬卡", 1.8, 0.3, 86.4, "YoY/MoM 為百分點(pp)；活卡率自動除算"],
    ["活卡表現", "card_issued", "流通卡數", 858, "萬卡", None, None, 100.0, "母體總卡數；未動用卡數(117萬卡)自動推導"],
    ["信用業務", "rev_balance", "循環信用餘額", 325.7, "億元", 6.7, 0.9, None, "次要業務指標 (月指標卡片右上方)"],
    ["信用業務", "cash_amount", "預借現金金額", 18.6, "億元", -3.4, -0.8, None, "次要業務指標 (月指標卡片右下方)"],
    ["信用業務", "cash_count", "預借現金筆數", 42.8, "萬筆", None, None, None, "顯示於預借現金增長率旁之筆數標籤"]
]

for r_idx, row in enumerate(rows1, start=5):
    for c_idx, val in enumerate(row, start=1):
        cell = ws1.cell(row=r_idx, column=c_idx, value=val)
        cell.font = bold_data_font if c_idx in [1, 3, 4] else data_font
        cell.border = thin_border
        if c_idx in [1, 2, 5]:
            cell.alignment = align_center
        elif c_idx in [4, 6, 7, 8]:
            cell.alignment = align_right
            if val is not None and isinstance(val, (int, float)):
                cell.number_format = "#,##0.0" if isinstance(val, float) else "#,##0"
        else:
            cell.alignment = align_left

# ==========================================
# SHEET 2: 01_四大行簽帳市占
# ==========================================
ws2 = wb.create_sheet(title="01_四大行簽帳市占")
ws2.views.sheetView[0].showGridLines = True

ws2['A1'] = "國泰世華銀行 信用卡營運儀表板 - 四大發卡行簽帳金額與市佔 (戰情室圓餅圖)"
ws2['A1'].font = title_font
ws2['A2'] = "說明：維護各發卡行簽帳金額與成長率。全市場總額與各行市占率(%)由系統自動計算並繪製 SVG 甜甜圈圖。"
ws2['A2'].font = note_font

headers2 = ["發卡銀行", "簽帳金額 (億元)", "市占率 (%)", "YoY (%)", "代表色碼 (HEX)", "是否為本行", "備註"]
ws2.append([])
ws2.append(headers2)

for col_num in range(1, len(headers2) + 1):
    cell = ws2.cell(row=4, column=col_num)
    cell.font = header_font
    cell.fill = header_fill_green
    cell.alignment = align_center

rows2 = [
    ["中國信託", 5980, 19.5, 11.2, "#003b5c", "否", "第一大行"],
    ["國泰世華", 5726, 18.6, 12.8, "#009e73", "是", "本行 (綠色高亮顯示)"],
    ["台北富邦", 4450, 14.5, 18.4, "#2563eb", "否", "Costco 卡主力"],
    ["玉山銀行", 4320, 14.1, 9.6, "#059669", "否", "第四大行"],
    ["其他同業", 10244, 33.3, 17.4, "#cbd5e1", "否", "全市場其餘發卡機構合計"]
]

for r_idx, row in enumerate(rows2, start=5):
    for c_idx, val in enumerate(row, start=1):
        cell = ws2.cell(row=r_idx, column=c_idx, value=val)
        cell.font = bold_data_font if c_idx in [1, 2] else data_font
        cell.border = thin_border
        if c_idx in [1, 5, 6]:
            cell.alignment = align_center
        elif c_idx in [2, 3, 4]:
            cell.alignment = align_right
            if isinstance(val, (int, float)):
                cell.number_format = "#,##0.0" if isinstance(val, float) else "#,##0"
        else:
            cell.alignment = align_left

# ==========================================
# SHEET 3: 01_同業對標明細
# ==========================================
ws3 = wb.create_sheet(title="01_同業對標明細")
ws3.views.sheetView[0].showGridLines = True

ws3['A1'] = "國泰世華銀行 信用卡營運儀表板 - 同業經營比較 (1B PEER BENCHMARK YTD)"
ws3['A1'].font = title_font
ws3['A2'] = "說明：維護同業各業務類別在 2026 年 1–8 月的累計經營數據。系統會自動排定各項名次與洞察分析條。"
ws3['A2'].font = note_font

headers3 = [
    "業務主題", "指標名稱", "單位", "優良方向", "全市場數值", "市場YoY(%)",
    "國泰數值", "國泰YoY(%)", "中信數值", "中信YoY(%)", "富邦數值", "富邦YoY(%)",
    "玉山數值", "玉山YoY(%)", "台新數值", "台新YoY(%)"
]
ws3.append([])
ws3.append(headers3)

for col_num in range(1, len(headers3) + 1):
    cell = ws3.cell(row=4, column=col_num)
    cell.font = header_font
    cell.fill = header_fill_orange
    cell.alignment = align_center

rows3 = [
    ["消費經營", "簽帳金額", "億元", "up", 30740, 14.3, 5726, 17.1, 6457, 25.9, 3894, 6.4, 4705, 18.4, 3480, 11.8],
    ["卡量經營", "有效卡數", "萬卡", "up", 4528, 4.8, 741, 1.8, 812, 5.2, 598, 8.4, 624, 3.1, 482, 4.0],
    ["卡量經營", "流通卡數", "萬卡", "up", 5892, 3.9, 858, 2.1, 980, 4.5, 762, 9.1, 745, 2.8, 620, 3.5],
    ["卡量經營", "活卡率", "%", "up", 76.8, 0.6, 86.4, -0.3, 82.9, 0.5, 78.5, -0.5, 83.8, 0.2, 77.7, 0.4],
    ["卡量經營", "發卡量", "萬卡", "up", 382, 12.5, 68, 15.3, 85, 20.1, 72, 8.6, 54, 4.2, 46, 6.8],
    ["卡量經營", "停卡量", "萬卡", "down", 215, -3.2, 34, -5.1, 48, 2.3, 39, -1.8, 31, -4.5, 28, -2.1],
    ["卡量經營", "淨發卡量", "萬卡", "up", 167, 41.5, 34, 47.8, 37, 54.2, 33, 23.5, 23, 19.8, 18, 24.5],
    ["信用業務", "循環信用餘額", "億元", "up", 1120, 5.4, 325.7, 6.7, 340.2, 7.8, 168.4, 4.2, 145.6, 3.8, 110.5, 2.9],
    ["信用業務", "預借現金金額", "億元", "up", 125, -1.2, 18.6, -3.4, 28.5, 1.2, 14.2, -2.1, 16.8, -0.5, 12.4, -1.8],
    ["收單業務", "特店簽帳金額", "億元", "up", 18500, 16.2, 3850, 18.4, 4200, 21.0, 2950, 14.5, 2800, 12.3, 2100, 10.8],
    ["收單業務", "特店家數", "萬家", "up", 54.2, 6.5, 12.5, 7.8, 14.2, 9.1, 8.4, 4.2, 8.1, 5.0, 6.2, 3.8],
    ["收益品質", "簽帳手續費收入", "億元", "up", 1320, 13.5, 287, 12.0, 276, 8.0, 238, 6.0, 252, 4.0, 245, 5.0],
    ["收益品質", "轉銷呆帳", "億元", "down", 6.8, -0.3, 1.1, -0.2, 1.4, 0.1, 1.2, 0.1, 1.3, 0.2, 1.3, -0.1]
]

for r_idx, row in enumerate(rows3, start=5):
    for c_idx, val in enumerate(row, start=1):
        cell = ws3.cell(row=r_idx, column=c_idx, value=val)
        cell.font = bold_data_font if c_idx in [1, 2, 7] else data_font
        cell.border = thin_border
        if c_idx in [1, 3, 4]:
            cell.alignment = align_center
        elif c_idx >= 5:
            cell.alignment = align_right
            if isinstance(val, (int, float)):
                cell.number_format = "#,##0.0" if isinstance(val, float) else "#,##0"
        else:
            cell.alignment = align_left

# Auto-adjust column widths for all sheets
for ws in [ws1, ws2, ws3]:
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            # ignore title rows
            if cell.row in [1, 2]:
                continue
            if cell.value:
                val_str = str(cell.value)
                # Count Chinese characters as 2
                cell_len = sum(2 if ord(c) > 127 else 1 for c in val_str)
                if cell_len > max_len:
                    max_len = cell_len
        ws.column_dimensions[col_letter].width = max(max_len + 4, 12)

wb.save('dashboard_data.xlsx')
print('Generated dashboard_data.xlsx successfully!')
