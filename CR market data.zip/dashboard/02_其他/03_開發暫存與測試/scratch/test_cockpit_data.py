# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

with open('scratch/dashboard_data.json', 'r', encoding='utf-8') as f:
    d = json.load(f)

with open('scratch/peer_data.json', 'r', encoding='utf-8') as f:
    peer_data = json.load(f)

print("Dashboard data loaded successfully!")
