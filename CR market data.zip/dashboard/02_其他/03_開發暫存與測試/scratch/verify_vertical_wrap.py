# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import re

with open('credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    text = f.read()

m = re.search(r'<div class="cockpit-market-vertical-wrap">[\s\S]*?</div>\s*</div>\s*</div>', text)
if m:
    print("Found vertical market wrap:")
    lines = m.group(0).splitlines()
    for l in lines[:20]:
        print("  ", l[:100])
    print("  ...")
    for l in lines[-12:]:
        print("  ", l[:100])
else:
    print("NOT FOUND!")
