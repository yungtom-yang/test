# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

transcript_path = "C:/Users/詠棠/.gemini/antigravity/brain/b95ecca9-971a-489b-ab53-ec5e0dbbb3cb/.system_generated/logs/transcript.jsonl"

steps_to_check = [61, 65, 183, 191]

with open(transcript_path, "r", encoding="utf-8") as f:
    for line in f:
        obj = json.loads(line)
        idx = obj.get("step_index")
        if idx in steps_to_check:
            print(f"=== STEP {idx} ===")
            c = obj.get("content", "")
            for line in c.splitlines():
                if "section-" in line or "class=" in line or "background" in line or "font-" in line:
                    print("  ", line[:120])
