const fs = require('fs');
const jsData = fs.readFileSync('01_儀表板執行環境/dashboard_data.js', 'utf-8');
const vm = require('vm');
const sandbox = { window: {} };
vm.createContext(sandbox);
vm.runInContext(jsData, sandbox);

const donut = sandbox.window.DASHBOARD_DATA?.block01?.cockpit_peer_donut;
console.log('Title:', donut?.title);
console.log('Market Label:', donut?.market_label);
console.log('Market Total:', donut?.market_total, donut?.unit);
console.log('Market YoY:', donut?.market_yoy);
console.log('Peers count:', donut?.peers?.length);
donut?.peers?.forEach((p, idx) => {
  console.log(`  ${idx+1}. ${p.name}: ${p.amount} 億 (${p.share}%) YoY: ${p.yoy}% Color: ${p.color} isCathay: ${p.is_cathay}`);
});
