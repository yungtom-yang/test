import openpyxl, sys
sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook("01_儀表板執行環境/dashboard_data.xlsx", data_only=True)

sheets_02 = [s for s in wb.sheetnames if s.startswith("02_")]
print("Found 02 sheets:", sheets_02)

for s in sheets_02:
    ws = wb[s]
    print(f"\n=================== SHEET: {s} ===================")
    for r_idx, row in enumerate(ws.iter_rows(values_only=True), start=1):
        if r_idx <= 12:
            print(f"Row {r_idx}: {row}")
