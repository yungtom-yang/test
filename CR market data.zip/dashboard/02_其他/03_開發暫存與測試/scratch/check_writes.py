# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

transcript_path = "C:/Users/詠棠/.gemini/antigravity/brain/b95ecca9-971a-489b-ab53-ec5e0dbbb3cb/.system_generated/logs/transcript.jsonl"

with open(transcript_path, "r", encoding="utf-8") as f:
    for line in f:
        obj = json.loads(line)
        idx = obj.get("step_index")
        calls = obj.get("tool_calls", [])
        for c in calls:
            if c.get("name") in ["write_to_file", "replace_file_content"]:
                args = c.get("args", {})
                tf = args.get("TargetFile", "")
                desc = args.get("Description", "")
                print(f"Step {idx}: {c.get('name')} -> {tf} | {desc}")
