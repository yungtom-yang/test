import openpyxl, sys
sys.stdout.reconfigure(encoding='utf-8')

wb_path = "01_儀表板執行環境/dashboard_data.xlsx"
wb = openpyxl.load_workbook(wb_path)

total_changes = 0
for sheet in wb.sheetnames:
    ws = wb[sheet]
    sheet_changes = 0
    for row in ws.iter_rows():
        for cell in row:
            if cell.value is not None and isinstance(cell.value, str) and "千元" in cell.value:
                old_val = cell.value
                new_val = old_val.replace("千元", "億元")
                cell.value = new_val
                sheet_changes += 1
                total_changes += 1
                print(f"[{sheet}] {cell.coordinate}: '{old_val}' -> '{new_val}'")
    if sheet_changes > 0:
        print(f"  -> Sheet [{sheet}] changed {sheet_changes} cells.")

wb.save(wb_path)
print(f"\nSuccessfully saved {wb_path} with {total_changes} changes!")
