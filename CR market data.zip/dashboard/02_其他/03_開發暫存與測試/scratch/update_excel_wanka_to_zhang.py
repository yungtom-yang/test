# -*- coding: utf-8 -*-
import openpyxl

EXCEL_FILE = "01_儀表板執行環境/dashboard_data.xlsx"
wb = openpyxl.load_workbook(EXCEL_FILE)

total_replaced = 0
for sheet_name in wb.sheetnames:
    ws = wb[sheet_name]
    for r in range(1, ws.max_row + 1):
        for c in range(1, ws.max_column + 1):
            cell = ws.cell(row=r, column=c)
            if cell.value and isinstance(cell.value, str) and "萬卡" in cell.value:
                old_val = cell.value
                cell.value = cell.value.replace("萬卡", "張")
                total_replaced += 1
                print(f"[{sheet_name}] R{r}C{c}: '{old_val}' -> '{cell.value}'")

wb.save(EXCEL_FILE)
print(f"Total cells updated in dashboard_data.xlsx: {total_replaced}")
