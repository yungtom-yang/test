import sys
from bs4 import BeautifulSoup

with open('credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    soup = BeautifulSoup(f, 'html.parser')

def extract_section_info(section_id, out_file):
    sec = soup.find('section', id=section_id)
    if not sec:
        print(f"Section {section_id} not found")
        return
    with open(out_file, 'w', encoding='utf-8') as out:
        out.write(f"=== SECTION: {section_id} ===\n")
        # Dump all text nodes with their parent tags and classes
        for tag in sec.find_all(True):
            # check direct text or interesting attributes
            direct_texts = [c.strip() for c in tag.children if isinstance(c, str) and c.strip()]
            attrs = []
            if tag.get('class'):
                attrs.append(f"class='{' '.join(tag['class'])}'")
            if tag.get('title'):
                attrs.append(f"title='{tag['title']}'")
            if tag.get('onclick'):
                attrs.append(f"onclick='{tag['onclick']}'")
            
            line_str = f"<{tag.name} {' '.join(attrs)}>"
            if direct_texts:
                line_str += f" -> {' | '.join(direct_texts)}"
            if attrs or direct_texts:
                out.write(line_str + "\n")

extract_section_info('section-cockpit', 'scratch/dump_cockpit.txt')
extract_section_info('section-overview', 'scratch/dump_overview.txt')
extract_section_info('section-acquiring', 'scratch/dump_acquiring.txt')
extract_section_info('section-issuing', 'scratch/dump_issuing.txt')
extract_section_info('section-resilience', 'scratch/dump_resilience.txt')
print("Extracted all sections!")
