# -*- coding: utf-8 -*-
"""
Robust, targeted replacement script for Block 02 in credit_card_full_dashboard.html.
Injects IDs and renderBlock02FromData while preserving 100% of HTML/CSS styling.
"""

with open("01_儀表板執行環境/credit_card_full_dashboard.html", "r", encoding="utf-8") as f:
    html = f.read()

replacements = [
    # ----------------------------------------------------
    # Cockpit Col 2: Card 1 (金額)
    # ----------------------------------------------------
    (
        '<span class="c-kpi-title">自行收單交易金額</span>\n              <div class="c-kpi-growth"><span class="number-positive">YoY +12.8%</span> <span class="number-positive">MoM +2.1%</span></div>',
        '<span class="c-kpi-title">自行收單交易金額</span>\n              <div class="c-kpi-growth" id="c00-acq-amt-growth"><span class="number-positive">YoY +12.8%</span> <span class="number-positive">MoM +2.1%</span></div>'
    ),
    (
        '<div class="c-kpi-main-val">285.0 <em>億元</em></div>',
        '<div class="c-kpi-main-val" id="c00-acq-amt-val">285.0 <em>億元</em></div>'
    ),
    (
        '<div class="c-ratio-seg seg-phys" style="width: 65%;" title="實體收單: 65% (185.0 億)"></div>',
        '<div class="c-ratio-seg seg-phys" id="c00-acq-amt-seg-phys" style="width: 65%;" title="實體收單: 65% (185.0 億)"></div>'
    ),
    (
        '<div class="c-ratio-seg seg-onl" style="width: 35%;" title="線上 EPOS+PH: 35% (100.0 億)"></div>',
        '<div class="c-ratio-seg seg-onl" id="c00-acq-amt-seg-onl" style="width: 35%;" title="線上 EPOS+PH: 35% (100.0 億)"></div>'
    ),
    (
        '<span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys">(65%)</span></span>\n                <strong class="r-val">185.0<em>億</em></strong>',
        '<span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys" id="c00-acq-amt-phys-pct">(65%)</span></span>\n                <strong class="r-val" id="c00-acq-amt-phys-val">185.0<em>億</em></strong>'
    ),
    (
        '<span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl">(35%)</span></span>\n                <strong class="r-val">100.0<em>億</em></strong>',
        '<span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl" id="c00-acq-amt-onl-pct">(35%)</span></span>\n                <strong class="r-val" id="c00-acq-amt-onl-val">100.0<em>億</em></strong>'
    ),

    # ----------------------------------------------------
    # Cockpit Col 2: Card 2 (筆數)
    # ----------------------------------------------------
    (
        '<span class="c-kpi-title">自行收單交易筆數</span>\n              <div class="c-kpi-growth"><span class="number-positive">YoY +15.2%</span> <span class="number-positive">MoM +1.8%</span></div>',
        '<span class="c-kpi-title">自行收單交易筆數</span>\n              <div class="c-kpi-growth" id="c00-acq-cnt-growth"><span class="number-positive">YoY +15.2%</span> <span class="number-positive">MoM +1.8%</span></div>'
    ),
    (
        '<div class="c-kpi-main-val">1,850 <em>萬筆</em></div>',
        '<div class="c-kpi-main-val" id="c00-acq-cnt-val">1,850 <em>萬筆</em></div>'
    ),
    (
        '<div class="c-ratio-seg seg-phys" style="width: 70%;" title="實體收單: 70% (1,295 萬筆)"></div>',
        '<div class="c-ratio-seg seg-phys" id="c00-acq-cnt-seg-phys" style="width: 70%;" title="實體收單: 70% (1,295 萬筆)"></div>'
    ),
    (
        '<div class="c-ratio-seg seg-onl" style="width: 30%;" title="線上 EPOS+PH: 30% (555 萬筆)"></div>',
        '<div class="c-ratio-seg seg-onl" id="c00-acq-cnt-seg-onl" style="width: 30%;" title="線上 EPOS+PH: 30% (555 萬筆)"></div>'
    ),
    (
        '<span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys">(70%)</span></span>\n                <strong class="r-val">1,295<em>萬筆</em></strong>',
        '<span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys" id="c00-acq-cnt-phys-pct">(70%)</span></span>\n                <strong class="r-val" id="c00-acq-cnt-phys-val">1,295<em>萬筆</em></strong>'
    ),
    (
        '<span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl">(30%)</span></span>\n                <strong class="r-val">555<em>萬筆</em></strong>',
        '<span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl" id="c00-acq-cnt-onl-pct">(30%)</span></span>\n                <strong class="r-val" id="c00-acq-cnt-onl-val">555<em>萬筆</em></strong>'
    ),

    # ----------------------------------------------------
    # Cockpit Col 2: Card 3 (特店)
    # ----------------------------------------------------
    (
        '<span class="c-kpi-title">收單特店總數</span>\n              <div class="c-kpi-growth"><span class="number-positive">YoY +8.5%</span> <span class="c-hint">(活店率 83.0%)</span></div>',
        '<span class="c-kpi-title">收單特店總數</span>\n              <div class="c-kpi-growth" id="c00-acq-mcht-growth"><span class="number-positive">YoY +8.5%</span> <span class="c-hint" id="c00-acq-mcht-hint">(活店率 83.0%)</span></div>'
    ),
    (
        '<div class="c-kpi-main-val">48,500 <em>家</em></div>',
        '<div class="c-kpi-main-val" id="c00-acq-mcht-val">48,500 <em>家</em></div>'
    ),
    (
        '<div class="c-ratio-seg seg-phys" style="width: 80%;" title="實體特店: 80% (38,800 家)"></div>',
        '<div class="c-ratio-seg seg-phys" id="c00-acq-mcht-seg-phys" style="width: 80%;" title="實體特店: 80% (38,800 家)"></div>'
    ),
    (
        '<div class="c-ratio-seg seg-onl" style="width: 20%;" title="線上特店: 20% (9,700 家)"></div>',
        '<div class="c-ratio-seg seg-onl" id="c00-acq-mcht-seg-onl" style="width: 20%;" title="線上特店: 20% (9,700 家)"></div>'
    ),
    (
        '<span class="r-label"><span class="r-dot dot-phys"></span>實體特店 <span class="r-pct r-pct-phys">(80%)</span></span>\n                <strong class="r-val">38,800<em>家</em></strong>',
        '<span class="r-label"><span class="r-dot dot-phys"></span>實體特店 <span class="r-pct r-pct-phys" id="c00-acq-mcht-phys-pct">(80%)</span></span>\n                <strong class="r-val" id="c00-acq-mcht-phys-val">38,800<em>家</em></strong>'
    ),
    (
        '<span class="r-label"><span class="r-dot dot-onl"></span>線上特店 <span class="r-pct r-pct-onl">(20%)</span></span>\n                <strong class="r-val">9,700<em>家</em></strong>',
        '<span class="r-label"><span class="r-dot dot-onl"></span>線上特店 <span class="r-pct r-pct-onl" id="c00-acq-mcht-onl-pct">(20%)</span></span>\n                <strong class="r-val" id="c00-acq-mcht-onl-val">9,700<em>家</em></strong>'
    ),

    # ----------------------------------------------------
    # Cockpit Col 2: TWQR
    # ----------------------------------------------------
    (
        '<div class="c-twqr-stat-grid three-col">\n              <div class="c-twqr-cell">\n                <span>當月申請進件數</span>\n                <strong>3,850 <em>件</em></strong>\n              </div>\n              <div class="c-twqr-cell">\n                <span>當月新增特店家數</span>\n                <strong>3,511 <em>家</em></strong>\n                <b class="number-positive">審查通過率 91.2%</b>\n              </div>\n              <div class="c-twqr-cell">\n                <span>累計特店家數</span>\n                <strong>22,100 <em>家</em></strong>\n                <b class="number-positive">MoM +5.8%</b>\n              </div>\n            </div>',
        '<div class="c-twqr-stat-grid three-col">\n              <div class="c-twqr-cell">\n                <span>當月申請進件數</span>\n                <strong id="c00-twqr-apply-cnt">3,850 <em>件</em></strong>\n              </div>\n              <div class="c-twqr-cell">\n                <span>當月新增特店家數</span>\n                <strong id="c00-twqr-new-mcht">1,210 <em>家</em></strong>\n                <b class="number-positive" id="c00-twqr-pass-rate">審查通過率 91.2%</b>\n              </div>\n              <div class="c-twqr-cell">\n                <span>累計特店家數</span>\n                <strong id="c00-twqr-total-mcht">22,100 <em>家</em></strong>\n                <b class="number-positive" id="c00-twqr-total-mom">MoM +5.8%</b>\n              </div>\n            </div>'
    ),
    (
        '<div class="twqr-subhead">\n              <b>交易狀態分析</b>\n            </div>\n            <div class="c-twqr-stat-grid three-col">\n              <div class="c-twqr-cell">\n                <span>當月交易金額</span>\n                <strong>14.8 <em>億</em></strong>\n                <b class="number-positive">MoM +18.5%</b>\n              </div>\n              <div class="c-twqr-cell">\n                <span>當月交易筆數</span>\n                <strong>185 <em>萬筆</em></strong>\n                <b class="number-positive">MoM +16.2%</b>\n              </div>\n              <div class="c-twqr-cell">\n                <span>動用特店率</span>\n                <strong>68.2<em>%</em></strong>\n                <b class="number-positive">實際產生交易</b>\n              </div>\n            </div>',
        '<div class="twqr-subhead">\n              <b>交易狀態分析</b>\n            </div>\n            <div class="c-twqr-stat-grid three-col">\n              <div class="c-twqr-cell">\n                <span>當月交易金額</span>\n                <strong id="c00-twqr-tx-amt">12.8 <em>億</em></strong>\n                <b class="number-positive" id="c00-twqr-amt-mom">MoM +18.5%</b>\n              </div>\n              <div class="c-twqr-cell">\n                <span>當月交易筆數</span>\n                <strong id="c00-twqr-tx-cnt">185 <em>萬筆</em></strong>\n                <b class="number-positive" id="c00-twqr-cnt-mom">MoM +22.1%</b>\n              </div>\n              <div class="c-twqr-cell">\n                <span>動用特店率</span>\n                <strong id="c00-twqr-active-rate">78.5<em>%</em></strong>\n                <b class="number-positive">實際產生交易</b>\n              </div>\n            </div>'
    ),

    # ----------------------------------------------------
    # Section 02 Primary Card 1 (金額)
    # ----------------------------------------------------
    (
        '<div class="monthly-kpi-title">自行收單交易金額</div>\n          <div class="monthly-kpi-value">285.0<em>億元</em></div>\n          <div class="monthly-growth">\n            <span class="number-positive"><b>YoY</b>+12.8%</span><span class="number-positive"><b>MoM</b>+2.1%</span>\n          </div>\n          <div class="monthly-ratio-box">\n            <!-- 100% 比例進度條 -->\n            <div class="c-ratio-bar-wrap">\n              <div class="c-ratio-bar-track">\n                <div class="c-ratio-seg seg-phys" style="width: 65.0%;" title="實體收單: 65.0% (185.0 億)"></div>\n                <div class="c-ratio-seg seg-onl" style="width: 35.0%;" title="線上 EPOS+PH: 35.0% (100.0 億)"></div>\n              </div>\n            </div>\n\n            <!-- 比例條下方實質數據 -->\n            <div class="c-ratio-data-row">\n              <div class="c-ratio-col">\n                <span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys">(65.0%)</span></span>\n                <strong class="r-val">185.0<em>億</em></strong>\n              </div>\n              <div class="c-ratio-col align-right">\n                <span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl">(35.0%)</span></span>\n                <strong class="r-val">100.0<em>億</em></strong>\n              </div>\n            </div>',
        '<div class="monthly-kpi-title">自行收單交易金額</div>\n          <div class="monthly-kpi-value" id="b02-amt-val">285.0<em>億元</em></div>\n          <div class="monthly-growth" id="b02-amt-growth">\n            <span class="number-positive"><b>YoY</b>+12.8%</span><span class="number-positive"><b>MoM</b>+2.1%</span>\n          </div>\n          <div class="monthly-ratio-box">\n            <!-- 100% 比例進度條 -->\n            <div class="c-ratio-bar-wrap">\n              <div class="c-ratio-bar-track">\n                <div class="c-ratio-seg seg-phys" id="b02-amt-seg-phys" style="width: 65.0%;" title="實體收單: 65.0% (185.0 億)"></div>\n                <div class="c-ratio-seg seg-onl" id="b02-amt-seg-onl" style="width: 35.0%;" title="線上 EPOS+PH: 35.0% (100.0 億)"></div>\n              </div>\n            </div>\n\n            <!-- 比例條下方實質數據 -->\n            <div class="c-ratio-data-row">\n              <div class="c-ratio-col">\n                <span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys" id="b02-amt-phys-pct">(65.0%)</span></span>\n                <strong class="r-val" id="b02-amt-phys-val">185.0<em>億</em></strong>\n              </div>\n              <div class="c-ratio-col align-right">\n                <span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl" id="b02-amt-onl-pct">(35.0%)</span></span>\n                <strong class="r-val" id="b02-amt-onl-val">100.0<em>億</em></strong>\n              </div>\n            </div>'
    ),

    # ----------------------------------------------------
    # Section 02 Primary Card 2 (筆數)
    # ----------------------------------------------------
    (
        '<div class="monthly-kpi-title">自行收單交易筆數</div>\n          <div class="monthly-kpi-value">1,850<em>萬筆</em></div>\n          <div class="monthly-growth">\n            <span class="number-positive"><b>YoY</b>+15.2%</span><span class="number-positive"><b>MoM</b>+1.8%</span>\n          </div>\n          <div class="monthly-ratio-box">\n            <!-- 100% 比例進度條 -->\n            <div class="c-ratio-bar-wrap">\n              <div class="c-ratio-bar-track">\n                <div class="c-ratio-seg seg-phys" style="width: 70.0%;" title="實體收單: 70.0% (1,295 萬筆)"></div>\n                <div class="c-ratio-seg seg-onl" style="width: 30.0%;" title="線上 EPOS+PH: 30.0% (555 萬筆)"></div>\n              </div>\n            </div>\n\n            <!-- 比例條下方實質數據 -->\n            <div class="c-ratio-data-row">\n              <div class="c-ratio-col">\n                <span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys">(70.0%)</span></span>\n                <strong class="r-val">1,295<em>萬筆</em></strong>\n              </div>\n              <div class="c-ratio-col align-right">\n                <span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl">(30.0%)</span></span>\n                <strong class="r-val">555<em>萬筆</em></strong>\n              </div>\n            </div>',
        '<div class="monthly-kpi-title">自行收單交易筆數</div>\n          <div class="monthly-kpi-value" id="b02-cnt-val">1,850<em>萬筆</em></div>\n          <div class="monthly-growth" id="b02-cnt-growth">\n            <span class="number-positive"><b>YoY</b>+15.2%</span><span class="number-positive"><b>MoM</b>+1.8%</span>\n          </div>\n          <div class="monthly-ratio-box">\n            <!-- 100% 比例進度條 -->\n            <div class="c-ratio-bar-wrap">\n              <div class="c-ratio-bar-track">\n                <div class="c-ratio-seg seg-phys" id="b02-cnt-seg-phys" style="width: 70.0%;" title="實體收單: 70.0% (1,295 萬筆)"></div>\n                <div class="c-ratio-seg seg-onl" id="b02-cnt-seg-onl" style="width: 30.0%;" title="線上 EPOS+PH: 30.0% (555 萬筆)"></div>\n              </div>\n            </div>\n\n            <!-- 比例條下方實質數據 -->\n            <div class="c-ratio-data-row">\n              <div class="c-ratio-col">\n                <span class="r-label"><span class="r-dot dot-phys"></span>實體收單 <span class="r-pct r-pct-phys" id="b02-cnt-phys-pct">(70.0%)</span></span>\n                <strong class="r-val" id="b02-cnt-phys-val">1,295<em>萬筆</em></strong>\n              </div>\n              <div class="c-ratio-col align-right">\n                <span class="r-label"><span class="r-dot dot-onl"></span>線上 EPOS+PH <span class="r-pct r-pct-onl">(30.0%)</span></span>\n                <strong class="r-val" id="b02-cnt-onl-val">555<em>萬筆</em></strong>\n              </div>\n            </div>'
    ),

    # ----------------------------------------------------
    # Section 02 Primary Card 3 (特店)
    # ----------------------------------------------------
    (
        '<div class="monthly-kpi-title">收單特店總數</div>\n          <div class="monthly-kpi-value">48,500<em>家</em></div>\n          <div class="monthly-growth">\n            <span class="number-positive"><b>YoY</b>+8.5%</span><span class="number-positive"><b>MoM</b>+0.7%</span>\n          </div>\n          <div class="monthly-ratio-box">\n            <!-- 100% 比例進度條 -->\n            <div class="c-ratio-bar-wrap">\n              <div class="c-ratio-bar-track">\n                <div class="c-ratio-seg seg-phys" style="width: 80.0%;" title="實體特店: 80.0% (38,800 家)"></div>\n                <div class="c-ratio-seg seg-onl" style="width: 20.0%;" title="線上特店: 20.0% (9,700 家)"></div>\n              </div>\n            </div>\n\n            <!-- 比例條下方實質數據 -->\n            <div class="c-ratio-data-row">\n              <div class="c-ratio-col">\n                <span class="r-label"><span class="r-dot dot-phys"></span>實體特店 <span class="r-pct r-pct-phys">(80.0%)</span></span>\n                <strong class="r-val">38,800<em>家</em></strong>\n              </div>\n              <div class="c-ratio-col align-right">\n                <span class="r-label"><span class="r-dot dot-onl"></span>線上特店 <span class="r-pct r-pct-onl">(20.0%)</span></span>\n                <strong class="r-val">9,700<em>家</em></strong>\n              </div>\n            </div>',
        '<div class="monthly-kpi-title">收單特店總數</div>\n          <div class="monthly-kpi-value" id="b02-mcht-val">48,500<em>家</em></div>\n          <div class="monthly-growth" id="b02-mcht-growth">\n            <span class="number-positive"><b>YoY</b>+8.5%</span><span class="number-positive"><b>MoM</b>+0.7%</span>\n          </div>\n          <div class="monthly-ratio-box">\n            <!-- 100% 比例進度條 -->\n            <div class="c-ratio-bar-wrap">\n              <div class="c-ratio-bar-track">\n                <div class="c-ratio-seg seg-phys" id="b02-mcht-seg-phys" style="width: 80.0%;" title="實體特店: 80.0% (38,800 家)"></div>\n                <div class="c-ratio-seg seg-onl" id="b02-mcht-seg-onl" style="width: 20.0%;" title="線上特店: 20.0% (9,700 家)"></div>\n              </div>\n            </div>\n\n            <!-- 比例條下方實質數據 -->\n            <div class="c-ratio-data-row">\n              <div class="c-ratio-col">\n                <span class="r-label"><span class="r-dot dot-phys"></span>實體特店 <span class="r-pct r-pct-phys" id="b02-mcht-phys-pct">(80.0%)</span></span>\n                <strong class="r-val" id="b02-mcht-phys-val">38,800<em>家</em></strong>\n              </div>\n              <div class="c-ratio-col align-right">\n                <span class="r-label"><span class="r-dot dot-onl"></span>線上特店 <span class="r-pct r-pct-onl" id="b02-mcht-onl-pct">(20.0%)</span></span>\n                <strong class="r-val" id="b02-mcht-onl-val">9,700<em>家</em></strong>\n              </div>\n            </div>'
    ),

    # ----------------------------------------------------
    # Section 02 Secondary Cards (4 Cards)
    # ----------------------------------------------------
    (
        '<div class="monthly-kpi-title">自行收單滲透率</div>\n          <div class="monthly-kpi-value">24.5%</div>\n          <div class="monthly-growth">\n            <span class="number-positive"><b>YoY</b>+1.8pp</span><span class="number-positive"><b>MoM</b>+0.3pp</span>\n          </div>',
        '<div class="monthly-kpi-title">自行收單滲透率</div>\n          <div class="monthly-kpi-value" id="b02-penetration-val">24.5%</div>\n          <div class="monthly-growth" id="b02-penetration-growth">\n            <span class="number-positive"><b>YoY</b>+1.8pp</span><span class="number-positive"><b>MoM</b>+0.3pp</span>\n          </div>'
    ),
    (
        '<div class="monthly-kpi-title">活躍自行特店數</div>\n          <div class="monthly-kpi-value">40,250<em>家</em></div>\n          <div class="monthly-growth">\n            <span class="number-positive"><b>YoY</b>+6.2%</span><span class="number-positive"><b>活店率</b>83.0%</span>\n          </div>',
        '<div class="monthly-kpi-title">活躍自行特店數</div>\n          <div class="monthly-kpi-value" id="b02-active-mcht-val">40,250<em>家</em></div>\n          <div class="monthly-growth" id="b02-active-mcht-growth">\n            <span class="number-positive"><b>YoY</b>+6.2%</span><span class="number-positive"><b>活店率</b>83.0%</span>\n          </div>'
    ),
    (
        '<div class="monthly-kpi-title">電子對帳單覆蓋率</div>\n          <div class="monthly-kpi-value">92.4%</div>',
        '<div class="monthly-kpi-title">電子對帳單覆蓋率</div>\n          <div class="monthly-kpi-value" id="b02-estatement-val">92.4%</div>'
    ),
    (
        '<div class="monthly-kpi-title">收單手續費收入</div>\n          <div class="monthly-kpi-value">4.52<em>億元</em></div>\n          <div class="monthly-growth">\n            <span class="number-positive"><b>YoY</b>+11.5%</span>\n          </div>',
        '<div class="monthly-kpi-title">收單手續費收入</div>\n          <div class="monthly-kpi-value" id="b02-fee-val">4.52<em>億元</em></div>\n          <div class="monthly-growth" id="b02-fee-growth">\n            <span class="number-positive"><b>YoY</b>+11.5%</span>\n          </div>'
    ),

    # ----------------------------------------------------
    # TAB 0: 線上交易分析
    # ----------------------------------------------------
    (
        '<div class="structure-bar">',
        '<div class="structure-bar" id="b02-online-struct-bar">'
    ),
    (
        '<tbody>\n                <tr>\n                  <td><strong>EPOS - 雲端</strong></td>',
        '<tbody id="b02-online-table-body">\n                <tr>\n                  <td><strong>EPOS - 雲端</strong></td>'
    ),

    # ----------------------------------------------------
    # TAB 1: 特店集中度與矩陣
    # ----------------------------------------------------
    (
        '<strong style="font-size:21px; font-weight:900; color:var(--blue-dark); line-height:1;">48.2%</strong>\n                    <span class="number-positive" style="font-size:12.5px; font-weight:800;">YoY +1.5pp</span>',
        '<strong style="font-size:21px; font-weight:900; color:var(--blue-dark); line-height:1;" id="b02-top10-share">48.2%</strong>\n                    <span class="number-positive" style="font-size:12.5px; font-weight:800;" id="b02-top10-yoy">YoY +1.5pp</span>'
    ),
    (
        '<div class="merchant-progress-list" style="display:flex; flex-direction:column; gap:13px;">',
        '<div class="merchant-progress-list" id="b02-top-merchants-list" style="display:flex; flex-direction:column; gap:13px;">'
    ),
    (
        '<strong style="color:var(--ink); font-size:13.5px; font-weight:800;">代表：特店 E 等</strong>',
        '<strong style="color:var(--ink); font-size:13.5px; font-weight:800;" id="b02-rep-potential">代表：特店 E 等</strong>'
    ),
    (
        '<strong style="color:var(--ink); font-size:13.5px; font-weight:800;">代表：特店 A、特店 B</strong>',
        '<strong style="color:var(--ink); font-size:13.5px; font-weight:800;" id="b02-rep-core">代表：特店 A、特店 B</strong>'
    ),
    (
        '<strong style="color:var(--ink); font-size:13.5px; font-weight:800;">代表：長尾特店群</strong>',
        '<strong style="color:var(--ink); font-size:13.5px; font-weight:800;" id="b02-rep-general">代表：長尾特店群</strong>'
    ),
    (
        '<strong style="color:var(--ink); font-size:13.5px; font-weight:800;">代表：特店 C、特店 D</strong>',
        '<strong style="color:var(--ink); font-size:13.5px; font-weight:800;" id="b02-rep-maintain">代表：特店 C、特店 D</strong>'
    ),

    # ----------------------------------------------------
    # TAB 2: 蝴蝶圖
    # ----------------------------------------------------
    (
        '<div class="acq-butterfly-list">',
        '<div class="acq-butterfly-list" id="b02-butterfly-list">'
    ),

    # ----------------------------------------------------
    # TWQR 專區
    # ----------------------------------------------------
    (
        '<strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;">3,850 件</strong>\n                <b class="" style="font-size:11.5px; font-weight:800; color:#64748b;">審查通過率 91.2%</b>',
        '<strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-apply-cnt">3,850 件</strong>\n                <b class="" style="font-size:11.5px; font-weight:800; color:#64748b;" id="b02-twqr-pass-rate">審查通過率 91.2%</b>'
    ),
    (
        '<strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;">1,210 家</strong>',
        '<strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-new-mcht">1,210 家</strong>'
    ),
    (
        '<strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;">22,100 家</strong>\n                <b class="is-good" style="font-size:11.5px; font-weight:800; color:#047857;">MoM +5.8%</b>',
        '<strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-total-mcht">22,100 家</strong>\n                <b class="is-good" style="font-size:11.5px; font-weight:800; color:#047857;" id="b02-twqr-total-mom">MoM +5.8%</b>'
    ),
    (
        '<strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;">12.8 億</strong>\n                <b class="is-good" style="font-size:11.5px; font-weight:800; color:#047857;">MoM +18.5%</b>',
        '<strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-tx-amt">12.8 億</strong>\n                <b class="is-good" style="font-size:11.5px; font-weight:800; color:#047857;" id="b02-twqr-amt-mom">MoM +18.5%</b>'
    ),
    (
        '<strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;">185 萬筆</strong>\n                <b class="is-good" style="font-size:11.5px; font-weight:800; color:#047857;">MoM +22.1%</b>',
        '<strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-tx-cnt">185 萬筆</strong>\n                <b class="is-good" style="font-size:11.5px; font-weight:800; color:#047857;" id="b02-twqr-cnt-mom">MoM +22.1%</b>'
    ),
    (
        '<strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;">692 元</strong>',
        '<strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-avg-ticket">692 元</strong>'
    ),
    (
        '<strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;">5.79 萬元</strong>',
        '<strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-mcht-avg-amt">5.79 萬元</strong>'
    ),
    (
        '<strong style="font-size:22px; font-weight:800; color:var(--blue-dark); margin:4px 0; display:block;">78.5%</strong>',
        '<strong style="font-size:22px; font-weight:800; color:var(--blue-dark); margin:4px 0; display:block;" id="b02-twqr-active-rate">78.5%</strong>'
    )
]

for idx, (target, repl) in enumerate(replacements, 1):
    cnt = html.count(target)
    assert cnt == 1, f"Replacement {idx} failed: found {cnt} occurrences"
    html = html.replace(target, repl)

# Add renderBlock02FromData
render_b02_code = """
  // ============================================================================
  // 動態渲染 02 收單業務 (Block 02) 數據引擎
  // ============================================================================
  function renderBlock02FromData(data) {
    if (!data || !data.block02) return;
    const b2 = data.block02;
    const kpi = b2.monthly_kpis || {};
    const twqr = b2.twqr || {};

    const isValidNum = (v) => v !== null && v !== undefined && !isNaN(Number(v));
    const fmtNum = (v, d = 1) => isValidNum(v) ? Number(v).toLocaleString(undefined, { minimumFractionDigits: d, maximumFractionDigits: d }) : "-";
    const fmtSign = (v, s = "%") => {
      if (!isValidNum(v)) return "-";
      const n = Number(v);
      return `${n > 0 ? "+" : ""}${n.toFixed(1)}${s}`;
    };
    const semCls = (v) => {
      if (!isValidNum(v)) return "number-neutral";
      return Number(v) >= 0 ? "number-positive" : "number-negative";
    };

    // 1. 自行收單交易金額
    const amt = kpi.acq_amt || {};
    const amtPhys = amt.physical || {};
    const amtOnl = amt.online || {};

    const amtValHtml = isValidNum(amt.total) ? `${fmtNum(amt.total, 1)}<em>${amt.unit || '億元'}</em>` : `-`;
    const amtGrowthHtml = `
      <span class="${semCls(amt.yoy)}"><b>YoY</b>${fmtSign(amt.yoy)}</span>
      <span class="${semCls(amt.mom)}"><b>MoM</b>${fmtSign(amt.mom)}</span>
    `;

    // Cockpit Col 2: Card 1
    const c00AmtVal = document.getElementById("c00-acq-amt-val");
    if (c00AmtVal) c00AmtVal.innerHTML = isValidNum(amt.total) ? `${fmtNum(amt.total, 1)} <em>${amt.unit || '億元'}</em>` : `-`;
    const c00AmtGrowth = document.getElementById("c00-acq-amt-growth");
    if (c00AmtGrowth) {
      c00AmtGrowth.innerHTML = `
        <span class="${semCls(amt.yoy)}">YoY ${fmtSign(amt.yoy)}</span>
        <span class="${semCls(amt.mom)}">MoM ${fmtSign(amt.mom)}</span>
      `;
    }
    const c00AmtSegPhys = document.getElementById("c00-acq-amt-seg-phys");
    if (c00AmtSegPhys) {
      c00AmtSegPhys.style.width = isValidNum(amtPhys.share) ? `${amtPhys.share}%` : `0%`;
      c00AmtSegPhys.title = isValidNum(amtPhys.share) ? `實體收單: ${amtPhys.share}% (${fmtNum(amtPhys.amount, 1)} 億)` : `實體收單: -`;
    }
    const c00AmtSegOnl = document.getElementById("c00-acq-amt-seg-onl");
    if (c00AmtSegOnl) {
      c00AmtSegOnl.style.width = isValidNum(amtOnl.share) ? `${amtOnl.share}%` : `0%`;
      c00AmtSegOnl.title = isValidNum(amtOnl.share) ? `線上 EPOS+PH: ${amtOnl.share}% (${fmtNum(amtOnl.amount, 1)} 億)` : `線上 EPOS+PH: -`;
    }
    const c00AmtPhysPct = document.getElementById("c00-acq-amt-phys-pct");
    if (c00AmtPhysPct) c00AmtPhysPct.textContent = isValidNum(amtPhys.share) ? `(${amtPhys.share}%)` : `(-%)`;
    const c00AmtPhysVal = document.getElementById("c00-acq-amt-phys-val");
    if (c00AmtPhysVal) c00AmtPhysVal.innerHTML = isValidNum(amtPhys.amount) ? `${fmtNum(amtPhys.amount, 1)}<em>億</em>` : `-`;
    const c00AmtOnlPct = document.getElementById("c00-acq-amt-onl-pct");
    if (c00AmtOnlPct) c00AmtOnlPct.textContent = isValidNum(amtOnl.share) ? `(${amtOnl.share}%)` : `(-%)`;
    const c00AmtOnlVal = document.getElementById("c00-acq-amt-onl-val");
    if (c00AmtOnlVal) c00AmtOnlVal.innerHTML = isValidNum(amtOnl.amount) ? `${fmtNum(amtOnl.amount, 1)}<em>億</em>` : `-`;

    // 02 Section: Primary Card 1
    const b02AmtVal = document.getElementById("b02-amt-val");
    if (b02AmtVal) b02AmtVal.innerHTML = amtValHtml;
    const b02AmtGrowth = document.getElementById("b02-amt-growth");
    if (b02AmtGrowth) b02AmtGrowth.innerHTML = amtGrowthHtml;
    const b02AmtSegPhys = document.getElementById("b02-amt-seg-phys");
    if (b02AmtSegPhys) {
      b02AmtSegPhys.style.width = isValidNum(amtPhys.share) ? `${amtPhys.share}%` : `0%`;
      b02AmtSegPhys.title = isValidNum(amtPhys.share) ? `實體收單: ${amtPhys.share}% (${fmtNum(amtPhys.amount, 1)} 億)` : `實體收單: -`;
    }
    const b02AmtSegOnl = document.getElementById("b02-amt-seg-onl");
    if (b02AmtSegOnl) {
      b02AmtSegOnl.style.width = isValidNum(amtOnl.share) ? `${amtOnl.share}%` : `0%`;
      b02AmtSegOnl.title = isValidNum(amtOnl.share) ? `線上 EPOS+PH: ${amtOnl.share}% (${fmtNum(amtOnl.amount, 1)} 億)` : `線上 EPOS+PH: -`;
    }
    const b02AmtPhysPct = document.getElementById("b02-amt-phys-pct");
    if (b02AmtPhysPct) b02AmtPhysPct.textContent = isValidNum(amtPhys.share) ? `(${amtPhys.share}%)` : `(-%)`;
    const b02AmtPhysVal = document.getElementById("b02-amt-phys-val");
    if (b02AmtPhysVal) b02AmtPhysVal.innerHTML = isValidNum(amtPhys.amount) ? `${fmtNum(amtPhys.amount, 1)}<em>億</em>` : `-`;
    const b02AmtOnlPct = document.getElementById("b02-amt-onl-pct");
    if (b02AmtOnlPct) b02AmtOnlPct.textContent = isValidNum(amtOnl.share) ? `(${amtOnl.share}%)` : `(-%)`;
    const b02AmtOnlVal = document.getElementById("b02-amt-onl-val");
    if (b02AmtOnlVal) b02AmtOnlVal.innerHTML = isValidNum(amtOnl.amount) ? `${fmtNum(amtOnl.amount, 1)}<em>億</em>` : `-`;

    // 2. 自行收單交易筆數
    const cnt = kpi.acq_cnt || {};
    const cntPhys = cnt.physical || {};
    const cntOnl = cnt.online || {};

    const cntValHtml = isValidNum(cnt.total) ? `${Number(cnt.total).toLocaleString()}<em>${cnt.unit || '萬筆'}</em>` : `-`;
    const cntGrowthHtml = `
      <span class="${semCls(cnt.yoy)}"><b>YoY</b>${fmtSign(cnt.yoy)}</span>
      <span class="${semCls(cnt.mom)}"><b>MoM</b>${fmtSign(cnt.mom)}</span>
    `;

    // Cockpit Col 2: Card 2
    const c00CntVal = document.getElementById("c00-acq-cnt-val");
    if (c00CntVal) c00CntVal.innerHTML = isValidNum(cnt.total) ? `${Number(cnt.total).toLocaleString()} <em>${cnt.unit || '萬筆'}</em>` : `-`;
    const c00CntGrowth = document.getElementById("c00-acq-cnt-growth");
    if (c00CntGrowth) {
      c00CntGrowth.innerHTML = `
        <span class="${semCls(cnt.yoy)}">YoY ${fmtSign(cnt.yoy)}</span>
        <span class="${semCls(cnt.mom)}">MoM ${fmtSign(cnt.mom)}</span>
      `;
    }
    const c00CntSegPhys = document.getElementById("c00-acq-cnt-seg-phys");
    if (c00CntSegPhys) {
      c00CntSegPhys.style.width = isValidNum(cntPhys.share) ? `${cntPhys.share}%` : `0%`;
      c00CntSegPhys.title = isValidNum(cntPhys.share) ? `實體收單: ${cntPhys.share}% (${fmtNum(cntPhys.count, 0)} 萬筆)` : `實體收單: -`;
    }
    const c00CntSegOnl = document.getElementById("c00-acq-cnt-seg-onl");
    if (c00CntSegOnl) {
      c00CntSegOnl.style.width = isValidNum(cntOnl.share) ? `${cntOnl.share}%` : `0%`;
      c00CntSegOnl.title = isValidNum(cntOnl.share) ? `線上 EPOS+PH: ${cntOnl.share}% (${fmtNum(cntOnl.count, 0)} 萬筆)` : `線上 EPOS+PH: -`;
    }
    const c00CntPhysPct = document.getElementById("c00-acq-cnt-phys-pct");
    if (c00CntPhysPct) c00CntPhysPct.textContent = isValidNum(cntPhys.share) ? `(${cntPhys.share}%)` : `(-%)`;
    const c00CntPhysVal = document.getElementById("c00-acq-cnt-phys-val");
    if (c00CntPhysVal) c00CntPhysVal.innerHTML = isValidNum(cntPhys.count) ? `${Number(cntPhys.count).toLocaleString()}<em>萬筆</em>` : `-`;
    const c00CntOnlPct = document.getElementById("c00-acq-cnt-onl-pct");
    if (c00CntOnlPct) c00CntOnlPct.textContent = isValidNum(cntOnl.share) ? `(${cntOnl.share}%)` : `(-%)`;
    const c00CntOnlVal = document.getElementById("c00-acq-cnt-onl-val");
    if (c00CntOnlVal) c00CntOnlVal.innerHTML = isValidNum(cntOnl.count) ? `${Number(cntOnl.count).toLocaleString()}<em>萬筆</em>` : `-`;

    // 02 Section: Primary Card 2
    const b02CntVal = document.getElementById("b02-cnt-val");
    if (b02CntVal) b02CntVal.innerHTML = cntValHtml;
    const b02CntGrowth = document.getElementById("b02-cnt-growth");
    if (b02CntGrowth) b02CntGrowth.innerHTML = cntGrowthHtml;
    const b02CntSegPhys = document.getElementById("b02-cnt-seg-phys");
    if (b02CntSegPhys) {
      b02CntSegPhys.style.width = isValidNum(cntPhys.share) ? `${cntPhys.share}%` : `0%`;
      b02CntSegPhys.title = isValidNum(cntPhys.share) ? `實體收單: ${cntPhys.share}% (${fmtNum(cntPhys.count, 0)} 萬筆)` : `實體收單: -`;
    }
    const b02CntSegOnl = document.getElementById("b02-cnt-seg-onl");
    if (b02CntSegOnl) {
      b02CntSegOnl.style.width = isValidNum(cntOnl.share) ? `${cntOnl.share}%` : `0%`;
      b02CntSegOnl.title = isValidNum(cntOnl.share) ? `線上 EPOS+PH: ${cntOnl.share}% (${fmtNum(cntOnl.count, 0)} 萬筆)` : `線上 EPOS+PH: -`;
    }
    const b02CntPhysPct = document.getElementById("b02-cnt-phys-pct");
    if (b02CntPhysPct) b02CntPhysPct.textContent = isValidNum(cntPhys.share) ? `(${cntPhys.share}%)` : `(-%)`;
    const b02CntPhysVal = document.getElementById("b02-cnt-phys-val");
    if (b02CntPhysVal) b02CntPhysVal.innerHTML = isValidNum(cntPhys.count) ? `${Number(cntPhys.count).toLocaleString()}<em>萬筆</em>` : `-`;
    const b02CntOnlPct = document.getElementById("b02-cnt-onl-pct");
    if (b02CntOnlPct) b02CntOnlPct.textContent = isValidNum(cntOnl.share) ? `(${cntOnl.share}%)` : `(-%)`;
    const b02CntOnlVal = document.getElementById("b02-cnt-onl-val");
    if (b02CntOnlVal) b02CntOnlVal.innerHTML = isValidNum(cntOnl.count) ? `${Number(cntOnl.count).toLocaleString()}<em>萬筆</em>` : `-`;

    // 3. 收單特店總數
    const mcht = kpi.acq_mcht || {};
    const mchtPhys = mcht.physical || {};
    const mchtOnl = mcht.online || {};

    const mchtValHtml = isValidNum(mcht.total) ? `${Number(mcht.total).toLocaleString()}<em>${mcht.unit || '家'}</em>` : `-`;
    const mchtGrowthHtml = `
      <span class="${semCls(mcht.yoy)}"><b>YoY</b>${fmtSign(mcht.yoy)}</span>
      <span class="${semCls(mcht.mom)}"><b>MoM</b>${fmtSign(mcht.mom)}</span>
    `;

    // Cockpit Col 2: Card 3
    const c00MchtVal = document.getElementById("c00-acq-mcht-val");
    if (c00MchtVal) c00MchtVal.innerHTML = isValidNum(mcht.total) ? `${Number(mcht.total).toLocaleString()} <em>${mcht.unit || '家'}</em>` : `-`;
    const c00MchtGrowth = document.getElementById("c00-acq-mcht-growth");
    if (c00MchtGrowth) {
      c00MchtGrowth.innerHTML = `<span class="${semCls(mcht.yoy)}">YoY ${fmtSign(mcht.yoy)}</span> <span class="c-hint" id="c00-acq-mcht-hint">(活店率 ${isValidNum(mcht.active_rate) ? mcht.active_rate + '%' : '-'})</span>`;
    }
    const c00MchtSegPhys = document.getElementById("c00-acq-mcht-seg-phys");
    if (c00MchtSegPhys) {
      c00MchtSegPhys.style.width = isValidNum(mchtPhys.share) ? `${mchtPhys.share}%` : `0%`;
      c00MchtSegPhys.title = isValidNum(mchtPhys.share) ? `實體特店: ${mchtPhys.share}% (${fmtNum(mchtPhys.count, 0)} 家)` : `實體特店: -`;
    }
    const c00MchtSegOnl = document.getElementById("c00-acq-mcht-seg-onl");
    if (c00MchtSegOnl) {
      c00MchtSegOnl.style.width = isValidNum(mchtOnl.share) ? `${mchtOnl.share}%` : `0%`;
      c00MchtSegOnl.title = isValidNum(mchtOnl.share) ? `線上特店: ${mchtOnl.share}% (${fmtNum(mchtOnl.count, 0)} 家)` : `線上特店: -`;
    }
    const c00MchtPhysPct = document.getElementById("c00-acq-mcht-phys-pct");
    if (c00MchtPhysPct) c00MchtPhysPct.textContent = isValidNum(mchtPhys.share) ? `(${mchtPhys.share}%)` : `(-%)`;
    const c00MchtPhysVal = document.getElementById("c00-acq-mcht-phys-val");
    if (c00MchtPhysVal) c00MchtPhysVal.innerHTML = isValidNum(mchtPhys.count) ? `${Number(mchtPhys.count).toLocaleString()}<em>家</em>` : `-`;
    const c00MchtOnlPct = document.getElementById("c00-acq-mcht-onl-pct");
    if (c00MchtOnlPct) c00MchtOnlPct.textContent = isValidNum(mchtOnl.share) ? `(${mchtOnl.share}%)` : `(-%)`;
    const c00MchtOnlVal = document.getElementById("c00-acq-mcht-onl-val");
    if (c00MchtOnlVal) c00MchtOnlVal.innerHTML = isValidNum(mchtOnl.count) ? `${Number(mchtOnl.count).toLocaleString()}<em>家</em>` : `-`;

    // 02 Section: Primary Card 3
    const b02MchtVal = document.getElementById("b02-mcht-val");
    if (b02MchtVal) b02MchtVal.innerHTML = mchtValHtml;
    const b02MchtGrowth = document.getElementById("b02-mcht-growth");
    if (b02MchtGrowth) b02MchtGrowth.innerHTML = mchtGrowthHtml;
    const b02MchtSegPhys = document.getElementById("b02-mcht-seg-phys");
    if (b02MchtSegPhys) {
      b02MchtSegPhys.style.width = isValidNum(mchtPhys.share) ? `${mchtPhys.share}%` : `0%`;
      b02MchtSegPhys.title = isValidNum(mchtPhys.share) ? `實體特店: ${mchtPhys.share}% (${fmtNum(mchtPhys.count, 0)} 家)` : `實體特店: -`;
    }
    const b02MchtSegOnl = document.getElementById("b02-mcht-seg-onl");
    if (b02MchtSegOnl) {
      b02MchtSegOnl.style.width = isValidNum(mchtOnl.share) ? `${mchtOnl.share}%` : `0%`;
      b02MchtSegOnl.title = isValidNum(mchtOnl.share) ? `線上特店: ${mchtOnl.share}% (${fmtNum(mchtOnl.count, 0)} 家)` : `線上特店: -`;
    }
    const b02MchtPhysPct = document.getElementById("b02-mcht-phys-pct");
    if (b02MchtPhysPct) b02MchtPhysPct.textContent = isValidNum(mchtPhys.share) ? `(${mchtPhys.share}%)` : `(-%)`;
    const b02MchtPhysVal = document.getElementById("b02-mcht-phys-val");
    if (b02MchtPhysVal) b02MchtPhysVal.innerHTML = isValidNum(mchtPhys.count) ? `${Number(mchtPhys.count).toLocaleString()}<em>家</em>` : `-`;
    const b02MchtOnlPct = document.getElementById("b02-mcht-onl-pct");
    if (b02MchtOnlPct) b02MchtOnlPct.textContent = isValidNum(mchtOnl.share) ? `(${mchtOnl.share}%)` : `(-%)`;
    const b02MchtOnlVal = document.getElementById("b02-mcht-onl-val");
    if (b02MchtOnlVal) b02MchtOnlVal.innerHTML = isValidNum(mchtOnl.count) ? `${Number(mchtOnl.count).toLocaleString()}<em>家</em>` : `-`;

    // 4. 次要指標 (4 Cards)
    const sec = kpi.secondary || {};
    const pen = sec.penetration_rate || {};
    const actMcht = sec.active_mcht || {};
    const estmt = sec.estatement_rate || {};
    const fee = sec.fee_income || {};

    const b02PenVal = document.getElementById("b02-penetration-val");
    if (b02PenVal) b02PenVal.textContent = isValidNum(pen.value) ? `${pen.value}%` : `-`;
    const b02PenGrowth = document.getElementById("b02-penetration-growth");
    if (b02PenGrowth) {
      b02PenGrowth.innerHTML = `
        <span class="${semCls(pen.yoy)}"><b>YoY</b>${fmtSign(pen.yoy, "pp")}</span>
        <span class="${semCls(pen.mom)}"><b>MoM</b>${fmtSign(pen.mom, "pp")}</span>
      `;
    }

    const b02ActMchtVal = document.getElementById("b02-active-mcht-val");
    if (b02ActMchtVal) b02ActMchtVal.innerHTML = isValidNum(actMcht.count) ? `${Number(actMcht.count).toLocaleString()}<em>${actMcht.unit || '家'}</em>` : `-`;
    const b02ActMchtGrowth = document.getElementById("b02-active-mcht-growth");
    if (b02ActMchtGrowth) {
      b02ActMchtGrowth.innerHTML = `
        <span class="${semCls(actMcht.yoy)}"><b>YoY</b>${fmtSign(actMcht.yoy)}</span>
        <span class="number-positive"><b>活店率</b>${isValidNum(actMcht.active_rate) ? actMcht.active_rate + '%' : '-'}</span>
      `;
    }

    const b02EstmtVal = document.getElementById("b02-estatement-val");
    if (b02EstmtVal) b02EstmtVal.textContent = isValidNum(estmt.value) ? `${estmt.value}%` : `-`;

    const b02FeeVal = document.getElementById("b02-fee-val");
    if (b02FeeVal) b02FeeVal.innerHTML = isValidNum(fee.value) ? `${fmtNum(fee.value, 2)}<em>${fee.unit || '億元'}</em>` : `-`;
    const b02FeeGrowth = document.getElementById("b02-fee-growth");
    if (b02FeeGrowth) {
      b02FeeGrowth.innerHTML = `<span class="${semCls(fee.yoy)}"><b>YoY</b>${fmtSign(fee.yoy)}</span>`;
    }

    // 5. 2B TAB 0: 線上交易型態
    const channels = b2.online_channels || [];
    if (channels.length > 0) {
      const structBar = document.getElementById("b02-online-struct-bar");
      if (structBar) {
        const colors = ["#003b5c", "#3b82f6", "#ea580c"];
        structBar.innerHTML = channels.map((c, idx) => `
          <div style="background:${colors[idx % colors.length]}; width:${isValidNum(c.amount_share) ? c.amount_share : 0}%;" title="${c.name} (${isValidNum(c.amount_share) ? c.amount_share + '%' : '-'})">
            <span>${c.name} (${isValidNum(c.amount_share) ? c.amount_share + '%' : '-'})</span>
          </div>
        `).join("");
      }

      const tableBody = document.getElementById("b02-online-table-body");
      if (tableBody) {
        tableBody.innerHTML = channels.map(c => `
          <tr>
            <td><strong>${c.name}</strong></td>
            <td style="text-align:right;"><strong style="color:var(--blue-dark); font-size:15.5px;">${isValidNum(c.amount) ? fmtNum(c.amount, 1) + ' 億元' : '-'}</strong></td>
            <td style="text-align:right;" class="${semCls(c.amount_yoy)}"><strong>${fmtSign(c.amount_yoy)}</strong></td>
            <td style="text-align:right;">${isValidNum(c.count) ? Number(c.count).toLocaleString() + ' 萬筆' : '-'}</td>
            <td style="text-align:right;" class="${semCls(c.count_yoy)}"><strong>${fmtSign(c.count_yoy)}</strong></td>
            <td style="text-align:right;">${isValidNum(c.avg_ticket) ? Number(c.avg_ticket).toLocaleString() + ' 元' : '-'}</td>
            <td style="text-align:right;" class="${semCls(c.avg_ticket_yoy)}"><strong>${fmtSign(c.avg_ticket_yoy)}</strong></td>
          </tr>
        `).join("");
      }
    }

    // 6. 2B TAB 1: 特店集中度與 2x2 矩陣
    const conc = b2.merchant_concentration || {};
    const top10ShareElem = document.getElementById("b02-top10-share");
    if (top10ShareElem) top10ShareElem.textContent = isValidNum(conc.top10_share) ? `${conc.top10_share}%` : `-`;
    const top10YoyElem = document.getElementById("b02-top10-yoy");
    if (top10YoyElem) top10YoyElem.textContent = isValidNum(conc.top10_yoy) ? `YoY ${fmtSign(conc.top10_yoy, 'pp')}` : `YoY -`;

    const topMchts = conc.top_merchants || [];
    const topMchtList = document.getElementById("b02-top-merchants-list");
    if (topMchtList && topMchts.length > 0) {
      const maxMchtAmt = Math.max(...topMchts.map(m => Number(m.amount) || 0), 1);
      topMchtList.innerHTML = topMchts.map(m => {
        const amtNum = Number(m.amount) || 0;
        const widthPct = isValidNum(m.amount) && maxMchtAmt > 0 ? ((amtNum / maxMchtAmt) * 100).toFixed(1) : 0;
        const isNeg = Number(m.yoy) < 0;
        const grad = isNeg ? 'linear-gradient(90deg, #d97706, #f59e0b)' : 'linear-gradient(90deg, #003b5c, #0284c7)';
        return `
          <div style="display:grid; grid-template-columns: 150px 1fr 130px; gap:12px; align-items:center;">
            <span style="font-size:14px; font-weight:800; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${m.name}（${m.sub}）">${m.name} <small style="color:#64748b; font-weight:600; font-size:12.5px;">(${m.sub})</small></span>
            <div style="height:11px; background:#e8eeee; border-radius:6px; overflow:hidden;">
              <div style="width:${widthPct}%; height:100%; background:${grad}; border-radius:6px;"></div>
            </div>
            <div style="text-align:right; white-space:nowrap;">
              <strong style="font-size:15px; font-weight:800; color:var(--blue-dark);">${isValidNum(m.amount) ? fmtNum(m.amount, 1) + ' 億' : '-'}</strong>
              <span class="${semCls(m.yoy)}" style="font-size:12.5px; font-weight:800; margin-left:4px;">${fmtSign(m.yoy)}</span>
            </div>
          </div>
        `;
      }).join("");
    }

    const reps = conc.matrix_reps || {};
    const repCore = document.getElementById("b02-rep-core");
    if (repCore && reps.core) repCore.textContent = reps.core;
    const repPot = document.getElementById("b02-rep-potential");
    if (repPot && reps.potential) repPot.textContent = reps.potential;
    const repMain = document.getElementById("b02-rep-maintain");
    if (repMain && reps.maintain) repMain.textContent = reps.maintain;
    const repGen = document.getElementById("b02-rep-general");
    if (repGen && reps.general) repGen.textContent = reps.general;

    // 7. 2B TAB 2: 特店產業結構蝴蝶圖
    const indList = b2.industry_structure || [];
    const butterflyWrap = document.getElementById("b02-butterfly-list");
    if (butterflyWrap && indList.length > 0) {
      const maxMchtCount = Math.max(...indList.map(i => Number(i.merchant_count) || 0), 1);
      const maxAmount = Math.max(...indList.map(i => Number(i.amount) || 0), 1);

      butterflyWrap.innerHTML = indList.map(i => {
        const leftWidth = isValidNum(i.merchant_count) && maxMchtCount > 0 ? ((Number(i.merchant_count) / maxMchtCount) * 100).toFixed(1) : 0;
        const rightWidth = isValidNum(i.amount) && maxAmount > 0 ? ((Number(i.amount) / maxAmount) * 100).toFixed(1) : 0;
        return `
          <div class="acq-butterfly-row">
            <div class="acq-b-left-wing">
              <span class="acq-b-val-left">${isValidNum(i.merchant_count) ? Number(i.merchant_count).toLocaleString() + ' 家' : '-'} (${isValidNum(i.merchant_share) ? i.merchant_share + '%' : '-'})</span>
              <div class="acq-b-bar-track-left">
                <div class="acq-b-bar-fill-left" style="width: ${leftWidth}%; background:${i.color || '#003b5c'};"></div>
              </div>
            </div>
            <div class="acq-b-center-axis">
              <span class="acq-b-axis-title">${i.label || i.name}</span>
            </div>
            <div class="acq-b-right-wing">
              <div class="acq-b-bar-track-right">
                <div class="acq-b-bar-fill-right" style="width: ${rightWidth}%; background:${i.color || '#003b5c'};"></div>
              </div>
              <span class="acq-b-val-right">${isValidNum(i.amount) ? fmtNum(i.amount, 1) + ' 億' : '-'} (${isValidNum(i.amount_share) ? i.amount_share + '%' : '-'})</span>
            </div>
            <div class="acq-b-avg-col">
              <span class="acq-b-avg-badge">${isValidNum(i.avg_per_merchant) ? fmtNum(i.avg_per_merchant, 1) + ' 萬/店' : '-'}</span>
            </div>
          </div>
        `;
      }).join("");
    }

    // 8. TWQR 業務數據更新
    const c00TwApply = document.getElementById("c00-twqr-apply-cnt");
    if (c00TwApply) c00TwApply.innerHTML = isValidNum(twqr.apply_count) ? `${Number(twqr.apply_count).toLocaleString()} <em>件</em>` : `-`;
    const c00TwPass = document.getElementById("c00-twqr-pass-rate");
    if (c00TwPass) c00TwPass.textContent = isValidNum(twqr.pass_rate) ? `審查通過率 ${twqr.pass_rate}%` : `-`;
    const c00TwNew = document.getElementById("c00-twqr-new-mcht");
    if (c00TwNew) c00TwNew.innerHTML = isValidNum(twqr.new_merchants) ? `${Number(twqr.new_merchants).toLocaleString()} <em>家</em>` : `-`;
    const c00TwTotM = document.getElementById("c00-twqr-total-mcht");
    if (c00TwTotM) c00TwTotM.innerHTML = isValidNum(twqr.total_merchants) ? `${Number(twqr.total_merchants).toLocaleString()} <em>家</em>` : `-`;
    const c00TwTotMom = document.getElementById("c00-twqr-total-mom");
    if (c00TwTotMom) c00TwTotMom.textContent = isValidNum(twqr.total_merchants_mom) ? `MoM ${fmtSign(twqr.total_merchants_mom)}` : `-`;

    const c00TwAmt = document.getElementById("c00-twqr-tx-amt");
    if (c00TwAmt) c00TwAmt.innerHTML = isValidNum(twqr.tx_amount) ? `${fmtNum(twqr.tx_amount, 1)} <em>億</em>` : `-`;
    const c00TwAmtMom = document.getElementById("c00-twqr-amt-mom");
    if (c00TwAmtMom) c00TwAmtMom.textContent = isValidNum(twqr.tx_amount_mom) ? `MoM ${fmtSign(twqr.tx_amount_mom)}` : `-`;
    const c00TwCnt = document.getElementById("c00-twqr-tx-cnt");
    if (c00TwCnt) c00TwCnt.innerHTML = isValidNum(twqr.tx_count) ? `${Number(twqr.tx_count).toLocaleString()} <em>萬筆</em>` : `-`;
    const c00TwCntMom = document.getElementById("c00-twqr-cnt-mom");
    if (c00TwCntMom) c00TwCntMom.textContent = isValidNum(twqr.tx_count_mom) ? `MoM ${fmtSign(twqr.tx_count_mom)}` : `-`;
    const c00TwActRate = document.getElementById("c00-twqr-active-rate");
    if (c00TwActRate) c00TwActRate.innerHTML = isValidNum(twqr.active_mcht_rate) ? `${twqr.active_mcht_rate}<em>%</em>` : `-`;

    // 02 Section: TWQR Panel
    const b02TwApply = document.getElementById("b02-twqr-apply-cnt");
    if (b02TwApply) b02TwApply.textContent = isValidNum(twqr.apply_count) ? `${Number(twqr.apply_count).toLocaleString()} 件` : `-`;
    const b02TwPass = document.getElementById("b02-twqr-pass-rate");
    if (b02TwPass) b02TwPass.textContent = isValidNum(twqr.pass_rate) ? `審查通過率 ${twqr.pass_rate}%` : `-`;
    const b02TwNew = document.getElementById("b02-twqr-new-mcht");
    if (b02TwNew) b02TwNew.textContent = isValidNum(twqr.new_merchants) ? `${Number(twqr.new_merchants).toLocaleString()} 家` : `-`;
    const b02TwTotM = document.getElementById("b02-twqr-total-mcht");
    if (b02TwTotM) b02TwTotM.textContent = isValidNum(twqr.total_merchants) ? `${Number(twqr.total_merchants).toLocaleString()} 家` : `-`;
    const b02TwTotMom = document.getElementById("b02-twqr-total-mom");
    if (b02TwTotMom) b02TwTotMom.textContent = isValidNum(twqr.total_merchants_mom) ? `MoM ${fmtSign(twqr.total_merchants_mom)}` : `-`;

    const b02TwAmt = document.getElementById("b02-twqr-tx-amt");
    if (b02TwAmt) b02TwAmt.textContent = isValidNum(twqr.tx_amount) ? `${fmtNum(twqr.tx_amount, 1)} 億` : `-`;
    const b02TwAmtMom = document.getElementById("b02-twqr-amt-mom");
    if (b02TwAmtMom) b02TwAmtMom.textContent = isValidNum(twqr.tx_amount_mom) ? `MoM ${fmtSign(twqr.tx_amount_mom)}` : `-`;
    const b02TwCnt = document.getElementById("b02-twqr-tx-cnt");
    if (b02TwCnt) b02TwCnt.textContent = isValidNum(twqr.tx_count) ? `${Number(twqr.tx_count).toLocaleString()} 萬筆` : `-`;
    const b02TwCntMom = document.getElementById("b02-twqr-cnt-mom");
    if (b02TwCntMom) b02TwCntMom.textContent = isValidNum(twqr.tx_count_mom) ? `MoM ${fmtSign(twqr.tx_count_mom)}` : `-`;
    const b02TwAvgTicket = document.getElementById("b02-twqr-avg-ticket");
    if (b02TwAvgTicket) b02TwAvgTicket.textContent = isValidNum(twqr.avg_ticket) ? `${Number(twqr.avg_ticket).toLocaleString()} 元` : `-`;
    const b02TwMchtAvgAmt = document.getElementById("b02-twqr-mcht-avg-amt");
    if (b02TwMchtAvgAmt) b02TwMchtAvgAmt.textContent = isValidNum(twqr.mcht_avg_amount) ? `${fmtNum(twqr.mcht_avg_amount, 2)} 萬元` : `-`;
    const b02TwActRate = document.getElementById("b02-twqr-active-rate");
    if (b02TwActRate) b02TwActRate.textContent = isValidNum(twqr.active_mcht_rate) ? `${twqr.active_mcht_rate}%` : `-`;
  }
"""

assert 'document.addEventListener("DOMContentLoaded",' in html, "Cannot find DOMContentLoaded"
html = html.replace('document.addEventListener("DOMContentLoaded",', render_b02_code + '\n  document.addEventListener("DOMContentLoaded",')

old_dom_listener = 'if (window.DASHBOARD_DATA) { renderBlock01FromData(window.DASHBOARD_DATA); }'
new_dom_listener = """if (window.DASHBOARD_DATA) {
      renderBlock01FromData(window.DASHBOARD_DATA);
      renderBlock02FromData(window.DASHBOARD_DATA);
    }"""
assert old_dom_listener in html, "Cannot find old_dom_listener"
html = html.replace(old_dom_listener, new_dom_listener)

with open("01_儀表板執行環境/credit_card_full_dashboard.html", "w", encoding="utf-8") as f:
    f.write(html)

print("Successfully injected all IDs and renderBlock02FromData into credit_card_full_dashboard.html!")
