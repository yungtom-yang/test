# -*- coding: utf-8 -*-
"""
apply_full_mock_purge.py
Thoroughly purges ALL static mock figures from 01_儀表板執行環境/credit_card_full_dashboard.html
All placeholders are standardized to '-', '(-%)', 'width: 0%'.
"""
import re
import os

HTML_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "..", "01_儀表板執行環境", "credit_card_full_dashboard.html")

with open(HTML_PATH, "r", encoding="utf-8") as f:
    content = f.read()

# 1. Cockpit 00: Peer Donut & Peer List
old_peer_block = '''              <div class="cockpit-donut-chart-wrap" id="c00-donut-wrap">
                <svg viewBox="0 0 120 120" width="88" height="88" style="display:block;">
                  <path class="cockpit-donut-slice" d="M 60.00 8.00 A 52 52 0 0 1 112.00 60.00 L 92.00 60.00 A 32 32 0 0 0 60.00 28.00 Z" fill="#003b5c" stroke="#ffffff" stroke-width="1.5"><title>中國信託: 25.0% (5,980億)</title></path>
                  <path class="cockpit-donut-slice" d="M 112.00 60.00 A 52 52 0 0 1 63.59 111.88 L 62.21 91.92 A 32 32 0 0 0 92.00 60.00 Z" fill="#009e73" stroke="#ffffff" stroke-width="1.5"><title>國泰世華: 23.9% (5,726億)</title></path>
                  <path class="cockpit-donut-slice" d="M 63.59 111.88 A 52 52 0 0 1 13.67 83.61 L 31.49 74.53 A 32 32 0 0 0 62.21 91.92 Z" fill="#2563eb" stroke="#ffffff" stroke-width="1.5"><title>台北富邦: 18.6% (4,450億)</title></path>
                  <path class="cockpit-donut-slice" d="M 13.67 83.61 A 52 52 0 0 1 18.91 28.13 L 34.72 40.39 A 32 32 0 0 0 31.49 74.53 Z" fill="#059669" stroke="#ffffff" stroke-width="1.5"><title>玉山銀行: 18.0% (4,320億)</title></path>
                  <path class="cockpit-donut-slice" d="M 18.91 28.13 A 52 52 0 0 1 60.00 8.00 L 60.00 28.00 A 32 32 0 0 0 34.72 40.39 Z" fill="#ea580c" stroke="#ffffff" stroke-width="1.5"><title>台新銀行: 14.5% (3,480億)</title></path>
                  <circle cx="60" cy="60" r="32" fill="#ffffff" />
                </svg>
              </div>
              <div class="cockpit-donut-summary-side">
                <div class="c-market-stat-label" id="c00-market-label">五大行簽帳總額</div>
                <div class="c-market-stat-val" id="c00-market-val">24,262 <em>億元</em></div>
                <div class="c-market-stat-sub" id="c00-market-sub">
                  <span class="number-positive" id="c00-market-yoy">YoY +16.8%</span>
                </div>
              </div>
            </div>
            <div class="cockpit-peer-table-box">
              <div class="cockpit-peer-header">
                <span class="p-name">發卡銀行</span>
                <span class="p-val">簽帳金額</span>
                <span class="p-share">佔比</span>
                <span class="p-yoy">YoY</span>
              </div>
              <div class="cockpit-peer-list" id="c00-peer-list">
                <div class="cockpit-peer-row">
                  <span class="p-name"><span class="peer-color-dot" style="background:#003b5c;"></span>中國信託</span>
                  <span class="p-val">6,457 億元</span>
                  <span class="p-share"><b>26.6%</b></span>
                  <span class="p-yoy number-positive">+25.9%</span>
                </div>
                <div class="cockpit-peer-row highlight">
                  <span class="p-name"><span class="peer-color-dot" style="background:#009e73;"></span>國泰世華</span>
                  <span class="p-val">5,726 億元</span>
                  <span class="p-share"><b>23.6%</b></span>
                  <span class="p-yoy number-positive">+17.1%</span>
                </div>
                <div class="cockpit-peer-row">
                  <span class="p-name"><span class="peer-color-dot" style="background:#059669;"></span>玉山銀行</span>
                  <span class="p-val">4,705 億元</span>
                  <span class="p-share"><b>19.4%</b></span>
                  <span class="p-yoy number-positive">+18.4%</span>
                </div>
                <div class="cockpit-peer-row">
                  <span class="p-name"><span class="peer-color-dot" style="background:#2563eb;"></span>台北富邦</span>
                  <span class="p-val">3,894 億元</span>
                  <span class="p-share"><b>16.1%</b></span>
                  <span class="p-yoy number-positive">+6.4%</span>
                </div>
                <div class="cockpit-peer-row">
                  <span class="p-name"><span class="peer-color-dot" style="background:#ea580c;"></span>台新銀行</span>
                  <span class="p-val">3,480 億元</span>
                  <span class="p-share"><b>14.3%</b></span>
                  <span class="p-yoy number-positive">+11.8%</span>
                </div>
              </div>
            </div>'''

new_peer_block = '''              <div class="cockpit-donut-chart-wrap" id="c00-donut-wrap">
                <svg viewBox="0 0 120 120" width="88" height="88" style="display:block;">
                  <circle cx="60" cy="60" r="42" fill="none" stroke="#e2e8f0" stroke-width="20" />
                  <circle cx="60" cy="60" r="32" fill="#ffffff" />
                </svg>
              </div>
              <div class="cockpit-donut-summary-side">
                <div class="c-market-stat-label" id="c00-market-label">五大行簽帳總額</div>
                <div class="c-market-stat-val" id="c00-market-val">- <em>億元</em></div>
                <div class="c-market-stat-sub" id="c00-market-sub">
                  <span class="number-neutral" id="c00-market-yoy">-</span>
                </div>
              </div>
            </div>
            <div class="cockpit-peer-table-box">
              <div class="cockpit-peer-header">
                <span class="p-name">發卡銀行</span>
                <span class="p-val">簽帳金額</span>
                <span class="p-share">佔比</span>
                <span class="p-yoy">YoY</span>
              </div>
              <div class="cockpit-peer-list" id="c00-peer-list">
                <div class="cockpit-peer-row">
                  <span class="p-name"><span class="peer-color-dot" style="background:#003b5c;"></span>中國信託</span>
                  <span class="p-val">- 億元</span>
                  <span class="p-share"><b>-%</b></span>
                  <span class="p-yoy number-neutral">-</span>
                </div>
                <div class="cockpit-peer-row highlight">
                  <span class="p-name"><span class="peer-color-dot" style="background:#009e73;"></span>國泰世華</span>
                  <span class="p-val">- 億元</span>
                  <span class="p-share"><b>-%</b></span>
                  <span class="p-yoy number-neutral">-</span>
                </div>
                <div class="cockpit-peer-row">
                  <span class="p-name"><span class="peer-color-dot" style="background:#059669;"></span>玉山銀行</span>
                  <span class="p-val">- 億元</span>
                  <span class="p-share"><b>-%</b></span>
                  <span class="p-yoy number-neutral">-</span>
                </div>
                <div class="cockpit-peer-row">
                  <span class="p-name"><span class="peer-color-dot" style="background:#2563eb;"></span>台北富邦</span>
                  <span class="p-val">- 億元</span>
                  <span class="p-share"><b>-%</b></span>
                  <span class="p-yoy number-neutral">-</span>
                </div>
                <div class="cockpit-peer-row">
                  <span class="p-name"><span class="peer-color-dot" style="background:#ea580c;"></span>台新銀行</span>
                  <span class="p-val">- 億元</span>
                  <span class="p-share"><b>-%</b></span>
                  <span class="p-yoy number-neutral">-</span>
                </div>
              </div>
            </div>'''

assert old_peer_block in content, "old_peer_block not found in content!"
content = content.replace(old_peer_block, new_peer_block)

# 2. Cockpit 00: TWQR
old_c00_twqr = '''            <div class="c-twqr-stat-grid three-col">
              <div class="c-twqr-cell">
                <span>當月申請進件數</span>
                <strong id="c00-twqr-apply-cnt">3,850 <em>件</em></strong>
              </div>
              <div class="c-twqr-cell">
                <span>當月新增特店家數</span>
                <strong id="c00-twqr-new-mcht">1,210 <em>家</em></strong>
                <b class="number-positive" id="c00-twqr-pass-rate">審查通過率 91.2%</b>
              </div>
              <div class="c-twqr-cell">
                <span>累計特店家數</span>
                <strong id="c00-twqr-total-mcht">22,100 <em>家</em></strong>
                <b class="number-positive" id="c00-twqr-total-mom">MoM +5.8%</b>
              </div>
            </div>
          </div>

          <!-- TWQR Bottom Block: 交易狀態分析 -->
          <div class="twqr-cockpit-section" style="margin-top: 8px;">
            <div class="twqr-subhead">
              <b>交易狀態分析</b>
            </div>
            <div class="c-twqr-stat-grid three-col">
              <div class="c-twqr-cell">
                <span>當月交易金額</span>
                <strong id="c00-twqr-tx-amt">130,620 <em>元</em></strong>
                <b class="number-positive" id="c00-twqr-amt-mom">MoM +18.5%</b>
              </div>
              <div class="c-twqr-cell">
                <span>當月交易筆數</span>
                <strong id="c00-twqr-tx-cnt">199 <em>筆</em></strong>
                <b class="number-positive" id="c00-twqr-cnt-mom">MoM +22.1%</b>
              </div>
              <div class="c-twqr-cell">
                <span>動用特店率</span>
                <strong id="c00-twqr-active-rate">78.5<em>%</em></strong>
                <b class="number-positive">實際產生交易</b>
              </div>
            </div>
          </div>'''

new_c00_twqr = '''            <div class="c-twqr-stat-grid three-col">
              <div class="c-twqr-cell">
                <span>當月申請進件數</span>
                <strong id="c00-twqr-apply-cnt">- <em>件</em></strong>
              </div>
              <div class="c-twqr-cell">
                <span>當月新增特店家數</span>
                <strong id="c00-twqr-new-mcht">- <em>家</em></strong>
                <b class="number-neutral" id="c00-twqr-pass-rate">-</b>
              </div>
              <div class="c-twqr-cell">
                <span>累計特店家數</span>
                <strong id="c00-twqr-total-mcht">- <em>家</em></strong>
                <b class="number-neutral" id="c00-twqr-total-mom">-</b>
              </div>
            </div>
          </div>

          <!-- TWQR Bottom Block: 交易狀態分析 -->
          <div class="twqr-cockpit-section" style="margin-top: 8px;">
            <div class="twqr-subhead">
              <b>交易狀態分析</b>
            </div>
            <div class="c-twqr-stat-grid three-col">
              <div class="c-twqr-cell">
                <span>當月交易金額</span>
                <strong id="c00-twqr-tx-amt">- <em>元</em></strong>
                <b class="number-neutral" id="c00-twqr-amt-mom">-</b>
              </div>
              <div class="c-twqr-cell">
                <span>當月交易筆數</span>
                <strong id="c00-twqr-tx-cnt">- <em>筆</em></strong>
                <b class="number-neutral" id="c00-twqr-cnt-mom">-</b>
              </div>
              <div class="c-twqr-cell">
                <span>動用特店率</span>
                <strong id="c00-twqr-active-rate">-<em>%</em></strong>
                <b class="number-neutral">-</b>
              </div>
            </div>
          </div>'''

assert old_c00_twqr in content, "old_c00_twqr not found in content!"
content = content.replace(old_c00_twqr, new_c00_twqr)

# 3. Cockpit 00: Bill Center
old_c00_bill = '''          <div class="cockpit-box-title">
            <span>帳單列印中心</span>
            <span class="c-tag-green" id="c00-iss-bill-tag">電子率 60.9%</span>
          </div>

          <div class="bill-dual-track-box" style="margin-top: 4px;">
            <!-- Track 1: 信用卡帳單 -->
            <div class="bill-track-item">
              <div class="bill-track-head">
                <b>信用卡帳單</b>
                <span id="c00-iss-bill-card-head">468<span class="decimal-part">.6</span> 萬份 (佔 88.2%)</span>
              </div>
              <div class="c-ratio-bar-wrap" style="margin:2px 0 3px;">
                <div class="c-ratio-bar-track" style="height:11px;">
                  <div class="c-ratio-seg seg-digital" id="c00-iss-bill-card-seg-dig" style="width: 67.9%;" title="信用卡電子: 67.9% (3,183,245 份)"></div>
                  <div class="c-ratio-seg seg-physical" id="c00-iss-bill-card-seg-phy" style="width: 32.1%;" title="信用卡紙本: 32.1% (1,503,101 份)"></div>
                </div>
              </div>
              <div class="c-ratio-data-row">
                <div class="c-ratio-col">
                  <span class="r-label"><span class="r-dot dot-digital"></span>電子 <span class="r-pct r-pct-digital" id="c00-iss-bill-card-dig-pct">(68%)</span></span>
                  <strong class="r-val" id="c00-iss-bill-card-dig-val" style="font-size:13.5px;">318<span class="decimal-part">.3</span><em>萬份</em></strong>
                </div>
                <div class="c-ratio-col align-right">
                  <span class="r-label"><span class="r-dot dot-physical"></span>紙本 <span class="r-pct r-pct-physical" id="c00-iss-bill-card-phy-pct">(32%)</span></span>
                  <strong class="r-val" id="c00-iss-bill-card-phy-val" style="font-size:13.5px;">150<span class="decimal-part">.3</span><em>萬份</em></strong>
                </div>
              </div>
            </div>

            <!-- Track 2: 銀行帳單 -->
            <div class="bill-track-item" style="margin-top: 2px;">
              <div class="bill-track-head">
                <b>銀行帳單</b>
                <span id="c00-iss-bill-bank-head">62<span class="decimal-part">.9</span> 萬份 (佔 11.8%)</span>
              </div>
              <div class="c-ratio-bar-wrap" style="margin:2px 0 3px;">
                <div class="c-ratio-bar-track" style="height:11px;">
                  <div class="c-ratio-seg" id="c00-iss-bill-bank-seg-dig" style="width: 8.5%; background:#10b981;" title="銀行電子: 8.5% (53,610 份)"></div>
                  <div class="c-ratio-seg" id="c00-iss-bill-bank-seg-phy" style="width: 91.5%; background:#d97706;" title="銀行紙本: 91.5% (575,569 份)"></div>
                </div>
              </div>
              <div class="c-ratio-data-row">
                <div class="c-ratio-col">
                  <span class="r-label"><span class="r-dot" style="background:#10b981;"></span>電子 <span class="r-pct" id="c00-iss-bill-bank-dig-pct" style="color:#059669;">(9%)</span></span>
                  <strong class="r-val" id="c00-iss-bill-bank-dig-val" style="font-size:13.5px;">5<span class="decimal-part">.4</span><em>萬份</em></strong>
                </div>
                <div class="c-ratio-col align-right">
                  <span class="r-label"><span class="r-dot" style="background:#d97706;"></span>紙本 <span class="r-pct" id="c00-iss-bill-bank-phy-pct" style="color:#b45309;">(91%)</span></span>
                  <strong class="r-val" id="c00-iss-bill-bank-phy-val" style="font-size:13.5px;">57<span class="decimal-part">.6</span><em>萬份</em></strong>
                </div>
              </div>
            </div>
          </div>'''

new_c00_bill = '''          <div class="cockpit-box-title">
            <span>帳單列印中心</span>
            <span class="c-tag-green" id="c00-iss-bill-tag">-</span>
          </div>

          <div class="bill-dual-track-box" style="margin-top: 4px;">
            <!-- Track 1: 信用卡帳單 -->
            <div class="bill-track-item">
              <div class="bill-track-head">
                <b>信用卡帳單</b>
                <span id="c00-iss-bill-card-head">-</span>
              </div>
              <div class="c-ratio-bar-wrap" style="margin:2px 0 3px;">
                <div class="c-ratio-bar-track" style="height:11px;">
                  <div class="c-ratio-seg seg-digital" id="c00-iss-bill-card-seg-dig" style="width: 0%;" title="-"></div>
                  <div class="c-ratio-seg seg-physical" id="c00-iss-bill-card-seg-phy" style="width: 0%;" title="-"></div>
                </div>
              </div>
              <div class="c-ratio-data-row">
                <div class="c-ratio-col">
                  <span class="r-label"><span class="r-dot dot-digital"></span>電子 <span class="r-pct r-pct-digital" id="c00-iss-bill-card-dig-pct">(-%)</span></span>
                  <strong class="r-val" id="c00-iss-bill-card-dig-val" style="font-size:13.5px;">-<em>萬份</em></strong>
                </div>
                <div class="c-ratio-col align-right">
                  <span class="r-label"><span class="r-dot dot-physical"></span>紙本 <span class="r-pct r-pct-physical" id="c00-iss-bill-card-phy-pct">(-%)</span></span>
                  <strong class="r-val" id="c00-iss-bill-card-phy-val" style="font-size:13.5px;">-<em>萬份</em></strong>
                </div>
              </div>
            </div>

            <!-- Track 2: 銀行帳單 -->
            <div class="bill-track-item" style="margin-top: 2px;">
              <div class="bill-track-head">
                <b>銀行帳單</b>
                <span id="c00-iss-bill-bank-head">-</span>
              </div>
              <div class="c-ratio-bar-wrap" style="margin:2px 0 3px;">
                <div class="c-ratio-bar-track" style="height:11px;">
                  <div class="c-ratio-seg" id="c00-iss-bill-bank-seg-dig" style="width: 0%; background:#10b981;" title="-"></div>
                  <div class="c-ratio-seg" id="c00-iss-bill-bank-seg-phy" style="width: 0%; background:#d97706;" title="-"></div>
                </div>
              </div>
              <div class="c-ratio-data-row">
                <div class="c-ratio-col">
                  <span class="r-label"><span class="r-dot" style="background:#10b981;"></span>電子 <span class="r-pct" id="c00-iss-bill-bank-dig-pct" style="color:#059669;">(-%)</span></span>
                  <strong class="r-val" id="c00-iss-bill-bank-dig-val" style="font-size:13.5px;">-<em>萬份</em></strong>
                </div>
                <div class="c-ratio-col align-right">
                  <span class="r-label"><span class="r-dot" style="background:#d97706;"></span>紙本 <span class="r-pct" id="c00-iss-bill-bank-phy-pct" style="color:#b45309;">(-%)</span></span>
                  <strong class="r-val" id="c00-iss-bill-bank-phy-val" style="font-size:13.5px;">-<em>萬份</em></strong>
                </div>
              </div>
            </div>
          </div>'''

assert old_c00_bill in content, "old_c00_bill not found in content!"
content = content.replace(old_c00_bill, new_c00_bill)

# 4. Cockpit 00: Resilience Cardpool & Cardlink
old_c00_resil = '''          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>交易響應時間</small>
              <strong style="color:var(--green);" id="c00-cp-resp-val">85 <em>ms</em></strong>
              <span class="number-positive" id="c00-cp-resp-sub">零超時 (0筆)</span>
            </div>
            <div class="c-stat-item">
              <small>月授權交易量</small>
              <strong id="c00-cp-vol-val">6,820 <em>萬筆</em></strong>
              <span id="c00-cp-vol-sub">成功率 98.8%</span>
            </div>
          </div>
        </div>

        <!-- Cardlink 核心帳務主機 -->
        <div class="cockpit-subbox" style="cursor: pointer;" onclick="drillToResilienceCardlink()" title="點擊前往 04 系統韌性 ➔ Cardlink 核心帳務主機">
          <div class="cockpit-box-title">
            <span>Cardlink 核心帳務主機</span>
          </div>
          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>月帳務處理量</small>
              <strong id="c00-cl-vol-val">1<span class="decimal-part">.42</span> <em>億筆</em></strong>
              <span id="c00-cl-vol-sub">高可靠運作</span>
            </div>
            <div class="c-stat-item">
              <small>系統可用率 / 峰值</small>
              <strong id="c00-cl-avail-val">100.0%</strong>
              <span id="c00-cl-tps-sub">峰值 4,850 TPS</span>
            </div>
          </div>
        </div>'''

new_c00_resil = '''          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>交易響應時間</small>
              <strong style="color:var(--green);" id="c00-cp-resp-val">- <em>ms</em></strong>
              <span class="number-neutral" id="c00-cp-resp-sub">-</span>
            </div>
            <div class="c-stat-item">
              <small>月授權交易量</small>
              <strong id="c00-cp-vol-val">- <em>萬筆</em></strong>
              <span id="c00-cp-vol-sub">-</span>
            </div>
          </div>
        </div>

        <!-- Cardlink 核心帳務主機 -->
        <div class="cockpit-subbox" style="cursor: pointer;" onclick="drillToResilienceCardlink()" title="點擊前往 04 系統韌性 ➔ Cardlink 核心帳務主機">
          <div class="cockpit-box-title">
            <span>Cardlink 核心帳務主機</span>
          </div>
          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>月帳務處理量</small>
              <strong id="c00-cl-vol-val">- <em>億筆</em></strong>
              <span id="c00-cl-vol-sub">-</span>
            </div>
            <div class="c-stat-item">
              <small>系統可用率 / 峰值</small>
              <strong id="c00-cl-avail-val">-</strong>
              <span id="c00-cl-tps-sub">-</span>
            </div>
          </div>
        </div>'''

assert old_c00_resil in content, "old_c00_resil not found in content!"
content = content.replace(old_c00_resil, new_c00_resil)

# 5. Section 02 Tab 0: 線上交易分析
old_b02_tab0 = '''          <div class="structure-bar" id="b02-online-struct-bar">
            <div style="background:#003b5c; width:58.3%;" title="EPOS - 雲端 (58.3%)">
              <span>EPOS - 雲端 (58.3%)</span>
            </div>
            <div style="background:#3b82f6; width:26.1%;" title="EPOS - 地端 (26.1%)">
              <span>EPOS - 地端 (26.1%)</span>
            </div>
            <div style="background:#ea580c; width:15.6%;" title="Payment Hub掃碼交易 (15.6%)">
              <span>Payment Hub掃碼 (15.6%)</span>
            </div>
          </div>

          <div class="compact-table" style="margin-bottom:14px;">
            <table>
              <thead>
                <tr>
                  <th>交易類型</th>
                  <th style="text-align:right;">交易金額</th>
                  <th style="text-align:right;">交易金額YOY</th>
                  <th style="text-align:right;">交易筆數</th>
                  <th style="text-align:right;">交易筆數YOY</th>
                  <th style="text-align:right;">平均客單價</th>
                  <th style="text-align:right;">平均客單價YOY</th>
                </tr>
              </thead>
              <tbody id="b02-online-table-body">
                <tr>
                  <td><strong>EPOS - 雲端</strong></td>
                  <td style="text-align:right;"><strong style="color:var(--blue-dark); font-size:15.5px;">69.1 億元</strong></td>
                  <td style="text-align:right;" class="number-positive"><strong>+32.5%</strong></td>
                  <td style="text-align:right;">345 萬筆</td>
                  <td style="text-align:right;" class="number-positive"><strong>+35.1%</strong></td>
                  <td style="text-align:right;">2,002 元</td>
                  <td style="text-align:right;" class="number-negative"><strong>-1.9%</strong></td>
                </tr>
                <tr>
                  <td><strong>EPOS - 地端</strong></td>
                  <td style="text-align:right;"><strong style="color:var(--blue-dark); font-size:15.5px;">30.9 億元</strong></td>
                  <td style="text-align:right;" class="number-negative"><strong>-4.2%</strong></td>
                  <td style="text-align:right;">210 萬筆</td>
                  <td style="text-align:right;" class="number-negative"><strong>-1.8%</strong></td>
                  <td style="text-align:right;">1,471 元</td>
                  <td style="text-align:right;" class="number-negative"><strong>-2.5%</strong></td>
                </tr>
                <tr>
                  <td><strong>Payment Hub掃碼交易</strong></td>
                  <td style="text-align:right;"><strong style="color:var(--blue-dark); font-size:15.5px;">18.5 億元</strong></td>
                  <td style="text-align:right;" class="number-positive"><strong>+38.2%</strong></td>
                  <td style="text-align:right;">240 萬筆</td>
                  <td style="text-align:right;" class="number-positive"><strong>+42.0%</strong></td>
                  <td style="text-align:right;">770 元</td>
                  <td style="text-align:right;" class="number-negative"><strong>-2.8%</strong></td>
                </tr>
              </tbody>
            </table>
          </div>'''

new_b02_tab0 = '''          <div class="structure-bar" id="b02-online-struct-bar">
            <div style="background:#cbd5e1; width:0%;" title="-">
              <span>-</span>
            </div>
          </div>

          <div class="compact-table" style="margin-bottom:14px;">
            <table>
              <thead>
                <tr>
                  <th>交易類型</th>
                  <th style="text-align:right;">交易金額</th>
                  <th style="text-align:right;">交易金額YOY</th>
                  <th style="text-align:right;">交易筆數</th>
                  <th style="text-align:right;">交易筆數YOY</th>
                  <th style="text-align:right;">平均客單價</th>
                  <th style="text-align:right;">平均客單價YOY</th>
                </tr>
              </thead>
              <tbody id="b02-online-table-body">
                <tr>
                  <td><strong>EPOS - 雲端</strong></td>
                  <td style="text-align:right;"><strong style="color:var(--blue-dark); font-size:15.5px;">- 億元</strong></td>
                  <td style="text-align:right;" class="number-neutral"><strong>-</strong></td>
                  <td style="text-align:right;">- 萬筆</td>
                  <td style="text-align:right;" class="number-neutral"><strong>-</strong></td>
                  <td style="text-align:right;">- 元</td>
                  <td style="text-align:right;" class="number-neutral"><strong>-</strong></td>
                </tr>
                <tr>
                  <td><strong>EPOS - 地端</strong></td>
                  <td style="text-align:right;"><strong style="color:var(--blue-dark); font-size:15.5px;">- 億元</strong></td>
                  <td style="text-align:right;" class="number-neutral"><strong>-</strong></td>
                  <td style="text-align:right;">- 萬筆</td>
                  <td style="text-align:right;" class="number-neutral"><strong>-</strong></td>
                  <td style="text-align:right;">- 元</td>
                  <td style="text-align:right;" class="number-neutral"><strong>-</strong></td>
                </tr>
                <tr>
                  <td><strong>Payment Hub掃碼交易</strong></td>
                  <td style="text-align:right;"><strong style="color:var(--blue-dark); font-size:15.5px;">- 億元</strong></td>
                  <td style="text-align:right;" class="number-neutral"><strong>-</strong></td>
                  <td style="text-align:right;">- 萬筆</td>
                  <td style="text-align:right;" class="number-neutral"><strong>-</strong></td>
                  <td style="text-align:right;">- 元</td>
                  <td style="text-align:right;" class="number-neutral"><strong>-</strong></td>
                </tr>
              </tbody>
            </table>
          </div>'''

assert old_b02_tab0 in content, "old_b02_tab0 not found in content!"
content = content.replace(old_b02_tab0, new_b02_tab0)

# 6. Section 02 Tab 1: 特店集中度與 2x2 矩陣
old_b02_tab1 = '''                <!-- Top 10 Macro Concentration Highlight Bar -->
                <div style="background:#f4f9f7; border:1px solid #d4eae3; border-left:4px solid var(--blue-dark); border-radius:6px; padding:10px 14px; margin-bottom:14px; display:flex; justify-content:space-between; align-items:center;">
                  <div style="display:flex; align-items:center; gap:8px;">
                    <span style="font-size:13.5px; font-weight:800; color:var(--ink);">Top 10 特店請款佔比</span>
                    <small style="color:#64748b; font-size:12px; font-weight:600;">(全行大盤集中度)</small>
                  </div>
                  <div style="display:flex; align-items:baseline; gap:8px;">
                    <strong style="font-size:21px; font-weight:900; color:var(--blue-dark); line-height:1;" id="b02-top10-share">48.2%</strong>
                    <span class="number-positive" style="font-size:12.5px; font-weight:800;" id="b02-top10-yoy">YoY +1.5pp</span>
                  </div>
                </div>

                <div class="merchant-progress-list" id="b02-top-merchants-list" style="display:flex; flex-direction:column; gap:13px;">
                  <!-- Row 1: 特店 A -->
                  <div style="display:grid; grid-template-columns: 150px 1fr 130px; gap:12px; align-items:center;">
                    <span style="font-size:14px; font-weight:800; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="特店 A（量販巨頭）">特店 A <small style="color:#64748b; font-weight:600; font-size:12.5px;">(量販巨頭)</small></span>
                    <div style="height:11px; background:#e8eeee; border-radius:6px; overflow:hidden;">
                      <div style="width:100%; height:100%; background:linear-gradient(90deg, #003b5c, #0284c7); border-radius:6px;"></div>
                    </div>
                    <div style="text-align:right; white-space:nowrap;">
                      <strong style="font-size:15px; font-weight:800; color:var(--blue-dark);">35.6 億</strong>
                      <span class="number-positive" style="font-size:12.5px; font-weight:800; margin-left:4px;">+18.2%</span>
                    </div>
                  </div>

                  <!-- Row 2: 特店 B -->
                  <div style="display:grid; grid-template-columns: 150px 1fr 130px; gap:12px; align-items:center;">
                    <span style="font-size:14px; font-weight:800; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="特店 B（綜合電商）">特店 B <small style="color:#64748b; font-weight:600; font-size:12.5px;">(綜合電商)</small></span>
                    <div style="height:11px; background:#e8eeee; border-radius:6px; overflow:hidden;">
                      <div style="width:73.6%; height:100%; background:linear-gradient(90deg, #003b5c, #0284c7); border-radius:6px;"></div>
                    </div>
                    <div style="text-align:right; white-space:nowrap;">
                      <strong style="font-size:15px; font-weight:800; color:var(--blue-dark);">26.2 億</strong>
                      <span class="number-positive" style="font-size:12.5px; font-weight:800; margin-left:4px;">+25.4%</span>
                    </div>
                  </div>

                  <!-- Row 3: 特店 C -->
                  <div style="display:grid; grid-template-columns: 150px 1fr 130px; gap:12px; align-items:center;">
                    <span style="font-size:14px; font-weight:800; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="特店 C（百貨生活）">特店 C <small style="color:#64748b; font-weight:600; font-size:12.5px;">(百貨生活)</small></span>
                    <div style="height:11px; background:#e8eeee; border-radius:6px; overflow:hidden;">
                      <div style="width:67.1%; height:100%; background:linear-gradient(90deg, #003b5c, #0284c7); border-radius:6px;"></div>
                    </div>
                    <div style="text-align:right; white-space:nowrap;">
                      <strong style="font-size:15px; font-weight:800; color:var(--blue-dark);">23.9 億</strong>
                      <span class="number-positive" style="font-size:12.5px; font-weight:800; margin-left:4px;">+1.2%</span>
                    </div>
                  </div>

                  <!-- Row 4: 特店 D -->
                  <div style="display:grid; grid-template-columns: 150px 1fr 130px; gap:12px; align-items:center;">
                    <span style="font-size:14px; font-weight:800; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="特店 D（連鎖超商）">特店 D <small style="color:#64748b; font-weight:600; font-size:12.5px;">(連鎖超商)</small></span>
                    <div style="height:11px; background:#e8eeee; border-radius:6px; overflow:hidden;">
                      <div style="width:48.9%; height:100%; background:linear-gradient(90deg, #d97706, #f59e0b); border-radius:6px;"></div>
                    </div>
                    <div style="text-align:right; white-space:nowrap;">
                      <strong style="font-size:15px; font-weight:800; color:var(--blue-dark);">17.4 億</strong>
                      <span class="number-negative" style="font-size:12.5px; font-weight:800; margin-left:4px;">−3.5%</span>
                    </div>
                  </div>

                  <!-- Row 5: 特店 E -->
                  <div style="display:grid; grid-template-columns: 150px 1fr 130px; gap:12px; align-items:center;">
                    <span style="font-size:14px; font-weight:800; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="特店 E（連鎖餐飲）">特店 E <small style="color:#64748b; font-weight:600; font-size:12.5px;">(連鎖餐飲)</small></span>
                    <div style="height:11px; background:#e8eeee; border-radius:6px; overflow:hidden;">
                      <div style="width:40.2%; height:100%; background:linear-gradient(90deg, #003b5c, #0284c7); border-radius:6px;"></div>
                    </div>
                    <div style="text-align:right; white-space:nowrap;">
                      <strong style="font-size:15px; font-weight:800; color:var(--blue-dark);">14.3 億</strong>
                      <span class="number-positive" style="font-size:12.5px; font-weight:800; margin-left:4px;">+32.0%</span>
                    </div>
                  </div>
                </div>'''

new_b02_tab1 = '''                <!-- Top 10 Macro Concentration Highlight Bar -->
                <div style="background:#f4f9f7; border:1px solid #d4eae3; border-left:4px solid var(--blue-dark); border-radius:6px; padding:10px 14px; margin-bottom:14px; display:flex; justify-content:space-between; align-items:center;">
                  <div style="display:flex; align-items:center; gap:8px;">
                    <span style="font-size:13.5px; font-weight:800; color:var(--ink);">Top 10 特店請款佔比</span>
                    <small style="color:#64748b; font-size:12px; font-weight:600;">(全行大盤集中度)</small>
                  </div>
                  <div style="display:flex; align-items:baseline; gap:8px;">
                    <strong style="font-size:21px; font-weight:900; color:var(--blue-dark); line-height:1;" id="b02-top10-share">-</strong>
                    <span class="number-neutral" style="font-size:12.5px; font-weight:800;" id="b02-top10-yoy">YoY -</span>
                  </div>
                </div>

                <div class="merchant-progress-list" id="b02-top-merchants-list" style="display:flex; flex-direction:column; gap:13px;">
                  <!-- Row 1: 特店 A -->
                  <div style="display:grid; grid-template-columns: 150px 1fr 130px; gap:12px; align-items:center;">
                    <span style="font-size:14px; font-weight:800; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="特店 A（量販巨頭）">特店 A <small style="color:#64748b; font-weight:600; font-size:12.5px;">(量販巨頭)</small></span>
                    <div style="height:11px; background:#e8eeee; border-radius:6px; overflow:hidden;">
                      <div style="width:0%; height:100%; background:linear-gradient(90deg, #003b5c, #0284c7); border-radius:6px;"></div>
                    </div>
                    <div style="text-align:right; white-space:nowrap;">
                      <strong style="font-size:15px; font-weight:800; color:var(--blue-dark);">-</strong>
                      <span class="number-neutral" style="font-size:12.5px; font-weight:800; margin-left:4px;">-</span>
                    </div>
                  </div>

                  <!-- Row 2: 特店 B -->
                  <div style="display:grid; grid-template-columns: 150px 1fr 130px; gap:12px; align-items:center;">
                    <span style="font-size:14px; font-weight:800; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="特店 B（綜合電商）">特店 B <small style="color:#64748b; font-weight:600; font-size:12.5px;">(綜合電商)</small></span>
                    <div style="height:11px; background:#e8eeee; border-radius:6px; overflow:hidden;">
                      <div style="width:0%; height:100%; background:linear-gradient(90deg, #003b5c, #0284c7); border-radius:6px;"></div>
                    </div>
                    <div style="text-align:right; white-space:nowrap;">
                      <strong style="font-size:15px; font-weight:800; color:var(--blue-dark);">-</strong>
                      <span class="number-neutral" style="font-size:12.5px; font-weight:800; margin-left:4px;">-</span>
                    </div>
                  </div>

                  <!-- Row 3: 特店 C -->
                  <div style="display:grid; grid-template-columns: 150px 1fr 130px; gap:12px; align-items:center;">
                    <span style="font-size:14px; font-weight:800; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="特店 C（百貨生活）">特店 C <small style="color:#64748b; font-weight:600; font-size:12.5px;">(百貨生活)</small></span>
                    <div style="height:11px; background:#e8eeee; border-radius:6px; overflow:hidden;">
                      <div style="width:0%; height:100%; background:linear-gradient(90deg, #003b5c, #0284c7); border-radius:6px;"></div>
                    </div>
                    <div style="text-align:right; white-space:nowrap;">
                      <strong style="font-size:15px; font-weight:800; color:var(--blue-dark);">-</strong>
                      <span class="number-neutral" style="font-size:12.5px; font-weight:800; margin-left:4px;">-</span>
                    </div>
                  </div>

                  <!-- Row 4: 特店 D -->
                  <div style="display:grid; grid-template-columns: 150px 1fr 130px; gap:12px; align-items:center;">
                    <span style="font-size:14px; font-weight:800; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="特店 D（連鎖超商）">特店 D <small style="color:#64748b; font-weight:600; font-size:12.5px;">(連鎖超商)</small></span>
                    <div style="height:11px; background:#e8eeee; border-radius:6px; overflow:hidden;">
                      <div style="width:0%; height:100%; background:linear-gradient(90deg, #d97706, #f59e0b); border-radius:6px;"></div>
                    </div>
                    <div style="text-align:right; white-space:nowrap;">
                      <strong style="font-size:15px; font-weight:800; color:var(--blue-dark);">-</strong>
                      <span class="number-neutral" style="font-size:12.5px; font-weight:800; margin-left:4px;">-</span>
                    </div>
                  </div>

                  <!-- Row 5: 特店 E -->
                  <div style="display:grid; grid-template-columns: 150px 1fr 130px; gap:12px; align-items:center;">
                    <span style="font-size:14px; font-weight:800; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="特店 E（連鎖餐飲）">特店 E <small style="color:#64748b; font-weight:600; font-size:12.5px;">(連鎖餐飲)</small></span>
                    <div style="height:11px; background:#e8eeee; border-radius:6px; overflow:hidden;">
                      <div style="width:0%; height:100%; background:linear-gradient(90deg, #003b5c, #0284c7); border-radius:6px;"></div>
                    </div>
                    <div style="text-align:right; white-space:nowrap;">
                      <strong style="font-size:15px; font-weight:800; color:var(--blue-dark);">-</strong>
                      <span class="number-neutral" style="font-size:12.5px; font-weight:800; margin-left:4px;">-</span>
                    </div>
                  </div>
                </div>'''

assert old_b02_tab1 in content, "old_b02_tab1 not found in content!"
content = content.replace(old_b02_tab1, new_b02_tab1)

# Replace 2x2 matrix representatives
content = re.sub(r'id="b02-rep-potential">[^<]+<', 'id="b02-rep-potential">代表：-<', content)
content = re.sub(r'id="b02-rep-core">[^<]+<', 'id="b02-rep-core">代表：-<', content)
content = re.sub(r'id="b02-rep-general">[^<]+<', 'id="b02-rep-general">代表：-<', content)
content = re.sub(r'id="b02-rep-maintain">[^<]+<', 'id="b02-rep-maintain">代表：-<', content)

# 7. Section 02 Tab 2: 產業 MCC 蝴蝶圖
old_butterfly = '''            <div class="acq-butterfly-list" id="b02-butterfly-list">
              <!-- Row 1: 量販超市 -->
              <div class="acq-butterfly-row">
                <div class="acq-b-left-wing">
                  <span class="acq-b-val-left">1,920 家 (4.0%)</span>
                  <div class="acq-b-bar-track-left">
                    <div class="acq-b-bar-fill-left" style="width: 9.7%; background:#003b5c;"></div>
                  </div>
                </div>
                <div class="acq-b-center-axis">
                  <span class="acq-b-axis-title">🛒 量販超市</span>
                </div>
                <div class="acq-b-right-wing">
                  <div class="acq-b-bar-track-right">
                    <div class="acq-b-bar-fill-right" style="width: 100%; background:#003b5c;"></div>
                  </div>
                  <span class="acq-b-val-right">74.1 億 (26.0%)</span>
                </div>
                <div class="acq-b-avg-col">
                  <span class="acq-b-avg-badge">385.9 萬/店</span>
                </div>
              </div>

              <!-- Row 2: 綜合電商 -->
              <div class="acq-butterfly-row">
                <div class="acq-b-left-wing">
                  <span class="acq-b-val-left">850 家 (1.8%)</span>
                  <div class="acq-b-bar-track-left">
                    <div class="acq-b-bar-fill-left" style="width: 4.4%; background:#0284c7;"></div>
                  </div>
                </div>
                <div class="acq-b-center-axis">
                  <span class="acq-b-axis-title">🌐 綜合電商</span>
                </div>
                <div class="acq-b-right-wing">
                  <div class="acq-b-bar-track-right">
                    <div class="acq-b-bar-fill-right" style="width: 80.7%; background:#0284c7;"></div>
                  </div>
                  <span class="acq-b-val-right">59.8 億 (21.0%)</span>
                </div>
                <div class="acq-b-avg-col">
                  <span class="acq-b-avg-badge highlight">703.5 萬/店 ⭐</span>
                </div>
              </div>

              <!-- Row 3: 百貨生活 -->
              <div class="acq-butterfly-row">
                <div class="acq-b-left-wing">
                  <span class="acq-b-val-left">4,850 家 (10.0%)</span>
                  <div class="acq-b-bar-track-left">
                    <div class="acq-b-bar-fill-left" style="width: 24.3%; background:#009e73;"></div>
                  </div>
                </div>
                <div class="acq-b-center-axis">
                  <span class="acq-b-axis-title">🏬 百貨生活</span>
                </div>
                <div class="acq-b-right-wing">
                  <div class="acq-b-bar-track-right">
                    <div class="acq-b-bar-fill-right" style="width: 59.2%; background:#009e73;"></div>
                  </div>
                  <span class="acq-b-val-right">43.9 億 (15.4%)</span>
                </div>
                <div class="acq-b-avg-col">
                  <span class="acq-b-avg-badge">90.5 萬/店</span>
                </div>
              </div>

              <!-- Row 4: 餐飲美食 -->
              <div class="acq-butterfly-row">
                <div class="acq-b-left-wing">
                  <span class="acq-b-val-left" style="color:#b45309; font-weight:800;">18,500 家 (38.1%)</span>
                  <div class="acq-b-bar-track-left">
                    <div class="acq-b-bar-fill-left" style="width: 92.5%; background:#f59e0b;"></div>
                  </div>
                </div>
                <div class="acq-b-center-axis">
                  <span class="acq-b-axis-title">🍽️ 餐飲美食</span>
                </div>
                <div class="acq-b-right-wing">
                  <div class="acq-b-bar-track-right">
                    <div class="acq-b-bar-fill-right" style="width: 42.3%; background:#f59e0b;"></div>
                  </div>
                  <span class="acq-b-val-right">31.4 億 (11.0%)</span>
                </div>
                <div class="acq-b-avg-col">
                  <span class="acq-b-avg-badge">17.0 萬/店</span>
                </div>
              </div>

              <!-- Row 5: 交通旅遊 -->
              <div class="acq-butterfly-row">
                <div class="acq-b-left-wing">
                  <span class="acq-b-val-left">2,400 家 (4.9%)</span>
                  <div class="acq-b-bar-track-left">
                    <div class="acq-b-bar-fill-left" style="width: 11.9%; background:#8b5cf6;"></div>
                  </div>
                </div>
                <div class="acq-b-center-axis">
                  <span class="acq-b-axis-title">✈️ 交通旅遊</span>
                </div>
                <div class="acq-b-right-wing">
                  <div class="acq-b-bar-track-right">
                    <div class="acq-b-bar-fill-right" style="width: 30.8%; background:#8b5cf6;"></div>
                  </div>
                  <span class="acq-b-val-right">22.8 億 (8.0%)</span>
                </div>
                <div class="acq-b-avg-col">
                  <span class="acq-b-avg-badge">95.0 萬/店</span>
                </div>
              </div>

              <!-- Row 6: 其他各業 -->
              <div class="acq-butterfly-row">
                <div class="acq-b-left-wing">
                  <span class="acq-b-val-left">19,980 家 (41.2%)</span>
                  <div class="acq-b-bar-track-left">
                    <div class="acq-b-bar-fill-left" style="width: 100%; background:#94a3b8;"></div>
                  </div>
                </div>
                <div class="acq-b-center-axis">
                  <span class="acq-b-axis-title">📦 其他各業</span>
                </div>
                <div class="acq-b-right-wing">
                  <div class="acq-b-bar-track-right">
                    <div class="acq-b-bar-fill-right" style="width: 71.5%; background:#94a3b8;"></div>
                  </div>
                  <span class="acq-b-val-right">53.0 億 (18.6%)</span>
                </div>
                <div class="acq-b-avg-col">
                  <span class="acq-b-avg-badge">26.5 萬/店</span>
                </div>
              </div>
            </div>'''

new_butterfly = '''            <div class="acq-butterfly-list" id="b02-butterfly-list">
              <!-- Row 1: 量販超市 -->
              <div class="acq-butterfly-row">
                <div class="acq-b-left-wing">
                  <span class="acq-b-val-left">- 家 (-%)</span>
                  <div class="acq-b-bar-track-left">
                    <div class="acq-b-bar-fill-left" style="width: 0%; background:#003b5c;"></div>
                  </div>
                </div>
                <div class="acq-b-center-axis">
                  <span class="acq-b-axis-title">🛒 量販超市</span>
                </div>
                <div class="acq-b-right-wing">
                  <div class="acq-b-bar-track-right">
                    <div class="acq-b-bar-fill-right" style="width: 0%; background:#003b5c;"></div>
                  </div>
                  <span class="acq-b-val-right">- 億 (-%)</span>
                </div>
                <div class="acq-b-avg-col">
                  <span class="acq-b-avg-badge">- 萬/店</span>
                </div>
              </div>

              <!-- Row 2: 綜合電商 -->
              <div class="acq-butterfly-row">
                <div class="acq-b-left-wing">
                  <span class="acq-b-val-left">- 家 (-%)</span>
                  <div class="acq-b-bar-track-left">
                    <div class="acq-b-bar-fill-left" style="width: 0%; background:#0284c7;"></div>
                  </div>
                </div>
                <div class="acq-b-center-axis">
                  <span class="acq-b-axis-title">🌐 綜合電商</span>
                </div>
                <div class="acq-b-right-wing">
                  <div class="acq-b-bar-track-right">
                    <div class="acq-b-bar-fill-right" style="width: 0%; background:#0284c7;"></div>
                  </div>
                  <span class="acq-b-val-right">- 億 (-%)</span>
                </div>
                <div class="acq-b-avg-col">
                  <span class="acq-b-avg-badge">- 萬/店</span>
                </div>
              </div>

              <!-- Row 3: 百貨生活 -->
              <div class="acq-butterfly-row">
                <div class="acq-b-left-wing">
                  <span class="acq-b-val-left">- 家 (-%)</span>
                  <div class="acq-b-bar-track-left">
                    <div class="acq-b-bar-fill-left" style="width: 0%; background:#009e73;"></div>
                  </div>
                </div>
                <div class="acq-b-center-axis">
                  <span class="acq-b-axis-title">🏬 百貨生活</span>
                </div>
                <div class="acq-b-right-wing">
                  <div class="acq-b-bar-track-right">
                    <div class="acq-b-bar-fill-right" style="width: 0%; background:#009e73;"></div>
                  </div>
                  <span class="acq-b-val-right">- 億 (-%)</span>
                </div>
                <div class="acq-b-avg-col">
                  <span class="acq-b-avg-badge">- 萬/店</span>
                </div>
              </div>

              <!-- Row 4: 餐飲美食 -->
              <div class="acq-butterfly-row">
                <div class="acq-b-left-wing">
                  <span class="acq-b-val-left" style="color:#b45309; font-weight:800;">- 家 (-%)</span>
                  <div class="acq-b-bar-track-left">
                    <div class="acq-b-bar-fill-left" style="width: 0%; background:#f59e0b;"></div>
                  </div>
                </div>
                <div class="acq-b-center-axis">
                  <span class="acq-b-axis-title">🍽️ 餐飲美食</span>
                </div>
                <div class="acq-b-right-wing">
                  <div class="acq-b-bar-track-right">
                    <div class="acq-b-bar-fill-right" style="width: 0%; background:#f59e0b;"></div>
                  </div>
                  <span class="acq-b-val-right">- 億 (-%)</span>
                </div>
                <div class="acq-b-avg-col">
                  <span class="acq-b-avg-badge">- 萬/店</span>
                </div>
              </div>

              <!-- Row 5: 交通旅遊 -->
              <div class="acq-butterfly-row">
                <div class="acq-b-left-wing">
                  <span class="acq-b-val-left">- 家 (-%)</span>
                  <div class="acq-b-bar-track-left">
                    <div class="acq-b-bar-fill-left" style="width: 0%; background:#8b5cf6;"></div>
                  </div>
                </div>
                <div class="acq-b-center-axis">
                  <span class="acq-b-axis-title">✈️ 交通旅遊</span>
                </div>
                <div class="acq-b-right-wing">
                  <div class="acq-b-bar-track-right">
                    <div class="acq-b-bar-fill-right" style="width: 0%; background:#8b5cf6;"></div>
                  </div>
                  <span class="acq-b-val-right">- 億 (-%)</span>
                </div>
                <div class="acq-b-avg-col">
                  <span class="acq-b-avg-badge">- 萬/店</span>
                </div>
              </div>

              <!-- Row 6: 其他各業 -->
              <div class="acq-butterfly-row">
                <div class="acq-b-left-wing">
                  <span class="acq-b-val-left">- 家 (-%)</span>
                  <div class="acq-b-bar-track-left">
                    <div class="acq-b-bar-fill-left" style="width: 0%; background:#94a3b8;"></div>
                  </div>
                </div>
                <div class="acq-b-center-axis">
                  <span class="acq-b-axis-title">📦 其他各業</span>
                </div>
                <div class="acq-b-right-wing">
                  <div class="acq-b-bar-track-right">
                    <div class="acq-b-bar-fill-right" style="width: 0%; background:#94a3b8;"></div>
                  </div>
                  <span class="acq-b-val-right">- 億 (-%)</span>
                </div>
                <div class="acq-b-avg-col">
                  <span class="acq-b-avg-badge">- 萬/店</span>
                </div>
              </div>
            </div>'''

assert old_butterfly in content, "old_butterfly not found in content!"
content = content.replace(old_butterfly, new_butterfly)

# 8. Section 02: TWQR Panel
old_b02_twqr = '''        <div class="twqr-grid" style="display:grid; grid-template-columns: 3fr 5fr; gap:14px; margin-top:14px;">
          <section style="padding:14px; background:#fff; border:1px solid #d8e6e1; border-radius:10px;">
            <h4 style="margin:0 0 12px; color:var(--blue-dark); font-size:15px; font-weight:900;">特店進件分析</h4>
            <div class="twqr-stats" style="display:grid; grid-template-columns: repeat(3, 1fr); gap:8px;">
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月申請進件數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-apply-cnt">3,850 件</strong>
                <b class="" style="font-size:11.5px; font-weight:800; color:#64748b;" id="b02-twqr-pass-rate">審查通過率 91.2%</b>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月新增特店家數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-new-mcht">1,210 家</strong>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">累計特店家數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-total-mcht">22,100 家</strong>
                <b class="is-good" style="font-size:11.5px; font-weight:800; color:#047857;" id="b02-twqr-total-mom">MoM +5.8%</b>
              </div>
            </div>
          </section>
          <section style="padding:14px; background:#fff; border:1px solid #d8e6e1; border-radius:10px;">
            <h4 style="margin:0 0 12px; color:var(--blue-dark); font-size:15px; font-weight:900;">交易狀態分析</h4>
            <div class="twqr-stats four" style="display:grid; grid-template-columns: repeat(5, 1fr); gap:8px;">
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月交易金額</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-tx-amt">130,620 元</strong>
                <b class="is-good" style="font-size:11.5px; font-weight:800; color:#047857;" id="b02-twqr-amt-mom">MoM +18.5%</b>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月交易筆數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-tx-cnt">199 筆</strong>
                <b class="is-good" style="font-size:11.5px; font-weight:800; color:#047857;" id="b02-twqr-cnt-mom">MoM +22.1%</b>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">平均每筆客單</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-avg-ticket">692 元</strong>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">店均交易金額</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-mcht-avg-amt">5.79 萬元</strong>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">動用特店比率</span>
                <strong style="font-size:22px; font-weight:800; color:var(--blue-dark); margin:4px 0; display:block;" id="b02-twqr-active-rate">78.5%</strong>
              </div>
            </div>
          </section>
        </div>'''

new_b02_twqr = '''        <div class="twqr-grid" style="display:grid; grid-template-columns: 3fr 5fr; gap:14px; margin-top:14px;">
          <section style="padding:14px; background:#fff; border:1px solid #d8e6e1; border-radius:10px;">
            <h4 style="margin:0 0 12px; color:var(--blue-dark); font-size:15px; font-weight:900;">特店進件分析</h4>
            <div class="twqr-stats" style="display:grid; grid-template-columns: repeat(3, 1fr); gap:8px;">
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月申請進件數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-apply-cnt">- 件</strong>
                <b class="number-neutral" style="font-size:11.5px; font-weight:800; color:#64748b;" id="b02-twqr-pass-rate">-</b>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月新增特店家數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-new-mcht">- 家</strong>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">累計特店家數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-total-mcht">- 家</strong>
                <b class="number-neutral" style="font-size:11.5px; font-weight:800; color:#64748b;" id="b02-twqr-total-mom">-</b>
              </div>
            </div>
          </section>
          <section style="padding:14px; background:#fff; border:1px solid #d8e6e1; border-radius:10px;">
            <h4 style="margin:0 0 12px; color:var(--blue-dark); font-size:15px; font-weight:900;">交易狀態分析</h4>
            <div class="twqr-stats four" style="display:grid; grid-template-columns: repeat(5, 1fr); gap:8px;">
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月交易金額</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-tx-amt">- 元</strong>
                <b class="number-neutral" style="font-size:11.5px; font-weight:800; color:#64748b;" id="b02-twqr-amt-mom">-</b>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">當月交易筆數</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-tx-cnt">- 筆</strong>
                <b class="number-neutral" style="font-size:11.5px; font-weight:800; color:#64748b;" id="b02-twqr-cnt-mom">-</b>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">平均每筆客單</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-avg-ticket">- 元</strong>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">店均交易金額</span>
                <strong style="font-size:22px; font-weight:800; color:var(--ink); margin:4px 0; display:block;" id="b02-twqr-mcht-avg-amt">- 萬元</strong>
              </div>
              <div style="padding:10px; background:#f4f8f7; border-radius:6px;">
                <span style="font-size:12.5px; font-weight:800; color:#556972;">動用特店比率</span>
                <strong style="font-size:22px; font-weight:800; color:var(--blue-dark); margin:4px 0; display:block;" id="b02-twqr-active-rate">-%</strong>
              </div>
            </div>
          </section>
        </div>'''

assert old_b02_twqr in content, "old_b02_twqr not found in content!"
content = content.replace(old_b02_twqr, new_b02_twqr)

# 9. Section 03 Tab 1: 帳單列印中心
old_b03_tab1 = '''            <div class="c-mini-kpi" style="background:#fff; border:1px solid #e5ece9; border-radius:8px; padding:12px 14px;">
              <span class="c-kpi-title" style="font-size:12.5px; color:#556972; font-weight:800;">全行出帳總份數</span>
              <strong class="c-mini-val" id="b03-bill-tot-val" style="font-size:24px; color:#003b5c; display:block; margin:3px 0 2px; font-weight:900;">531.6 <em style="font-size:13px; font-style:normal; font-weight:700;">萬份</em></strong>
              <div class="c-kpi-growth" id="b03-bill-tot-growth" style="font-size:11.5px;"><span class="number-positive">YoY +4.2%</span> </div>
            </div>
            <div class="c-mini-kpi" style="background:#fff; border:1px solid #e5ece9; border-radius:8px; padding:12px 14px;">
              <span class="c-kpi-title" style="font-size:12.5px; color:#556972; font-weight:800;">全行綜合電子化率</span>
              <strong class="c-mini-val" id="b03-bill-erate-val" style="font-size:24px; color:#009e73; display:block; margin:3px 0 2px; font-weight:900;">60.9<em style="font-size:13px; font-style:normal; font-weight:700;">%</em></strong>
              <div class="c-kpi-growth" id="b03-bill-erate-growth" style="font-size:11.5px;"><span class="number-positive">YoY +5.8%</span> <span class="c-hint" id="b03-bill-erate-hint" style="color:#64748b;">(電子 323.7萬份)</span></div>
            </div>
            <div class="c-mini-kpi" style="background:#fff; border:1px solid #e5ece9; border-radius:8px; padding:12px 14px;">
              <span class="c-kpi-title" style="font-size:12.5px; color:#556972; font-weight:800;">有效投遞率</span>
              <strong class="c-mini-val" id="b03-bill-deliv-val" style="font-size:24px; color:#2563eb; display:block; margin:3px 0 2px; font-weight:900;">99.1<em style="font-size:13px; font-style:normal; font-weight:700;">%</em></strong>
              <div class="c-kpi-growth" id="b03-bill-deliv-growth" style="font-size:11.5px;"><span class="number-positive" id="b03-bill-deliv-pos">電子退信 0.6%</span> <span class="c-hint" id="b03-bill-deliv-hint" style="color:#64748b;">(紙本退件 1.1%)</span></div>
            </div>
            <div class="c-mini-kpi" style="background:#fff; border:1px solid #e5ece9; border-radius:8px; padding:12px 14px;">
              <span class="c-kpi-title" style="font-size:12.5px; color:#556972; font-weight:800;">綠色節能省費效益</span>
              <strong class="c-mini-val" id="b03-bill-green-val" style="font-size:24px; color:#059669; display:block; margin:3px 0 2px; font-weight:900;">2,052 <em style="font-size:13px; font-style:normal; font-weight:700;">萬元</em></strong>
              <div class="c-kpi-growth" id="b03-bill-green-growth" style="font-size:11.5px;"><span class="number-positive" id="b03-bill-green-pos">節省郵資+紙張/月</span> <span class="c-hint" id="b03-bill-green-hint" style="color:#64748b;">(減碳 38.6 噸)</span></div>
            </div>
          </div>

          <!-- 雙軌帳單深入分析：信用卡帳單 vs 銀行綜合對帳單 (左右並列 2-Column Grid) -->
          <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
            <!-- Left Card: 信用卡帳單 -->
            <div class="svg-chart-card">
              <div class="svg-chart-note">
                <span style="font-size:14px; font-weight:900; color:#003b5c; display:flex; align-items:center; gap:8px;">
                  <span style="width:10px; height:10px; border-radius:50%; background:#003b5c; display:inline-block;"></span>信用卡帳單
                </span>
              </div>

              <!-- 比例條與主數據 -->
              <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:16px;">
                <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:10px;">
                  <div>
                    <span style="font-size:12.5px; color:#64748b; font-weight:800;">當月出帳總量</span>
                    <div style="font-size:26px; font-weight:900; color:#003b5c; margin-top:2px;" id="b03-bill-card-tot">468.6 <em style="font-size:14px; font-style:normal; font-weight:700;">萬份</em></div>
                  </div>
                  <div style="text-align:right;">
                    <span style="font-size:12.5px; color:#64748b; font-weight:800;">電子化滲透率</span>
                    <div style="font-size:26px; font-weight:900; color:#009e73; margin-top:2px;" id="b03-bill-card-erate">67.9%</div>
                  </div>
                </div>

                <!-- 100% 比例進度條 -->
                <div style="height:18px; background:#e2e8f0; border-radius:9px; overflow:hidden; display:flex; margin-bottom:10px;">
                  <div id="b03-bill-card-seg-elec" style="width:67.9%; height:100%; background:linear-gradient(90deg, #009e73, #10b981); border-radius:9px 0 0 9px;" title="電子帳單: 67.9% (318.3萬份)"></div>
                  <div id="b03-bill-card-seg-papr" style="width:32.1%; height:100%; background:#d97706; border-radius:0 9px 9px 0;" title="紙本帳單: 32.1% (150.3萬份)"></div>
                </div>

                <div style="display:flex; justify-content:space-between; font-size:13px; font-weight:800;">
                  <span id="b03-bill-card-lbl-elec" style="color:#007a5e;">● 電子帳單 67.9% (318.3 萬份)</span>
                  <span id="b03-bill-card-lbl-papr" style="color:#92400e;">● 紙本帳單 32.1% (150.3 萬份)</span>
                </div>
              </div>
            </div>

            <!-- Right Card: 銀行對帳單 -->
            <div class="svg-chart-card">
              <div class="svg-chart-note">
                <span style="font-size:14px; font-weight:900; color:#1e293b; display:flex; align-items:center; gap:8px;">
                  <span style="width:10px; height:10px; border-radius:50%; background:#2563eb; display:inline-block;"></span>銀行對帳單
                </span>
              </div>

              <!-- 比例條與主數據 -->
              <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:16px;">
                <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:10px;">
                  <div>
                    <span style="font-size:12.5px; color:#64748b; font-weight:800;">當月出帳總量</span>
                    <div style="font-size:26px; font-weight:900; color:#1e293b; margin-top:2px;" id="b03-bill-bank-tot">62.9 <em style="font-size:14px; font-style:normal; font-weight:700;">萬份</em></div>
                  </div>
                  <div style="text-align:right;">
                    <span style="font-size:12.5px; color:#64748b; font-weight:800;">電子化滲透率</span>
                    <div style="font-size:26px; font-weight:900; color:#2563eb; margin-top:2px;" id="b03-bill-bank-erate">8.5%</div>
                  </div>
                </div>

                <!-- 100% 比例進度條 -->
                <div style="height:18px; background:#e2e8f0; border-radius:9px; overflow:hidden; display:flex; margin-bottom:10px;">
                  <div id="b03-bill-bank-seg-elec" style="width:8.5%; height:100%; background:linear-gradient(90deg, #2563eb, #3b82f6); border-radius:9px 0 0 9px;" title="電子帳單: 8.5% (5.4萬份)"></div>
                  <div id="b03-bill-bank-seg-papr" style="width:91.5%; height:100%; background:#94a3b8; border-radius:0 9px 9px 0;" title="紙本帳單: 91.5% (57.6萬份)"></div>
                </div>

                <div style="display:flex; justify-content:space-between; font-size:13px; font-weight:800;">
                  <span id="b03-bill-bank-lbl-elec" style="color:#1d4ed8;">● 電子帳單 8.5% (5.4 萬份)</span>
                  <span id="b03-bill-bank-lbl-papr" style="color:#475569;">● 紙本帳單 91.5% (57.6 萬份)</span>
                </div>
              </div>
            </div>
          </div>'''

new_b03_tab1 = '''            <div class="c-mini-kpi" style="background:#fff; border:1px solid #e5ece9; border-radius:8px; padding:12px 14px;">
              <span class="c-kpi-title" style="font-size:12.5px; color:#556972; font-weight:800;">全行出帳總份數</span>
              <strong class="c-mini-val" id="b03-bill-tot-val" style="font-size:24px; color:#003b5c; display:block; margin:3px 0 2px; font-weight:900;">- <em style="font-size:13px; font-style:normal; font-weight:700;">萬份</em></strong>
              <div class="c-kpi-growth" id="b03-bill-tot-growth" style="font-size:11.5px;"><span class="number-neutral">-</span> </div>
            </div>
            <div class="c-mini-kpi" style="background:#fff; border:1px solid #e5ece9; border-radius:8px; padding:12px 14px;">
              <span class="c-kpi-title" style="font-size:12.5px; color:#556972; font-weight:800;">全行綜合電子化率</span>
              <strong class="c-mini-val" id="b03-bill-erate-val" style="font-size:24px; color:#009e73; display:block; margin:3px 0 2px; font-weight:900;">-<em style="font-size:13px; font-style:normal; font-weight:700;">%</em></strong>
              <div class="c-kpi-growth" id="b03-bill-erate-growth" style="font-size:11.5px;"><span class="number-neutral">-</span> <span class="c-hint" id="b03-bill-erate-hint" style="color:#64748b;">(電子 -萬份)</span></div>
            </div>
            <div class="c-mini-kpi" style="background:#fff; border:1px solid #e5ece9; border-radius:8px; padding:12px 14px;">
              <span class="c-kpi-title" style="font-size:12.5px; color:#556972; font-weight:800;">有效投遞率</span>
              <strong class="c-mini-val" id="b03-bill-deliv-val" style="font-size:24px; color:#2563eb; display:block; margin:3px 0 2px; font-weight:900;">-<em style="font-size:13px; font-style:normal; font-weight:700;">%</em></strong>
              <div class="c-kpi-growth" id="b03-bill-deliv-growth" style="font-size:11.5px;"><span class="number-neutral" id="b03-bill-deliv-pos">電子退信 -%</span> <span class="c-hint" id="b03-bill-deliv-hint" style="color:#64748b;">(紙本退件 -%)</span></div>
            </div>
            <div class="c-mini-kpi" style="background:#fff; border:1px solid #e5ece9; border-radius:8px; padding:12px 14px;">
              <span class="c-kpi-title" style="font-size:12.5px; color:#556972; font-weight:800;">綠色節能省費效益</span>
              <strong class="c-mini-val" id="b03-bill-green-val" style="font-size:24px; color:#059669; display:block; margin:3px 0 2px; font-weight:900;">- <em style="font-size:13px; font-style:normal; font-weight:700;">萬元</em></strong>
              <div class="c-kpi-growth" id="b03-bill-green-growth" style="font-size:11.5px;"><span class="number-neutral" id="b03-bill-green-pos">節省郵資+紙張/月</span> <span class="c-hint" id="b03-bill-green-hint" style="color:#64748b;">(減碳 - 噸)</span></div>
            </div>
          </div>

          <!-- 雙軌帳單深入分析：信用卡帳單 vs 銀行綜合對帳單 (左右並列 2-Column Grid) -->
          <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
            <!-- Left Card: 信用卡帳單 -->
            <div class="svg-chart-card">
              <div class="svg-chart-note">
                <span style="font-size:14px; font-weight:900; color:#003b5c; display:flex; align-items:center; gap:8px;">
                  <span style="width:10px; height:10px; border-radius:50%; background:#003b5c; display:inline-block;"></span>信用卡帳單
                </span>
              </div>

              <!-- 比例條與主數據 -->
              <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:16px;">
                <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:10px;">
                  <div>
                    <span style="font-size:12.5px; color:#64748b; font-weight:800;">當月出帳總量</span>
                    <div style="font-size:26px; font-weight:900; color:#003b5c; margin-top:2px;" id="b03-bill-card-tot">- <em style="font-size:14px; font-style:normal; font-weight:700;">萬份</em></div>
                  </div>
                  <div style="text-align:right;">
                    <span style="font-size:12.5px; color:#64748b; font-weight:800;">電子化滲透率</span>
                    <div style="font-size:26px; font-weight:900; color:#009e73; margin-top:2px;" id="b03-bill-card-erate">-%</div>
                  </div>
                </div>

                <!-- 100% 比例進度條 -->
                <div style="height:18px; background:#e2e8f0; border-radius:9px; overflow:hidden; display:flex; margin-bottom:10px;">
                  <div id="b03-bill-card-seg-elec" style="width:0%; height:100%; background:linear-gradient(90deg, #009e73, #10b981); border-radius:9px 0 0 9px;" title="-"></div>
                  <div id="b03-bill-card-seg-papr" style="width:0%; height:100%; background:#d97706; border-radius:0 9px 9px 0;" title="-"></div>
                </div>

                <div style="display:flex; justify-content:space-between; font-size:13px; font-weight:800;">
                  <span id="b03-bill-card-lbl-elec" style="color:#007a5e;">● 電子帳單 -% (- 萬份)</span>
                  <span id="b03-bill-card-lbl-papr" style="color:#92400e;">● 紙本帳單 -% (- 萬份)</span>
                </div>
              </div>
            </div>

            <!-- Right Card: 銀行對帳單 -->
            <div class="svg-chart-card">
              <div class="svg-chart-note">
                <span style="font-size:14px; font-weight:900; color:#1e293b; display:flex; align-items:center; gap:8px;">
                  <span style="width:10px; height:10px; border-radius:50%; background:#2563eb; display:inline-block;"></span>銀行對帳單
                </span>
              </div>

              <!-- 比例條與主數據 -->
              <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:16px;">
                <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:10px;">
                  <div>
                    <span style="font-size:12.5px; color:#64748b; font-weight:800;">當月出帳總量</span>
                    <div style="font-size:26px; font-weight:900; color:#1e293b; margin-top:2px;" id="b03-bill-bank-tot">- <em style="font-size:14px; font-style:normal; font-weight:700;">萬份</em></div>
                  </div>
                  <div style="text-align:right;">
                    <span style="font-size:12.5px; color:#64748b; font-weight:800;">電子化滲透率</span>
                    <div style="font-size:26px; font-weight:900; color:#2563eb; margin-top:2px;" id="b03-bill-bank-erate">-%</div>
                  </div>
                </div>

                <!-- 100% 比例進度條 -->
                <div style="height:18px; background:#e2e8f0; border-radius:9px; overflow:hidden; display:flex; margin-bottom:10px;">
                  <div id="b03-bill-bank-seg-elec" style="width:0%; height:100%; background:linear-gradient(90deg, #2563eb, #3b82f6); border-radius:9px 0 0 9px;" title="-"></div>
                  <div id="b03-bill-bank-seg-papr" style="width:0%; height:100%; background:#94a3b8; border-radius:0 9px 9px 0;" title="-"></div>
                </div>

                <div style="display:flex; justify-content:space-between; font-size:13px; font-weight:800;">
                  <span id="b03-bill-bank-lbl-elec" style="color:#1d4ed8;">● 電子帳單 -% (- 萬份)</span>
                  <span id="b03-bill-bank-lbl-papr" style="color:#475569;">● 紙本帳單 -% (- 萬份)</span>
                </div>
              </div>
            </div>
          </div>'''

assert old_b03_tab1 in content, "old_b03_tab1 not found in content!"
content = content.replace(old_b03_tab1, new_b03_tab1)

# 10. Section 03 Tab 2: 小樹點折抵通路
old_b03_bonus = '''              <div class="svg-chart-note">
                <span>五大折抵通路佔比</span>
                <span class="status-pill primary" id="b03-bonus-redeem-pill">當月兌換 3.2 百萬點</span>
              </div>

              <!-- 5 通路排行列表 (自適配高度與左側小樹點概況分析完美切齊) -->
              <div id="b03-bonus-channels-container" style="flex:1; display:flex; flex-direction:column; justify-content:space-between; min-height:220px; padding:6px 2px 2px;">
                <!-- Row 1: 即時折抵 -->
                <div style="display:grid; grid-template-columns: 110px 1fr 130px; align-items:center; gap:16px;">
                  <span style="font-size:14px; font-weight:800; color:#1e293b; display:flex; align-items:center; gap:8px;">
                    <span style="width:24px; height:24px; border-radius:5px; background:#e6f6f1; color:#009e73; font-size:12px; font-weight:900; display:inline-flex; align-items:center; justify-content:center;">1</span>即時折抵
                  </span>
                  <div style="height:15px; background:#eef2f6; border-radius:8px; overflow:hidden;">
                    <div style="width:42%; height:100%; background:linear-gradient(90deg, #009e73, #10b981); border-radius:8px;"></div>
                  </div>
                  <div style="text-align:right; font-variant-numeric:tabular-nums; white-space:nowrap;">
                    <b style="font-size:15px; color:#1e293b; font-weight:900;">1.34 百萬點</b>
                    <span style="font-size:13px; font-weight:800; color:#009e73; margin-left:8px;">42.0%</span>
                  </div>
                </div>

                <!-- Row 2: 商戶折抵 -->
                <div style="display:grid; grid-template-columns: 110px 1fr 130px; align-items:center; gap:16px;">
                  <span style="font-size:14px; font-weight:800; color:#1e293b; display:flex; align-items:center; gap:8px;">
                    <span style="width:24px; height:24px; border-radius:5px; background:#eef5f8; color:#003b5c; font-size:12px; font-weight:900; display:inline-flex; align-items:center; justify-content:center;">2</span>商戶折抵
                  </span>
                  <div style="height:15px; background:#eef2f6; border-radius:8px; overflow:hidden;">
                    <div style="width:24%; height:100%; background:linear-gradient(90deg, #003b5c, #0284c7); border-radius:8px;"></div>
                  </div>
                  <div style="text-align:right; font-variant-numeric:tabular-nums; white-space:nowrap;">
                    <b style="font-size:15px; color:#1e293b; font-weight:900;">0.77 百萬點</b>
                    <span style="font-size:13px; font-weight:800; color:#003b5c; margin-left:8px;">24.0%</span>
                  </div>
                </div>

                <!-- Row 3: 里程兌換 -->
                <div style="display:grid; grid-template-columns: 110px 1fr 130px; align-items:center; gap:16px;">
                  <span style="font-size:14px; font-weight:800; color:#1e293b; display:flex; align-items:center; gap:8px;">
                    <span style="width:24px; height:24px; border-radius:5px; background:#f3efff; color:#7c4dff; font-size:12px; font-weight:900; display:inline-flex; align-items:center; justify-content:center;">3</span>里程兌換
                  </span>
                  <div style="height:15px; background:#eef2f6; border-radius:8px; overflow:hidden;">
                    <div style="width:16%; height:100%; background:linear-gradient(90deg, #7c4dff, #a78bfa); border-radius:8px;"></div>
                  </div>
                  <div style="text-align:right; font-variant-numeric:tabular-nums; white-space:nowrap;">
                    <b style="font-size:15px; color:#1e293b; font-weight:900;">0.51 百萬點</b>
                    <span style="font-size:13px; font-weight:800; color:#7c4dff; margin-left:8px;">16.0%</span>
                  </div>
                </div>

                <!-- Row 4: 合併用點 -->
                <div style="display:grid; grid-template-columns: 110px 1fr 130px; align-items:center; gap:16px;">
                  <span style="font-size:14px; font-weight:800; color:#1e293b; display:flex; align-items:center; gap:8px;">
                    <span style="width:24px; height:24px; border-radius:5px; background:#fef6ec; color:#c9892e; font-size:12px; font-weight:900; display:inline-flex; align-items:center; justify-content:center;">4</span>合併用點
                  </span>
                  <div style="height:15px; background:#eef2f6; border-radius:8px; overflow:hidden;">
                    <div style="width:11%; height:100%; background:linear-gradient(90deg, #c9892e, #f59e0b); border-radius:8px;"></div>
                  </div>
                  <div style="text-align:right; font-variant-numeric:tabular-nums; white-space:nowrap;">
                    <b style="font-size:15px; color:#1e293b; font-weight:900;">0.35 百萬點</b>
                    <span style="font-size:13px; font-weight:800; color:#c9892e; margin-left:8px;">11.0%</span>
                  </div>
                </div>

                <!-- Row 5: 其他折抵 -->
                <div style="display:grid; grid-template-columns: 110px 1fr 130px; align-items:center; gap:16px;">
                  <span style="font-size:14px; font-weight:800; color:#1e293b; display:flex; align-items:center; gap:8px;">
                    <span style="width:24px; height:24px; border-radius:5px; background:#f1f5f9; color:#64748b; font-size:12px; font-weight:900; display:inline-flex; align-items:center; justify-content:center;">5</span>其他折抵
                  </span>
                  <div style="height:15px; background:#eef2f6; border-radius:8px; overflow:hidden;">
                    <div style="width:7%; height:100%; background:#94a3b8; border-radius:8px;"></div>
                  </div>
                  <div style="text-align:right; font-variant-numeric:tabular-nums; white-space:nowrap;">
                    <b style="font-size:15px; color:#1e293b; font-weight:900;">0.23 百萬點</b>
                    <span style="font-size:13px; font-weight:800; color:#64748b; margin-left:8px;">7.0%</span>
                  </div>
                </div>
              </div>'''

new_b03_bonus = '''              <div class="svg-chart-note">
                <span>五大折抵通路佔比</span>
                <span class="status-pill primary" id="b03-bonus-redeem-pill">當月兌換 - 百萬點</span>
              </div>

              <!-- 5 通路排行列表 (自適配高度與左側小樹點概況分析完美切齊) -->
              <div id="b03-bonus-channels-container" style="flex:1; display:flex; flex-direction:column; justify-content:space-between; min-height:220px; padding:6px 2px 2px;">
                <!-- Row 1: 即時折抵 -->
                <div style="display:grid; grid-template-columns: 110px 1fr 130px; align-items:center; gap:16px;">
                  <span style="font-size:14px; font-weight:800; color:#1e293b; display:flex; align-items:center; gap:8px;">
                    <span style="width:24px; height:24px; border-radius:5px; background:#e6f6f1; color:#009e73; font-size:12px; font-weight:900; display:inline-flex; align-items:center; justify-content:center;">1</span>即時折抵
                  </span>
                  <div style="height:15px; background:#eef2f6; border-radius:8px; overflow:hidden;">
                    <div style="width:0%; height:100%; background:linear-gradient(90deg, #009e73, #10b981); border-radius:8px;"></div>
                  </div>
                  <div style="text-align:right; font-variant-numeric:tabular-nums; white-space:nowrap;">
                    <b style="font-size:15px; color:#1e293b; font-weight:900;">- 百萬點</b>
                    <span style="font-size:13px; font-weight:800; color:#009e73; margin-left:8px;">-%</span>
                  </div>
                </div>

                <!-- Row 2: 商戶折抵 -->
                <div style="display:grid; grid-template-columns: 110px 1fr 130px; align-items:center; gap:16px;">
                  <span style="font-size:14px; font-weight:800; color:#1e293b; display:flex; align-items:center; gap:8px;">
                    <span style="width:24px; height:24px; border-radius:5px; background:#eef5f8; color:#003b5c; font-size:12px; font-weight:900; display:inline-flex; align-items:center; justify-content:center;">2</span>商戶折抵
                  </span>
                  <div style="height:15px; background:#eef2f6; border-radius:8px; overflow:hidden;">
                    <div style="width:0%; height:100%; background:linear-gradient(90deg, #003b5c, #0284c7); border-radius:8px;"></div>
                  </div>
                  <div style="text-align:right; font-variant-numeric:tabular-nums; white-space:nowrap;">
                    <b style="font-size:15px; color:#1e293b; font-weight:900;">- 百萬點</b>
                    <span style="font-size:13px; font-weight:800; color:#003b5c; margin-left:8px;">-%</span>
                  </div>
                </div>

                <!-- Row 3: 里程兌換 -->
                <div style="display:grid; grid-template-columns: 110px 1fr 130px; align-items:center; gap:16px;">
                  <span style="font-size:14px; font-weight:800; color:#1e293b; display:flex; align-items:center; gap:8px;">
                    <span style="width:24px; height:24px; border-radius:5px; background:#f3efff; color:#7c4dff; font-size:12px; font-weight:900; display:inline-flex; align-items:center; justify-content:center;">3</span>里程兌換
                  </span>
                  <div style="height:15px; background:#eef2f6; border-radius:8px; overflow:hidden;">
                    <div style="width:0%; height:100%; background:linear-gradient(90deg, #7c4dff, #a78bfa); border-radius:8px;"></div>
                  </div>
                  <div style="text-align:right; font-variant-numeric:tabular-nums; white-space:nowrap;">
                    <b style="font-size:15px; color:#1e293b; font-weight:900;">- 百萬點</b>
                    <span style="font-size:13px; font-weight:800; color:#7c4dff; margin-left:8px;">-%</span>
                  </div>
                </div>

                <!-- Row 4: 合併用點 -->
                <div style="display:grid; grid-template-columns: 110px 1fr 130px; align-items:center; gap:16px;">
                  <span style="font-size:14px; font-weight:800; color:#1e293b; display:flex; align-items:center; gap:8px;">
                    <span style="width:24px; height:24px; border-radius:5px; background:#fef6ec; color:#c9892e; font-size:12px; font-weight:900; display:inline-flex; align-items:center; justify-content:center;">4</span>合併用點
                  </span>
                  <div style="height:15px; background:#eef2f6; border-radius:8px; overflow:hidden;">
                    <div style="width:0%; height:100%; background:linear-gradient(90deg, #c9892e, #f59e0b); border-radius:8px;"></div>
                  </div>
                  <div style="text-align:right; font-variant-numeric:tabular-nums; white-space:nowrap;">
                    <b style="font-size:15px; color:#1e293b; font-weight:900;">- 百萬點</b>
                    <span style="font-size:13px; font-weight:800; color:#c9892e; margin-left:8px;">-%</span>
                  </div>
                </div>

                <!-- Row 5: 其他折抵 -->
                <div style="display:grid; grid-template-columns: 110px 1fr 130px; align-items:center; gap:16px;">
                  <span style="font-size:14px; font-weight:800; color:#1e293b; display:flex; align-items:center; gap:8px;">
                    <span style="width:24px; height:24px; border-radius:5px; background:#f1f5f9; color:#64748b; font-size:12px; font-weight:900; display:inline-flex; align-items:center; justify-content:center;">5</span>其他折抵
                  </span>
                  <div style="height:15px; background:#eef2f6; border-radius:8px; overflow:hidden;">
                    <div style="width:0%; height:100%; background:#94a3b8; border-radius:8px;"></div>
                  </div>
                  <div style="text-align:right; font-variant-numeric:tabular-nums; white-space:nowrap;">
                    <b style="font-size:15px; color:#1e293b; font-weight:900;">- 百萬點</b>
                    <span style="font-size:13px; font-weight:800; color:#64748b; margin-left:8px;">-%</span>
                  </div>
                </div>
              </div>'''

assert old_b03_bonus in content, "old_b03_bonus not found in content!"
content = content.replace(old_b03_bonus, new_b03_bonus)

# 11. Section 04: Primary Cards (CardPool, CardLink, Fraud)
old_b04_primary = '''      <div class="monthly-kpi-layout-3">
        
        <article class="monthly-kpi monthly-primary" id="sys-cardpool-kpi">
          <div class="monthly-kpi-title">CardPool 授權核心主機</div>
          <div class="monthly-kpi-value" id="b04-cp-resp-val">85<em>ms</em></div>
          <div class="monthly-growth" id="b04-cp-growth">
            <span class="number-positive" id="b04-cp-avail-tag"><b>可用率</b>99.999%</span><span class="number-positive" id="b04-cp-sla-tag"><b>SLA</b>100% 達標</span>
          </div>
          <div class="monthly-split">
            
            <div class="split-item" tabindex="0">
              <span>月授權量</span>
              <strong id="b04-cp-vol-val">6,820<em>萬筆</em></strong>
              <b class="number-positive" id="b04-cp-vol-tag">零超時</b>
              <div class="split-tooltip" id="b04-cp-vol-tt">
                <strong>授權核心負載</strong>
                <span>授權筆數：6,820 萬筆</span><span>超時筆數：0 筆</span><span>P99 延遲：< 120ms</span>
              </div>
            </div>
            <div class="split-item" tabindex="0">
              <span>授權成功率</span>
              <strong id="b04-cp-succ-val">98.8%<em></em></strong>
              <b class="number-positive" id="b04-cp-succ-tag">可用率 99.999%</b>
              <div class="split-tooltip" id="b04-cp-succ-tt">
                <strong>系統可用率</strong>
                <span>成功率：98.8%</span><span>系統可用：99.999%</span><span>無中斷運行：744 小時</span>
              </div>
            </div>
          </div>
        </article>
        <article class="monthly-kpi monthly-primary" id="sys-cardlink-kpi">
          <div class="monthly-kpi-title">CardLink 帳務清算核心主機</div>
          <div class="monthly-kpi-value" id="b04-cl-time-val">03:20<em>AM</em></div>
          <div class="monthly-growth" id="b04-cl-growth">
            <span class="number-positive" id="b04-cl-punc-tag"><b>批次準點率</b>100%</span><span class="number-positive" id="b04-cl-early-tag"><b>提前</b>40 分鐘</span>
          </div>
          <div class="monthly-split">
            
            <div class="split-item" tabindex="0">
              <span>排程窗口上限</span>
              <strong id="b04-cl-limit-val">04:00<em>AM</em></strong>
              <b class="number-positive" id="b04-cl-limit-tag">安全裕度足</b>
              <div class="split-tooltip" id="b04-cl-limit-tt">
                <strong>清算作業窗口</strong>
                <span>排程上限：04:00 AM</span><span>平均完成：03:20 AM</span><span>裕度時間：40 分鐘</span>
              </div>
            </div>
            <div class="split-item" tabindex="0">
              <span>日均處理帳單</span>
              <strong id="b04-cl-acc-val">17.3<em>萬戶</em></strong>
              <b class="number-positive" id="b04-cl-acc-tag">平帳 100%</b>
              <div class="split-tooltip" id="b04-cl-acc-tt">
                <strong>日均結帳量</strong>
                <span>帳單戶數：17.3 萬戶/日</span><span>平帳率：100.0%</span><span>批次作業零延宕</span>
              </div>
            </div>
          </div>
        </article>
        <article class="monthly-kpi monthly-primary" id="sys-fraud-kpi">
          <div class="monthly-kpi-title">全行防詐防堵總成效</div>
          <div class="monthly-kpi-value" id="b04-fr-amt-val">4,280<em>萬元</em></div>
          <div class="monthly-growth" id="b04-fr-growth">
            <span class="number-positive" id="b04-fr-cnt-tag"><b>防堵總卡數</b>2,684 張</span>
          </div>
          <div class="monthly-split">
            
            <div class="split-item" tabindex="0">
              <span>SFM 系統防堵</span>
              <strong id="b04-fr-sfm-amt">3,420<em>萬元</em></strong>
              <b class="number-positive" id="b04-fr-sfm-cnt">2,064 張</b>
              <div class="split-tooltip" id="b04-fr-sfm-tt">
                <strong>智慧偵測 SFM 系統</strong>
                <span>防堵金額：3,420 萬元（80%）</span><span>• 申請詐欺：1,150 萬 ｜ 842 張</span><span>• 交易詐欺：2,270 萬 ｜ 1,222 張</span>
              </div>
            </div>
            <div class="split-item" tabindex="0">
              <span>3DS 系統防堵</span>
              <strong id="b04-fr-tds-amt">860<em>萬元</em></strong>
              <b class="number-positive" id="b04-fr-tds-cnt">620 張</b>
              <div class="split-tooltip" id="b04-fr-tds-tt">
                <strong>線上交易 3DS 驗證</strong>
                <span>防堵金額：860 萬元（20%）</span><span>防堵卡數：620 張</span><span>OTP 異常攔阻率：99.6%</span>
              </div>
            </div>
          </div>
        </article>
      </div>'''

new_b04_primary = '''      <div class="monthly-kpi-layout-3">
        
        <article class="monthly-kpi monthly-primary" id="sys-cardpool-kpi">
          <div class="monthly-kpi-title">CardPool 授權核心主機</div>
          <div class="monthly-kpi-value" id="b04-cp-resp-val">-<em>ms</em></div>
          <div class="monthly-growth" id="b04-cp-growth">
            <span class="number-neutral" id="b04-cp-avail-tag"><b>可用率</b>-%</span><span class="number-neutral" id="b04-cp-sla-tag"><b>SLA</b>-%</span>
          </div>
          <div class="monthly-split">
            
            <div class="split-item" tabindex="0">
              <span>月授權量</span>
              <strong id="b04-cp-vol-val">-<em>萬筆</em></strong>
              <b class="number-neutral" id="b04-cp-vol-tag">-</b>
              <div class="split-tooltip" id="b04-cp-vol-tt">
                <strong>授權核心負載</strong>
                <span>授權筆數：- 萬筆</span><span>超時筆數：- 筆</span><span>P99 延遲：-</span>
              </div>
            </div>
            <div class="split-item" tabindex="0">
              <span>授權成功率</span>
              <strong id="b04-cp-succ-val">-%<em></em></strong>
              <b class="number-neutral" id="b04-cp-succ-tag">可用率 -%</b>
              <div class="split-tooltip" id="b04-cp-succ-tt">
                <strong>系統可用率</strong>
                <span>成功率：-%</span><span>系統可用：-%</span><span>無中斷運行：- 小時</span>
              </div>
            </div>
          </div>
        </article>
        <article class="monthly-kpi monthly-primary" id="sys-cardlink-kpi">
          <div class="monthly-kpi-title">CardLink 帳務清算核心主機</div>
          <div class="monthly-kpi-value" id="b04-cl-time-val">-<em>AM</em></div>
          <div class="monthly-growth" id="b04-cl-growth">
            <span class="number-neutral" id="b04-cl-punc-tag"><b>批次準點率</b>-%</span><span class="number-neutral" id="b04-cl-early-tag"><b>提前</b>- 分鐘</span>
          </div>
          <div class="monthly-split">
            
            <div class="split-item" tabindex="0">
              <span>排程窗口上限</span>
              <strong id="b04-cl-limit-val">-<em>AM</em></strong>
              <b class="number-neutral" id="b04-cl-limit-tag">-</b>
              <div class="split-tooltip" id="b04-cl-limit-tt">
                <strong>清算作業窗口</strong>
                <span>排程上限：- AM</span><span>平均完成：- AM</span><span>裕度時間：- 分鐘</span>
              </div>
            </div>
            <div class="split-item" tabindex="0">
              <span>日均處理帳單</span>
              <strong id="b04-cl-acc-val">-<em>萬戶</em></strong>
              <b class="number-neutral" id="b04-cl-acc-tag">平帳 -%</b>
              <div class="split-tooltip" id="b04-cl-acc-tt">
                <strong>日均結帳量</strong>
                <span>帳單戶數：- 萬戶/日</span><span>平帳率：-%</span><span>批次作業 -</span>
              </div>
            </div>
          </div>
        </article>
        <article class="monthly-kpi monthly-primary" id="sys-fraud-kpi">
          <div class="monthly-kpi-title">全行防詐防堵總成效</div>
          <div class="monthly-kpi-value" id="b04-fr-amt-val">-<em>萬元</em></div>
          <div class="monthly-growth" id="b04-fr-growth">
            <span class="number-neutral" id="b04-fr-cnt-tag"><b>防堵總卡數</b>- 張</span>
          </div>
          <div class="monthly-split">
            
            <div class="split-item" tabindex="0">
              <span>SFM 系統防堵</span>
              <strong id="b04-fr-sfm-amt">-<em>萬元</em></strong>
              <b class="number-neutral" id="b04-fr-sfm-cnt">- 張</b>
              <div class="split-tooltip" id="b04-fr-sfm-tt">
                <strong>智慧偵測 SFM 系統</strong>
                <span>防堵金額：- 萬元（-%）</span><span>• 申請詐欺：- 萬 ｜ - 張</span><span>• 交易詐欺：- 萬 ｜ - 張</span>
              </div>
            </div>
            <div class="split-item" tabindex="0">
              <span>3DS 系統防堵</span>
              <strong id="b04-fr-tds-amt">-<em>萬元</em></strong>
              <b class="number-neutral" id="b04-fr-tds-cnt">- 張</b>
              <div class="split-tooltip" id="b04-fr-tds-tt">
                <strong>線上交易 3DS 驗證</strong>
                <span>防堵金額：- 萬元（-%）</span><span>防堵卡數：- 張</span><span>OTP 異常攔阻率：-%</span>
              </div>
            </div>
          </div>
        </article>
      </div>'''

assert old_b04_primary in content, "old_b04_primary not found in content!"
content = content.replace(old_b04_primary, new_b04_primary)

# 12. Section 04 Tab 0: Stress Events Table
old_b04_events = '''              <tbody id="b04-events-table-body">
                
                <tr>
                  <td><strong>2026/06/18</strong> ｜ 年中大促 618</td>
                  <td>00:00–01:00</td>
                  <td>32 vCPU / 128GB (36 實例)</td>
                  <td><strong style="color:var(--orange-dark);">3,850 TPS</strong></td>
                  <td><strong class="is-good">54%</strong></td>
                  <td>平穩運行，延遲 < 80ms</td>
                </tr>
                <tr>
                  <td><strong>2026/08/08</strong> ｜ 父親節檔期</td>
                  <td>12:30–13:30</td>
                  <td>32 vCPU / 128GB (24 實例)</td>
                  <td><strong style="color:var(--orange-dark);">2,420 TPS</strong></td>
                  <td><strong class="is-good">38%</strong></td>
                  <td>平穩運行，處於常態健康區</td>
                </tr>
                <tr>
                  <td><strong>2026/10/24</strong> ｜ 百貨週年慶首週末</td>
                  <td>14:30–16:30</td>
                  <td>48 vCPU / 192GB (48 實例)</td>
                  <td><strong style="color:var(--orange-dark);">4,180 TPS</strong></td>
                  <td><strong class="is-good">62%</strong></td>
                  <td>平穩運行，實體與掃碼無延滯</td>
                </tr>
                <tr>
                  <td><strong>2026/11/11</strong> ｜ 雙11電商零點狂歡</td>
                  <td>00:00–00:30</td>
                  <td>64 vCPU / 256GB (72 實例)</td>
                  <td><strong style="color:var(--orange-dark);">5,420 TPS</strong></td>
                  <td><strong class="is-good">68%</strong></td>
                  <td>年度最高峰順暢通過，零中斷</td>
                </tr>
                <tr>
                  <td><strong>2026/12/12</strong> ｜ 雙12年終購物節</td>
                  <td>20:00–22:00</td>
                  <td>48 vCPU / 192GB (48 實例)</td>
                  <td><strong style="color:var(--orange-dark);">3,960 TPS</strong></td>
                  <td><strong class="is-good">58%</strong></td>
                  <td>平穩運行，延遲 < 82ms</td>
                </tr>
              </tbody>'''

new_b04_events = '''              <tbody id="b04-events-table-body">
                <tr>
                  <td><strong>-</strong> ｜ -</td>
                  <td>-</td>
                  <td>- (-)</td>
                  <td><strong style="color:var(--orange-dark);">- TPS</strong></td>
                  <td><strong class="is-good">-%</strong></td>
                  <td>-</td>
                </tr>
              </tbody>'''

assert old_b04_events in content, "old_b04_events not found in content!"
content = content.replace(old_b04_events, new_b04_events)

# 13. Section 04 Tab 1: Fraud Table
old_b04_fraud_table = '''              <tbody id="b04-fraud-table-body">
                <tr>
                  <td><strong>SFM 交易詐欺防堵</strong></td>
                  <td><strong>1,222 張</strong></td>
                  <td><strong style="color:var(--ink);">2,270 萬元</strong></td>
                  <td><strong>1.86 萬元 / 張</strong></td>
                  <td><strong>53.0%</strong></td>
                </tr>
                <tr>
                  <td><strong>SFM 申請詐欺防堵</strong></td>
                  <td><strong>842 張</strong></td>
                  <td><strong style="color:var(--ink);">1,150 萬元</strong></td>
                  <td><strong>1.37 萬元 / 張</strong></td>
                  <td><strong>26.9%</strong></td>
                </tr>
                <tr>
                  <td><strong>3DS 系統防堵</strong></td>
                  <td><strong>620 張</strong></td>
                  <td><strong style="color:var(--ink);">860 萬元</strong></td>
                  <td><strong>1.39 萬元 / 張</strong></td>
                  <td><strong>20.1%</strong></td>
                </tr>
                
                <tr style="background:#f0f7f5; font-weight:700;">
                  <td><strong>全行防詐防堵合計</strong></td>
                  <td><strong style="color:var(--orange-dark);">2,684 張</strong></td>
                  <td><strong style="color:var(--orange-dark);">4,280 萬元</strong></td>
                  <td><strong>1.59 萬元 / 張</strong></td>
                  <td><strong>100.0%</strong></td>
                </tr>
              </tbody>'''

new_b04_fraud_table = '''              <tbody id="b04-fraud-table-body">
                <tr>
                  <td><strong>SFM 交易詐欺防堵</strong></td>
                  <td><strong>- 張</strong></td>
                  <td><strong style="color:var(--ink);">- 萬元</strong></td>
                  <td><strong>- 萬元 / 張</strong></td>
                  <td><strong>-%</strong></td>
                </tr>
                <tr>
                  <td><strong>SFM 申請詐欺防堵</strong></td>
                  <td><strong>- 張</strong></td>
                  <td><strong style="color:var(--ink);">- 萬元</strong></td>
                  <td><strong>- 萬元 / 張</strong></td>
                  <td><strong>-%</strong></td>
                </tr>
                <tr>
                  <td><strong>3DS 系統防堵</strong></td>
                  <td><strong>- 張</strong></td>
                  <td><strong style="color:var(--ink);">- 萬元</strong></td>
                  <td><strong>- 萬元 / 張</strong></td>
                  <td><strong>-%</strong></td>
                </tr>
                
                <tr style="background:#f0f7f5; font-weight:700;">
                  <td><strong>全行防詐防堵合計</strong></td>
                  <td><strong style="color:var(--orange-dark);">- 張</strong></td>
                  <td><strong style="color:var(--orange-dark);">- 萬元</strong></td>
                  <td><strong>- 萬元 / 張</strong></td>
                  <td><strong>-%</strong></td>
                </tr>
              </tbody>'''

assert old_b04_fraud_table in content, "old_b04_fraud_table not found in content!"
content = content.replace(old_b04_fraud_table, new_b04_fraud_table)

# 14. Section 04 Tab 1: Fraud SVG
old_b04_fraud_svg = '''                <!-- Bar 1: SFM 交易詐欺防堵 (6,155萬, 5,434張, 64.9%) -->
                <rect x="145" y="96.9" width="80" height="123.1" rx="6" fill="#003b5c"/>
                <rect x="125" y="86.0" width="120" height="24" rx="4" fill="#eef6ff" stroke="#bddbff"/>
                <text x="185" y="102.0" font-size="11" font-weight="900" fill="#003b5c" text-anchor="middle">防堵：6,155 萬元</text>
                <text x="185" y="240" font-size="13" font-weight="900" fill="#12344d" text-anchor="middle">SFM 交易詐欺防堵</text>
                <text x="185" y="256" font-size="10" fill="#667a76" text-anchor="middle">佔 64.9%</text>

                <!-- Bar 2: SFM 申請詐欺防堵 (3,070萬, 195張, 32.4%) -->
                <rect x="340" y="158.6" width="80" height="61.4" rx="6" fill="#2d6a8f"/>
                <rect x="320" y="128.6" width="120" height="24" rx="4" fill="#eef6ff" stroke="#bddbff"/>
                <text x="380" y="144.6" font-size="11" font-weight="900" fill="#003b5c" text-anchor="middle">防堵：3,070 萬元</text>
                <text x="380" y="240" font-size="13" font-weight="900" fill="#12344d" text-anchor="middle">SFM 申請詐欺防堵</text>
                <text x="380" y="256" font-size="10" fill="#667a76" text-anchor="middle">佔 32.4%</text>

                <!-- Bar 3: 3DS 系統防堵 (257萬, 229張, 2.7%) -->
                <rect x="535" y="214.9" width="80" height="5.1" rx="2" fill="#588ea8"/>
                <rect x="515" y="186.0" width="120" height="24" rx="4" fill="#eef6ff" stroke="#bddbff"/>
                <text x="575" y="202.0" font-size="11" font-weight="900" fill="#003b5c" text-anchor="middle">防堵：257 萬元</text>
                <text x="575" y="240" font-size="13" font-weight="900" fill="#12344d" text-anchor="middle">3DS 系統防堵</text>
                <text x="575" y="256" font-size="10" fill="#667a76" text-anchor="middle">佔 2.7%</text>

                <!-- Connected Green Polyline for 卡數 -->
                <polyline points="185,75.1 380,214.8 575,213.9" fill="none" stroke="#009e73" stroke-width="2.5" stroke-dasharray="4 3"/>
                
                <circle cx="185" cy="75.1" r="5.5" fill="#009e73" stroke="#ffffff" stroke-width="2.5"/>
                <rect x="150" y="48.0" width="70" height="18" rx="3" fill="#007a5e"/>
                <text x="185" y="61.0" font-size="10" font-weight="900" fill="#ffffff" text-anchor="middle">5,434 張</text>

                <circle cx="380" cy="214.8" r="5.5" fill="#009e73" stroke="#ffffff" stroke-width="2.5"/>
                <rect x="345" y="188.0" width="70" height="18" rx="3" fill="#007a5e"/>
                <text x="380" y="201.0" font-size="10" font-weight="900" fill="#ffffff" text-anchor="middle">195 張</text>

                <circle cx="575" cy="213.9" r="5.5" fill="#009e73" stroke="#ffffff" stroke-width="2.5"/>
                <rect x="540" y="162.0" width="70" height="18" rx="3" fill="#007a5e"/>
                <text x="575" y="175.0" font-size="10" font-weight="900" fill="#ffffff" text-anchor="middle">229 張</text>'''

new_b04_fraud_svg = '''                <!-- Bar 1: SFM 交易詐欺防堵 -->
                <rect x="145" y="220" width="80" height="0" rx="6" fill="#003b5c"/>
                <rect x="125" y="86.0" width="120" height="24" rx="4" fill="#eef6ff" stroke="#bddbff"/>
                <text x="185" y="102.0" font-size="11" font-weight="900" fill="#003b5c" text-anchor="middle">防堵：- 萬元</text>
                <text x="185" y="240" font-size="13" font-weight="900" fill="#12344d" text-anchor="middle">SFM 交易詐欺防堵</text>
                <text x="185" y="256" font-size="10" fill="#667a76" text-anchor="middle">佔 -%</text>

                <!-- Bar 2: SFM 申請詐欺防堵 -->
                <rect x="340" y="220" width="80" height="0" rx="6" fill="#2d6a8f"/>
                <rect x="320" y="128.6" width="120" height="24" rx="4" fill="#eef6ff" stroke="#bddbff"/>
                <text x="380" y="144.6" font-size="11" font-weight="900" fill="#003b5c" text-anchor="middle">防堵：- 萬元</text>
                <text x="380" y="240" font-size="13" font-weight="900" fill="#12344d" text-anchor="middle">SFM 申請詐欺防堵</text>
                <text x="380" y="256" font-size="10" fill="#667a76" text-anchor="middle">佔 -%</text>

                <!-- Bar 3: 3DS 系統防堵 -->
                <rect x="535" y="220" width="80" height="0" rx="2" fill="#588ea8"/>
                <rect x="515" y="186.0" width="120" height="24" rx="4" fill="#eef6ff" stroke="#bddbff"/>
                <text x="575" y="202.0" font-size="11" font-weight="900" fill="#003b5c" text-anchor="middle">防堵：- 萬元</text>
                <text x="575" y="240" font-size="13" font-weight="900" fill="#12344d" text-anchor="middle">3DS 系統防堵</text>
                <text x="575" y="256" font-size="10" fill="#667a76" text-anchor="middle">佔 -%</text>

                <!-- Connected Green Polyline for 卡數 -->
                <polyline points="185,220 380,220 575,220" fill="none" stroke="#009e73" stroke-width="2.5" stroke-dasharray="4 3"/>
                
                <circle cx="185" cy="220" r="5.5" fill="#009e73" stroke="#ffffff" stroke-width="2.5"/>
                <rect x="150" y="48.0" width="70" height="18" rx="3" fill="#007a5e"/>
                <text x="185" y="61.0" font-size="10" font-weight="900" fill="#ffffff" text-anchor="middle">- 張</text>

                <circle cx="380" cy="220" r="5.5" fill="#009e73" stroke="#ffffff" stroke-width="2.5"/>
                <rect x="345" y="188.0" width="70" height="18" rx="3" fill="#007a5e"/>
                <text x="380" y="201.0" font-size="10" font-weight="900" fill="#ffffff" text-anchor="middle">- 張</text>

                <circle cx="575" cy="220" r="5.5" fill="#009e73" stroke="#ffffff" stroke-width="2.5"/>
                <rect x="540" y="162.0" width="70" height="18" rx="3" fill="#007a5e"/>
                <text x="575" y="175.0" font-size="10" font-weight="900" fill="#ffffff" text-anchor="middle">- 張</text>'''

assert old_b04_fraud_svg in content, "old_b04_fraud_svg not found in content!"
content = content.replace(old_b04_fraud_svg, new_b04_fraud_svg)

# 15. Section 04 Tab 2: BMS 4 Cards
old_b04_bms_cards = '''          <div class="monthly-kpi-layout-4" style="margin-bottom:14px;">
            
            <article class="monthly-kpi monthly-secondary">
              <div class="monthly-kpi-title" id="b04-ms-c1-title">小樹點查詢服務</div>
              <div class="monthly-kpi-value" id="b04-ms-c1-val">11,516.57<em>萬次</em></div>
              <div class="monthly-growth" id="b04-ms-c1-growth">
                <span class="number-positive" id="b04-ms-c1-yoy"><b>YoY</b>+8.88%</span>
                <span class="number-positive" id="b04-ms-c1-mom"><b>MoM</b>+1.92%</span>
              </div>
            </article>
            <article class="monthly-kpi monthly-secondary">
              <div class="monthly-kpi-title" id="b04-ms-c2-title">回饋總覽查詢服務</div>
              <div class="monthly-kpi-value" id="b04-ms-c2-val">996.37<em>萬次</em></div>
              <div class="monthly-growth" id="b04-ms-c2-growth">
                <span class="number-positive" id="b04-ms-c2-yoy"><b>YoY</b>+3.92%</span>
                <span class="number-negative" id="b04-ms-c2-mom"><b>MoM</b>-0.88%</span>
              </div>
            </article>
            <article class="monthly-kpi monthly-secondary">
              <div class="monthly-kpi-title" id="b04-ms-c3-title">小樹點兌換服務</div>
              <div class="monthly-kpi-value" id="b04-ms-c3-val">210.94<em>萬次</em></div>
              <div class="monthly-growth" id="b04-ms-c3-growth">
                <span class="number-positive" id="b04-ms-c3-yoy"><b>YoY</b>+4.12%</span>
                <span class="number-positive" id="b04-ms-c3-mom"><b>MoM</b>+3.05%</span>
              </div>
            </article>
            <article class="monthly-kpi monthly-secondary">
              <div class="monthly-kpi-title" id="b04-ms-c4-title">票券服務（雲端）</div>
              <div class="monthly-kpi-value" id="b04-ms-c4-val">23.39<em>萬次</em></div>
              <div class="monthly-growth" id="b04-ms-c4-growth">
                <span class="number-positive" id="b04-ms-c4-yoy"><b>YoY</b>-%</span>
                <span class="number-positive" id="b04-ms-c4-mom"><b>MoM</b>+6.32%</span>
              </div>
            </article>
          </div>'''

new_b04_bms_cards = '''          <div class="monthly-kpi-layout-4" style="margin-bottom:14px;">
            
            <article class="monthly-kpi monthly-secondary">
              <div class="monthly-kpi-title" id="b04-ms-c1-title">小樹點查詢服務</div>
              <div class="monthly-kpi-value" id="b04-ms-c1-val">-<em>萬次</em></div>
              <div class="monthly-growth" id="b04-ms-c1-growth">
                <span class="number-neutral" id="b04-ms-c1-yoy"><b>YoY</b>-</span>
                <span class="number-neutral" id="b04-ms-c1-mom"><b>MoM</b>-</span>
              </div>
            </article>
            <article class="monthly-kpi monthly-secondary">
              <div class="monthly-kpi-title" id="b04-ms-c2-title">回饋總覽查詢服務</div>
              <div class="monthly-kpi-value" id="b04-ms-c2-val">-<em>萬次</em></div>
              <div class="monthly-growth" id="b04-ms-c2-growth">
                <span class="number-neutral" id="b04-ms-c2-yoy"><b>YoY</b>-</span>
                <span class="number-neutral" id="b04-ms-c2-mom"><b>MoM</b>-</span>
              </div>
            </article>
            <article class="monthly-kpi monthly-secondary">
              <div class="monthly-kpi-title" id="b04-ms-c3-title">小樹點兌換服務</div>
              <div class="monthly-kpi-value" id="b04-ms-c3-val">-<em>萬次</em></div>
              <div class="monthly-growth" id="b04-ms-c3-growth">
                <span class="number-neutral" id="b04-ms-c3-yoy"><b>YoY</b>-</span>
                <span class="number-neutral" id="b04-ms-c3-mom"><b>MoM</b>-</span>
              </div>
            </article>
            <article class="monthly-kpi monthly-secondary">
              <div class="monthly-kpi-title" id="b04-ms-c4-title">票券服務（雲端）</div>
              <div class="monthly-kpi-value" id="b04-ms-c4-val">-<em>萬次</em></div>
              <div class="monthly-growth" id="b04-ms-c4-growth">
                <span class="number-neutral" id="b04-ms-c4-yoy"><b>YoY</b>-</span>
                <span class="number-neutral" id="b04-ms-c4-mom"><b>MoM</b>-</span>
              </div>
            </article>
          </div>'''

assert old_b04_bms_cards in content, "old_b04_bms_cards not found in content!"
content = content.replace(old_b04_bms_cards, new_b04_bms_cards)

# 16. Section 04 Tab 2: BMS SVG YoY text labels
content = content.replace('<text x="111" y="43.6" font-size="9.5" font-weight="900" fill="#007a5e" text-anchor="middle">YoY +8.88%</text>',
                          '<text x="111" y="43.6" font-size="9.5" font-weight="900" fill="#007a5e" text-anchor="middle">YoY -</text>')
content = content.replace('<text x="266" y="42.4" font-size="9.5" font-weight="900" fill="#007a5e" text-anchor="middle">YoY +3.92%</text>',
                          '<text x="266" y="42.4" font-size="9.5" font-weight="900" fill="#007a5e" text-anchor="middle">YoY -</text>')
content = content.replace('<text x="381" y="147.1" font-size="9.5" font-weight="900" fill="#007a5e" text-anchor="middle">YoY +4.12%</text>',
                          '<text x="381" y="147.1" font-size="9.5" font-weight="900" fill="#007a5e" text-anchor="middle">YoY -</text>')

# 17. Section 04 Tab 2: TPS Rank list
old_b04_tps = '''              <div id="b04-tps-rank-list">
              <div class="tps-rank-item">
                <div class="tps-rank-labels">
                  <span><strong>1. 小樹點查詢</strong></span>
                  <b>1,850 TPS <small style="color:var(--muted); font-weight:normal;">/ 2,500 容量</small></b>
                </div>
                <div class="tps-bar-track">
                  <div class="tps-bar-fill" style="width: 74%; background: linear-gradient(90deg, #009e73, #007a5e);"></div>
                </div>
              </div>
              <div class="tps-rank-item">
                <div class="tps-rank-labels">
                  <span><strong>2. 回饋總覽</strong></span>
                  <b>1,320 TPS <small style="color:var(--muted); font-weight:normal;">/ 2,000 容量</small></b>
                </div>
                <div class="tps-bar-track">
                  <div class="tps-bar-fill" style="width: 66%; background: linear-gradient(90deg, #003b5c, #002b49);"></div>
                </div>
              </div>
              <div class="tps-rank-item">
                <div class="tps-rank-labels">
                  <span><strong>3. 小樹點兌換</strong></span>
                  <b>620 TPS <small style="color:var(--muted); font-weight:normal;">/ 1,200 容量</small></b>
                </div>
                <div class="tps-bar-track">
                  <div class="tps-bar-fill" style="width: 51.6%; background: linear-gradient(90deg, #c9892e, #a46d1b);"></div>
                </div>
              </div>
              <div class="tps-rank-item" style="margin-bottom:0;">
                <div class="tps-rank-labels">
                  <span><strong>4. 票券服務</strong></span>
                  <b>380 TPS <small style="color:var(--muted); font-weight:normal;">/ 800 容量</small></b>
                </div>
                <div class="tps-bar-track">
                  <div class="tps-bar-fill" style="width: 47.5%; background: linear-gradient(90deg, #7c4dff, #5e35b1);"></div>
                </div>
              </div>
              </div>'''

new_b04_tps = '''              <div id="b04-tps-rank-list">
              <div class="tps-rank-item">
                <div class="tps-rank-labels">
                  <span><strong>1. 小樹點查詢</strong></span>
                  <b>- TPS <small style="color:var(--muted); font-weight:normal;">/ - 容量</small></b>
                </div>
                <div class="tps-bar-track">
                  <div class="tps-bar-fill" style="width: 0%; background: linear-gradient(90deg, #009e73, #007a5e);"></div>
                </div>
              </div>
              <div class="tps-rank-item">
                <div class="tps-rank-labels">
                  <span><strong>2. 回饋總覽</strong></span>
                  <b>- TPS <small style="color:var(--muted); font-weight:normal;">/ - 容量</small></b>
                </div>
                <div class="tps-bar-track">
                  <div class="tps-bar-fill" style="width: 0%; background: linear-gradient(90deg, #003b5c, #002b49);"></div>
                </div>
              </div>
              <div class="tps-rank-item">
                <div class="tps-rank-labels">
                  <span><strong>3. 小樹點兌換</strong></span>
                  <b>- TPS <small style="color:var(--muted); font-weight:normal;">/ - 容量</small></b>
                </div>
                <div class="tps-bar-track">
                  <div class="tps-bar-fill" style="width: 0%; background: linear-gradient(90deg, #c9892e, #a46d1b);"></div>
                </div>
              </div>
              <div class="tps-rank-item" style="margin-bottom:0;">
                <div class="tps-rank-labels">
                  <span><strong>4. 票券服務</strong></span>
                  <b>- TPS <small style="color:var(--muted); font-weight:normal;">/ - 容量</small></b>
                </div>
                <div class="tps-bar-track">
                  <div class="tps-bar-fill" style="width: 0%; background: linear-gradient(90deg, #7c4dff, #5e35b1);"></div>
                </div>
              </div>
              </div>'''

assert old_b04_tps in content, "old_b04_tps not found in content!"
content = content.replace(old_b04_tps, new_b04_tps)

with open(HTML_PATH, "w", encoding="utf-8") as f:
    f.write(content)

print("SUCCESS: All mock blocks in credit_card_full_dashboard.html have been purged!")
