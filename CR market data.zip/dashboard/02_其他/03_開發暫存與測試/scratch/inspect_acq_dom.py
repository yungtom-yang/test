import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('01_儀表板執行環境/credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print("=== Lines 3050 to 3180 ===")
for i in range(3049, min(3180, len(lines))):
    print(f"{i+1}: {lines[i].rstrip()}")
