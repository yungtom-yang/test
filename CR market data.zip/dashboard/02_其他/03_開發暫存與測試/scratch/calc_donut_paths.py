import math

peers = [
    {'name': '中國信託', 'share': 25.0, 'amount': 5980, 'color': '#003b5c'},
    {'name': '國泰世華', 'share': 23.9, 'amount': 5726, 'color': '#009e73'},
    {'name': '台北富邦', 'share': 18.6, 'amount': 4450, 'color': '#2563eb'},
    {'name': '玉山銀行', 'share': 18.0, 'amount': 4320, 'color': '#059669'},
    {'name': '台新銀行', 'share': 14.5, 'amount': 3480, 'color': '#ea580c'},
]

cumulative_angle = 0
r_out = 52
r_in = 32
cx, cy = 60, 60

for p in peers:
    slice_angle = (p['share'] / 100.0) * 360.0
    start_angle = cumulative_angle
    end_angle = cumulative_angle + slice_angle
    cumulative_angle = end_angle

    start_rad = math.radians(start_angle - 90)
    end_rad = math.radians(end_angle - 90)

    x1 = cx + r_out * math.cos(start_rad)
    y1 = cy + r_out * math.sin(start_rad)
    x2 = cx + r_out * math.cos(end_rad)
    y2 = cy + r_out * math.sin(end_rad)

    x3 = cx + r_in * math.cos(end_rad)
    y3 = cy + r_in * math.sin(end_rad)
    x4 = cx + r_in * math.cos(start_rad)
    y4 = cy + r_in * math.sin(start_rad)

    large_arc = 1 if slice_angle > 180 else 0
    path_data = f'M {x1:.2f} {y1:.2f} A {r_out} {r_out} 0 {large_arc} 1 {x2:.2f} {y2:.2f} L {x3:.2f} {y3:.2f} A {r_in} {r_in} 0 {large_arc} 0 {x4:.2f} {y4:.2f} Z'
    print(f'                  <path class="cockpit-donut-slice" d="{path_data}" fill="{p["color"]}" stroke="#ffffff" stroke-width="1.5"><title>{p["name"]}: {p["share"]}% ({p["amount"]:,}億)</title></path>')
