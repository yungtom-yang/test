# -*- coding: utf-8 -*-
"""
Helper script to compile all dashboard data into a unified, cleanly-structured dashboard_data.json.
Integrates peer_data.json and all data points across Blocks 01 to 04 with 100% precision.
"""
import json
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PEER_JSON = os.path.join(BASE_DIR, "scratch", "peer_data.json")
OUTPUT_JSON = os.path.join(BASE_DIR, "scratch", "dashboard_data.json")

# Load existing peer competition data
with open(PEER_JSON, "r", encoding="utf-8") as f:
    peer_data = json.load(f)

dashboard_data = {
    "meta": {
        "title": "國泰世華銀行 信用卡營運整合數據儀表板",
        "brand": "國泰世華",
        "header_title": "信用卡數據儀表板",
        "year": "2026",
        "month": "08",
        "period_label": "營運月報"
    },

    "block01_overview": {
        "section_id": "section-overview",
        "section_num": "01",
        "section_title": "信用卡整體經營概況",
        "subtitle": "2026/08 經營月報 ｜ 全行核心營運指標與同業競爭態勢",
        "kpis": [
            {
                "id": "b1_total_amount",
                "title": "總交易金額",
                "value": "1,286.4",
                "unit": "億元",
                "yoy": "+12.8%",
                "mom": "+2.1%",
                "splits": [
                    {
                        "label": "一般交易",
                        "value": "1,086.4",
                        "unit": "億",
                        "badge": "佔比 84.4%",
                        "tooltip": {
                            "title": "一般交易金額",
                            "lines": [
                                "金額：1,086.4 億元（84.4%）",
                                "YoY：+10.5%",
                                "MoM：+1.4%",
                                "平均客單：$1,402"
                            ]
                        }
                    },
                    {
                        "label": "分期交易",
                        "value": "200.0",
                        "unit": "億",
                        "badge": "佔比 15.6%",
                        "tooltip": {
                            "title": "分期交易金額",
                            "lines": [
                                "金額：200.0 億元（15.6%）",
                                "YoY：+27.3%",
                                "MoM：+8.7%",
                                "平均客單：$29,630"
                            ]
                        }
                    }
                ],
                "footer": "分期交易滲透率：15.6%（年增 +1.8pp）"
            },
            {
                "id": "b1_total_count",
                "title": "總交易筆數",
                "value": "8,425",
                "unit": "萬筆",
                "yoy": "+15.2%",
                "mom": "+1.7%",
                "splits": [
                    {
                        "label": "一般交易",
                        "value": "7,750",
                        "unit": "萬筆",
                        "badge": "佔比 92.0%",
                        "tooltip": {
                            "title": "一般交易筆數",
                            "lines": [
                                "筆數：7,750 萬筆（92.0%）",
                                "YoY：+14.1%",
                                "MoM：+1.2%"
                            ]
                        }
                    },
                    {
                        "label": "分期交易",
                        "value": "675",
                        "unit": "萬筆",
                        "badge": "佔比 8.0%",
                        "tooltip": {
                            "title": "分期交易筆數",
                            "lines": [
                                "筆數：675 萬筆（8.0%）",
                                "YoY：+29.8%",
                                "MoM：+7.9%"
                            ]
                        }
                    }
                ],
                "footer": "分期筆數滲透率：8.0%（高頻小額日常帶動）"
            },
            {
                "id": "b1_cash_advance",
                "title": "預借現金金額",
                "value": "18.6",
                "unit": "億元",
                "yoy": "-3.4%",
                "mom": "-0.8%",
                "is_positive_yoy": False,
                "is_positive_mom": False,
                "note": "信貸業務流動性監控",
                "note_title": "預借現金筆數：42.8 萬筆 ｜ 平均單筆：$43,458"
            },
            {
                "id": "b1_revolving_balance",
                "title": "循環信用餘額",
                "value": "325.7",
                "unit": "億元",
                "yoy": "+6.7%",
                "mom": "+0.9%",
                "is_positive_yoy": True,
                "is_positive_mom": True,
                "note": "生息資產規模",
                "note_title": "循環息收穩定貢獻 ｜ 逾放比 1.12%"
            }
        ],
        "peer_comparison": peer_data,
        "insights": [
            { "label": "簽帳金額市場排名", "value": "第二名", "note": "市佔率 18.6% (YTD 5,726 億)" },
            { "label": "有效卡數市場排名", "value": "第二名", "note": "動卡率 86.4% (有效 741 萬卡)" },
            { "label": "流通卡數市場排名", "value": "第二名", "note": "市場佔有 15.8% (流通 858 萬卡)" },
            { "label": "循環信用額市場排名", "value": "第二名", "note": "生息資產市佔 26.6% (餘額 326 億)" }
        ]
    },

    "block02_acquiring": {
        "section_id": "section-acquiring",
        "section_num": "02",
        "section_title": "收單業務",
        "subtitle": "2026/08 經營月報 ｜ 自行收單特店、多元管道與 TWQR 拓點動能",
        "kpis_primary": [
            {
                "title": "自行收單交易金額",
                "value": "285.0",
                "unit": "億元",
                "yoy": "+12.8%",
                "mom": "+2.1%",
                "splits": [
                    {
                        "label": "實體收單",
                        "value": "185.0",
                        "unit": "億",
                        "badge": "佔比 65.0%",
                        "tooltip": {
                            "title": "實體特店收單",
                            "lines": ["金額：185.0 億元", "YoY：+8.5%", "實體佔比：65.0%"]
                        }
                    },
                    {
                        "label": "線上 EPOS",
                        "value": "100.0",
                        "unit": "億",
                        "badge": "佔比 35.0%",
                        "tooltip": {
                            "title": "線上 EPOS 收單",
                            "lines": ["金額：100.0 億元", "YoY：+21.8%", "線上佔比：35.0%"]
                        }
                    }
                ],
                "footer": "平均每筆客單：1,540 元（+1.2%）"
            },
            {
                "title": "自行收單交易筆數",
                "value": "1,850",
                "unit": "萬筆",
                "yoy": "+15.2%",
                "mom": "+1.8%",
                "splits": [
                    {
                        "label": "實體收單",
                        "value": "1,295",
                        "unit": "萬筆",
                        "badge": "佔比 70.0%",
                        "tooltip": {
                            "title": "實體特店筆數",
                            "lines": ["筆數：1,295 萬筆", "YoY：+11.0%", "實體佔比：70.0%"]
                        }
                    },
                    {
                        "label": "線上 EPOS",
                        "value": "555",
                        "unit": "萬筆",
                        "badge": "佔比 30.0%",
                        "tooltip": {
                            "title": "線上 EPOS 筆數",
                            "lines": ["筆數：555 萬筆", "YoY：+26.2%", "線上佔比：30.0%"]
                        }
                    }
                ],
                "footer": "掃碼高頻帶動筆數成長優於金額"
            },
            {
                "title": "收單特店總數",
                "value": "48,500",
                "unit": "家",
                "yoy": "+8.5%",
                "mom": "+0.7%",
                "splits": [
                    {
                        "label": "實體特店",
                        "value": "38,800",
                        "unit": "家",
                        "badge": "佔比 80.0%",
                        "tooltip": {
                            "title": "實體特店數",
                            "lines": ["店家：38,800 家", "實體佔比：80.0%"]
                        }
                    },
                    {
                        "label": "線上特店",
                        "value": "9,700",
                        "unit": "家",
                        "badge": "佔比 20.0%",
                        "tooltip": {
                            "title": "線上特店數",
                            "lines": ["店家：9,700 家", "線上佔比：20.0%"]
                        }
                    }
                ],
                "footer": "店均交易金額：58.8 萬元（+4.0%）"
            }
        ],
        "kpis_secondary": [
            {
                "title": "自行收單滲透率",
                "value": "24.5%",
                "badges": [
                    { "type": "positive", "prefix": "YoY", "text": "+1.8pp" },
                    { "type": "positive", "prefix": "MoM", "text": "+0.3pp" }
                ],
                "note": "自行收單一般交易 ÷ 全行一般交易",
                "note_title": "跨售動能強勁"
            },
            {
                "title": "活躍自行特店數",
                "value": "40,250",
                "unit": "家",
                "badges": [
                    { "type": "positive", "prefix": "YoY", "text": "+6.2%" },
                    { "type": "positive", "prefix": "活店率", "text": "83.0%" }
                ],
                "note": "當月有實質請款交易之特店",
                "note_title": "動用率維持 83% 以上高檔"
            },
            {
                "title": "電子對帳單覆蓋率",
                "value": "92.4%",
                "badges": [
                    { "type": "positive", "prefix": "寄送", "text": "99.8%" },
                    { "type": "positive", "prefix": "覆蓋", "text": "44,800 家" }
                ],
                "note": "電子對帳單服務比例，運營降本",
                "note_title": "無紙化綠色營運達標"
            },
            {
                "title": "收單手續費收入",
                "value": "4.52",
                "unit": "億元",
                "badges": [
                    { "type": "positive", "prefix": "YoY", "text": "+11.5%" },
                    { "type": "positive", "prefix": "Net MDR", "text": "1.58%" }
                ],
                "note": "扣除通路成本後實質淨手續費",
                "note_title": "實質淨收入持續雙位數成長"
            }
        ],
        "tab1_channel": {
            "title": "交易型態分布診斷 (雲地端結構)",
            "structure_bars": [
                { "label": "EPOS 雲端", "amount": "69.1 億", "pct": "58.3%", "color": "var(--blue)" },
                { "label": "EPOS 地端", "amount": "30.9 億", "pct": "26.1%", "color": "var(--blue-light)" },
                { "label": "掃碼 PH", "amount": "18.5 億", "pct": "15.6%", "color": "var(--orange)" }
            ],
            "rows": [
                {
                    "channel": "EPOS 雲端",
                    "amount": "69.1 億元",
                    "amount_share": "58.3%",
                    "tx_count": "345 萬筆",
                    "count_share": "43.4%",
                    "yoy_amount": "+32.5%",
                    "yoy_count": "+35.1%",
                    "avg_ticket": "2,002 元",
                    "note": "線上主力大額，高成長引擎"
                },
                {
                    "channel": "EPOS 地端",
                    "amount": "30.9 億元",
                    "amount_share": "26.1%",
                    "tx_count": "210 萬筆",
                    "count_share": "26.4%",
                    "yoy_amount": "-4.2%",
                    "yoy_count": "-1.8%",
                    "avg_ticket": "1,471 元",
                    "note": "既有大型百貨量販架構"
                },
                {
                    "channel": "掃碼 PH",
                    "amount": "18.5 億元",
                    "amount_share": "15.6%",
                    "tx_count": "240 萬筆",
                    "count_share": "30.2%",
                    "yoy_amount": "+38.2%",
                    "yoy_count": "+42.0%",
                    "avg_ticket": "770 元",
                    "note": "高頻小額日常餐飲交通場景"
                }
            ],
            "insights": [
                { "label": "EPOS 雲端化比例", "value": "62.8%", "note": "YoY +15.4pp" },
                { "label": "掃碼 (PH) 筆數佔比", "value": "13.0%", "note": "YoY +2.8pp" },
                { "label": "線上平均客單", "value": "2,002 元", "note": "電商主力大額" },
                { "label": "掃碼平均客單", "value": "770 元", "note": "小額高頻造血" }
            ]
        },
        "tab2_merchants": {
            "title": "特店集中度與 2x2 矩陣",
            "top_merchants": [
                { "name": "特店 A（量販巨頭）", "amount": "35.6 億", "yoy": "+18.2%", "status": "is-good" },
                { "name": "特店 B（綜合電商）", "amount": "26.2 億", "yoy": "+25.4%", "status": "is-good" },
                { "name": "特店 C（百貨生活）", "amount": "23.9 億", "yoy": "+1.2%", "status": "is-good" },
                { "name": "特店 D（連鎖超商）", "amount": "17.4 億", "yoy": "−3.5%", "status": "is-warn" },
                { "name": "特店 E（連鎖餐飲）", "amount": "14.3 億", "yoy": "+32.0%", "status": "is-good" }
            ],
            "quadrants": {
                "q1": { "name": "潛力開發區", "desc": "高成長、低佔比", "items": "品牌服飾、3C連鎖" },
                "q2": { "name": "核心成長區", "desc": "高成長、高佔比", "items": "量販、電商" },
                "q3": { "name": "一般維護區", "desc": "低成長、低佔比", "items": "中小型長尾特店" },
                "q4": { "name": "重點維繫區 ⚠", "desc": "低成長、高佔比", "items": "超商、連鎖餐飲" }
            },
            "insights": [
                { "label": "Top 10 特店請款佔比", "value": "48.2%", "note": "YoY +1.5pp" },
                { "label": "大型特店依賴度", "value": "高度維繫", "note": "需持續深化專案" },
                { "label": "超商警示特店 D", "value": "−3.5%", "note": "受競業分流影響" },
                { "label": "餐飲龍頭特店 E", "value": "+32.0%", "note": "掃碼與聯名卡加持" }
            ]
        },
        "tab3_mcc": {
            "title": "產業 MCC 結構分布",
            "industries": [
                { "name": "量販超市", "merchants": "1,920 家", "merchant_share": "4.0%", "amount": "74.1 億元", "amount_share": "26.0%", "avg_store_rev": "385.9 萬元" },
                { "name": "綜合電商", "merchants": "850 家", "merchant_share": "1.8%", "amount": "59.8 億元", "amount_share": "21.0%", "avg_store_rev": "703.5 萬元" },
                { "name": "百貨生活", "merchants": "4,850 家", "merchant_share": "10.0%", "amount": "43.9 億元", "amount_share": "15.4%", "avg_store_rev": "90.5 萬元" },
                { "name": "餐飲美食", "merchants": "18,500 家", "merchant_share": "38.1%", "amount": "31.4 億元", "amount_share": "11.0%", "avg_store_rev": "17.0 萬元" },
                { "name": "交通旅遊", "merchants": "2,400 家", "merchant_share": "4.9%", "amount": "22.8 億元", "amount_share": "8.0%", "avg_store_rev": "95.0 萬元" },
                { "name": "其他各業", "merchants": "19,980 家", "merchant_share": "41.2%", "amount": "53.0 億元", "amount_share": "18.6%", "avg_store_rev": "26.5 萬元" }
            ],
            "total": { "name": "全行合計", "merchants": "48,500 家", "merchant_share": "100.0%", "amount": "285.0 億元", "amount_share": "100.0%", "avg_store_rev": "58.8 萬元" },
            "insights": [
                { "label": "前三大產業金額佔比", "value": "62.4%", "note": "量販、電商、百貨合計" },
                { "label": "最高產能產業", "value": "綜合電商", "note": "店均請款 703.5 萬元" },
                { "label": "最大長尾店家", "value": "餐飲美食", "note": "18,500 家，佔比特店數 38.1%" },
                { "label": "交通旅遊成長", "value": "+28.5%", "note": "暑期出遊旺季挹注" }
            ]
        },
        "twqr": {
            "title": "TWQR 業務推展與交易動能",
            "subtitle": "國家級共同掃碼標準拓展 Pipeline 與動用動能追蹤。",
            "tags": "進件審查 ｜ 動用商家 ｜ 客單分析",
            "section1": {
                "title": "特店進件分析",
                "sub": "拓展 Pipeline",
                "items": [
                    { "label": "當月申請進件數", "value": "3,850 件", "badge": "審查通過率 91.2%", "is_good": False },
                    { "label": "累計特店家數", "value": "22,100 家", "badge": "MoM +5.8%（+1,210 家）", "is_good": True }
                ]
            },
            "section2": {
                "title": "交易狀態分析",
                "sub": "交易造血動能",
                "items": [
                    { "label": "當月交易金額", "value": "12.8 億", "badge": "MoM +18.5%", "is_good": True },
                    { "label": "當月交易筆數", "value": "185 萬筆", "badge": "MoM +22.1%", "is_good": True },
                    { "label": "平均每筆客單", "value": "692 元", "badge": "小額高頻日常場景", "is_good": False },
                    { "label": "店均交易金額", "value": "5.79 萬元", "badge": "動用特店比率 78.5%", "is_good": False }
                ]
            },
            "insights": [
                { "label": "當月核准特店", "value": "3,511 家", "note": "審查通過率 91.2%" },
                { "label": "動用特店比率", "value": "78.5%", "note": "實際產生交易店家" },
                { "label": "筆數月增動能", "value": "+22.1%", "note": "小額掃碼高黏著" }
            ]
        }
    },

    "block03_issuing": {
        "section_id": "section-issuing",
        "section_num": "03",
        "section_title": "發卡業務",
        "subtitle": "2026/08 經營月報 ｜ 申辦進件中樞、三大分期雙軸、小樹點水庫與催收資產品質",
        "kpis_primary": [
            {
                "title": "申辦進件總量",
                "value": "85,400",
                "unit": "件",
                "yoy": "+22.4%",
                "mom": "+5.1%",
                "splits": [
                    {
                        "label": "數位進件",
                        "value": "74,300",
                        "unit": "件",
                        "badge": "佔比 87%",
                        "tooltip": {
                            "title": "數位進件管道",
                            "lines": ["進件：74,300 件", "YoY：+27.8%", "數位佔比：87.0%"]
                        }
                    },
                    {
                        "label": "實體進件",
                        "value": "11,100",
                        "unit": "件",
                        "badge": "佔比 13%",
                        "tooltip": {
                            "title": "分行與實體進件",
                            "lines": ["進件：11,100 件", "佔比：13.0%"]
                        }
                    }
                ],
                "footer": "數位進件率：87.0%（YoY +4.2pp）"
            },
            {
                "title": "授權交易總數（雙卡）",
                "value": "6,820",
                "unit": "萬筆",
                "yoy": "+14.8%",
                "mom": "+2.2%",
                "splits": [
                    {
                        "label": "信用卡",
                        "value": "5,250",
                        "unit": "萬筆",
                        "badge": "佔比 77%",
                        "tooltip": {
                            "title": "信用卡授權筆數",
                            "lines": ["筆數：5,250 萬筆", "佔比：77.0%"]
                        }
                    },
                    {
                        "label": "簽帳卡",
                        "value": "1,570",
                        "unit": "萬筆",
                        "badge": "佔比 23%",
                        "tooltip": {
                            "title": "簽帳金融卡筆數",
                            "lines": ["筆數：1,570 萬筆", "佔比：23.0%"]
                        }
                    }
                ],
                "footer": "全行授權成功率：98.8%"
            },
            {
                "title": "分期交易總額",
                "value": "200.0",
                "unit": "億元",
                "yoy": "+27.3%",
                "mom": "+8.7%",
                "splits": [
                    {
                        "label": "單筆分期",
                        "value": "164.0",
                        "unit": "億",
                        "badge": "佔比 82.0%",
                        "tooltip": {
                            "title": "單筆分期（授權＋請款）",
                            "lines": [
                                "合計金額：164.0 億元（82.0%）",
                                "合計筆數：505 萬筆",
                                "• 授權單筆：110.0 億 ｜ 285 萬筆",
                                "• 請款單筆：54.0 億 ｜ 220 萬筆"
                            ]
                        }
                    },
                    {
                        "label": "帳單分期",
                        "value": "36.0",
                        "unit": "億",
                        "badge": "佔比 18.0%",
                        "tooltip": {
                            "title": "帳單分期",
                            "lines": [
                                "分期金額：36.0 億元（18.0%）",
                                "分期筆數：170 萬筆",
                                "平均客單：$21,176"
                            ]
                        }
                    }
                ],
                "footer": "分期滲透率：15.6%（佔全行交易金額）",
                "footer_title": "分期總筆數：675 萬筆（單筆 505 萬筆 ＋ 帳單 170 萬筆）"
            }
        ],
        "kpis_secondary": [
            {
                "title": "綜合自動核准率 (STP)",
                "value": "76.5%",
                "badges": [
                    { "type": "positive", "prefix": "舊戶", "text": "88.3%" },
                    { "type": "positive", "prefix": "新戶", "text": "62.0%" }
                ],
                "note": "全行自動審查率 94.1%",
                "note_title": "全行進件自動審查比率"
            },
            {
                "title": "信用卡電子帳單率",
                "value": "91.8%",
                "badges": [
                    { "type": "positive", "prefix": "總量", "text": "520萬本" },
                    { "type": "positive", "prefix": "紙本", "text": "42.6萬" }
                ],
                "note": "數位減碳成效斐然",
                "note_title": "紙本帳單 YoY −8.0%"
            },
            {
                "title": "小樹點流通兌換率",
                "value": "84.2%",
                "badges": [
                    { "type": "positive", "prefix": "贈送", "text": "3.8億點" },
                    { "type": "positive", "prefix": "兌換", "text": "3.2億點" }
                ],
                "note": "生態圈活絡動能強勁",
                "note_title": "兌換量 YoY +22.5%"
            },
            {
                "title": "小樹點有效總餘額",
                "value": "18.5",
                "unit": "億點",
                "badges": [
                    { "type": "positive", "prefix": "YoY", "text": "+21.7%" },
                    { "type": "positive", "prefix": "失效", "text": "2.1%" }
                ],
                "note": "年化失效維持健康低檔",
                "note_title": "流通未兌負債約 1.85 億元"
            }
        ],
        "tab0_sankey": {
            "title": "申辦自動化審查分析",
            "subtitle": "進件申辦 → AI 自動徵審中樞 → 核決處遇流向圖 (Sankey Flow)",
            "status_pill": "全行自動審查率 94.1%",
            "nodes": {
                "stage1_old": { "name": "舊戶加辦", "count": "47,000", "unit": "件 (55%)", "auto_rate": "自動審查率 97.4%" },
                "stage1_new": { "name": "新戶申辦 (新客)", "count": "38,400", "unit": "件 (45%)", "auto_rate": "自動審查率 90.0%" },
                "stage2_hub": { "name": "進件自動審查中樞", "count": "80,360", "unit": "件", "old_pass": "● 舊戶通過率 88.3%", "new_pass": "● 新戶通過率 62.0%" },
                "stage3_approved": { "name": "✅ 自動直接核准 (STP)", "count": "65,300", "unit": "件 (76.5%)", "detail": "舊戶 41,500 ｜ 新戶 23,800" },
                "stage3_manual": { "name": "⚠️ 轉入人工審查", "count": "20,100", "unit": "件 (23.5%)", "detail": "主要為新戶財力補件與洗錢覆核" }
            },
            "insights": [
                { "label": "全行進件自動核准率", "value": "76.5%", "note": "STP 直通比率" },
                { "label": "舊戶自動核准率", "value": "88.3%", "note": "41,500 件通過" },
                { "label": "新戶自動核准率", "value": "62.0%", "note": "23,800 件通過" },
                { "label": "人工審查處理量", "value": "20,100 件", "note": "23.5% 轉人工照會" }
            ]
        },
        "tab1_installments": {
            "title": "分期產品結構分析",
            "subtitle": "三大分期產品規模與頻次對照 (雙軸柱線圖：長條柱為金額、紫色虛線連線為筆數)",
            "status_pill": "全行分期滲透率：15.6%",
            "items": [
                {
                    "name": "授權單筆分期",
                    "amount": 110.0,
                    "amount_str": "110.0 億",
                    "share_str": "佔 55.0% ｜ YoY +31%",
                    "avg_ticket": "$38,596",
                    "tx_count": "285 萬筆",
                    "color": "#003b5c"
                },
                {
                    "name": "請款單筆分期",
                    "amount": 54.0,
                    "amount_str": "54.0 億",
                    "share_str": "佔 27.0% ｜ YoY +25%",
                    "avg_ticket": "$24,545",
                    "tx_count": "220 萬筆",
                    "color": "#2d6a8f"
                },
                {
                    "name": "帳單分期",
                    "amount": 36.0,
                    "amount_str": "36.0 億",
                    "share_str": "佔 18.0% ｜ YoY +20%",
                    "avg_ticket": "$21,176",
                    "tx_count": "170 萬筆",
                    "color": "#588ea8"
                }
            ],
            "insights": [
                { "label": "分期總規模", "value": "200.0 億元", "note": "YoY +27.3%" },
                { "label": "分期總筆數", "value": "675 萬筆", "note": "YoY +30.0%" },
                { "label": "分期滲透率", "value": "15.6%", "note": "佔全行交易金額" },
                { "label": "授權單筆平均客單", "value": "$38,596", "note": "高單價消費主力" }
            ]
        },
        "tab2_tree_points": {
            "title": "小樹點經營與折抵通路",
            "waterfall_title": "小樹點收支水庫 (動態流向瀑布圖)",
            "status_pill": "淨增存量：+0.6 億點",
            "waterfall_bars": [
                { "label": "去年同月", "val": 15.2, "type": "compare" },
                { "label": "上月餘額", "val": 17.9, "type": "base" },
                { "label": "本月新增", "val": 2.3, "type": "inflow", "display": "+2.3" },
                { "label": "本月贈送", "val": 1.5, "type": "inflow", "display": "+1.5" },
                { "label": "本月兌換", "val": -3.2, "type": "outflow", "display": "-3.2" },
                { "label": "本月累積", "val": 18.5, "type": "total" }
            ],
            "formula_note": "算式：上月餘額 17.9 + 新增 2.3 + 贈送 1.5 − 兌換 3.2 ＝ 本月累積餘額 18.5 億點 (YoY +21.7%)",
            "channels": [
                { "name": "即時折抵", "pct": "42%", "amount": "1.34億", "color": "#009e73" },
                { "name": "商戶折抵", "pct": "24%", "amount": "0.77億", "color": "#003b5c" },
                { "name": "里程兌換", "pct": "16%", "amount": "0.51億", "color": "#7c4dff" },
                { "name": "合併用點", "pct": "11%", "amount": "0.35億", "color": "#c9892e" },
                { "name": "其他折抵", "pct": "7%", "amount": "0.23億", "color": "#94a3b8" }
            ],
            "total_redeem_points": "3.2 億",
            "insights": [
                { "label": "小樹點流通兌換率", "value": "84.2%", "note": "當月兌換 3.2 億點" },
                { "label": "有效總餘額存量", "value": "18.5 億點", "note": "YoY +21.7%" },
                { "label": "即時折抵滲透", "value": "42.0%", "note": "主要兌換場景" },
                { "label": "年化到期失效比率", "value": "2.1%", "note": "低檔健康水準" }
            ]
        },
        "tab3_collection": {
            "title": "催收與呆帳分析",
            "m1_title": "M1 催收第一防線成效",
            "m1_pill": "當期進案 28,500 戶 (8.2 億)",
            "cure_rate": "85.6%",
            "cure_desc": "成功繳款回復正常：24,400 戶 (8.2 億元)",
            "cure_sub": "經簡訊與智能語音提醒後於當期正常化",
            "m2_rate": "14.4% (4,100 戶)",
            "m2_sub": "未如期補足最低應繳，轉由專人電催覆核並啟動額度管控",
            "aging_buckets": [
                { "name": "M1 (1–30天)", "amount": "8.2 億 (28,500 戶)", "pct_str": "0.52% 應收", "width_pct": 52, "color": "#003b5c" },
                { "name": "M2 (31–60天)", "amount": "2.5 億 (4,100 戶)", "pct_str": "0.16% 應收", "width_pct": 16, "color": "#c9892e" },
                { "name": "M3+ (61天以上)", "amount": "2.8 億 (2,950 戶)", "pct_str": "0.18% 應收", "width_pct": 18, "color": "#b84a4a" }
            ],
            "loss_settlement": {
                "chargeoff": "-1.45 億",
                "recovery": "+0.35 億",
                "net_loss": "-1.10 億"
            },
            "insights": [
                { "label": "3M+ 逾期帳款比率", "value": "0.18%", "note": "法定警示線 1.0%" },
                { "label": "備抵呆帳提足率", "value": "725.4%", "note": "每1元逾期提7.25元" },
                { "label": "M1 催收回復率", "value": "85.6%", "note": "第一防線正常化" },
                { "label": "當月淨信用損失", "value": "-1.10 億", "note": "損失年減 ▼8.8%" }
            ]
        }
    },

    "block04_resilience": {
        "section_id": "section-resilience",
        "section_num": "04",
        "section_title": "系統韌性",
        "subtitle": "2026/08 經營月報 ｜ 核心主機負載、活動日尖峰壓測與全行資安防詐防護",
        "kpis_primary": [
            {
                "title": "CardPool 授權核心主機",
                "value": "85",
                "unit": "ms",
                "badges": [
                    { "type": "positive", "prefix": "可用率", "text": "99.999%" },
                    { "type": "positive", "prefix": "SLA", "text": "100% 達標" }
                ],
                "splits": [
                    {
                        "label": "月授權量",
                        "value": "6,820",
                        "unit": "萬筆",
                        "badge": "零超時",
                        "tooltip": {
                            "title": "授權核心負載",
                            "lines": ["授權筆數：6,820 萬筆", "超時筆數：0 筆", "P99 延遲：< 120ms"]
                        }
                    },
                    {
                        "label": "授權成功率",
                        "value": "98.8%",
                        "badge": "可用率 99.999%",
                        "tooltip": {
                            "title": "系統可用率",
                            "lines": ["成功率：98.8%", "系統可用：99.999%", "無中斷運行：744 小時"]
                        }
                    }
                ],
                "footer": "雙活授權連線系統 ｜ 零超時中斷"
            },
            {
                "title": "CardLink 帳務清算核心主機",
                "value": "03:20",
                "unit": "AM",
                "badges": [
                    { "type": "positive", "prefix": "批次準點率", "text": "100%" },
                    { "type": "positive", "prefix": "提前", "text": "40 分鐘" }
                ],
                "splits": [
                    {
                        "label": "排程窗口上限",
                        "value": "04:00",
                        "unit": "AM",
                        "badge": "安全裕度足",
                        "tooltip": {
                            "title": "清算作業窗口",
                            "lines": ["排程上限：04:00 AM", "平均完成：03:20 AM", "裕度時間：40 分鐘"]
                        }
                    },
                    {
                        "label": "日均處理帳單",
                        "value": "17.3",
                        "unit": "萬戶",
                        "badge": "平帳 100%",
                        "tooltip": {
                            "title": "日均結帳量",
                            "lines": ["帳單戶數：17.3 萬戶/日", "平帳率：100.0%", "批次作業零延宕"]
                        }
                    }
                ],
                "footer": "發卡與收單核心帳務清算 ｜ 零差額平帳"
            },
            {
                "title": "全行防詐防堵總成效",
                "value": "4,280",
                "unit": "萬元",
                "badges": [
                    { "type": "positive", "prefix": "防堵總卡數", "text": "2,684 張" },
                    { "type": "positive", "prefix": "阻斷率", "text": "99.1%" }
                ],
                "splits": [
                    {
                        "label": "SFM 系統防堵",
                        "value": "3,420",
                        "unit": "萬元",
                        "badge": "2,064 張",
                        "tooltip": {
                            "title": "智慧偵測 SFM 系統",
                            "lines": [
                                "防堵金額：3,420 萬元（80%）",
                                "• 申請詐欺：1,150 萬 ｜ 842 張",
                                "• 交易詐欺：2,270 萬 ｜ 1,222 張"
                            ]
                        }
                    },
                    {
                        "label": "3DS 系統防堵",
                        "value": "860",
                        "unit": "萬元",
                        "badge": "620 張",
                        "tooltip": {
                            "title": "線上交易 3DS 驗證",
                            "lines": ["防堵金額：860 萬元（20%）", "防堵卡數：620 張", "OTP 異常攔阻率：99.6%"]
                        }
                    }
                ],
                "footer": "涵蓋發卡端 (申請/3DS) 與收單端 (交易) 三大防線"
            }
        ],
        "tab1_events": {
            "title": "活動日雲端服務監控數據",
            "events": [
                { "date": "2026/06/18", "name": "年中大促 618", "peak_time": "00:00–01:00", "specs": "32 vCPU / 128GB (36 實例)", "peak_tps": "3,850 TPS", "max_cpu": "54%", "note": "平穩運行，延遲 < 80ms" },
                { "date": "2026/08/08", "name": "父親節檔期", "peak_time": "12:30–13:30", "specs": "32 vCPU / 128GB (24 實例)", "peak_tps": "2,420 TPS", "max_cpu": "38%", "note": "平穩運行，處於常態健康區" },
                { "date": "2026/10/24", "name": "百貨週年慶首週末", "peak_time": "14:30–16:30", "specs": "48 vCPU / 192GB (48 實例)", "peak_tps": "4,180 TPS", "max_cpu": "62%", "note": "平穩運行，實體與掃碼無延滯" },
                { "date": "2026/11/11", "name": "雙11電商零點狂歡", "peak_time": "00:00–00:30", "specs": "64 vCPU / 256GB (72 實例)", "peak_tps": "5,420 TPS", "max_cpu": "68%", "note": "年度最高峰順暢通過，零中斷" },
                { "date": "2026/12/12", "name": "雙12年終購物節", "peak_time": "20:00–22:00", "specs": "48 vCPU / 192GB (48 實例)", "peak_tps": "3,960 TPS", "max_cpu": "58%", "note": "平穩運行，延遲 < 82ms" }
            ],
            "insights": [
                { "label": "年度瞬時最高峰值", "value": "5,420 TPS", "note": "雙11零點電商尖峰" },
                { "label": "活動日最高 CPU 負載", "value": "68%", "note": "容量裕度維持安全區間" },
                { "label": "最大彈性配置規格", "value": "64 vCPU / 256GB", "note": "72 個動態微服務實例" },
                { "label": "尖峰時段交易中斷", "value": "0 次", "note": "可用率 100% 達成 SLA" }
            ]
        },
        "tab2_fraud": {
            "title": "三大資安防詐防堵成效分析",
            "items": [
                { "name": "申請詐欺防堵", "system": "SFM 系統", "domain": "發卡端（進件審查）", "cards": "842 張", "amount": "1,150 萬元", "avg_card": "1.37 萬元 / 張", "share": "26.9%" },
                { "name": "3DS 系統防堵", "system": "3DS 系統", "domain": "發卡端（線上交易）", "cards": "620 張", "amount": "860 萬元", "avg_card": "1.39 萬元 / 張", "share": "20.1%" },
                { "name": "交易詐欺防堵", "system": "SFM 系統", "domain": "收單端（特店交易）", "cards": "1,222 張", "amount": "2,270 萬元", "avg_card": "1.86 萬元 / 張", "share": "53.0%" }
            ],
            "total": { "name": "全行防詐防堵合計", "system": "SFM + 3DS", "domain": "全行（發卡＋收單）", "cards": "2,684 張", "amount": "4,280 萬元", "avg_card": "1.59 萬元 / 張", "share": "100.0%" },
            "chart_data": {
                "max_amount": 2500,
                "max_cards": 1500,
                "bars": [
                    { "name": "申請詐欺", "amount": 1150, "cards": 842 },
                    { "name": "3DS線上", "amount": 860, "cards": 620 },
                    { "name": "交易詐欺", "amount": 2270, "cards": 1222 }
                ]
            },
            "insights": [
                { "label": "全月防堵總金額", "value": "4,280 萬元", "note": "全行資產實質保全" },
                { "label": "全月防堵總卡數", "value": "2,684 張", "note": "及時阻斷冒用風險" },
                { "label": "SFM 系統防堵佔比", "value": "80.0%", "note": "申請與交易雙重防線 (3,420 萬)" },
                { "label": "3DS 線上防堵佔比", "value": "20.0%", "note": "線上交易身份驗證 (860 萬)" }
            ]
        },
        "tab3_microservices": {
            "title": "紅利核心微服務交易量能監控",
            "overview_cards": [
                { "name": "小樹點查詢服務", "value": "4,850", "unit": "萬次", "yoy": "+31.8%", "peak_tps": "1,850 TPS", "note": "日常高頻查詢微服務" },
                { "name": "回饋總覽查詢服務", "value": "3,420", "unit": "萬次", "yoy": "+39.6%", "peak_tps": "1,320 TPS", "note": "方案切換與回饋試算" },
                { "name": "小樹點兌換服務", "value": "1,180", "unit": "萬次", "yoy": "+22.9%", "peak_tps": "620 TPS", "note": "交易折抵扣點微服務" },
                { "name": "票券服務（雲端）", "value": "580", "unit": "萬次", "yoy": "+26.1%", "peak_tps": "380 TPS", "note": "即時出券與核銷服務" }
            ],
            "services_chart": {
                "max_scale": 5000,
                "services": [
                    {
                        "name": "小樹點查詢",
                        "y_last_year": 3680,
                        "y_prev_month": 4620,
                        "y_cur_month": 4850,
                        "yoy": "+31.8%",
                        "peak_tps": 1850,
                        "capacity": 2500,
                        "share_pct": "48.4%",
                        "badge": "日常高頻",
                        "badge_type": "primary",
                        "fill_pct": 74,
                        "gradient": "linear-gradient(90deg, #009e73, #007a5e)",
                        "foot_latency": "P99 延遲 < 45ms ｜ 零中斷"
                    },
                    {
                        "name": "回饋總覽",
                        "y_last_year": 2450,
                        "y_prev_month": 3250,
                        "y_cur_month": 3420,
                        "yoy": "+39.6%",
                        "peak_tps": 1320,
                        "capacity": 2000,
                        "share_pct": "34.1%",
                        "badge": "CUBE權益",
                        "badge_type": "success",
                        "fill_pct": 66,
                        "gradient": "linear-gradient(90deg, #003b5c, #002b49)",
                        "foot_latency": "晚間方案切換尖峰平穩通過"
                    },
                    {
                        "name": "小樹點兌換",
                        "y_last_year": 960,
                        "y_prev_month": 1120,
                        "y_cur_month": 1180,
                        "yoy": "+22.9%",
                        "peak_tps": 620,
                        "capacity": 1200,
                        "share_pct": "11.8%",
                        "badge": "交易扣帳",
                        "badge_type": "warning",
                        "fill_pct": 51.6,
                        "gradient": "linear-gradient(90deg, #c9892e, #a46d1b)",
                        "foot_latency": "帳務扣帳平帳率 100%"
                    },
                    {
                        "name": "票券服務",
                        "y_last_year": 460,
                        "y_prev_month": 540,
                        "y_cur_month": 580,
                        "yoy": "+26.1%",
                        "peak_tps": 380,
                        "capacity": 800,
                        "share_pct": "5.8%",
                        "badge": "即時出券",
                        "badge_type": "primary",
                        "fill_pct": 47.5,
                        "gradient": "linear-gradient(90deg, #7c4dff, #5e35b1)",
                        "foot_latency": "出券核銷成功率 99.98%"
                    }
                ]
            },
            "insights": [
                { "label": "全月微服務總請求", "value": "10,030 萬次", "note": "跨越 1.0 億次量能大關" },
                { "label": "查詢兌換比率", "value": "7.0 : 1", "note": "高頻查詢有效驅動實質兌點" },
                { "label": "微服務綜合峰值", "value": "4,170 TPS", "note": "活動日併發容量裕度維持 50%+" },
                { "label": "雲端服務可用率", "value": "99.99%", "note": "微服務叢集零中斷達成 SLA" }
            ]
        }
    }
}

with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
    json.dump(dashboard_data, f, ensure_ascii=False, indent=2)

print(f"Successfully generated {OUTPUT_JSON} (keys: {list(dashboard_data.keys())})")
