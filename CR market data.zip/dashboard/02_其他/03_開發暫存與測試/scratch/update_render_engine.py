# -*- coding: utf-8 -*-
with open('credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    html = f.read()

start_mark = '  // ========================================================\n  // 動態數據渲染引擎：Block 01 全維度數據綁定 (Single Source of Truth)'
end_mark = '  document.addEventListener("DOMContentLoaded", () => {'

if start_mark in html and end_mark in html:
    idx_start = html.find(start_mark)
    idx_end = html.find(end_mark)

    new_render = """  // ========================================================
  // 動態數據渲染引擎：Block 01 全維度數據綁定 (Single Source of Truth)
  // 自動具備：基礎數值自動推導計算、份額百分比推導、動態字串組裝
  // ========================================================
  function renderBlock01FromData(data) {
    if (!data || !data.block01) return;
    const b1 = data.block01;
    const kpi = b1.monthly_kpis;

    const fmtSign = (v, sfx="%") => `${v > 0 ? "+" : ""}${Number(v).toFixed(1)}${sfx}`;
    const semCls = (v) => v >= 0 ? "number-positive" : "number-negative";

    // 1. 總交易金額 (自動推導：若無總值則累加；若無佔比則依金額推導)
    const amt = kpi.total_amount;
    if (amt.general && amt.installment) {
      if (amt.value === undefined) amt.value = +(amt.general.amount + amt.installment.amount).toFixed(1);
      if (amt.general.share === undefined) amt.general.share = +((amt.general.amount / amt.value) * 100).toFixed(1);
      if (amt.installment.share === undefined) amt.installment.share = +(100 - amt.general.share).toFixed(1);
    }
    const amtValHtml = `${Number(amt.value).toLocaleString('en-US', {minimumFractionDigits:1, maximumFractionDigits:1})} <em>${amt.unit || '億元'}</em>`;
    const amtGrowthHtml = `<span class="${semCls(amt.yoy)}"><b>YoY</b>${fmtSign(amt.yoy)}</span> <span class="${semCls(amt.mom)}"><b>MoM</b>${fmtSign(amt.mom)}</span>`;
    
    // c00 Card 1 (00 戰情室)
    const c00AmtVal = document.getElementById("c00-amt-val");
    if (c00AmtVal) c00AmtVal.innerHTML = amtValHtml;
    const c00AmtGrowth = document.getElementById("c00-amt-growth");
    if (c00AmtGrowth) c00AmtGrowth.innerHTML = `<span class="${semCls(amt.yoy)}">YoY ${fmtSign(amt.yoy)}</span> <span class="${semCls(amt.mom)}">MoM ${fmtSign(amt.mom)}</span>`;
    const c00AmtSegGen = document.getElementById("c00-amt-seg-gen");
    if (c00AmtSegGen) {
      c00AmtSegGen.style.width = `${amt.general.share}%`;
      c00AmtSegGen.title = `一般交易: ${amt.general.share}% (${amt.general.amount} 億)`;
    }
    const c00AmtSegInst = document.getElementById("c00-amt-seg-inst");
    if (c00AmtSegInst) {
      c00AmtSegInst.style.width = `${amt.installment.share}%`;
      c00AmtSegInst.title = `分期交易: ${amt.installment.share}% (${amt.installment.amount} 億)`;
    }
    const c00AmtGenPct = document.getElementById("c00-amt-gen-pct");
    if (c00AmtGenPct) c00AmtGenPct.textContent = `(${amt.general.share}%)`;
    const c00AmtGenVal = document.getElementById("c00-amt-gen-val");
    if (c00AmtGenVal) c00AmtGenVal.innerHTML = `${amt.general.amount}<em>${amt.general.unit || '億'}</em>`;
    const c00AmtInstPct = document.getElementById("c00-amt-inst-pct");
    if (c00AmtInstPct) c00AmtInstPct.textContent = `(${amt.installment.share}%)`;
    const c00AmtInstVal = document.getElementById("c00-amt-inst-val");
    if (c00AmtInstVal) c00AmtInstVal.innerHTML = `${amt.installment.amount}<em>${amt.installment.unit || '億'}</em>`;

    // b01 Card 1 (01 全行概況)
    const b01AmtVal = document.getElementById("b01-amt-val");
    if (b01AmtVal) b01AmtVal.innerHTML = amtValHtml;
    const b01AmtGrowth = document.getElementById("b01-amt-growth");
    if (b01AmtGrowth) b01AmtGrowth.innerHTML = amtGrowthHtml;
    const b01AmtSegGen = document.getElementById("b01-amt-seg-gen");
    if (b01AmtSegGen) {
      b01AmtSegGen.style.width = `${amt.general.share}%`;
      b01AmtSegGen.title = `一般交易: ${amt.general.share}% (${amt.general.amount} 億)`;
    }
    const b01AmtSegInst = document.getElementById("b01-amt-seg-inst");
    if (b01AmtSegInst) {
      b01AmtSegInst.style.width = `${amt.installment.share}%`;
      b01AmtSegInst.title = `分期交易: ${amt.installment.share}% (${amt.installment.amount} 億)`;
    }
    const b01AmtGenPct = document.getElementById("b01-amt-gen-pct");
    if (b01AmtGenPct) b01AmtGenPct.textContent = `(${amt.general.share}%)`;
    const b01AmtGenVal = document.getElementById("b01-amt-gen-val");
    if (b01AmtGenVal) b01AmtGenVal.innerHTML = `${amt.general.amount}<em>${amt.general.unit || '億'}</em>`;
    const b01AmtInstPct = document.getElementById("b01-amt-inst-pct");
    if (b01AmtInstPct) b01AmtInstPct.textContent = `(${amt.installment.share}%)`;
    const b01AmtInstVal = document.getElementById("b01-amt-inst-val");
    if (b01AmtInstVal) b01AmtInstVal.innerHTML = `${amt.installment.amount}<em>${amt.installment.unit || '億'}</em>`;

    // 2. 總交易筆數 (自動推導：若無總值則累加；若無佔比則依筆數推導)
    const cnt = kpi.total_count;
    if (cnt.general && cnt.installment) {
      if (cnt.value === undefined) cnt.value = cnt.general.count + cnt.installment.count;
      if (cnt.general.share === undefined) cnt.general.share = +((cnt.general.count / cnt.value) * 100).toFixed(1);
      if (cnt.installment.share === undefined) cnt.installment.share = +(100 - cnt.general.share).toFixed(1);
    }
    const cntValHtml = `${Number(cnt.value).toLocaleString('en-US')} <em>${cnt.unit || '萬筆'}</em>`;
    const cntGrowthHtml = `<span class="${semCls(cnt.yoy)}"><b>YoY</b>${fmtSign(cnt.yoy)}</span> <span class="${semCls(cnt.mom)}"><b>MoM</b>${fmtSign(cnt.mom)}</span>`;
    
    // c00 Card 2
    const c00CntVal = document.getElementById("c00-cnt-val");
    if (c00CntVal) c00CntVal.innerHTML = cntValHtml;
    const c00CntGrowth = document.getElementById("c00-cnt-growth");
    if (c00CntGrowth) c00CntGrowth.innerHTML = `<span class="${semCls(cnt.yoy)}">YoY ${fmtSign(cnt.yoy)}</span> <span class="${semCls(cnt.mom)}">MoM ${fmtSign(cnt.mom)}</span>`;
    const c00CntSegGen = document.getElementById("c00-cnt-seg-gen");
    if (c00CntSegGen) {
      c00CntSegGen.style.width = `${cnt.general.share}%`;
      c00CntSegGen.title = `一般交易: ${cnt.general.share}% (${cnt.general.count} 萬筆)`;
    }
    const c00CntSegInst = document.getElementById("c00-cnt-seg-inst");
    if (c00CntSegInst) {
      c00CntSegInst.style.width = `${cnt.installment.share}%`;
      c00CntSegInst.title = `分期交易: ${cnt.installment.share}% (${cnt.installment.count} 萬筆)`;
    }
    const c00CntGenPct = document.getElementById("c00-cnt-gen-pct");
    if (c00CntGenPct) c00CntGenPct.textContent = `(${cnt.general.share}%)`;
    const c00CntGenVal = document.getElementById("c00-cnt-gen-val");
    if (c00CntGenVal) c00CntGenVal.innerHTML = `${cnt.general.count}<em>${cnt.general.unit || '萬筆'}</em>`;
    const c00CntInstPct = document.getElementById("c00-cnt-inst-pct");
    if (c00CntInstPct) c00CntInstPct.textContent = `(${cnt.installment.share}%)`;
    const c00CntInstVal = document.getElementById("c00-cnt-inst-val");
    if (c00CntInstVal) c00CntInstVal.innerHTML = `${cnt.installment.count}<em>${cnt.installment.unit || '萬筆'}</em>`;

    // b01 Card 2
    const b01CntVal = document.getElementById("b01-cnt-val");
    if (b01CntVal) b01CntVal.innerHTML = cntValHtml;
    const b01CntGrowth = document.getElementById("b01-cnt-growth");
    if (b01CntGrowth) b01CntGrowth.innerHTML = cntGrowthHtml;
    const b01CntSegGen = document.getElementById("b01-cnt-seg-gen");
    if (b01CntSegGen) {
      b01CntSegGen.style.width = `${cnt.general.share}%`;
      b01CntSegGen.title = `一般交易: ${cnt.general.share}% (${cnt.general.count} 萬筆)`;
    }
    const b01CntSegInst = document.getElementById("b01-cnt-seg-inst");
    if (b01CntSegInst) {
      b01CntSegInst.style.width = `${cnt.installment.share}%`;
      b01CntSegInst.title = `分期交易: ${cnt.installment.share}% (${cnt.installment.count} 萬筆)`;
    }
    const b01CntGenPct = document.getElementById("b01-cnt-gen-pct");
    if (b01CntGenPct) b01CntGenPct.textContent = `(${cnt.general.share}%)`;
    const b01CntGenVal = document.getElementById("b01-cnt-gen-val");
    if (b01CntGenVal) b01CntGenVal.innerHTML = `${cnt.general.count}<em>${cnt.general.unit || '萬筆'}</em>`;
    const b01CntInstPct = document.getElementById("b01-cnt-inst-pct");
    if (b01CntInstPct) b01CntInstPct.textContent = `(${cnt.installment.share}%)`;
    const b01CntInstVal = document.getElementById("b01-cnt-inst-val");
    if (b01CntInstVal) b01CntInstVal.innerHTML = `${cnt.installment.count}<em>${cnt.installment.unit || '萬筆'}</em>`;

    // 3. 活卡率 (自動推導：活卡率、未動用卡數與佔比)
    const act = kpi.active_card;
    if (act.active_cards !== undefined && act.issued_cards !== undefined) {
      if (act.rate === undefined) act.rate = +((act.active_cards / act.issued_cards) * 100).toFixed(1);
      if (act.active_share === undefined) act.active_share = act.rate;
      if (act.inactive_cards === undefined) act.inactive_cards = +(act.issued_cards - act.active_cards).toFixed(1);
      if (act.inactive_share === undefined) act.inactive_share = +(100 - act.active_share).toFixed(1);
    }
    const b01ActVal = document.getElementById("b01-active-val");
    if (b01ActVal) b01ActVal.innerHTML = `${act.rate}<em>${act.unit || '%'}</em>`;
    const b01ActGrowth = document.getElementById("b01-active-growth");
    if (b01ActGrowth) b01ActGrowth.innerHTML = `<span class="${semCls(act.yoy_pp)}"><b>YoY</b>${fmtSign(act.yoy_pp, "pp")}</span> <span class="${semCls(act.mom_pp)}"><b>MoM</b>${fmtSign(act.mom_pp, "pp")}</span>`;
    const b01ActSegGen = document.getElementById("b01-active-seg-gen");
    if (b01ActSegGen) {
      b01ActSegGen.style.width = `${act.active_share}%`;
      b01ActSegGen.title = `有效卡數: ${act.active_share}% (${act.active_cards} ${act.active_cards_unit || '萬卡'})`;
    }
    const b01ActSegInact = document.getElementById("b01-active-seg-inact");
    if (b01ActSegInact) {
      b01ActSegInact.style.width = `${act.inactive_share}%`;
      b01ActSegInact.title = `未動用卡: ${act.inactive_share}% (${act.inactive_cards} ${act.inactive_cards_unit || '萬卡'})`;
    }
    const b01ActGenPct = document.getElementById("b01-active-gen-pct");
    if (b01ActGenPct) b01ActGenPct.textContent = `(${act.active_share}%)`;
    const b01ActActVal = document.getElementById("b01-active-act-val");
    if (b01ActActVal) b01ActActVal.innerHTML = `${act.active_cards}<em>${act.active_cards_unit || '萬卡'}</em>`;
    const b01ActIssVal = document.getElementById("b01-active-iss-val");
    if (b01ActIssVal) b01ActIssVal.innerHTML = `${act.issued_cards}<em>${act.issued_cards_unit || '萬卡'}</em>`;

    // 4. 信用業務 (00 迷你卡 & 01 Card 4)
    const cred = kpi.credit_business;
    // 循環信用餘額
    const revValHtml = `${cred.revolving.balance} <em>${cred.revolving.unit || '億元'}</em>`;
    const revGrowthHtml = `<span class="${semCls(cred.revolving.yoy)}"><b>YoY</b>${fmtSign(cred.revolving.yoy)}</span> <span class="${semCls(cred.revolving.mom)}"><b>MoM</b>${fmtSign(cred.revolving.mom)}</span>`;
    const c00RevVal = document.getElementById("c00-revolving-val");
    if (c00RevVal) c00RevVal.innerHTML = revValHtml;
    const c00RevGrowth = document.getElementById("c00-revolving-growth");
    if (c00RevGrowth) c00RevGrowth.innerHTML = `<span class="${semCls(cred.revolving.yoy)}">YoY ${fmtSign(cred.revolving.yoy)}</span>`;
    const b01RevVal = document.getElementById("b01-revolving-val");
    if (b01RevVal) b01RevVal.innerHTML = revValHtml;
    const b01RevGrowth = document.getElementById("b01-revolving-growth");
    if (b01RevGrowth) b01RevGrowth.innerHTML = revGrowthHtml;

    // 預借現金金額 (動態組裝筆數提示字串)
    const cashValHtml = `${cred.cash_advance.amount} <em>${cred.cash_advance.unit || '億元'}</em>`;
    const cashGrowthHtml = `<span class="${semCls(cred.cash_advance.yoy)}"><b>YoY</b>${fmtSign(cred.cash_advance.yoy)}</span> <span class="${semCls(cred.cash_advance.mom)}"><b>MoM</b>${fmtSign(cred.cash_advance.mom)}</span>`;
    const cashCountHint = cred.cash_advance.count_hint || (cred.cash_advance.count_wan !== undefined ? `(${cred.cash_advance.count_wan}萬筆)` : "");
    const c00CashVal = document.getElementById("c00-cashadv-val");
    if (c00CashVal) c00CashVal.innerHTML = cashValHtml;
    const c00CashGrowth = document.getElementById("c00-cashadv-growth");
    if (c00CashGrowth) c00CashGrowth.innerHTML = `<span class="${semCls(cred.cash_advance.yoy)}">YoY ${fmtSign(cred.cash_advance.yoy)}</span> <span class="c-hint">${cashCountHint}</span>`;
    const b01CashVal = document.getElementById("b01-cashadv-val");
    if (b01CashVal) b01CashVal.innerHTML = cashValHtml;
    const b01CashGrowth = document.getElementById("b01-cashadv-growth");
    if (b01CashGrowth) b01CashGrowth.innerHTML = cashGrowthHtml;

    // 5. 戰情室同業圓餅圖與排名清單 (00 戰情室)
    const donut = b1.cockpit_peer_donut;
    // 自動推導：若無市場總額則累加；若無市占率則依金額計算
    if (donut.peers && donut.peers.length > 0) {
      if (donut.market_total === undefined) {
        donut.market_total = donut.peers.reduce((s, p) => s + (p.amount || 0), 0);
      }
      donut.peers.forEach(p => {
        if (p.share === undefined && p.amount && donut.market_total) {
          p.share = +((p.amount / donut.market_total) * 100).toFixed(1);
        }
      });
      if (donut.top4_share === undefined) {
        donut.top4_share = +donut.peers.slice(0, 4).reduce((s, p) => s + (p.share || 0), 0).toFixed(1);
      }
    }
    const top4HintStr = donut.top4_hint || (donut.top4_share !== undefined ? `四大行佔 ${donut.top4_share}%` : "");
    const c00MktVal = document.getElementById("c00-market-val");
    if (c00MktVal) c00MktVal.innerHTML = `${donut.market_total.toLocaleString()} <em>${donut.unit || '億元'}</em>`;
    const c00MktYoy = document.getElementById("c00-market-yoy");
    if (c00MktYoy) c00MktYoy.textContent = `YoY ${fmtSign(donut.market_yoy)}`;
    const c00Top4Hint = document.getElementById("c00-top4-hint");
    if (c00Top4Hint) c00Top4Hint.textContent = top4HintStr;

    // 渲染同業列表
    const c00PeerList = document.getElementById("c00-peer-list");
    if (c00PeerList && donut.peers) {
      c00PeerList.innerHTML = donut.peers.map(p => `
        <div class="cockpit-peer-row ${p.is_cathay ? 'highlight' : ''}">
          <span class="p-name"><span class="peer-color-dot" style="background:${p.color};"></span>${p.name}</span>
          <span class="p-val" style="${p.is_cathay ? '' : (p.name === '其他同業' ? 'color:#64748b;' : '')}">${Number(p.amount).toLocaleString()} ${p.unit || '億'}</span>
          <span class="p-share" style="${p.name === '其他同業' ? 'color:#64748b;' : ''}"><b>${p.share}%</b></span>
          <span class="p-yoy number-positive" style="${p.name === '其他同業' ? 'color:#64748b;' : ''}">${fmtSign(p.yoy)}</span>
        </div>
      `).join("");
    }

    // 渲染動態 SVG Donut 切片 (自動依 share 百分比精準計算弧度坐標)
    const donutWrap = document.getElementById("c00-donut-wrap");
    if (donutWrap && donut.peers) {
      let cumulativeAngle = 0;
      const radiusOuter = 52;
      const radiusInner = 32;
      const cx = 60, cy = 60;
      
      const paths = donut.peers.map(p => {
        const sliceAngle = (p.share / 100) * 360;
        const startAngle = cumulativeAngle;
        const endAngle = cumulativeAngle + sliceAngle;
        cumulativeAngle = endAngle;

        const startRad = (startAngle - 90) * Math.PI / 180;
        const endRad = (endAngle - 90) * Math.PI / 180;

        const x1 = (cx + radiusOuter * Math.cos(startRad)).toFixed(2);
        const y1 = (cy + radiusOuter * Math.sin(startRad)).toFixed(2);
        const x2 = (cx + radiusOuter * Math.cos(endRad)).toFixed(2);
        const y2 = (cy + radiusOuter * Math.sin(endRad)).toFixed(2);

        const x3 = (cx + radiusInner * Math.cos(endRad)).toFixed(2);
        const y3 = (cy + radiusInner * Math.sin(endRad)).toFixed(2);
        const x4 = (cx + radiusInner * Math.cos(startRad)).toFixed(2);
        const y4 = (cy + radiusInner * Math.sin(startRad)).toFixed(2);

        const largeArc = sliceAngle > 180 ? 1 : 0;
        const pathData = `M ${x1} ${y1} A ${radiusOuter} ${radiusOuter} 0 ${largeArc} 1 ${x2} ${y2} L ${x3} ${y3} A ${radiusInner} ${radiusInner} 0 ${largeArc} 0 ${x4} ${y4} Z`;

        return `<path class="cockpit-donut-slice" d="${pathData}" fill="${p.color}" stroke="#ffffff" stroke-width="1.5"><title>${p.name}: ${p.share}% (${p.amount}億)</title></path>`;
      }).join("\\n");

      donutWrap.innerHTML = `
        <svg viewBox="0 0 120 120" width="88" height="88" style="display:block;">
          ${paths}
          <circle cx="60" cy="60" r="32" fill="#ffffff" />
        </svg>
      `;
    }

    // 6. 同步 1B 同業對標資料
    if (b1.peer_benchmark) {
      peerCategories.splice(0, peerCategories.length, ...b1.peer_benchmark);
      if (typeof renderYtd === 'function') {
        renderYtd();
      }
    }
  }
\n"""

    updated = html[:idx_start] + new_render + html[idx_end:]
    with open('credit_card_full_dashboard.html', 'w', encoding='utf-8') as out:
        out.write(updated)
    print("Updated renderBlock01FromData successfully!")
else:
    print("Could not find markers!")
