# -*- coding: utf-8 -*-
"""
Refactored, Data-Driven Dashboard Builder
Reads configuration and values from dashboard_data.json and produces credit_card_full_dashboard.html.
"""
import json
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSS_FILE = os.path.join(BASE_DIR, "scratch", "globals.css")
DATA_FILE = os.path.join(BASE_DIR, "scratch", "dashboard_data.json")
OUTPUT_HTML = os.path.join(BASE_DIR, "credit_card_full_dashboard.html")

# 1. Load CSS
with open(CSS_FILE, "r", encoding="utf-8") as f:
    css_content = f.read()

clean_css = css_content.replace('@import "tailwindcss";', """/* Resets */
*, ::before, ::after { box-sizing: border-box; }
html { line-height: 1.5; -webkit-text-size-adjust: 100%; tab-size: 4; font-family: ui-sans-serif, system-ui, sans-serif; }
body { margin: 0; line-height: inherit; }
button { font-family: inherit; font-size: 100%; font-weight: inherit; line-height: inherit; color: inherit; margin: 0; padding: 0; text-transform: none; }
table { text-indent: 0; border-color: inherit; border-collapse: collapse; }
""").strip()

# 2. Extra CSS
extra_css = """
/* Single-Page Main Section Switcher */
.main-section { display: none; }
.main-section.active { display: block; animation: fadein 0.22s ease; }

/* Subnav - Centered, Clean Tab Switcher */
.subnav {
  height: 54px;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 0 20px;
  background: #ffffff;
  border-bottom: 2px solid var(--line);
  box-shadow: 0 3px 12px rgba(0, 60, 45, 0.08);
  position: sticky;
  top: 76px;
  z-index: 19;
}
.nav-links {
  display: flex;
  gap: 12px;
}
.nav-tab-btn {
  border: 1px solid #cbd9df;
  background: #f8fafb;
  color: #556972;
  padding: 9px 24px;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 900;
  cursor: pointer;
  transition: all 0.18s ease;
  display: inline-flex;
  align-items: center;
  gap: 8px;
}
.nav-tab-btn:hover {
  background: #eaf7f2;
  color: var(--orange-dark);
  border-color: var(--orange);
}
.nav-tab-btn.active {
  background: var(--blue-dark);
  color: #ffffff;
  border-color: var(--blue-dark);
  box-shadow: 0 4px 12px rgba(0, 43, 73, 0.25);
}
.nav-num {
  display: inline-block;
  padding: 2px 7px;
  border-radius: 4px;
  background: #e2e8f0;
  color: #475569;
  font-size: 11px;
  font-weight: 900;
  transition: all 0.18s ease;
}
.nav-tab-btn.active .nav-num {
  background: var(--orange);
  color: #ffffff;
}

/* Grid Layouts for 2, 3, 4 cards in Section A */
.monthly-kpi-layout-3 {
  grid-column: 1 / -1;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
}
.monthly-kpi-layout-4 {
  grid-column: 1 / -1;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 12px;
}

@media (max-width: 1024px) {
  .monthly-kpi-layout-3 { grid-template-columns: repeat(2, 1fr); }
  .monthly-kpi-layout-4 { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 640px) {
  .monthly-kpi-layout-3 { grid-template-columns: 1fr; }
  .monthly-kpi-layout-4 { grid-template-columns: 1fr; }
}

.split-foot {
  margin-top: 14px;
  padding-top: 10px;
  border-top: 1px dashed #e4ebe8;
  color: #667a76;
  font-size: 11px;
  font-weight: 700;
}

.unified-tabs {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin: 14px 0;
}
.unified-tabs button {
  padding: 8px 16px;
  border: 1px solid #cbd9df;
  border-radius: 5px;
  background: #ffffff;
  color: #63747e;
  font-size: 12px;
  font-weight: 900;
  cursor: pointer;
  transition: all 0.15s ease;
}
.unified-tabs button:hover,
.unified-tabs button.active {
  border-color: var(--blue);
  background: var(--blue);
  color: #ffffff;
  box-shadow: 0 2px 6px rgba(0, 43, 73, 0.18);
}

.unified-insights {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
  margin-top: 14px;
}
.unified-insights.cols-3 {
  grid-template-columns: repeat(3, 1fr);
}
.unified-insights.cols-2 {
  grid-template-columns: repeat(2, 1fr);
}
.unified-insights div {
  padding: 10px 14px;
  background: #f5f8f7;
  border-left: 3px solid var(--orange);
  border-radius: 0 6px 6px 0;
}
.unified-insights div:nth-child(2) { border-left-color: var(--blue); }
.unified-insights div:nth-child(3) { border-left-color: #91a1a8; }
.unified-insights div:nth-child(4) { border-left-color: var(--orange-dark); }
.unified-insights span {
  display: block;
  color: #6c7a7b;
  font-size: 11px;
  font-weight: 800;
}
.unified-insights strong {
  display: block;
  margin-top: 5px;
  color: var(--ink);
  font-size: 20px;
  font-weight: 700;
  line-height: 1.1;
  font-variant-numeric: tabular-nums;
}
.unified-insights em {
  display: block;
  margin-top: 3px;
  color: var(--muted);
  font-size: 10px;
  font-style: normal;
}

.tab-content { display: none; }
.tab-content.active { display: block; animation: fadein 0.18s ease; }

.status-pill { display: inline-flex; align-items: center; gap: 4px; padding: 2px 7px; border-radius: 4px; font-size: 10px; font-weight: 800; }
.status-pill.success { background: #eaf7f2; color: var(--green); border: 1px solid #b5e4d2; }
.status-pill.warning { background: #fff7e7; color: #b8781c; border: 1px solid #fae1b8; }
.status-pill.primary { background: #eef5ff; color: var(--blue); border: 1px solid #bfd9f8; }

.svg-chart-card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 16px; margin-top: 8px; }
.svg-chart-note { display: flex; justify-content: space-between; align-items: center; font-size: 12px; font-weight: 800; color: var(--blue-dark); margin-bottom: 12px; padding-bottom: 8px; border-bottom: 1px solid #e2e8f0; }

html { scroll-padding-top: 140px; }

.dashboard-section {
  font-size: 14px;
}
.dashboard-section .block-intro p {
  font-size: 14px;
  font-weight: 700;
  line-height: 1.5;
  color: #4b5d67;
}

.dashboard-section .monthly-kpi {
  padding: 18px 20px;
  border-radius: 12px;
}
.dashboard-section .monthly-kpi-title {
  font-size: 14px;
  font-weight: 800;
  letter-spacing: 0.02em;
}
.dashboard-section .monthly-primary .monthly-kpi-value {
  font-size: 40px;
  font-weight: 900;
  line-height: 1;
  margin: 8px 0 6px;
  color: var(--ink);
}
.dashboard-section .monthly-primary .monthly-kpi-value em {
  font-size: 16px;
  font-weight: 700;
  margin-left: 6px;
}
.dashboard-section .monthly-secondary .monthly-kpi-value {
  font-size: 32px;
  font-weight: 900;
  line-height: 1.05;
  margin: 6px 0 4px;
  color: var(--ink);
}
.dashboard-section .monthly-secondary .monthly-kpi-value em {
  font-size: 14px;
  font-weight: 700;
  margin-left: 5px;
}
.dashboard-section .monthly-growth {
  gap: 10px;
  font-size: 13.5px;
  font-weight: 800;
}
.dashboard-section .monthly-growth b {
  font-size: 11px;
  margin-right: 4px;
}

.dashboard-section .monthly-split {
  margin-top: 18px;
  padding-top: 14px;
  gap: 14px;
}
.dashboard-section .split-item>span {
  font-size: 13px;
  font-weight: 800;
  color: #4b5d67;
}
.dashboard-section .split-item>strong {
  font-size: 23px;
  font-weight: 800;
  margin-top: 5px;
  color: var(--ink);
}
.dashboard-section .split-item>strong em {
  font-size: 13px;
  font-weight: 600;
  color: #64748b;
  margin-left: 4px;
}
.dashboard-section .split-item>b {
  font-size: 13px;
  font-weight: 800;
  margin-top: 5px;
}
.dashboard-section .split-foot {
  margin-top: 14px;
  padding-top: 10px;
  border-top: 1px dashed #e4ebe8;
  color: #556972;
  font-size: 12px;
  font-weight: 700;
}

.dashboard-section .split-tooltip {
  width: 210px;
  padding: 12px 14px;
  border-radius: 8px;
}
.dashboard-section .split-tooltip strong {
  font-size: 13px;
  font-weight: 800;
  margin-bottom: 6px;
}
.dashboard-section .split-tooltip span {
  font-size: 12px;
  line-height: 1.5;
}
.dashboard-section .secondary-note {
  font-size: 12px;
  font-weight: 700;
  color: #556872;
  bottom: 15px;
  right: 18px;
}

.dashboard-section .panel,
.dashboard-section .ytd-panel {
  padding: 22px;
  border-radius: 14px;
}
.dashboard-section .ytd-heading {
  gap: 16px;
  padding-bottom: 14px;
}
.dashboard-section .ytd-heading small {
  font-size: 12px;
  font-weight: 900;
  letter-spacing: 0.14em;
  color: var(--blue);
}
.dashboard-section .ytd-heading h3 {
  font-size: 21px;
  font-weight: 900;
  margin-top: 3px;
  color: var(--blue-dark);
}
.dashboard-section .ytd-heading>span {
  font-size: 12.5px;
  font-weight: 800;
  padding: 6px 12px;
  border-radius: 5px;
  background: #edf4f7;
  color: var(--blue-dark);
}

.dashboard-section .ytd-tabs,
.dashboard-section .unified-tabs {
  gap: 9px;
  margin: 16px 0;
}
.dashboard-section .ytd-tabs button,
.dashboard-section .unified-tabs button {
  font-size: 14px;
  font-weight: 900;
  padding: 9px 18px;
  border-radius: 6px;
}
.dashboard-section .kpi-selector {
  gap: 8px;
  padding: 10px;
  margin-bottom: 14px;
}
.dashboard-section .kpi-selector button {
  font-size: 13px;
  font-weight: 800;
  padding: 7px 15px;
}

.dashboard-section .compact-table th,
.dashboard-section .compact-table td {
  padding: 11px 12px;
  font-size: 13.5px;
  line-height: 1.35;
}
.dashboard-section .compact-table th {
  font-size: 13.5px;
  font-weight: 900;
  background: #f1f7f5;
  color: var(--blue-dark);
}
.dashboard-section .compact-table td strong {
  font-size: 14px;
}

.dashboard-section .svg-chart-note {
  font-size: 13.5px;
  font-weight: 800;
  color: var(--blue-dark);
  padding-bottom: 10px;
  margin-bottom: 14px;
}
.dashboard-section .status-pill {
  font-size: 11.5px;
  font-weight: 800;
  padding: 3px 8px;
  border-radius: 4px;
}

.dashboard-section .peer-chart-heading {
  padding: 12px 14px;
}
.dashboard-section .peer-chart-heading b {
  font-size: 16px;
  font-weight: 900;
  color: var(--blue-dark);
}
.dashboard-section .peer-chart-heading span {
  font-size: 12px;
  font-weight: 700;
  color: #64748b;
}
.dashboard-section .peer-chart-heading em {
  font-size: 12px;
  font-weight: 800;
  color: #556570;
}
.dashboard-section .peer-chart {
  padding: 10px 4px 6px;
}
.dashboard-section .peer-row {
  min-height: 52px;
  gap: 14px;
  padding: 0 12px;
}
.dashboard-section .peer-name {
  font-size: 14.5px;
  font-weight: 800;
  color: var(--ink);
}
.dashboard-section .peer-name small {
  font-size: 11px;
  font-weight: 900;
  padding: 2px 7px;
  border-radius: 4px;
  margin-left: 6px;
}
.dashboard-section .peer-bar-track {
  height: 22px;
  border-radius: 4px;
}
.dashboard-section .peer-bar-track span {
  font-size: 12px;
  font-weight: 900;
  right: 10px;
}
.dashboard-section .peer-row>b {
  font-size: 14.5px;
  font-weight: 800;
}

.dashboard-section .ytd-insights,
.dashboard-section .unified-insights {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 12px;
  margin-top: 16px;
}
.dashboard-section .ytd-insights div,
.dashboard-section .unified-insights div {
  padding: 14px 16px;
  border-radius: 6px;
  background: #f5f8f7;
}
.dashboard-section .ytd-insights span,
.dashboard-section .unified-insights span {
  font-size: 12px;
  font-weight: 800;
  color: #556972;
}
.dashboard-section .ytd-insights strong,
.dashboard-section .unified-insights strong {
  font-size: 24px;
  font-weight: 800;
  color: var(--ink);
  margin-top: 6px;
}
.dashboard-section .ytd-insights em,
.dashboard-section .unified-insights em {
  font-size: 11.5px;
  font-style: normal;
  color: #718086;
  margin-top: 3px;
  display: block;
}

.dashboard-section .matrix>b {
  font-size: 13.5px;
  font-weight: 800;
}
.dashboard-section .matrix small {
  font-size: 11.5px;
}
.dashboard-section .merchant-bars>div {
  font-size: 12.5px;
}
.dashboard-section .twqr-grid h4 {
  font-size: 15px;
  font-weight: 900;
  color: var(--blue-dark);
}
.dashboard-section .twqr-grid h4 small {
  font-size: 12px;
  font-weight: 600;
  color: #64748b;
}
.dashboard-section .twqr-stats strong {
  font-size: 26px;
  font-weight: 800;
}
.dashboard-section .twqr-stats span,
.dashboard-section .twqr-stats b {
  font-size: 12px;
  font-weight: 800;
}

/* Block 04 Tab 3: Dual Charts (Grouped Bar + TPS Ranking) */
.dual-chart-shell {
  display: grid;
  grid-template-columns: 1.25fr 1fr;
  gap: 16px;
  margin-bottom: 14px;
}
@media (max-width: 1024px) {
  .dual-chart-shell {
    grid-template-columns: 1fr;
  }
}
.chart-box {
  background: #ffffff;
  border: 1px solid var(--line);
  border-radius: 10px;
  padding: 16px;
}
.chart-box-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 14px;
  padding-bottom: 10px;
  border-bottom: 1px solid #edf2f0;
}
.chart-box-header h3 {
  margin: 0;
  font-size: 15px;
  font-weight: 900;
  color: var(--ink);
}
.chart-box-header span {
  font-size: 12px;
  color: var(--muted);
  font-weight: 700;
}

.tps-rank-item {
  margin-bottom: 15px;
}
.tps-rank-labels {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 13px;
  margin-bottom: 5px;
}
.tps-rank-labels strong {
  color: var(--ink);
  font-weight: 800;
}
.tps-rank-labels b {
  color: var(--orange-dark);
  font-weight: 900;
}
.tps-bar-track {
  width: 100%;
  height: 13px;
  background: #eef3f1;
  border-radius: 7px;
  overflow: hidden;
  position: relative;
}
.tps-bar-fill {
  height: 100%;
  border-radius: 7px;
  transition: width 0.4s ease;
}
.tps-rank-foot {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 11px;
  color: var(--muted);
  margin-top: 3px;
}


.c-kpi-split-card {
  background: #ffffff;
  border: 1px solid #e1ebe7;
  border-radius: 6px;
  padding: 6px 8px;
}
.c-kpi-header-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.c-kpi-main-val {
  font-size: 18px;
  font-weight: 900;
  color: var(--ink);
  line-height: 1.15;
  margin: 1px 0 4px;
}
.c-kpi-main-val em {
  font-size: 11px;
  font-style: normal;
  font-weight: 600;
  color: #72848c;
}
.c-kpi-breakdown-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #f8fafb;
  border-radius: 4px;
  padding: 4px 6px;
  border: 1px solid #edf2f0;
}
.c-breakdown-item {
  display: flex;
  flex-direction: column;
  gap: 1px;
  flex: 1;
}
.b-label {
  font-size: 9.5px;
  color: #62757d;
  font-weight: 700;
}
.b-val {
  font-size: 11.5px;
  font-weight: 800;
  color: var(--ink);
}
.b-share {
  font-size: 9.5px;
  font-weight: 800;
  color: var(--orange-dark);
}
.c-breakdown-divider {
  width: 1px;
  height: 24px;
  background: #e2ebe6;
  margin: 0 6px;
}
.c-kpi-mini-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
}
.c-mini-kpi {
  background: #ffffff;
  border: 1px solid #e1ebe7;
  border-radius: 5px;
  padding: 5px 7px;
  display: flex;
  flex-direction: column;
}
.c-mini-val {
  font-size: 14.5px;
  font-weight: 900;
  color: var(--ink);
  margin: 1px 0;
}
.c-mini-val em {
  font-size: 9.5px;
  font-style: normal;
  color: #72848c;
  font-weight: 600;
}
.c-hint {
  font-size: 9.5px;
  color: #7d8f96;
  font-weight: 600;
}
.cockpit-market-vertical-wrap {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-top: 4px;
}
.cockpit-donut-center {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 2px 0;
}
.cockpit-peer-table-box {
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.cockpit-peer-table-box {
  width: 100%;
}
.cockpit-peer-header {
  display: grid;
  grid-template-columns: 66px 1fr 46px 48px;
  align-items: center;
  font-size: 10px;
  font-weight: 800;
  color: #64748b;
  padding: 2px 6px;
  border-bottom: 1px solid #e2e8f0;
  margin-bottom: 2px;
}
.cockpit-peer-header .p-name { text-align: left; }
.cockpit-peer-header .p-val { text-align: right; }
.cockpit-peer-header .p-share { text-align: right; }
.cockpit-peer-header .p-yoy { text-align: right; }

.cockpit-peer-list {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.cockpit-peer-row {
  display: grid;
  grid-template-columns: 66px 1fr 46px 48px;
  align-items: center;
  font-size: 10px;
  padding: 2.5px 6px;
  border-radius: 4px;
  background: #fff;
  border: 1px solid #edf2f0;
}
.cockpit-peer-row.highlight {
  background: #f0f9f5;
  border-color: #b5e4d2;
  font-weight: 800;
  color: var(--green);
}
.cockpit-peer-row .p-name { font-weight: 700; color: var(--ink); text-align: left; }
.cockpit-peer-row .p-val { text-align: right; color: #4b5d66; font-variant-numeric: tabular-nums; }
.cockpit-peer-row .p-share { text-align: right; color: var(--ink); }
.cockpit-peer-row .p-yoy { text-align: right; font-size: 9.5px; font-weight: 700; }

/* SECTION 00: COCKPIT VIEWPORT STYLING (ZERO SCROLL FIT) */
#section-cockpit {
  padding-bottom: 0;
}
.cockpit-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
  padding: 12px;
  background: var(--orange-soft);
  border: 1px solid var(--line);
  border-radius: 12px;
  height: calc(100vh - 165px);
  min-height: 600px;
  box-sizing: border-box;
}

@media (max-height: 800px) {
  .cockpit-grid {
    height: auto;
    min-height: 560px;
  }
}

.cockpit-col {
  background: #ffffff;
  border: 1px solid #d8e5e0;
  border-radius: 8px;
  padding: 10px 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  box-shadow: 0 1px 4px rgba(0,0,0,0.03);
}

.cockpit-col-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #e5ece9;
  padding-bottom: 6px;
}
.c-header-left {
  display: flex;
  align-items: center;
  gap: 6px;
}
.cockpit-badge {
  font-size: 11px;
  font-weight: 800;
  padding: 2px 6px;
  border-radius: 4px;
  color: #fff;
  letter-spacing: 0.02em;
}
.c-badge-orange { background: var(--orange); }
.c-badge-blue { background: var(--blue); }
.c-badge-dark { background: var(--blue-dark); }

.cockpit-col-header h3 {
  font-size: 13.5px;
  margin: 0;
  color: var(--ink);
  font-weight: 800;
  letter-spacing: -0.01em;
}
.cockpit-link-btn {
  background: none;
  border: 1px solid #cbd9df;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 700;
  color: var(--blue);
  padding: 2px 7px;
  cursor: pointer;
  transition: all 0.15s ease;
}
.cockpit-link-btn:hover {
  background: var(--blue);
  color: #fff;
  border-color: var(--blue);
}

.cockpit-subbox {
  background: #f8fafb;
  border: 1px solid #e6eeec;
  border-radius: 6px;
  padding: 8px 10px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.cockpit-subbox.flex-grow {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.cockpit-box-title {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 11.5px;
  font-weight: 800;
  color: #43555f;
}
.cockpit-tag-pill {
  font-size: 10px;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 10px;
  background: #e8eff2;
  color: #43555f;
}
.cockpit-tag-pill.primary { background: #eef5ff; color: var(--blue); }
.cockpit-tag-pill.warning { background: #fff7e7; color: #b8781c; }
.c-tag-green {
  font-size: 10.5px;
  font-weight: 800;
  color: var(--green);
  background: #eaf7f2;
  padding: 1px 5px;
  border-radius: 4px;
}

.cockpit-kpi-quad {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
}
.c-kpi-card {
  background: #ffffff;
  border: 1px solid #e1ebe7;
  border-radius: 5px;
  padding: 6px 8px;
  display: flex;
  flex-direction: column;
}
.c-kpi-card.highlight-glow {
  border-color: #b5e4d2;
  background: #fafdfc;
}
.c-kpi-title {
  font-size: 11px;
  color: #5a6d75;
  font-weight: 700;
}
.c-kpi-val {
  font-size: 18px;
  font-weight: 900;
  color: var(--ink);
  line-height: 1.15;
  margin: 2px 0;
  font-variant-numeric: tabular-nums;
}
.c-kpi-val em {
  font-size: 11px;
  font-weight: 600;
  font-style: normal;
  color: #72848c;
  margin-left: 2px;
}
.c-kpi-growth {
  font-size: 10.5px;
  display: flex;
  gap: 4px;
  align-items: center;
}
.c-kpi-sub {
  color: #7d8f96;
  font-size: 10.5px;
}

/* Removed duplicate peer table styles */

.cockpit-foot-note {
  font-size: 10.5px;
  color: #61737a;
  background: #ffffff;
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid #e5ece9;
  text-align: center;
  margin-top: 4px;
}
.cockpit-foot-note b { color: var(--orange-dark); }

.c-mini-stat-banner {
  display: flex;
  align-items: center;
  justify-content: space-around;
  background: #fff;
  border: 1px solid #e2ebe6;
  border-radius: 5px;
  padding: 6px 8px;
}
.c-mini-stat-banner small {
  font-size: 10px;
  color: #61737a;
  display: block;
}
.c-mini-stat-banner strong {
  font-size: 16px;
  font-weight: 900;
  color: var(--ink);
  display: block;
  margin: 1px 0;
}
.c-mini-stat-banner strong em {
  font-size: 10.5px;
  font-style: normal;
  color: #72848c;
}
.divider-v {
  width: 1px;
  height: 32px;
  background: #e2ebe6;
  margin: 0 6px;
}
.c-split-bar {
  display: flex;
  height: 15px;
  border-radius: 3px;
  overflow: hidden;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  text-align: center;
  line-height: 15px;
  margin: 2px 0;
}
.bar-phys { background: var(--blue); }
.bar-onl { background: var(--orange); }
.c-foot-hint { font-size: 9.5px; color: #72848c; display: block; text-align: center; }

.twqr-cockpit-section {
  background: #fff;
  border: 1px solid #e2ebe6;
  border-radius: 5px;
  padding: 6px 8px;
}
.twqr-subhead {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 10.5px;
  color: var(--blue-dark);
  font-weight: 800;
  margin-bottom: 4px;
}
.c-twqr-stat-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
}
.c-twqr-stat-grid.three-col {
  grid-template-columns: 1fr 1fr 1fr;
}
.c-twqr-cell {
  background: #f8fafb;
  border: 1px solid #edf2f0;
  border-radius: 4px;
  padding: 4px 6px;
  text-align: center;
}
.c-twqr-cell span {
  font-size: 9.5px;
  color: #6b7e86;
  display: block;
  font-weight: 700;
  white-space: nowrap;
}
.c-twqr-cell strong {
  font-size: 14.5px;
  font-weight: 900;
  color: var(--ink);
  display: block;
  margin: 1px 0;
  font-variant-numeric: tabular-nums;
}
.c-twqr-cell strong em {
  font-size: 9.5px;
  font-style: normal;
  color: #7c8e96;
  font-weight: 600;
}
.c-twqr-cell b {
  font-size: 9.5px;
  font-weight: 800;
  display: block;
  white-space: nowrap;
}

.c-stat-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
}
.c-stat-row.compact {
  gap: 4px;
}
.c-stat-item {
  background: #fff;
  border: 1px solid #e2ebe6;
  border-radius: 5px;
  padding: 5px 7px;
}
.c-stat-item.highlight-box {
  background: #f5fcf9;
  border-color: #b5e4d2;
}
.c-stat-item small {
  font-size: 9.5px;
  color: #667982;
  display: block;
  font-weight: 700;
}
.c-stat-item strong {
  font-size: 14.5px;
  font-weight: 900;
  color: var(--ink);
  display: block;
  margin: 1px 0;
  font-variant-numeric: tabular-nums;
}
.c-stat-item strong em {
  font-size: 9.5px;
  font-style: normal;
  color: #7c8e96;
  font-weight: 600;
}
.c-stat-item span {
  font-size: 9.5px;
  color: #62757d;
  font-weight: 600;
  display: block;
}

.c-progress-bar-wrap {
  display: flex;
  height: 13px;
  border-radius: 3px;
  overflow: hidden;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  text-align: center;
  line-height: 13px;
  margin-top: 3px;
}
.c-progress-fill { background: var(--green); }
.c-progress-rest { background: #cbd5e1; color: #475569; }

.fraud-total-cockpit-bar {
  display: flex;
  align-items: center;
  justify-content: space-around;
  border: 1px solid #fed7aa;
  border-radius: 5px;
  padding: 5px 8px;
  background: #fffcf8;
}
.fraud-total-cockpit-bar span {
  font-size: 9.5px;
  color: #78350f;
  font-weight: 700;
  display: block;
}
.fraud-total-cockpit-bar strong {
  font-size: 15.5px;
  font-weight: 900;
  color: #c2410c;
  display: block;
  margin-top: 1px;
}
.fraud-total-cockpit-bar strong em {
  font-size: 9.5px;
  font-style: normal;
  font-weight: 600;
}
.fraud-lines-list {
  display: flex;
  flex-direction: column;
  gap: 3px;
  margin-top: 3px;
}
.f-line-item {
  display: grid;
  grid-template-columns: 28px 1fr 62px 46px;
  align-items: center;
  font-size: 10px;
  padding: 3px 5px;
  background: #fff;
  border: 1px solid #edf2f0;
  border-radius: 4px;
}
.f-tag {
  font-size: 8.5px;
  font-weight: 900;
  padding: 1px 3px;
  border-radius: 2px;
  text-align: center;
  color: #fff;
}
.f-tag.sfm { background: var(--orange-dark); }
.f-tag.tds { background: var(--blue); }
.f-name { font-weight: 700; color: var(--ink); padding-left: 3px; }
.f-amt { text-align: right; font-weight: 800; color: var(--orange-dark); }
.f-cnt { text-align: right; color: #62757d; font-size: 9.5px; }

"""

# 3. Load Unified Data
with open(DATA_FILE, "r", encoding="utf-8") as f:
    d = json.load(f)

peer_json_str = json.dumps(d["block01_overview"]["peer_comparison"], ensure_ascii=False)

# Helper Renderers
def render_primary_card(card):
    splits_html = ""
    for sp in card.get("splits", []):
        tooltip_lines = "".join([f"<span>{line}</span>" for line in sp["tooltip"]["lines"]])
        splits_html += f"""
            <div class="split-item" tabindex="0">
              <span>{sp['label']}</span>
              <strong>{sp['value']}<em>{sp.get('unit', '')}</em></strong>
              <b class="number-positive">{sp['badge']}</b>
              <div class="split-tooltip">
                <strong>{sp['tooltip']['title']}</strong>
                {tooltip_lines}
              </div>
            </div>"""
    
    ftitle = card.get("footer_title", "")
    footer_attr = f' title="{ftitle}"' if ftitle else ""
    footer_html = f'<div class="split-foot"{footer_attr}>{card["footer"]}</div>' if "footer" in card else ""
    
    badges_html = ""
    if "badges" in card:
        for b in card["badges"]:
            cls = "number-positive" if b["type"] == "positive" else "number-negative"
            badges_html += f'<span class="{cls}"><b>{b["prefix"]}</b>{b["text"]}</span>'
    elif "yoy" in card:
        mom_html = f'<span class="number-positive"><b>MoM</b>{card["mom"]}</span>' if "mom" in card else ""
        badges_html = f'<span class="number-positive"><b>YoY</b>{card["yoy"]}</span>{mom_html}'

    return f"""
        <article class="monthly-kpi monthly-primary">
          <div class="monthly-kpi-title">{card['title']}</div>
          <div class="monthly-kpi-value">{card['value']}<em>{card.get('unit', '')}</em></div>
          <div class="monthly-growth">
            {badges_html}
          </div>
          <div class="monthly-split">
            {splits_html}
          </div>
          {footer_html}
        </article>"""

def render_secondary_card(card):
    badges_html = ""
    if "badges" in card:
        for b in card["badges"]:
            cls = "number-positive" if b["type"] == "positive" else "number-negative"
            badges_html += f'<span class="{cls}"><b>{b["prefix"]}</b>{b["text"]}</span>'
    else:
        cls_yoy = "number-positive" if card.get("is_positive_yoy", True) else "number-negative"
        cls_mom = "number-positive" if card.get("is_positive_mom", True) else "number-negative"
        badges_html = f'<span class="{cls_yoy}"><b>YoY</b>{card["yoy"]}</span><span class="{cls_mom}"><b>MoM</b>{card["mom"]}</span>'
    
    note_html = f'<span class="secondary-note" title="{card.get("note_title", "")}">{card["note"]}</span>' if "note" in card else ""
    unit_str = f"<em>{card['unit']}</em>" if "unit" in card else ""
    
    return f"""
        <article class="monthly-kpi monthly-secondary">
          <div class="monthly-kpi-title">{card['title']}</div>
          <div class="monthly-kpi-value">{card['value']}{unit_str}</div>
          <div class="monthly-growth">
            {badges_html}
          </div>
          {note_html}
        </article>"""

def render_insights(insights, cols=4):
    style_attr = ' style="grid-template-columns: repeat(3, 1fr);"' if cols == 3 else ""
    items = "".join([f"<div><span>{ins['label']}</span><strong>{ins['value']}</strong><em>{ins['note']}</em></div>" for ins in insights])
    return f"""
          <div class="unified-insights"{style_attr}>
            {items}
          </div>"""


import math

def get_cockpit_donut_svg():
    slices = [
        {"name": "中國信託", "share": 19.5, "color": "#003b5c"},
        {"name": "國泰世華", "share": 18.6, "color": "#009e73"},
        {"name": "台北富邦", "share": 14.5, "color": "#2563eb"},
        {"name": "玉山銀行", "share": 14.1, "color": "#059669"},
        {"name": "其他同業", "share": 33.3, "color": "#cbd5e1"}
    ]
    cx, cy, r_out, r_in = 60, 60, 52, 32
    paths = []
    start_angle = -90.0
    for s in slices:
        angle_len = (s["share"] / 100.0) * 360.0
        end_angle = start_angle + angle_len
        rad_start = math.radians(start_angle)
        rad_end = math.radians(end_angle)
        x1_out = cx + r_out * math.cos(rad_start)
        y1_out = cy + r_out * math.sin(rad_start)
        x2_out = cx + r_out * math.cos(rad_end)
        y2_out = cy + r_out * math.sin(rad_end)
        x1_in = cx + r_in * math.cos(rad_end)
        y1_in = cy + r_in * math.sin(rad_end)
        x2_in = cx + r_in * math.cos(rad_start)
        y2_in = cy + r_in * math.sin(rad_start)
        large_arc = 1 if angle_len > 180 else 0
        path_d = f"M {x1_out:.2f} {y1_out:.2f} A {r_out} {r_out} 0 {large_arc} 1 {x2_out:.2f} {y2_out:.2f} L {x1_in:.2f} {y1_in:.2f} A {r_in} {r_in} 0 {large_arc} 0 {x2_in:.2f} {y2_in:.2f} Z"
        paths.append(f'<path d="{path_d}" fill="{s["color"]}" stroke="#ffffff" stroke-width="1.5"><title>{s["name"]}: {s["share"]}%</title></path>')
        start_angle = end_angle
    return f'''<svg viewBox="0 0 120 120" width="96" height="96" style="display:block; margin:0 auto;">
        {''.join(paths)}
        <circle cx="{cx}" cy="{cy}" r="{r_in}" fill="#ffffff" />
        <text x="{cx}" y="{cy-3}" font-size="9.5" font-weight="900" fill="#003b5c" text-anchor="middle">全市場</text>
        <text x="{cx}" y="{cy+9}" font-size="8.5" font-weight="700" fill="#64748b" text-anchor="middle">30,720億</text>
    </svg>'''

def render_cockpit_section(d):
    b1 = d["block01_overview"]
    b2 = d["block02_acquiring"]
    b3 = d["block03_issuing"]
    b4 = d["block04_resilience"]

    donut_svg = get_cockpit_donut_svg()

    peers_list = [
        {"name": "中國信託", "val": 5980.0, "share": 19.5, "yoy": "+11.2%", "rank": 1, "is_me": False},
        {"name": "國泰世華", "val": 5726.0, "share": 18.6, "yoy": "+12.8%", "rank": 2, "is_me": True},
        {"name": "台北富邦", "val": 4450.0, "share": 14.5, "yoy": "+18.4%", "rank": 3, "is_me": False},
        {"name": "玉山銀行", "val": 4320.0, "share": 14.1, "yoy": "+9.6%", "rank": 4, "is_me": False}
    ]

    peer_rows_html = "".join([f'''
      <div class="cockpit-peer-row {"highlight" if p["is_me"] else ""}">
        <span class="p-name">{p["name"]}</span>
        <span class="p-val">{p["val"]:,.0f} 億</span>
        <span class="p-share"><b>{p["share"]}%</b></span>
        <span class="p-yoy number-positive">{p["yoy"]}</span>
      </div>''' for p in peers_list])

    return f"""
  <!-- ========================================================
       SECTION 00: 信用卡營運總覽 (SINGLE-VIEWPORT NO-SCROLL COCKPIT)
       ======================================================== -->
  <section id="section-cockpit" class="dashboard-section main-section active">
    <div class="section-title section-orange">
      <span>00</span>
      <h2>信用卡營運總覽</h2>
      <i></i>
    </div>

    <div class="cockpit-grid">
      <!-- COLUMN 1: 01 全行概況 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <span class="cockpit-badge c-badge-orange">01 全行概況</span>
        </div>

        <!-- 總交易金額 & 總交易筆數 (含一般/分期絕對金額、筆數與佔比) -->
        <div class="cockpit-subbox">
          <!-- Card 1: 總交易金額 -->
          <div class="c-kpi-split-card">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">總交易金額</span>
              <div class="c-kpi-growth"><span class="number-positive">YoY +12.8%</span> <span class="number-positive">MoM +2.1%</span></div>
            </div>
            <div class="c-kpi-main-val">1,286.4 <em>億元</em></div>
            <div class="c-kpi-breakdown-row">
              <div class="c-breakdown-item">
                <span class="b-label">一般交易</span>
                <strong class="b-val">1,086.4 億</strong>
                <span class="b-share">佔比 84.4%</span>
              </div>
              <div class="c-breakdown-divider"></div>
              <div class="c-breakdown-item">
                <span class="b-label">分期交易</span>
                <strong class="b-val">200.0 億</strong>
                <span class="b-share">佔比 15.6%</span>
              </div>
            </div>
          </div>

          <!-- Card 2: 總交易筆數 -->
          <div class="c-kpi-split-card" style="margin-top: 3px;">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">總交易筆數</span>
              <div class="c-kpi-growth"><span class="number-positive">YoY +15.2%</span> <span class="number-positive">MoM +1.7%</span></div>
            </div>
            <div class="c-kpi-main-val">8,425 <em>萬筆</em></div>
            <div class="c-kpi-breakdown-row">
              <div class="c-breakdown-item">
                <span class="b-label">一般交易</span>
                <strong class="b-val">7,750 萬筆</strong>
                <span class="b-share">佔比 92.0%</span>
              </div>
              <div class="c-breakdown-divider"></div>
              <div class="c-breakdown-item">
                <span class="b-label">分期交易</span>
                <strong class="b-val">675 萬筆</strong>
                <span class="b-share">佔比 8.0%</span>
              </div>
            </div>
          </div>

          <!-- Mini Row: 預借現金 & 循環信用 -->
          <div class="c-kpi-mini-grid" style="margin-top: 3px;">
            <div class="c-mini-kpi">
              <span class="c-kpi-title">預借現金金額</span>
              <strong class="c-mini-val">18.6 <em>億元</em></strong>
              <div class="c-kpi-growth"><span class="number-negative">YoY -3.4%</span> <span class="c-hint">42.8萬筆</span></div>
            </div>
            <div class="c-mini-kpi">
              <span class="c-kpi-title">循環信用餘額</span>
              <strong class="c-mini-val">325.7 <em>億元</em></strong>
              <div class="c-kpi-growth"><span class="number-positive">YoY +6.7%</span> <span class="c-hint">生息資產</span></div>
            </div>
          </div>
        </div>

        <!-- 四大發卡行簽帳金額與市佔 (圓餅圖 + 表頭項目名稱 + 無註解) -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>四大發卡行簽帳金額與市佔</span>
            <span class="cockpit-tag-pill">2026 年 1–8 月</span>
          </div>

          <div class="cockpit-market-vertical-wrap">
            <div class="cockpit-donut-center">
              {donut_svg}
            </div>
            <div class="cockpit-peer-table-box">
              <div class="cockpit-peer-header">
                <span class="p-name">發卡銀行</span>
                <span class="p-val">簽帳金額</span>
                <span class="p-share">市占率</span>
                <span class="p-yoy">YoY</span>
              </div>
              <div class="cockpit-peer-list">
                {peer_rows_html}
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- COLUMN 2: 02 收單業務 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <span class="cockpit-badge c-badge-blue">02 收單業務</span>
        </div>

        <!-- 自行收單核心概況 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>自行收單大盤</span>
            <span class="c-tag-green">活店率 83.0%</span>
          </div>
          <div class="c-mini-stat-banner">
            <div>
              <small>收單總金額</small>
              <strong>285.0<em>億</em></strong>
              <b class="number-positive">YoY +12.8%</b>
            </div>
            <div class="divider-v"></div>
            <div>
              <small>實體 / 線上 EPOS</small>
              <div class="c-split-bar">
                <span class="bar-phys" style="width: 65%;">65% 實體</span>
                <span class="bar-onl" style="width: 35%;">35% 線上</span>
              </div>
              <small class="c-foot-hint">平均客單：1,540 元（+1.2%）</small>
            </div>
          </div>
        </div>

        <!-- TWQR 業務分析專區 (特店進件 + 交易造血) -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>TWQR 國家共同標準業務分析</span>
            <span class="cockpit-tag-pill primary">特店拓點特刊</span>
          </div>

          <!-- TWQR Top Block: 特店進件分析 -->
          <div class="twqr-cockpit-section">
            <div class="twqr-subhead">
              <b>拓展 Pipeline</b>
              <span>通過率 91.2%</span>
            </div>
            <div class="c-twqr-stat-grid">
              <div class="c-twqr-cell">
                <span>當月申請進件數</span>
                <strong>3,850 <em>件</em></strong>
                <b class="number-positive">審查通過率 91.2%</b>
              </div>
              <div class="c-twqr-cell">
                <span>累計特店家數</span>
                <strong>22,100 <em>家</em></strong>
                <b class="number-positive">MoM +5.8% (+1,210家)</b>
              </div>
            </div>
          </div>

          <!-- TWQR Bottom Block: 交易狀態造血動能 -->
          <div class="twqr-cockpit-section" style="margin-top: 8px;">
            <div class="twqr-subhead">
              <b>交易造血動能</b>
              <span>動用特店率 68.2%</span>
            </div>
            <div class="c-twqr-stat-grid three-col">
              <div class="c-twqr-cell">
                <span>當月交易金額</span>
                <strong>14.8 <em>億</em></strong>
                <b class="number-positive">MoM +18.5%</b>
              </div>
              <div class="c-twqr-cell">
                <span>當月交易筆數</span>
                <strong>185 <em>萬筆</em></strong>
                <b class="number-positive">MoM +16.2%</b>
              </div>
              <div class="c-twqr-cell">
                <span>平均客單價</span>
                <strong>800 <em>元</em></strong>
                <b class="number-positive">MoM +2.0%</b>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- COLUMN 3: 03 發卡業務 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <span class="cockpit-badge c-badge-orange">03 發卡業務</span>
        </div>

        <!-- 徵審進件中樞 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>徵審進件中樞自動化</span>
            <span class="c-tag-green">STP 核准率 76.5%</span>
          </div>
          <div class="c-stat-row">
            <div class="c-stat-item">
              <small>當月申辦總量</small>
              <strong>85,400 <em>件</em></strong>
              <span>舊戶 4.7 萬 ｜ 新戶 3.84 萬</span>
            </div>
            <div class="c-stat-item highlight-box">
              <small>自動直接核准</small>
              <strong style="color:var(--green);">65,300 <em>件</em></strong>
              <span>綜合自動核准率 76.5%</span>
            </div>
          </div>
          <div class="c-progress-bar-wrap">
            <div class="c-progress-fill" style="width: 76.5%;">自動核准 76.5%</div>
            <div class="c-progress-rest" style="width: 23.5%;">人工 23.5%</div>
          </div>
        </div>

        <!-- 信用卡電子帳單數據 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>帳單數據與數位降本</span>
            <span class="cockpit-tag-pill">覆蓋率 91.8%</span>
          </div>
          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>電子帳單總本數</small>
              <strong>520.0 <em>萬本</em></strong>
              <span class="number-positive">YoY +6.8%</span>
            </div>
            <div class="c-stat-item">
              <small>紙本帳單節約</small>
              <strong>42.6 <em>萬本</em></strong>
              <span class="number-positive">YoY −8.0%</span>
            </div>
          </div>
        </div>

        <!-- 小樹點概況 (TAB 3 水庫循環) -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>小樹點水庫循環概況 (TAB 3)</span>
            <span class="c-tag-green">兌換率 84.2%</span>
          </div>
          <div class="c-twqr-stat-grid three-col">
            <div class="c-twqr-cell">
              <span>水庫流通累積</span>
              <strong>48.2 <em>億點</em></strong>
              <b class="number-positive">活水循環</b>
            </div>
            <div class="c-twqr-cell">
              <span>當月贈送點數</span>
              <strong>3.8 <em>億點</em></strong>
              <b class="number-positive">YoY +18.7%</b>
            </div>
            <div class="c-twqr-cell">
              <span>當月兌換點數</span>
              <strong>3.2 <em>億點</em></strong>
              <b class="number-positive">YoY +23.1%</b>
            </div>
          </div>
        </div>
      </div>

      <!-- COLUMN 4: 04 系統韌性 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <span class="cockpit-badge c-badge-dark">04 系統韌性</span>
        </div>

        <!-- CardPool 授權核心主機 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>CardPool 授權核心主機</span>
            <span class="c-tag-green">可用率 99.999%</span>
          </div>
          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>交易響應時間</small>
              <strong style="color:var(--green);">85 <em>ms</em></strong>
              <span class="number-positive">零超時 (0筆)</span>
            </div>
            <div class="c-stat-item">
              <small>月授權交易量</small>
              <strong>6,820 <em>萬筆</em></strong>
              <span>成功率 98.8%</span>
            </div>
          </div>
        </div>

        <!-- Cardlink 核心帳務主機 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>Cardlink 核心帳務主機</span>
            <span class="c-tag-green">SLA 100% 達標</span>
          </div>
          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>月帳務處理量</small>
              <strong>1.42 <em>億筆</em></strong>
              <span>高可靠運作</span>
            </div>
            <div class="c-stat-item">
              <small>系統可用率 / 峰值</small>
              <strong>100.0%</strong>
              <span>峰值 4,850 TPS</span>
            </div>
          </div>
        </div>

        <!-- 三大資安防詐防線成果 (SFM & 3DS) -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>三大資安防詐成果 (SFM & 3DS)</span>
            <span class="cockpit-tag-pill warning">全月防堵 4,280 萬</span>
          </div>

          <!-- Total Banner -->
          <div class="fraud-total-cockpit-bar">
            <div>
              <span>全月總防堵金額</span>
              <strong>4,280 <em>萬元</em></strong>
            </div>
            <div class="divider-v"></div>
            <div>
              <span>阻斷冒用卡數</span>
              <strong>2,684 <em>張</em></strong>
            </div>
          </div>

          <!-- 3-line Breakdown -->
          <div class="fraud-lines-list">
            <div class="f-line-item">
              <span class="f-tag sfm">SFM</span>
              <span class="f-name">申請詐欺防堵</span>
              <span class="f-amt">1,150 萬元</span>
              <span class="f-cnt">842 張</span>
            </div>
            <div class="f-line-item">
              <span class="f-tag tds">3DS</span>
              <span class="f-name">線上交易防堵</span>
              <span class="f-amt">860 萬元</span>
              <span class="f-cnt">620 張</span>
            </div>
            <div class="f-line-item">
              <span class="f-tag sfm">SFM</span>
              <span class="f-name">交易詐欺防堵</span>
              <span class="f-amt">2,270 萬元</span>
              <span class="f-cnt">1,222 張</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
"""


b0_cockpit_html = render_cockpit_section(d)

# Render Block 01
b1 = d["block01_overview"]
b1_kpis_html = "".join([render_primary_card(c) if "splits" in c else render_secondary_card(c) for c in b1["kpis"]])
b1_insights_html = render_insights(b1["insights"])

# Render Block 02
b2 = d["block02_acquiring"]
b2_pri_html = "".join([render_primary_card(c) for c in b2["kpis_primary"]])
b2_sec_html = "".join([render_secondary_card(c) for c in b2["kpis_secondary"]])

# B2 Tab 1
b2_t1 = b2["tab1_channel"]
b2_t1_bars = "".join([f'<div style="background:{bar["color"]}; width:{bar["pct"]};"><span>{bar["label"]} {bar["amount"]} ({bar["pct"]})</span></div>' for bar in b2_t1["structure_bars"]])
b2_t1_rows = "".join([f"""
                <tr>
                  <td><strong>{r['channel']}</strong></td>
                  <td><strong>{r['amount']}</strong></td>
                  <td>{r['tx_count']}</td>
                  <td><strong class="{'is-good' if r['yoy_amount'].startswith('+') else 'is-warn'}">{r['yoy_amount']}</strong> / {r['yoy_count']}</td>
                  <td>{r['avg_ticket']}</td>
                  <td>{r['note']}</td>
                </tr>""" for r in b2_t1["rows"]])
b2_t1_insights = render_insights(b2_t1["insights"])

# B2 Tab 2
b2_t2 = b2["tab2_merchants"]
b2_t2_merchants = "".join([f'<div><span>{m["name"]}</span><b>{m["amount"]} <small class="{m["status"]}">({m["yoy"]})</small></b></div>' for m in b2_t2["top_merchants"]])
q = b2_t2["quadrants"]
b2_t2_insights = render_insights(b2_t2["insights"])

# B2 Tab 3
b2_t3 = b2["tab3_mcc"]
b2_t3_rows = "".join([f"""
                <tr>
                  <td>{ind['name']}</td>
                  <td>{ind['merchants']}</td>
                  <td>{ind['merchant_share']}</td>
                  <td><strong>{ind['amount']}</strong></td>
                  <td>{ind['amount_share']}</td>
                  <td>{ind['avg_store_rev']}</td>
                </tr>""" for ind in b2_t3["industries"]])
tot = b2_t3["total"]
b2_t3_total = f"""
                <tr style="background:#f0f7f5; font-weight:700;">
                  <td><strong>{tot['name']}</strong></td>
                  <td><strong>{tot['merchants']}</strong></td>
                  <td><strong>{tot['merchant_share']}</strong></td>
                  <td><strong style="color:var(--orange-dark);">{tot['amount']}</strong></td>
                  <td><strong>{tot['amount_share']}</strong></td>
                  <td><strong>{tot['avg_store_rev']}</strong></td>
                </tr>"""
b2_t3_insights = render_insights(b2_t3["insights"])

# B2 TWQR
tw = b2["twqr"]
tw_s1 = "".join([f'<div><span>{it["label"]}</span><strong>{it["value"]}</strong><b class="{"is-good" if it["is_good"] else ""}">{it["badge"]}</b></div>' for it in tw["section1"]["items"]])
tw_s2 = "".join([f'<div><span>{it["label"]}</span><strong>{it["value"]}</strong><b class="{"is-good" if it["is_good"] else ""}">{it["badge"]}</b></div>' for it in tw["section2"]["items"]])
tw_insights = render_insights(tw["insights"], cols=3)

# Render Block 03
b3 = d["block03_issuing"]
b3_pri_html = "".join([render_primary_card(c) for c in b3["kpis_primary"]])
b3_sec_html = "".join([render_secondary_card(c) for c in b3["kpis_secondary"]])
b3_t0_insights = render_insights(b3["tab0_sankey"]["insights"])
b3_t1_insights = render_insights(b3["tab1_installments"]["insights"])
b3_t2_insights = render_insights(b3["tab2_tree_points"]["insights"])
b3_t3_insights = render_insights(b3["tab3_collection"]["insights"])

# Render Block 04
b4 = d["block04_resilience"]
b4_pri_html = "".join([render_primary_card(c) for c in b4["kpis_primary"]])

# B4 Tab 0
b4_t0 = b4["tab1_events"]
b4_t0_rows = "".join([f"""
                <tr>
                  <td><strong>{ev['date']}</strong> ｜ {ev['name']}</td>
                  <td>{ev['peak_time']}</td>
                  <td>{ev['specs']}</td>
                  <td><strong style="color:var(--orange-dark);">{ev['peak_tps']}</strong></td>
                  <td><strong class="is-good">{ev['max_cpu']}</strong></td>
                  <td>{ev['note']}</td>
                </tr>""" for ev in b4_t0["events"]])
b4_t0_insights = render_insights(b4_t0["insights"])

# B4 Tab 1
b4_t1 = b4["tab2_fraud"]
b4_t1_rows = "".join([f"""
                <tr>
                  <td><strong>{item['name']}</strong></td>
                  <td>{item['system']}</td>
                  <td>{item['domain']}</td>
                  <td><strong>{item['cards']}</strong></td>
                  <td><strong style="color:var(--ink);">{item['amount']}</strong></td>
                  <td>{item['avg_card']}</td>
                  <td>{item['share']}</td>
                </tr>""" for item in b4_t1["items"]])
f_tot = b4_t1["total"]
b4_t1_total = f"""
                <tr style="background:#f0f7f5; font-weight:700;">
                  <td><strong>{f_tot['name']}</strong></td>
                  <td><strong>{f_tot['system']}</strong></td>
                  <td><strong>{f_tot['domain']}</strong></td>
                  <td><strong style="color:var(--orange-dark);">{f_tot['cards']}</strong></td>
                  <td><strong style="color:var(--orange-dark);">{f_tot['amount']}</strong></td>
                  <td><strong>{f_tot['avg_card']}</strong></td>
                  <td><strong>{f_tot['share']}</strong></td>
                </tr>"""
b4_t1_insights = render_insights(b4_t1["insights"])

# B4 Tab 2: Microservices Dual-Chart Layout
b4_t2 = b4["tab3_microservices"]
b4_t2_cards = "".join([f"""
            <article class="monthly-kpi monthly-secondary">
              <div class="monthly-kpi-title">{c['name']}</div>
              <div class="monthly-kpi-value">{c['value']}<em>{c['unit']}</em></div>
              <div class="monthly-growth">
                <span class="number-positive"><b>YoY</b>{c['yoy']}</span>
                <span class="number-positive"><b>峰值</b>{c['peak_tps']}</span>
              </div>
              <span class="secondary-note" title="{c['note']}">{c['note']}</span>
            </article>""" for c in b4_t2["overview_cards"]])

# Microservices Grouped Bars SVG Dynamic Calculation
scale = 160.0 / b4_t2["services_chart"]["max_scale"]
baseline_y = 185
chart_groups_svg = ""
x_offsets = [65, 180, 295, 410]

for idx, s in enumerate(b4_t2["services_chart"]["services"]):
    x_base = x_offsets[idx]
    h_last = s["y_last_year"] * scale
    y_last = baseline_y - h_last
    h_prev = s["y_prev_month"] * scale
    y_prev = baseline_y - h_prev
    h_cur = s["y_cur_month"] * scale
    y_cur = baseline_y - h_cur
    
    # YoY Badge
    min_bar_y = min(y_last, y_prev, y_cur)
    badge_y = max(8, min_bar_y - 21.8)
    badge_text_y = badge_y + 12
    badge_x = x_base + 5
    badge_text_x = x_base + 36
    label_x = x_base + 36

    chart_groups_svg += f"""
            <!-- Group {idx+1}: {s['name']} -->
            <rect x="{x_base}" y="{y_last:.1f}" width="22" height="{h_last:.1f}" rx="3" fill="#cbd5e1"/>
            <rect x="{x_base+25}" y="{y_prev:.1f}" width="22" height="{h_prev:.1f}" rx="3" fill="#4a7c98"/>
            <rect x="{x_base+50}" y="{y_cur:.1f}" width="22" height="{h_cur:.1f}" rx="3" fill="#009e73"/>
            <rect x="{badge_x}" y="{badge_y:.1f}" width="62" height="16" rx="3" fill="#eaf7f2" stroke="#c2ebd9"/>
            <text x="{badge_text_x}" y="{badge_text_y:.1f}" font-size="9.5" font-weight="900" fill="#007a5e" text-anchor="middle">{s['yoy']} YoY</text>
            <text x="{label_x}" y="202" font-size="12" font-weight="800" fill="#12344d" text-anchor="middle">{s['name']}</text>"""

# Right: TPS Ranking Items
tps_rank_html = ""
for idx, s in enumerate(b4_t2["services_chart"]["services"]):
    mb_style = ' style="margin-bottom:0;"' if idx == len(b4_t2["services_chart"]["services"]) - 1 else ""
    tps_rank_html += f"""
              <div class="tps-rank-item"{mb_style}>
                <div class="tps-rank-labels">
                  <span><strong>{idx+1}. {s['name']}</strong> <span class="status-pill {s['badge_type']}" style="margin-left:4px;">{s['badge']}</span></span>
                  <b>{s['peak_tps']:,} TPS <small style="color:var(--muted); font-weight:normal;">/ {s['capacity']:,} 容量</small></b>
                </div>
                <div class="tps-bar-track">
                  <div class="tps-bar-fill" style="width: {s['fill_pct']}%; background: {s['gradient']};"></div>
                </div>
                <div class="tps-rank-foot">
                  <span>月請求 {s['y_cur_month']:,} 萬次 (佔 {s['share_pct']})</span>
                  <span>{s['foot_latency']}</span>
                </div>
              </div>"""

b4_t2_insights = render_insights(b4_t2["insights"])

# Generate Complete HTML
html_template = f"""<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{d['meta']['title']} ({d['meta']['year']}/{d['meta']['month']})</title>
  <style>
{clean_css}
{extra_css}
  </style>
</head>
<body>
<main>
  <!-- TOPBAR -->
  <header class="topbar">
    <div class="brand-ribbon">{d['meta']['brand']}</div>
    <div class="dashboard-title">
      <span>{d['meta']['header_title']}</span>
    </div>
    <div class="period">
      <strong>{d['meta']['year']}</strong>
      <b>{d['meta']['month']}</b>
      <span>{d['meta']['period_label']}</span>
    </div>
  </header>

  <!-- SINGLE-PAGE MAIN SECTION SUBNAV -->
  <nav class="subnav">
    <div class="nav-links">
      <button type="button" class="nav-tab-btn active" data-target="section-cockpit" onclick="switchMainSection('section-cockpit')">
        <span class="nav-num">00</span> 總覽
      </button>
      <button type="button" class="nav-tab-btn" data-target="section-overview" onclick="switchMainSection('section-overview')">
        <span class="nav-num">01</span> 全行概況
      </button>
      <button type="button" class="nav-tab-btn" data-target="section-acquiring" onclick="switchMainSection('section-acquiring')">
        <span class="nav-num">02</span> 收單業務
      </button>
      <button type="button" class="nav-tab-btn" data-target="section-issuing" onclick="switchMainSection('section-issuing')">
        <span class="nav-num">03</span> 發卡業務
      </button>
      <button type="button" class="nav-tab-btn" data-target="section-resilience" onclick="switchMainSection('section-resilience')">
        <span class="nav-num">04</span> 系統韌性
      </button>
    </div>
  </nav>

  {b0_cockpit_html}

  <!-- ========================================================
       SECTION 01: 全行概況 (OVERVIEW BASELINE)
       ======================================================== -->
  <section id="section-overview" class="dashboard-section main-section">
    <div class="section-title section-orange">
      <span>01</span>
      <h2>信用卡整體經營概況</h2>
      <i></i>
    </div>
    <div class="business-grid">
      <div class="block-intro">
        <p>2026/08 經營月報 <i>×</i> 全行核心營運指標與同業競爭態勢</p>
      </div>

      <!-- 1A: Monthly KPI Cards (2 Primary + 2 Secondary) -->
      <div class="monthly-kpi-layout-4">
        {b1_kpis_html}
      </div>

      <!-- 1B: 同業 YTD 經營比較 (Panel Directly Leads, Zero Clutter) -->
      <article class="panel ytd-panel" style="margin-top: 14px;">
        <div class="ytd-heading">
          <div>
            <small>YTD PEER COMPETITIVE BENCHMARK</small>
            <h3>同業 YTD 經營比較</h3>
            <p style="margin: 4px 0 0; color: #5d6f78; font-size: 13px;">四家主要發卡行 2026 年 1–8 月累計經營成果對標分析。</p>
          </div>
          <span>累計數據 ｜ 同期比較 ｜ 市場份額</span>
        </div>

        <!-- Category Tabs -->
        <div class="ytd-tabs" id="ytd-category-tabs"></div>

        <!-- Metric Selector -->
        <div class="kpi-selector" id="ytd-metric-selector"></div>

        <!-- Peer Comparison Chart Card -->
        <div class="peer-chart-card">
          <div class="peer-chart-heading">
            <b id="peer-chart-title">簽帳金額｜2026 年 1–8 月</b>
            <span id="peer-chart-unit">單位：億元</span>
            <em>市場 YoY 基準對照</em>
          </div>
          <div class="peer-chart" id="peer-chart-rows"></div>
        </div>

        <!-- Dynamic Peer Insights Strip -->
        <div class="ytd-insights" id="peer-insights"></div>
      </article>
    </div>
  </section>

  <!-- ========================================================
       SECTION 02: 收單業務 (UNIFIED WITH 01 BASELINE)
       ======================================================== -->
  <section id="section-acquiring" class="dashboard-section main-section">
    <div class="section-title section-blue">
      <span>02</span>
      <h2>收單業務</h2>
      <i></i>
    </div>
    <div class="business-grid">
      <div class="block-intro">
        <p>2026/08 經營月報 <i>×</i> 自行收單特店、多元管道與 TWQR 拓點動能</p>
      </div>

      <!-- 2A Primary (3 Cards formatted exactly like Block 01) -->
      <div class="monthly-kpi-layout-3">
        {b2_pri_html}
      </div>

      <!-- 2A Secondary (4 Cards formatted exactly like Block 01) -->
      <div class="monthly-kpi-layout-4">
        {b2_sec_html}
      </div>

      <!-- 收單深入診斷圖表 (Panel Directly Leads, Zero Clutter) -->
      <article class="panel ytd-panel" style="margin-top: 14px;">
        <div class="ytd-heading">
          <div>
            <small>ACQUIRING DIAGNOSIS CHARTS</small>
            <h3>收單深入診斷圖表</h3>
            <p style="margin: 4px 0 0; color: #5d6f78; font-size: 13px;">深入追蹤實體/線上渠道消長、特店經營集中度與產業請款規模。</p>
          </div>
          <span>雲地分布 ｜ 特店矩陣 ｜ 產業結構</span>
        </div>

        <div class="unified-tabs" id="acq-diag-tabs">
          <button type="button" class="active" onclick="switchAcqTab(0)">TAB 1｜交易型態分布診斷 (雲地端結構)</button>
          <button type="button" onclick="switchAcqTab(1)">TAB 2｜特店集中度與 2x2 矩陣</button>
          <button type="button" onclick="switchAcqTab(2)">TAB 3｜產業 MCC 結構分布</button>
        </div>

        <!-- 2B Tab 0: 交易型態分布診斷 -->
        <div id="acq-tab-0" class="tab-content active">
          <div class="structure-bar" style="margin-bottom:14px;">
            {b2_t1_bars}
          </div>

          <div class="compact-table" style="margin-bottom:14px;">
            <table>
              <thead>
                <tr>
                  <th>交易型態</th>
                  <th>交易金額</th>
                  <th>交易筆數</th>
                  <th>YoY（金額／筆數）</th>
                  <th>平均客單價</th>
                  <th>特性備註</th>
                </tr>
              </thead>
              <tbody>
                {b2_t1_rows}
              </tbody>
            </table>
          </div>

          <!-- Unified Bottom Insights Strip -->
          {b2_t1_insights}
        </div>

        <!-- 2B Tab 1: 特店集中度與 2x2 矩陣 -->
        <div id="acq-tab-1" class="tab-content">
          <div style="display:grid; grid-template-columns: 1fr 1.2fr; gap:16px; margin-bottom:14px;">
            <div style="background:#fbfdfc; border:1px solid #dce6e2; border-radius:8px; padding:14px;">
              <h4 style="font-size:14px; font-weight:800; color:var(--ink); margin-bottom:10px;">Top 5 核心特店經營概況</h4>
              <div class="merchant-bars" style="display:grid; gap:8px;">
                {b2_t2_merchants}
              </div>
            </div>
            <div style="background:#fbfdfc; border:1px solid #dce6e2; border-radius:8px; padding:14px;">
              <h4 style="font-size:14px; font-weight:800; color:var(--ink); margin-bottom:10px;">特店經營 2×2 矩陣定位</h4>
              <div style="display:grid; grid-template-columns: 1fr 1fr; gap:8px;">
                <div class="matrix" style="background:#fff; border:1px solid #e1e9e6; border-radius:6px; padding:10px;">
                  <b>{q['q1']['name']}</b>
                  <p>{q['q1']['desc']}</p>
                  <small>{q['q1']['items']}</small>
                </div>
                <div class="matrix" style="background:#eaf7f2; border:1px solid #b5e4d2; border-radius:6px; padding:10px;">
                  <b style="color:var(--green);">{q['q2']['name']}</b>
                  <p>{q['q2']['desc']}</p>
                  <small>{q['q2']['items']}</small>
                </div>
                <div class="matrix" style="background:#fff; border:1px solid #e1e9e6; border-radius:6px; padding:10px;">
                  <b>{q['q3']['name']}</b>
                  <p>{q['q3']['desc']}</p>
                  <small>{q['q3']['items']}</small>
                </div>
                <div class="matrix" style="background:#fff7e7; border:1px solid #fae1b8; border-radius:6px; padding:10px;">
                  <b style="color:var(--orange-dark);">{q['q4']['name']}</b>
                  <p>{q['q4']['desc']}</p>
                  <small>{q['q4']['items']}</small>
                </div>
              </div>
            </div>
          </div>

          <!-- Unified Bottom Insights Strip -->
          {b2_t2_insights}
        </div>

        <!-- 2B Tab 2: 產業 MCC 結構分布 -->
        <div id="acq-tab-2" class="tab-content">
          <div class="compact-table" style="margin-bottom:14px;">
            <table>
              <thead>
                <tr>
                  <th>產業類別</th>
                  <th>特店家數</th>
                  <th>家數占比</th>
                  <th>請款金額</th>
                  <th>金額占比</th>
                  <th>店均請款金額</th>
                </tr>
              </thead>
              <tbody>
                {b2_t3_rows}
                {b2_t3_total}
              </tbody>
            </table>
          </div>

          <!-- Unified Bottom Insights Strip -->
          {b2_t3_insights}
        </div>
      </article>

      <!-- TWQR 業務分析專區 (Panel Directly Leads, Zero Clutter) -->
      <article class="panel ytd-panel" style="margin-top: 14px;">
        <div class="ytd-heading">
          <div>
            <small>{tw['subtitle']}</small>
            <h3>{tw['title']}</h3>
            <p style="margin: 4px 0 0; color: #5d6f78; font-size: 13px;">{tw['subtitle']}</p>
          </div>
          <span>{tw['tags']}</span>
        </div>
        <div class="twqr-grid" style="margin-top:12px;">
          <section>
            <h4>{tw['section1']['title']} <small>{tw['section1']['sub']}</small></h4>
            <div class="twqr-stats">
              {tw_s1}
            </div>
          </section>
          <section>
            <h4>{tw['section2']['title']} <small>{tw['section2']['sub']}</small></h4>
            <div class="twqr-stats four">
              {tw_s2}
            </div>
          </section>
        </div>
        <!-- Unified Bottom Insights Strip -->
        {tw_insights}
      </article>
    </div>
  </section>

  <!-- ========================================================
       SECTION 03: 發卡業務 (UNIFIED WITH 01 BASELINE)
       ======================================================== -->
  <section id="section-issuing" class="dashboard-section issuing-section main-section">
    <div class="section-title section-orange">
      <span>03</span>
      <h2>發卡業務</h2>
      <i></i>
    </div>
    <div class="business-grid">
      <div class="block-intro">
        <p>2026/08 經營月報 <i>×</i> 申辦進件中樞、三大分期雙軸、小樹點水庫與催收資產品質</p>
      </div>

      <!-- 3A Primary (3 Cards formatted exactly like Block 01) -->
      <div class="monthly-kpi-layout-3">
        {b3_pri_html}
      </div>

      <!-- 3A Secondary (4 Cards formatted exactly like Block 01) -->
      <div class="monthly-kpi-layout-4">
        {b3_sec_html}
      </div>

      <!-- 發卡深入診斷圖表 (Panel Directly Leads, Zero Clutter) -->
      <article class="panel ytd-panel" style="margin-top: 14px;">
        <div class="ytd-heading">
          <div>
            <small>ISSUING DIAGNOSIS CHARTS</small>
            <h3>發卡深入診斷圖表</h3>
            <p style="margin: 4px 0 0; color: #5d6f78; font-size: 13px;">深入分析進件中樞審查流、三大分期產品雙軸定位、小樹點水庫流向與催收資產品質。</p>
          </div>
          <span>自動徵審 ｜ 分期雙軸 ｜ 小樹點水庫 ｜ 催收階梯</span>
        </div>

        <div class="unified-tabs" id="iss-diag-tabs">
          <button type="button" class="active" onclick="switchIssTab(0)">TAB 1｜申辦自動化審查分析</button>
          <button type="button" onclick="switchIssTab(1)">TAB 2｜分期產品結構分析</button>
          <button type="button" onclick="switchIssTab(2)">TAB 3｜小樹點經營與折抵通路</button>
          <button type="button" onclick="switchIssTab(3)">TAB 4｜催收與呆帳分析</button>
        </div>

        <!-- 3B Tab 0: 申辦自動化審查分析 (Sankey Flow) -->
        <div id="iss-tab-0" class="tab-content active">
          <div class="svg-chart-card">
            <div class="svg-chart-note">
              <span>進件申辦 → AI 自動徵審中樞 → 核決處遇流向圖 (Sankey Flow)</span>
              <span class="status-pill success">{b3['tab0_sankey']['status_pill']}</span>
            </div>
            
            <div style="width:100%; overflow-x:auto;">
              <svg viewBox="0 0 840 280" style="width:100%; min-width:720px; height:auto; display:block;">
                <defs>
                  <linearGradient id="flow-green" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stop-color="#003b5c" stop-opacity="0.4"/>
                    <stop offset="100%" stop-color="#009e73" stop-opacity="0.6"/>
                  </linearGradient>
                  <linearGradient id="flow-amber" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stop-color="#003b5c" stop-opacity="0.3"/>
                    <stop offset="100%" stop-color="#c9892e" stop-opacity="0.5"/>
                  </linearGradient>
                  <linearGradient id="flow-red" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stop-color="#64748b" stop-opacity="0.25"/>
                    <stop offset="100%" stop-color="#b84a4a" stop-opacity="0.5"/>
                  </linearGradient>
                </defs>

                <!-- Headers -->
                <text x="30" y="24" fill="#667a76" font-size="11" font-weight="bold">階段一：申辦進件 (85,400 件)</text>
                <text x="320" y="24" fill="#667a76" font-size="11" font-weight="bold">階段二：自動徵信審查 (80,360 件)</text>
                <text x="630" y="24" fill="#667a76" font-size="11" font-weight="bold">階段三：核決處遇結果</text>

                <!-- Flow Ribbons -->
                <path d="M 180 65 C 250 65, 250 60, 320 60 L 320 120 C 250 120, 250 125, 180 125 Z" fill="url(#flow-green)"/>
                <path d="M 470 60 C 550 60, 550 60, 630 60 L 630 115 C 550 115, 550 110, 470 110 Z" fill="url(#flow-green)"/>
                <path d="M 470 110 C 550 110, 550 190, 630 190 L 630 205 C 550 205, 550 120, 470 120 Z" fill="url(#flow-amber)"/>

                <path d="M 180 160 C 250 160, 250 160, 320 160 L 320 220 C 250 220, 250 220, 180 220 Z" fill="url(#flow-green)"/>
                <path d="M 470 160 C 550 160, 550 115, 630 115 L 630 145 C 550 145, 550 190, 470 190 Z" fill="url(#flow-green)"/>
                <path d="M 470 190 C 550 190, 550 205, 630 205 L 630 250 C 550 250, 550 220, 470 220 Z" fill="url(#flow-red)"/>

                <!-- Stage 1 Nodes -->
                <rect x="30" y="45" width="150" height="85" rx="8" fill="#eaf7f2" stroke="#009e73" stroke-width="2"/>
                <text x="45" y="75" font-size="13" font-weight="900" fill="#007a5e">舊戶加辦</text>
                <text x="45" y="98" font-size="18" font-weight="900" fill="#12344d">{b3['tab0_sankey']['nodes']['stage1_old']['count']} <tspan font-size="11" font-weight="normal" fill="#667a76">{b3['tab0_sankey']['nodes']['stage1_old']['unit']}</tspan></text>
                <text x="45" y="118" font-size="10" fill="#009e73" font-weight="bold">{b3['tab0_sankey']['nodes']['stage1_old']['auto_rate']}</text>

                <rect x="30" y="145" width="150" height="85" rx="8" fill="#eff6f5" stroke="#003b5c" stroke-width="1.5"/>
                <text x="45" y="175" font-size="13" font-weight="900" fill="#003b5c">新戶申辦 (新客)</text>
                <text x="45" y="198" font-size="18" font-weight="900" fill="#12344d">{b3['tab0_sankey']['nodes']['stage1_new']['count']} <tspan font-size="11" font-weight="normal" fill="#667a76">{b3['tab0_sankey']['nodes']['stage1_new']['unit']}</tspan></text>
                <text x="45" y="218" font-size="10" fill="#667a76">{b3['tab0_sankey']['nodes']['stage1_new']['auto_rate']}</text>

                <!-- Stage 2 Node -->
                <rect x="320" y="45" width="150" height="185" rx="8" fill="#ffffff" stroke="#cbd5e1" stroke-width="1.5"/>
                <text x="335" y="75" font-size="13" font-weight="900" fill="#002b49">進件自動審查中樞</text>
                <text x="335" y="98" font-size="16" font-weight="900" fill="#12344d">{b3['tab0_sankey']['nodes']['stage2_hub']['count']} <tspan font-size="11" font-weight="normal">{b3['tab0_sankey']['nodes']['stage2_hub']['unit']}</tspan></text>
                <text x="335" y="118" font-size="11" fill="#009e73" font-weight="bold">{b3['tab0_sankey']['nodes']['stage2_hub']['old_pass']}</text>
                <text x="335" y="138" font-size="11" fill="#c9892e" font-weight="bold">{b3['tab0_sankey']['nodes']['stage2_hub']['new_pass']}</text>
                <line x1="335" y1="155" x2="455" y2="155" stroke="#e5ece9"/>
                <text x="335" y="178" font-size="10" fill="#667a76">AI 徵信評分模型</text>
                <text x="335" y="195" font-size="10" fill="#667a76">聯徵數據即時自動介接</text>

                <!-- Stage 3 Nodes -->
                <rect x="630" y="45" width="180" height="100" rx="8" fill="#eaf7f2" stroke="#009e73" stroke-width="2"/>
                <text x="645" y="75" font-size="13" font-weight="900" fill="#007a5e">{b3['tab0_sankey']['nodes']['stage3_approved']['name']}</text>
                <text x="645" y="105" font-size="22" font-weight="900" fill="#009e73">{b3['tab0_sankey']['nodes']['stage3_approved']['count']} <tspan font-size="12" font-weight="normal" fill="#007a5e">{b3['tab0_sankey']['nodes']['stage3_approved']['unit']}</tspan></text>
                <text x="645" y="130" font-size="11" fill="#007a5e">{b3['tab0_sankey']['nodes']['stage3_approved']['detail']}</text>

                <rect x="630" y="160" width="180" height="95" rx="8" fill="#fff7e7" stroke="#c9892e" stroke-width="1.5"/>
                <text x="645" y="185" font-size="13" font-weight="900" fill="#9a6518">{b3['tab0_sankey']['nodes']['stage3_manual']['name']}</text>
                <text x="645" y="215" font-size="20" font-weight="900" fill="#c9892e">{b3['tab0_sankey']['nodes']['stage3_manual']['count']} <tspan font-size="12" font-weight="normal" fill="#9a6518">{b3['tab0_sankey']['nodes']['stage3_manual']['unit']}</tspan></text>
                <text x="645" y="238" font-size="10" fill="#9a6518">{b3['tab0_sankey']['nodes']['stage3_manual']['detail']}</text>
              </svg>
            </div>
          </div>
          <!-- Unified Bottom Insights Strip -->
          {b3_t0_insights}
        </div>

        <!-- 3B Tab 1: 分期產品結構分析 (雙軸柱線圖) -->
        <div id="iss-tab-1" class="tab-content">
          <div class="svg-chart-card">
            <div class="svg-chart-note">
              <span>三大分期產品規模與頻次對照 (雙軸柱線圖：長條柱為金額、紫色虛線連線為筆數)</span>
              <span class="status-pill primary">{b3['tab1_installments']['status_pill']}</span>
            </div>

            <div style="width:100%; overflow-x:auto;">
              <svg viewBox="0 0 760 270" style="width:100%; min-width:680px; height:auto; display:block;">
                <!-- Grid Lines -->
                <line x1="80" y1="40" x2="680" y2="40" stroke="#e5ece9" stroke-dasharray="3 3"/>
                <line x1="80" y1="100" x2="680" y2="100" stroke="#e5ece9" stroke-dasharray="3 3"/>
                <line x1="80" y1="160" x2="680" y2="160" stroke="#e5ece9" stroke-dasharray="3 3"/>
                <line x1="80" y1="220" x2="680" y2="220" stroke="#cbd5e1" stroke-width="1.5"/>

                <!-- Y1 Axis (Left: 金額) -->
                <line x1="80" y1="35" x2="80" y2="220" stroke="#cbd5e1" stroke-width="1"/>
                <text x="74" y="24" font-size="10" fill="#003b5c" font-weight="bold" text-anchor="end">金額 (億元)</text>
                <text x="74" y="44" font-size="10" fill="#667a76" text-anchor="end">120 億</text>
                <text x="74" y="104" font-size="10" fill="#667a76" text-anchor="end">80 億</text>
                <text x="74" y="164" font-size="10" fill="#667a76" text-anchor="end">40 億</text>
                <text x="74" y="224" font-size="10" fill="#667a76" text-anchor="end">0</text>

                <!-- Y2 Axis (Right: 筆數) -->
                <line x1="680" y1="35" x2="680" y2="220" stroke="#cbd5e1" stroke-width="1"/>
                <text x="686" y="24" font-size="10" fill="#7c4dff" font-weight="bold">筆數 (萬筆)</text>
                <text x="686" y="44" font-size="10" fill="#667a76">300 萬</text>
                <text x="686" y="104" font-size="10" fill="#667a76">200 萬</text>
                <text x="686" y="164" font-size="10" fill="#667a76">100 萬</text>
                <text x="686" y="224" font-size="10" fill="#667a76">0</text>

                <!-- Bar 1: 授權單筆分期 -->
                <rect x="145" y="55" width="80" height="165" rx="6" fill="#003b5c"/>
                <rect x="125" y="22" width="120" height="24" rx="4" fill="#eef6ff" stroke="#bddbff"/>
                <text x="185" y="38" font-size="11" font-weight="900" fill="#003b5c" text-anchor="middle">平均客單：{b3['tab1_installments']['items'][0]['avg_ticket']}</text>
                <text x="185" y="130" font-size="15" font-weight="900" fill="#ffffff" text-anchor="middle">{b3['tab1_installments']['items'][0]['amount_str']}</text>
                <text x="185" y="240" font-size="13" font-weight="900" fill="#12344d" text-anchor="middle">授權單筆分期</text>
                <text x="185" y="256" font-size="10" fill="#667a76" text-anchor="middle">{b3['tab1_installments']['items'][0]['share_str']}</text>

                <!-- Bar 2: 請款單筆分期 -->
                <rect x="340" y="139" width="80" height="81" rx="6" fill="#2d6a8f"/>
                <rect x="320" y="106" width="120" height="24" rx="4" fill="#eef6ff" stroke="#bddbff"/>
                <text x="380" y="122" font-size="11" font-weight="900" fill="#003b5c" text-anchor="middle">平均客單：{b3['tab1_installments']['items'][1]['avg_ticket']}</text>
                <text x="380" y="180" font-size="14" font-weight="900" fill="#ffffff" text-anchor="middle">{b3['tab1_installments']['items'][1]['amount_str']}</text>
                <text x="380" y="240" font-size="13" font-weight="900" fill="#12344d" text-anchor="middle">請款單筆分期</text>
                <text x="380" y="256" font-size="10" fill="#667a76" text-anchor="middle">{b3['tab1_installments']['items'][1]['share_str']}</text>

                <!-- Bar 3: 帳單分期 -->
                <rect x="535" y="166" width="80" height="54" rx="6" fill="#588ea8"/>
                <rect x="515" y="133" width="120" height="24" rx="4" fill="#eef6ff" stroke="#bddbff"/>
                <text x="575" y="149" font-size="11" font-weight="900" fill="#003b5c" text-anchor="middle">平均客單：{b3['tab1_installments']['items'][2]['avg_ticket']}</text>
                <text x="575" y="200" font-size="13" font-weight="900" fill="#ffffff" text-anchor="middle">{b3['tab1_installments']['items'][2]['amount_str']}</text>
                <text x="575" y="240" font-size="13" font-weight="900" fill="#12344d" text-anchor="middle">帳單分期</text>
                <text x="575" y="256" font-size="10" fill="#667a76" text-anchor="middle">{b3['tab1_installments']['items'][2]['share_str']}</text>

                <!-- Connected Purple Polyline for 筆數 -->
                <polyline points="185,49 380,88 575,118" fill="none" stroke="#7c4dff" stroke-width="2.5" stroke-dasharray="4 3"/>
                <circle cx="185" cy="49" r="6" fill="#7c4dff" stroke="#ffffff" stroke-width="2.5"/>
                <rect x="150" y="60" width="70" height="18" rx="3" fill="#7c4dff"/>
                <text x="185" y="73" font-size="10" font-weight="900" fill="#ffffff" text-anchor="middle">{b3['tab1_installments']['items'][0]['tx_count']}</text>

                <circle cx="380" cy="88" r="6" fill="#7c4dff" stroke="#ffffff" stroke-width="2.5"/>
                <rect x="345" y="62" width="70" height="18" rx="3" fill="#7c4dff"/>
                <text x="380" y="75" font-size="10" font-weight="900" fill="#ffffff" text-anchor="middle">{b3['tab1_installments']['items'][1]['tx_count']}</text>

                <circle cx="575" cy="118" r="6" fill="#7c4dff" stroke="#ffffff" stroke-width="2.5"/>
                <rect x="540" y="92" width="70" height="18" rx="3" fill="#7c4dff"/>
                <text x="575" y="105" font-size="10" font-weight="900" fill="#ffffff" text-anchor="middle">{b3['tab1_installments']['items'][2]['tx_count']}</text>
              </svg>
            </div>

            <!-- Clear Chart Legend -->
            <div style="display:flex; justify-content:center; gap:24px; font-size:13px; font-weight:800; color:#667a76; margin-top:14px; padding-top:10px; border-top:1px solid #e5ece9;">
              <span style="display:inline-flex; align-items:center; gap:6px;">
                <i style="width:12px; height:12px; border-radius:3px; background:#003b5c; display:inline-block;"></i> 分期交易金額 (左軸長條柱)
              </span>
              <span style="display:inline-flex; align-items:center; gap:6px;">
                <i style="width:14px; height:3px; background:#7c4dff; display:inline-block;"></i> 分期筆數 (右軸紫色虛線與圓點)
              </span>
              <span style="display:inline-flex; align-items:center; gap:6px;">
                <i style="padding:1px 5px; border-radius:3px; background:#eef6ff; border:1px solid #bddbff; color:#003b5c; font-size:11.5px; font-style:normal;">平均客單</i> 頂部精準定位標籤
              </span>
            </div>
          </div>
          <!-- Unified Bottom Insights Strip -->
          {b3_t1_insights}
        </div>

        <!-- 3B Tab 2: 小樹點經營與折抵通路 -->
        <div id="iss-tab-2" class="tab-content">
          <div style="display:grid; grid-template-columns: 1.3fr 0.9fr; gap:16px; margin-top:8px;">
            <!-- Left: 6 柱動態流向瀑布圖 -->
            <div class="svg-chart-card">
              <div class="svg-chart-note">
                <span>{b3['tab2_tree_points']['waterfall_title']}</span>
                <span class="status-pill success">{b3['tab2_tree_points']['status_pill']}</span>
              </div>
              <div style="width:100%; overflow-x:auto;">
                <svg viewBox="0 0 520 220" style="width:100%; height:auto; display:block;">
                  <line x1="20" y1="180" x2="500" y2="180" stroke="#cbd5e1" stroke-width="1"/>
                  
                  <!-- 柱 1: 去年同月餘額 15.2 (獨立對比柱) -->
                  <rect x="30" y="70" width="45" height="110" rx="4" fill="#f8fafc" stroke="#94a3b8" stroke-width="1.5" stroke-dasharray="3"/>
                  <text x="52" y="60" font-size="11" font-weight="bold" fill="#64748b" text-anchor="middle">15.2</text>
                  <text x="52" y="196" font-size="10" fill="#64748b" text-anchor="middle">去年同月</text>

                  <line x1="92" y1="30" x2="92" y2="180" stroke="#e2e8f0" stroke-dasharray="2"/>

                  <!-- 柱 2: 上月餘額 17.9 (起點) -->
                  <rect x="110" y="52" width="48" height="128" rx="4" fill="#003b5c"/>
                  <text x="134" y="42" font-size="11" font-weight="bold" fill="#003b5c" text-anchor="middle">17.9</text>
                  <text x="134" y="196" font-size="10" fill="#003b5c" font-weight="bold" text-anchor="middle">上月餘額</text>

                  <line x1="158" y1="52" x2="190" y2="52" stroke="#94a3b8" stroke-dasharray="2"/>

                  <!-- 柱 3: 本月新增 +2.3 (綠色上升) -->
                  <rect x="190" y="35" width="48" height="17" rx="3" fill="#009e73"/>
                  <text x="214" y="27" font-size="11" font-weight="bold" fill="#007a5e" text-anchor="middle">+2.3</text>
                  <text x="214" y="196" font-size="10" fill="#007a5e" font-weight="bold" text-anchor="middle">本月新增</text>

                  <line x1="238" y1="35" x2="270" y2="35" stroke="#94a3b8" stroke-dasharray="2"/>

                  <!-- 柱 4: 本月贈送 +1.5 (藍色上升) -->
                  <rect x="270" y="24" width="48" height="11" rx="3" fill="#0284c7"/>
                  <text x="294" y="16" font-size="11" font-weight="bold" fill="#0369a1" text-anchor="middle">+1.5</text>
                  <text x="294" y="196" font-size="10" fill="#0369a1" font-weight="bold" text-anchor="middle">本月贈送</text>

                  <line x1="318" y1="24" x2="350" y2="24" stroke="#94a3b8" stroke-dasharray="2"/>

                  <!-- 柱 5: 本月兌換 -3.2 (紅色下降) -->
                  <rect x="350" y="24" width="48" height="24" rx="3" fill="#b84a4a"/>
                  <text x="374" y="16" font-size="11" font-weight="bold" fill="#b84a4a" text-anchor="middle">-3.2</text>
                  <text x="374" y="196" font-size="10" fill="#b84a4a" font-weight="bold" text-anchor="middle">本月兌換</text>

                  <line x1="398" y1="48" x2="430" y2="48" stroke="#94a3b8" stroke-dasharray="2"/>

                  <!-- 柱 6: 本月累積餘額 18.5 (終點) -->
                  <rect x="430" y="48" width="52" height="132" rx="4" fill="#7c4dff"/>
                  <text x="456" y="38" font-size="13" font-weight="extrabold" fill="#7c4dff" text-anchor="middle">18.5</text>
                  <text x="456" y="196" font-size="10" font-weight="extrabold" fill="#7c4dff" text-anchor="middle">本月累積</text>
                </svg>
              </div>
              <div style="font-size:12.5px; color:#556972; background:#fff; padding:10px 12px; border-radius:6px; border:1px solid #e5ece9; margin-top:8px;">
                {b3['tab2_tree_points']['formula_note']}
              </div>
            </div>

            <!-- Right: 甜甜圈圓餅圖與通路列表 -->
            <div class="svg-chart-card">
              <div class="svg-chart-note">
                <span>五大折抵通路佔比</span>
                <span class="status-pill primary">當月兌換 {b3['tab2_tree_points']['total_redeem_points']}點</span>
              </div>
              <div style="display:flex; flex-direction:column; align-items:center; gap:14px; padding-top:6px;">
                <div style="position:relative; width:130px; height:130px;">
                  <svg viewBox="0 0 36 36" style="width:100%; height:100%; transform:rotate(-90deg);">
                    <circle cx="18" cy="18" r="15.9155" fill="transparent" stroke="#f1f5f9" stroke-width="4"/>
                    <circle cx="18" cy="18" r="15.9155" fill="transparent" stroke="#009e73" stroke-width="4" stroke-dasharray="42 58" stroke-dashoffset="0"/>
                    <circle cx="18" cy="18" r="15.9155" fill="transparent" stroke="#003b5c" stroke-width="4" stroke-dasharray="24 76" stroke-dashoffset="-42"/>
                    <circle cx="18" cy="18" r="15.9155" fill="transparent" stroke="#7c4dff" stroke-width="4" stroke-dasharray="16 84" stroke-dashoffset="-66"/>
                    <circle cx="18" cy="18" r="15.9155" fill="transparent" stroke="#c9892e" stroke-width="4" stroke-dasharray="11 89" stroke-dashoffset="-82"/>
                    <circle cx="18" cy="18" r="15.9155" fill="transparent" stroke="#94a3b8" stroke-width="4" stroke-dasharray="7 93" stroke-dashoffset="-93"/>
                  </svg>
                  <div style="position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center;">
                    <span style="font-size:15px; font-weight:900; color:#12344d;">{b3['tab2_tree_points']['total_redeem_points']}</span>
                    <span style="font-size:11.5px; font-weight:700; color:#667a76;">總兌換點數</span>
                  </div>
                </div>

                <div style="width:100%; font-size:12.5px; display:grid; gap:8px;">
                  {"".join([f'<div style="display:flex; justify-content:space-between; align-items:center;"><span style="display:flex; align-items:center; gap:6px;"><i style="width:9px; height:9px; border-radius:50%; background:{ch["color"]}; display:inline-block;"></i>{ch["name"]}</span><b>{ch["pct"]} ({ch["amount"]})</b></div>' for ch in b3['tab2_tree_points']['channels']])}
                </div>
              </div>
            </div>
          </div>
          <!-- Unified Bottom Insights Strip -->
          {b3_t2_insights}
        </div>

        <!-- 3B Tab 3: 催收與呆帳分析 -->
        <div id="iss-tab-3" class="tab-content">
          <div style="display:grid; grid-template-columns:1fr 1.2fr; gap:16px; margin-top:8px;">
            <!-- M1 催收第一防線 -->
            <div class="svg-chart-card">
              <div class="svg-chart-note">
                <span>{b3['tab3_collection']['m1_title']}</span>
                <span class="status-pill success">{b3['tab3_collection']['m1_pill']}</span>
              </div>
              <div style="background:#fff; border:2px solid #009e73; border-radius:8px; padding:14px; margin-bottom:12px;">
                <span style="font-size:12.5px; color:#556972; font-weight:800;">催收回復正常率 (Cure Rate)</span>
                <div style="font-size:34px; font-weight:900; color:#009e73; margin:4px 0;">{b3['tab3_collection']['cure_rate']}</div>
                <div style="font-size:13px; color:#007a5e; font-weight:800;">{b3['tab3_collection']['cure_desc']}</div>
                <div style="font-size:12px; color:#667a76; margin-top:3px;">{b3['tab3_collection']['cure_sub']}</div>
              </div>
              <div style="background:#fff; border:1px solid #e5ece9; border-radius:8px; padding:12px 14px; font-size:12.5px;">
                <div style="display:flex; justify-content:space-between; font-weight:800; color:#12344d;">
                  <span>轉入 M2 催收流程</span>
                  <span style="color:#c9892e;">{b3['tab3_collection']['m2_rate']}</span>
                </div>
                <div style="font-size:11.5px; color:#667a76; margin-top:3px;">{b3['tab3_collection']['m2_sub']}</div>
              </div>
            </div>

            <!-- 天期階梯結構與呆帳淨損失算式 -->
            <div class="svg-chart-card">
              <div class="svg-chart-note">
                <span>逾期天期帳款結構 (Aging Buckets)</span>
                <span class="status-pill primary">階梯收斂管控</span>
              </div>
              <div style="display:grid; gap:10px; margin-bottom:14px;">
                {"".join([f'''<div>
                  <div style="display:flex; justify-content:space-between; font-size:12.5px; font-weight:800; color:{bk["color"]}; margin-bottom:3px;">
                    <span>{bk["name"]} {bk["amount"]}</span>
                    <span>{bk["pct_str"]}</span>
                  </div>
                  <div style="width:100%; height:9px; background:#e5ece9; border-radius:4px; overflow:hidden;">
                    <div style="width:{bk["width_pct"]}%; height:100%; background:{bk["color"]}; border-radius:4px;"></div>
                  </div>
                </div>''' for bk in b3['tab3_collection']['aging_buckets']])}
              </div>

              <!-- 呆帳淨損失結算卡 -->
              <div style="display:flex; align-items:center; justify-content:space-around; background:#fff; padding:12px; border-radius:8px; border:1px solid #e5ece9; font-size:12.5px;">
                <div style="text-align:center;">
                  <span style="font-size:11.5px; font-weight:700; color:#667a76; display:block;">當月轉銷呆帳 (損)</span>
                  <strong style="font-size:18px; color:#b84a4a;">{b3['tab3_collection']['loss_settlement']['chargeoff']}</strong>
                </div>
                <span style="font-size:20px; font-weight:900; color:#667a76;">−</span>
                <div style="text-align:center;">
                  <span style="font-size:11.5px; font-weight:700; color:#667a76; display:block;">當月呆帳回收 (益)</span>
                  <strong style="font-size:18px; color:#009e73;">{b3['tab3_collection']['loss_settlement']['recovery']}</strong>
                </div>
                <span style="font-size:20px; font-weight:900; color:#667a76;">＝</span>
                <div style="text-align:center; background:#fff5f5; padding:5px 10px; border-radius:6px; border:1px solid #fbd5d5;">
                  <span style="font-size:11.5px; color:#b84a4a; font-weight:800; display:block;">當月淨信用損失</span>
                  <strong style="font-size:18px; color:#b84a4a;">{b3['tab3_collection']['loss_settlement']['net_loss']}</strong>
                </div>
              </div>
            </div>
          </div>
          <!-- Unified Bottom Insights Strip -->
          {b3_t3_insights}
        </div>
      </article>
    </div>
  </section>

  <!-- ========================================================
       SECTION 04: 系統韌性 (STRICT USER SPECIFICATION & 01 BASELINE)
       ======================================================== -->
  <section id="section-resilience" class="dashboard-section system-section main-section">
    <div class="section-title section-orange">
      <span>04</span>
      <h2>系統韌性</h2>
      <i></i>
    </div>
    <div class="business-grid">
      <div class="block-intro">
        <p>核心主機運行量能 <i>×</i> 活動日尖峰負載與三大防詐成效診斷</p>
      </div>

      <div class="monthly-kpi-layout-3" style="margin-top: 10px;">
        {b4_pri_html}
      </div>

      <!-- 系統韌性深入診斷圖表 (Panel Directly Leads, Zero Clutter) -->
      <article class="panel ytd-panel" style="margin-top: 14px;">
        <div class="ytd-heading">
          <div>
            <small>SYSTEM RESILIENCE DIAGNOSIS</small>
            <h3>系統韌性與資安防詐診斷</h3>
            <p style="margin: 4px 0 0; color: #5d6f78; font-size: 13px;">雲端即時擴容彈性負載、三大資安防詐防堵成果與紅利微服務高頻監控。</p>
          </div>
          <span>雲端彈性 ｜ 三大防詐 ｜ 紅利微服務</span>
        </div>

        <div class="unified-tabs" id="sys-diag-tabs">
          <button type="button" class="active" onclick="switchSysTab(0)">TAB 1｜活動日雲端服務監控數據</button>
          <button type="button" onclick="switchSysTab(1)">TAB 2｜三大資安防詐防堵成效分析</button>
          <button type="button" onclick="switchSysTab(2)">TAB 3｜紅利核心微服務交易量能監控</button>
        </div>

        <!-- 4B Tab 0: 活動日雲端服務監控數據 -->
        <div id="sys-tab-0" class="tab-content active">
          <div class="compact-table" style="margin-bottom:14px;">
            <table>
              <thead>
                <tr>
                  <th>特定日期 / 活動名稱</th>
                  <th>特定尖峰時段</th>
                  <th>系統規格</th>
                  <th>瞬時峰值 TPS</th>
                  <th>最高 CPU 負載</th>
                  <th>平穩運行備註</th>
                </tr>
              </thead>
              <tbody>
                {b4_t0_rows}
              </tbody>
            </table>
          </div>

          <!-- Unified Bottom Insights Strip -->
          {b4_t0_insights}
        </div>

        <!-- 4B Tab 1: 三大資安防詐防堵成效分析 -->
        <div id="sys-tab-1" class="tab-content">
          <div class="compact-table" style="margin-bottom:14px;">
            <table>
              <thead>
                <tr>
                  <th>防詐防堵項目</th>
                  <th>主責控管系統</th>
                  <th>業務歸屬端</th>
                  <th>當月防堵卡數 (張)</th>
                  <th>當月防堵金額 (萬元)</th>
                  <th>卡均防堵金額</th>
                  <th>金額佔比 (%)</th>
                </tr>
              </thead>
              <tbody>
                {b4_t1_rows}
                {b4_t1_total}
              </tbody>
            </table>
          </div>

          <!-- Crisp, professional SVG Dual-Axis Chart for Fraud Defense -->
          <div class="svg-chart-card" style="margin-bottom:14px;">
            <div class="svg-chart-note">
              <span>三大防詐管道成效對比 (雙軸柱線圖：深藍長條柱為防堵金額、綠色折線為防堵卡數)</span>
              <span class="status-pill success">全月防堵總金額：4,280 萬元</span>
            </div>

            <div style="width:100%; overflow-x:auto;">
              <svg viewBox="0 0 760 270" style="width:100%; min-width:680px; height:auto; display:block;">
                <!-- Grid Lines -->
                <line x1="80" y1="40" x2="680" y2="40" stroke="#e5ece9" stroke-dasharray="3 3"/>
                <line x1="80" y1="100" x2="680" y2="100" stroke="#e5ece9" stroke-dasharray="3 3"/>
                <line x1="80" y1="160" x2="680" y2="160" stroke="#e5ece9" stroke-dasharray="3 3"/>
                <line x1="80" y1="220" x2="680" y2="220" stroke="#cbd5e1" stroke-width="1.5"/>

                <!-- Y1 Axis (Left: 金額 萬元, Max 2500) -->
                <line x1="80" y1="35" x2="80" y2="220" stroke="#cbd5e1" stroke-width="1"/>
                <text x="74" y="24" font-size="10" fill="#003b5c" font-weight="bold" text-anchor="end">金額 (萬元)</text>
                <text x="74" y="44" font-size="10" fill="#667a76" text-anchor="end">2,500 萬</text>
                <text x="74" y="104" font-size="10" fill="#667a76" text-anchor="end">1,667 萬</text>
                <text x="74" y="164" font-size="10" fill="#667a76" text-anchor="end">833 萬</text>
                <text x="74" y="224" font-size="10" fill="#667a76" text-anchor="end">0</text>

                <!-- Y2 Axis (Right: 卡數 張, Max 1500) -->
                <line x1="680" y1="35" x2="680" y2="220" stroke="#cbd5e1" stroke-width="1"/>
                <text x="686" y="24" font-size="10" fill="#007a5e" font-weight="bold">卡數 (張)</text>
                <text x="686" y="44" font-size="10" fill="#667a76">1,500 張</text>
                <text x="686" y="104" font-size="10" fill="#667a76">1,000 張</text>
                <text x="686" y="164" font-size="10" fill="#667a76">500 張</text>
                <text x="686" y="224" font-size="10" fill="#667a76">0</text>

                <!-- Bar 1: 申請詐欺防堵 (1150萬 -> height=82.8, y=137.2) -->
                <rect x="145" y="137.2" width="80" height="82.8" rx="6" fill="#003b5c"/>
                <rect x="125" y="94" width="120" height="24" rx="4" fill="#eef6ff" stroke="#bddbff"/>
                <text x="185" y="110" font-size="11" font-weight="900" fill="#003b5c" text-anchor="middle">防堵：1,150 萬元</text>
                <text x="185" y="240" font-size="13" font-weight="900" fill="#12344d" text-anchor="middle">申請詐欺防堵</text>
                <text x="185" y="256" font-size="10" fill="#667a76" text-anchor="middle">佔 26.9% ｜ SFM系統</text>

                <!-- Bar 2: 3DS系統防堵 (860萬 -> height=61.9, y=158.1) -->
                <rect x="340" y="158.1" width="80" height="61.9" rx="6" fill="#2d6a8f"/>
                <rect x="320" y="115" width="120" height="24" rx="4" fill="#eef6ff" stroke="#bddbff"/>
                <text x="380" y="131" font-size="11" font-weight="900" fill="#003b5c" text-anchor="middle">防堵：860 萬元</text>
                <text x="380" y="240" font-size="13" font-weight="900" fill="#12344d" text-anchor="middle">3DS 系統防堵</text>
                <text x="380" y="256" font-size="10" fill="#667a76" text-anchor="middle">佔 20.1% ｜ 3DS系統</text>

                <!-- Bar 3: 交易詐欺防堵 (2270萬 -> height=163.4, y=56.6) -->
                <rect x="535" y="56.6" width="80" height="163.4" rx="6" fill="#588ea8"/>
                <rect x="515" y="13" width="120" height="24" rx="4" fill="#eef6ff" stroke="#bddbff"/>
                <text x="575" y="29" font-size="11" font-weight="900" fill="#003b5c" text-anchor="middle">防堵：2,270 萬元</text>
                <text x="575" y="240" font-size="13" font-weight="900" fill="#12344d" text-anchor="middle">交易詐欺防堵</text>
                <text x="575" y="256" font-size="10" fill="#667a76" text-anchor="middle">佔 53.0% ｜ SFM系統</text>

                <!-- Connected Green Polyline for 卡數 -->
                <polyline points="185,119 380,146 575,73" fill="none" stroke="#009e73" stroke-width="2.5" stroke-dasharray="4 3"/>
                
                <circle cx="185" cy="119" r="6" fill="#009e73" stroke="#ffffff" stroke-width="2.5"/>
                <rect x="150" y="129" width="70" height="18" rx="3" fill="#007a5e"/>
                <text x="185" y="142" font-size="10" font-weight="900" fill="#ffffff" text-anchor="middle">842 張</text>

                <circle cx="380" cy="146" r="6" fill="#009e73" stroke="#ffffff" stroke-width="2.5"/>
                <rect x="345" y="156" width="70" height="18" rx="3" fill="#007a5e"/>
                <text x="380" y="169" font-size="10" font-weight="900" fill="#ffffff" text-anchor="middle">620 張</text>

                <circle cx="575" cy="73" r="6" fill="#009e73" stroke="#ffffff" stroke-width="2.5"/>
                <rect x="540" y="83" width="70" height="18" rx="3" fill="#007a5e"/>
                <text x="575" y="96" font-size="10" font-weight="900" fill="#ffffff" text-anchor="middle">1,222 張</text>
              </svg>
            </div>

            <!-- Clear Chart Legend -->
            <div style="display:flex; justify-content:center; gap:24px; font-size:13px; font-weight:800; color:#667a76; margin-top:14px; padding-top:10px; border-top:1px solid #e5ece9;">
              <span style="display:inline-flex; align-items:center; gap:6px;">
                <i style="width:12px; height:12px; border-radius:3px; background:#003b5c; display:inline-block;"></i> 防堵金額 (左軸深藍柱)
              </span>
              <span style="display:inline-flex; align-items:center; gap:6px;">
                <i style="width:14px; height:3px; background:#009e73; display:inline-block;"></i> 防堵卡數 (右軸綠色虛線與徽章)
              </span>
            </div>
          </div>

          <!-- Unified Bottom Insights Strip -->
          {b4_t1_insights}
        </div>

        <!-- 4B Tab 2: 紅利核心微服務交易量能監控 (方案一：左右雙圖雙軌制) -->
        <div id="sys-tab-2" class="tab-content">
          <!-- 4 Microservice Overview Cards -->
          <div class="monthly-kpi-layout-4" style="margin-bottom:14px;">
            {b4_t2_cards}
          </div>

          <!-- Dual Charts: 3-Period Grouped Bar + TPS Peak Ranking -->
          <div class="dual-chart-shell">
            <!-- Left Chart: 3-Period Grouped Bars -->
            <div class="chart-box">
              <div class="chart-box-header">
                <div>
                  <h3>四大微服務三期放量趨勢 (萬次)</h3>
                  <span>去年同期 (2025/08) vs 前期 (2026/07) vs 本期 (2026/08)</span>
                </div>
                <div style="display:flex; gap:12px; font-size:11.5px; font-weight:800;">
                  <span style="display:flex; align-items:center; gap:4px;"><i style="width:10px; height:10px; background:#cbd5e1; border-radius:2px; display:inline-block;"></i> 去年同期</span>
                  <span style="display:flex; align-items:center; gap:4px;"><i style="width:10px; height:10px; background:#4a7c98; border-radius:2px; display:inline-block;"></i> 前期</span>
                  <span style="display:flex; align-items:center; gap:4px;"><i style="width:10px; height:10px; background:#009e73; border-radius:2px; display:inline-block;"></i> 本期</span>
                </div>
              </div>

              <svg viewBox="0 0 540 220" style="width:100%; height:auto; display:block;" font-family="inherit">
                <!-- Grid Lines -->
                <line x1="45" y1="25" x2="520" y2="25" stroke="#edf2f0" stroke-dasharray="3 3"/>
                <line x1="45" y1="65" x2="520" y2="65" stroke="#edf2f0" stroke-dasharray="3 3"/>
                <line x1="45" y1="105" x2="520" y2="105" stroke="#edf2f0" stroke-dasharray="3 3"/>
                <line x1="45" y1="145" x2="520" y2="145" stroke="#edf2f0" stroke-dasharray="3 3"/>
                <line x1="45" y1="185" x2="520" y2="185" stroke="#cbd5e1" stroke-width="1.2"/>

                <!-- Y Axis Scale (0 ~ 5,000 萬次) -->
                <text x="38" y="29" font-size="10.5" fill="#667a76" text-anchor="end">5,000萬</text>
                <text x="38" y="69" font-size="10.5" fill="#667a76" text-anchor="end">3,750萬</text>
                <text x="38" y="109" font-size="10.5" fill="#667a76" text-anchor="end">2,500萬</text>
                <text x="38" y="149" font-size="10.5" fill="#667a76" text-anchor="end">1,250萬</text>
                <text x="38" y="188" font-size="10.5" fill="#667a76" text-anchor="end">0</text>

                {chart_groups_svg}
              </svg>
            </div>

            <!-- Right Chart: TPS Peak Ranking Progress Bars -->
            <div class="chart-box">
              <div class="chart-box-header">
                <div>
                  <h3>微服務瞬時並發最高 TPS 排名</h3>
                  <span>各服務瞬時尖峰負載與系統延遲表現</span>
                </div>
                <span class="status-pill primary">全月峰值 4,170 TPS</span>
              </div>

              {tps_rank_html}
            </div>
          </div>

          <!-- Unified Bottom Insights Strip -->
          {b4_t2_insights}
        </div>
      </article>
    </div>
  </section>
</main>

<script>
  // Main Section Exclusive Switcher (01, 02, 03, 04)
  function switchMainSection(targetSectionId) {{
    const sections = document.querySelectorAll('.main-section');
    sections.forEach(sec => sec.classList.remove('active'));

    const target = document.getElementById(targetSectionId);
    if (target) {{
      target.classList.add('active');
    }}

    const btns = document.querySelectorAll('.nav-tab-btn');
    btns.forEach(btn => {{
      btn.classList.toggle('active', btn.dataset.target === targetSectionId);
    }});

    window.scrollTo({{ top: 0, behavior: 'smooth' }});
  }}

  // Peer comparison data
  const peerCategories = {peer_json_str};

  let currentCatIdx = 0;
  let currentMetricIdx = 0;

  function semanticClass(direction, change) {{
    return (direction === "up" ? change >= 0 : change <= 0) ? "number-positive" : "number-negative";
  }}

  function formatChange(value, suffix = "%") {{
    return `${{value > 0 ? "+" : ""}}${{Number(value).toFixed(1)}}${{suffix}}`;
  }}

  function renderYtd() {{
    const catTabsContainer = document.getElementById("ytd-category-tabs");
    const metricContainer = document.getElementById("ytd-metric-selector");
    const peerRowsContainer = document.getElementById("peer-chart-rows");
    const insightsContainer = document.getElementById("peer-insights");
    const chartTitle = document.getElementById("peer-chart-title");
    const chartUnit = document.getElementById("peer-chart-unit");

    if (!catTabsContainer) return;

    // Render Category Tabs
    catTabsContainer.innerHTML = peerCategories.map((cat, idx) => `
      <button type="button" class="${{idx === currentCatIdx ? 'active' : ''}}" onclick="selectCategory(${{idx}})">
        ${{cat.label}}
      </button>
    `).join("");

    const category = peerCategories[currentCatIdx];
    const metrics = category.metrics;

    // Render Metric Selector if more than 1
    if (metrics.length > 1) {{
      metricContainer.style.display = "flex";
      metricContainer.innerHTML = metrics.map((m, idx) => `
        <button type="button" class="${{idx === currentMetricIdx ? 'active' : ''}}" onclick="selectMetric(${{idx}})">
          ${{m.label}}
        </button>
      `).join("");
    }} else {{
      metricContainer.style.display = "none";
    }}

    const metric = metrics[currentMetricIdx];
    chartTitle.textContent = `${{metric.label}}｜2026 年 1–8 月`;
    chartUnit.textContent = `單位：${{metric.unit}}`;

    const cathay = metric.peers.find(p => p.bank === "國泰世華") || metric.peers[0];
    const maxVal = Math.max(...metric.peers.map(p => p.value));
    const sortedPeers = [...metric.peers].sort((a, b) => b.value - a.value);
    const isQuality = metric.summaryMode === "quality";

    // Render Peer Rows
    peerRowsContainer.innerHTML = sortedPeers.map(peer => {{
      const isCathay = peer.bank === "國泰世華";
      const barWidth = ((peer.value / maxVal) * 100).toFixed(1);
      const semCls = semanticClass(metric.positiveDirection, peer.yoy);
      const formattedYoy = formatChange(peer.yoy, isQuality ? "pp" : "%");

      return `
        <div class="peer-row ${{isCathay ? 'is-cathay' : ''}}">
          <div class="peer-name">
            ${{peer.bank}}
            ${{isCathay ? '<small>本行</small>' : ''}}
          </div>
          <div class="peer-bar-track">
            <i style="width: ${{barWidth}}%;">
              <span>${{peer.value.toLocaleString()}}</span>
            </i>
          </div>
          <b class="${{semCls}}">${{formattedYoy}}</b>
        </div>
      `;
    }}).join("");

    // Render Insights
    let insights = [];
    if (isQuality) {{
      insights = [
        {{ label: "本行值", value: `${{cathay.value.toFixed(2)}}${{metric.unit}}` }},
        {{ label: "市場平均", value: `${{(metric.marketAverage || 0).toFixed(2)}}${{metric.unit}}` }},
        {{ label: "與市場差距", value: `${{(cathay.value - (metric.marketAverage || 0)).toFixed(2)}}${{metric.unit}}` }},
        {{ label: "YoY 變化", value: formatChange(cathay.yoy, "pp") }}
      ];
    }} else {{
      const marketVal = metric.marketValue || cathay.value;
      const share = ((cathay.value / marketVal) * 100).toFixed(1);
      const marketYoy = metric.marketYoy || 0;
      const gap = (cathay.yoy - marketYoy).toFixed(1);
      insights = [
        {{ label: "本行 YoY", value: formatChange(cathay.yoy) }},
        {{ label: "市場 YoY", value: formatChange(marketYoy) }},
        {{ label: "Growth Gap", value: formatChange(gap, "pp") }},
        {{ label: "本行市占率", value: `${{share}}%` }}
      ];
    }}

    insightsContainer.innerHTML = insights.map(item => `
      <div>
        <span>${{item.label}}</span>
        <strong>${{item.value}}</strong>
      </div>
    `).join("");
  }}

  function selectCategory(idx) {{
    currentCatIdx = idx;
    currentMetricIdx = 0;
    renderYtd();
  }}

  function selectMetric(idx) {{
    currentMetricIdx = idx;
    renderYtd();
  }}

  // Tab switching for Acquiring (2B)
  function switchAcqTab(tabIdx) {{
    const btns = document.querySelectorAll("#acq-diag-tabs button");
    btns.forEach((btn, i) => {{
      btn.classList.toggle("active", i === tabIdx);
    }});
    for (let i = 0; i < 3; i++) {{
      const content = document.getElementById(`acq-tab-${{i}}`);
      if (content) content.classList.toggle("active", i === tabIdx);
    }}
  }}

  // Tab switching for Issuing (3B)
  function switchIssTab(tabIdx) {{
    const btns = document.querySelectorAll("#iss-diag-tabs button");
    btns.forEach((btn, i) => {{
      btn.classList.toggle("active", i === tabIdx);
    }});
    for (let i = 0; i < 4; i++) {{
      const content = document.getElementById(`iss-tab-${{i}}`);
      if (content) content.classList.toggle("active", i === tabIdx);
    }}
  }}

  // Tab switching for System Resilience (4B)
  function switchSysTab(tabIdx) {{
    const btns = document.querySelectorAll("#sys-diag-tabs button");
    btns.forEach((btn, i) => {{
      btn.classList.toggle("active", i === tabIdx);
    }});
    for (let i = 0; i < 3; i++) {{
      const content = document.getElementById(`sys-tab-${{i}}`);
      if (content) content.classList.toggle("active", i === tabIdx);
    }}
  }}

  // Initialize on load
  document.addEventListener("DOMContentLoaded", () => {{
    renderYtd();
  }});
</script>
</body>
</html>
"""

with open(OUTPUT_HTML, "w", encoding="utf-8") as f:
    f.write(html_template)

print(f"Test build succeeded: {OUTPUT_HTML} (size: {len(html_template)} bytes)")
