# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import re

with open('credit_card_full_dashboard.html', 'r', encoding='utf-8', errors='ignore') as f:
    text = f.read()

print('1. Section titles in generated HTML:')
for m in re.finditer(r'<div class=[\'\"]section-title[^>]*>[\s\S]*?</div>', text):
    print('  ', ' '.join(m.group(0).split()))

print('\n2. Check if 市場排名 exists:')
print('   Count of 市場排名:', text.count('市場排名'))

print('\n3. Check if override CSS exists:')
print('   Count of .dashboard-section .section-title:', text.count('.dashboard-section .section-title'))
