# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

transcript_path = 'C:/Users/詠棠/.gemini/antigravity/brain/b95ecca9-971a-489b-ab53-ec5e0dbbb3cb/.system_generated/logs/transcript_full.jsonl'
with open(transcript_path, 'r', encoding='utf-8') as f:
    for line in f:
        obj = json.loads(line)
        idx = obj.get('step_index')
        if idx in [242, 244, 248, 250]:
            c = obj.get('content', '')
            print(f"=== Step {idx} ===")
            for l in c.splitlines()[:60]:
                if any(k in l for k in ['section', '01', '02', '03', '04', 'label', 'title', 'shell', 'grid']):
                    print("  ", l)
