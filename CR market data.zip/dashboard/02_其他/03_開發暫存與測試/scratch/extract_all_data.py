import json
import sys
from bs4 import BeautifulSoup

output_lines = []

def pr(s=''):
    output_lines.append(s)

# 1. Peer Data in Block 01
pr("================================================================================")
pr("BLOCK 01: 全行概況 - PEER DATA INVENTORY (市場同業比較數據)")
pr("================================================================================")
with open('scratch/peer_data.json', 'r', encoding='utf-8') as f:
    peer_data = json.load(f)

for cat in peer_data:
    cat_label = cat['label']
    pr(f"\n### 分類：{cat_label}")
    for m in cat['metrics']:
        m_label = m['label']
        m_unit = m['unit']
        m_pos = m.get('positiveDirection', '')
        mv = m.get('marketValue')
        my = m.get('marketYoy')
        ma = m.get('marketAverage')
        sm = m.get('summaryMode')
        pr(f"\n  * 指標：{m_label}（單位：{m_unit}）| 市場總計/均值：{mv or ma} | 市場 YoY：{my} | 摘要模式：{sm} | 導向：{m_pos}")
        pr(f"    {'同業銀行':<10} | {'數值':<10} | {'YoY':<8}")
        pr(f"    {'-'*35}")
        for p in m['peers']:
            b = p.get('bank')
            v = p.get('value')
            y = p.get('yoy')
            pr(f"    {b:<10} | {v:<10} | {y}")

pr("\n================================================================================")
pr("BLOCKS 01-04: HTML MARKUP DATA INVENTORY (儀表板全介面數據清單)")
pr("================================================================================")

with open('credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    soup = BeautifulSoup(f.read(), 'html.parser')

sections = soup.find_all('section', class_='dashboard-section')
for sec in sections:
    sec_id = sec.get('id')
    h2 = sec.find('h2').text.strip() if sec.find('h2') else ''
    intro = sec.find('div', class_='block-intro').text.strip() if sec.find('div', class_='block-intro') else ''
    pr(f"\n=======================================================")
    pr(f"SECTION: {sec_id} - {h2}")
    pr(f"Intro: {intro}")
    pr(f"=======================================================")
    
    # KPIs
    kpis = sec.find_all('article', class_='monthly-kpi')
    pr(f"\n--- 月度 KPI 卡片 (共 {len(kpis)} 張) ---")
    for idx, k in enumerate(kpis, 1):
        classes = " ".join(k.get('class', []))
        title = k.find('div', class_='monthly-kpi-title').text.strip() if k.find('div', class_='monthly-kpi-title') else ''
        val = k.find('div', class_='monthly-kpi-value').text.strip() if k.find('div', class_='monthly-kpi-value') else ''
        growth = k.find('div', class_='monthly-growth')
        growth_items = [span.text.strip() for span in growth.find_all('span')] if growth else []
        note = k.find('span', class_='secondary-note')
        note_text = note.text.strip() if note else ''
        note_title = note.get('title', '') if note else ''
        foot = k.find('div', class_='split-foot')
        foot_text = foot.text.strip() if foot else ''
        
        pr(f"\n  [{idx}] {title} ({classes})")
        pr(f"      主要數值: {val}")
        pr(f"      成長指標: {' | '.join(growth_items)}")
        if note_text:
            pr(f"      補充說明: {note_text} (Title: {note_title})")
        if foot_text:
            pr(f"      底部分析: {foot_text}")
            
        splits = k.find_all('div', class_='split-item')
        for s in splits:
            s_title = s.find('span').text.strip() if s.find('span') else ''
            s_val = s.find('strong').text.strip() if s.find('strong') else ''
            s_badge = s.find('b').text.strip() if s.find('b') else ''
            tip = s.find('div', class_='split-tooltip')
            tip_items = [x.strip() for x in tip.stripped_strings] if tip else []
            pr(f"      * 拆解: {s_title} = {s_val} [{s_badge}] | 懸浮詳情: {' / '.join(tip_items)}")

    # Panels
    panels = sec.find_all('article', class_='panel')
    for pidx, p in enumerate(panels, 1):
        p_h3 = p.find('h3').text.strip() if p.find('h3') else ''
        p_sub = p.find('p').text.strip() if p.find('p') else ''
        p_span = p.find('span').text.strip() if p.find('span') else ''
        pr(f"\n--- 診斷面板 [{pidx}]: {p_h3} ---")
        pr(f"    說明: {p_sub}")
        pr(f"    標籤/區間: {p_span}")
        
        # Tabs
        tabs_div = p.find('div', class_='unified-tabs')
        if tabs_div:
            buttons = [b.text.strip() for b in tabs_div.find_all('button')]
            pr(f"    Tabs: {buttons}")
            
        # TWQR specific
        twqr_grid = p.find('div', class_='twqr-grid')
        if twqr_grid:
            pr(f"    [TWQR 專區數據]")
            for s in twqr_grid.find_all('section'):
                s_h4 = s.find('h4').text.strip() if s.find('h4') else ''
                pr(f"      子區塊: {s_h4}")
                for box in s.find_all('div', class_='twqr-stats'):
                    for item in box.find_all('div'):
                        lbl = item.find('span').text.strip() if item.find('span') else ''
                        num = item.find('strong').text.strip() if item.find('strong') else ''
                        b_txt = item.find('b').text.strip() if item.find('b') else ''
                        pr(f"        - {lbl}: {num} ({b_txt})")

        # Tab contents
        tab_contents = p.find_all('div', class_='tab-content')
        for tidx, tc in enumerate(tab_contents, 1):
            t_id = tc.get('id', '')
            pr(f"\n    >> Tab 內容 [{tidx}] (ID: {t_id})")
            
            # SVG note
            svg_notes = tc.find_all('div', class_='svg-chart-note')
            for sn in svg_notes:
                pr(f"       圖表標註: {' | '.join([s.text.strip() for s in sn.find_all('span')])}")
                
            # Structure bar
            s_bar = tc.find('div', class_='structure-bar')
            if s_bar:
                items = [i.text.strip() for i in s_bar.find_all('i')]
                pr(f"       結構佔比條: {' | '.join(items)}")

            # Tables
            tables = tc.find_all('table')
            for table in tables:
                th_list = [th.text.strip() for th in table.find_all('th')]
                pr(f"       表格欄位: {' | '.join(th_list)}")
                for tr in table.find_all('tr'):
                    td_list = [td.text.strip().replace('\n', ' ') for td in tr.find_all('td')]
                    if td_list:
                        pr(f"         行: {' | '.join(td_list)}")

            # SVGs
            svgs = tc.find_all('svg')
            for s_idx, svg in enumerate(svgs, 1):
                viewbox = svg.get('viewBox', '')
                texts = [t.text.strip() for t in svg.find_all('text') if t.text.strip()]
                pr(f"       SVG 圖表 [{s_idx}] viewBox='{viewbox}' - 包含文字數值: {texts}")

            # Insights
            insights = tc.find_all('div', class_='unified-insights')
            for ins in insights:
                pr(f"       底部洞察欄位:")
                for div in ins.find_all('div'):
                    s_label = div.find('span').text.strip() if div.find('span') else ''
                    s_val = div.find('strong').text.strip() if div.find('strong') else ''
                    s_sub = div.find('em').text.strip() if div.find('em') else ''
                    pr(f"         * {s_label}: {s_val} ({s_sub})")

with open('scratch/all_data_dump_clean.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(output_lines))

print(f"Done! Successfully wrote {len(output_lines)} lines to scratch/all_data_dump_clean.txt")
