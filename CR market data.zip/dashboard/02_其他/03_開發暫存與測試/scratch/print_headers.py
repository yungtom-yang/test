# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('scratch/build_dashboard.py', 'r', encoding='utf-8', errors='ignore') as f:
    lines = f.readlines()

for i, l in enumerate(lines):
    if any(k in l for k in ['id="section-', 'class="section-title', 'class="block-intro', 'class="block-label', '<nav class="subnav"']):
        print(f"{i+1}: {l.strip()}")
