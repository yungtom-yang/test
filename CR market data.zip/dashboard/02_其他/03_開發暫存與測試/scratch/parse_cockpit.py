import sys
from bs4 import BeautifulSoup

with open('credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    soup = BeautifulSoup(f, 'html.parser')

cockpit = soup.find('section', id='section-cockpit')
cols = cockpit.find_all('div', class_='cockpit-col')

with open('scratch/cockpit_details.txt', 'w', encoding='utf-8') as out:
    for c_idx, col in enumerate(cols):
        badge = col.find(class_='cockpit-badge')
        badge_txt = badge.get_text(strip=True) if badge else f"Col {c_idx+1}"
        out.write(f"\n========================================\n")
        out.write(f"COCKPIT COLUMN {c_idx+1}: {badge_txt}\n")
        out.write(f"========================================\n")
        
        # cards or elements
        # let's find all cards
        subboxes = col.find_all(class_=['cockpit-subbox', 'c-kpi-split-card', 'c-mini-kpi', 'cockpit-peer-table-box', 'cockpit-donut-summary-side', 'c-col-card'])
        # Or better, iterate over all tags with text inside col
        for tag in col.find_all(['div', 'span', 'strong', 'em', 'small', 'b', 'title', 'p', 'h3', 'h4']):
            # check if it has meaningful text or title attribute
            title_attr = tag.get('title', '')
            t = tag.get_text(strip=True)
            cls = ' '.join(tag.get('class', []))
            # if it has direct text or title
            if title_attr:
                out.write(f"  [TITLE ATTR] ({cls}) {title_attr}\n")
            # print elements with interesting classes
            if any(k in cls for k in ['title', 'val', 'growth', 'label', 'pct', 'hint', 'stat', 'badge', 'row', 'name', 'share', 'yoy']):
                out.write(f"  <{tag.name} class='{cls}'>: {t}\n")
