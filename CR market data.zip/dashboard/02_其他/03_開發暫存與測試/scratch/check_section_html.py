# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

transcript_path = "C:/Users/詠棠/.gemini/antigravity/brain/b95ecca9-971a-489b-ab53-ec5e0dbbb3cb/.system_generated/logs/transcript_full.jsonl"

with open(transcript_path, "r", encoding="utf-8") as f:
    for line in f:
        if "SECTION 02: 收單業務" in line or "SECTION 04: 系統韌性" in line:
            obj = json.loads(line)
            idx = obj.get("step_index")
            calls = obj.get("tool_calls", [])
            for call in calls:
                args = call.get("args", {})
                for k, v in args.items():
                    if isinstance(v, str) and ("SECTION 02: 收單業務" in v or "SECTION 04: 系統韌性" in v):
                        print(f"Step {idx} in {k}:")
                        # print lines around SECTION 02 / 04
                        lines = v.splitlines()
                        for i, l in enumerate(lines):
                            if "SECTION 0" in l or "<section" in l or "section-title" in l or "business-grid" in l or "shell" in l:
                                print(f"  {i}: {l}")
