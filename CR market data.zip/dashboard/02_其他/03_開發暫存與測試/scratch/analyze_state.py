import re
import os

with open('credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    html = f.read()

print('=== credit_card_full_dashboard.html Analysis ===')
print('Total file size:', len(html), 'bytes')

# Check title
title_match = re.search(r'<title>(.*?)</title>', html)
print('Title:', title_match.group(1) if title_match else 'None')

# Check main sections
sections = re.findall(r'<section\s+id=[\'"]([^\'"]+)[\'"]\s+class=[\'"]([^\'"]+)[\'"]', html)
print(f'Total Main Sections ({len(sections)}):')
for s_id, s_cls in sections:
    print(f'  - ID: {s_id} | Classes: {s_cls}')

# Check Section Titles
titles = re.findall(r'<div class=["\']section-title[^"\']*["\']>[\s\S]*?<span>(.*?)</span>[\s\S]*?<h2>(.*?)</h2>', html)
print(f'Section Titles ({len(titles)}):')
for num, t in titles:
    print(f'  - [{num.strip()}] {t.strip()}')

# Check Subnav buttons
nav_btns = re.findall(r'<button[^>]*class=["\'][^"\']*nav-tab-btn[^"\']*["\'][^>]*>([\s\S]*?)</button>', html)
print(f'Nav Tabs ({len(nav_btns)}):')
for btn in nav_btns:
    cleaned = ' '.join(re.sub(r'<[^<]+?>', ' ', btn).split())
    print(f'  - {cleaned}')

# Check tabs within sections
diag_tabs = re.findall(r'<div class=["\'](?:diagnosis-tabs|unified-tabs)["\'][^>]*id=["\']([^"\']+)["\']>([\s\S]*?)</div>', html)
print(f'Diagnostic Tab Containers ({len(diag_tabs)}):')
for tid, tcontent in diag_tabs:
    btns = re.findall(r'<button[^>]*>([\s\S]*?)</button>', tcontent)
    cleaned_btns = [' '.join(re.sub(r'<[^<]+?>', ' ', b).split()) for b in btns]
    print(f'  - ID: {tid} -> {cleaned_btns}')

# Check KPI counts per section
print('\n=== KPI Card Distribution ===')
sec_blocks = re.split(r'<section\s+id=[\'"]', html)[1:]
for sb in sec_blocks:
    sec_id = sb.split('\'"')[0].split('"')[0].split("'")[0]
    p_cards = len(re.findall(r'class=["\'][^"\']*monthly-primary[^"\']*["\']', sb))
    s_cards = len(re.findall(r'class=["\'][^"\']*monthly-secondary[^"\']*["\']', sb))
    acq_p = len(re.findall(r'class=["\'][^"\']*acq-primary[^"\']*["\']', sb))
    print(f'  Section {sec_id}: Primary KPI Cards = {p_cards + acq_p}, Secondary KPI Cards = {s_cards}')

