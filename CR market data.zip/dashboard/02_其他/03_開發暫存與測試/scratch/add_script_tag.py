import os
from bs4 import BeautifulSoup

html_path = 'credit_card_full_dashboard.html'
with open(html_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Let's inspect where <script src="dashboard_data.js"> can be added
if 'dashboard_data.js' not in content:
    # Add right before </head>
    head_end = content.find('</head>')
    if head_end != -1:
        content = content[:head_end] + '  <script src="dashboard_data.js"></script>\n' + content[head_end:]
        print("Added <script src='dashboard_data.js'></script> to head")

with open(html_path, 'w', encoding='utf-8') as f:
    f.write(content)
print("Updated HTML with script reference!")
