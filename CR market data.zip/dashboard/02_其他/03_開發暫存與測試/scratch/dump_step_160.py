# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

transcript_path = 'C:/Users/詠棠/.gemini/antigravity/brain/b95ecca9-971a-489b-ab53-ec5e0dbbb3cb/.system_generated/logs/transcript_full.jsonl'
with open(transcript_path, 'r', encoding='utf-8') as f:
    for line in f:
        obj = json.loads(line)
        idx = obj.get('step_index')
        if idx in [154, 156, 160, 162]:
            calls = obj.get('tool_calls', [])
            for c in calls:
                args = c.get('args', {})
                print(f"=== Step {idx} Call {c.get('name')} ===")
                tc = args.get('TargetContent', '')
                rc = args.get('ReplacementContent', '')
                if tc:
                    print("TargetContent:", tc[:300])
                    print("ReplacementContent:", rc[:300])
