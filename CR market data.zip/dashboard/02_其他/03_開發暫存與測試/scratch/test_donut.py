# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import math

def generate_donut_svg():
    # Data: 5 slices
    slices = [
        {"name": "中國信託", "share": 19.47, "color": "#003b5c"},
        {"name": "國泰世華", "share": 18.64, "color": "#009e73"}, # Cathay Green
        {"name": "台北富邦", "share": 14.49, "color": "#2563eb"},
        {"name": "玉山銀行", "share": 14.06, "color": "#059669"},
        {"name": "其他同業", "share": 33.34, "color": "#cbd5e1"}
    ]
    
    cx, cy, r_out, r_in = 65, 65, 60, 36
    paths = []
    start_angle = -90.0 # start at 12 o'clock
    
    for s in slices:
        angle_len = (s["share"] / 100.0) * 360.0
        end_angle = start_angle + angle_len
        
        # Radians
        rad_start = math.radians(start_angle)
        rad_end = math.radians(end_angle)
        
        x1_out = cx + r_out * math.cos(rad_start)
        y1_out = cy + r_out * math.sin(rad_start)
        x2_out = cx + r_out * math.cos(rad_end)
        y2_out = cy + r_out * math.sin(rad_end)
        
        x1_in = cx + r_in * math.cos(rad_end)
        y1_in = cy + r_in * math.sin(rad_end)
        x2_in = cx + r_in * math.cos(rad_start)
        y2_in = cy + r_in * math.sin(rad_start)
        
        large_arc = 1 if angle_len > 180 else 0
        
        d = f"M {x1_out:.2f} {y1_out:.2f} A {r_out} {r_out} 0 {large_arc} 1 {x2_out:.2f} {y2_out:.2f} L {x1_in:.2f} {y1_in:.2f} A {r_in} {r_in} 0 {large_arc} 0 {x2_in:.2f} {y2_in:.2f} Z"
        paths.append(f'<path d="{d}" fill="{s["color"]}" stroke="#ffffff" stroke-width="1.5"><title>{s["name"]}: {s["share"]}%</title></path>')
        
        start_angle = end_angle
        
    svg = f'''<svg viewBox="0 0 130 130" width="105" height="105" style="display:block; flex-shrink:0;">
        {''.join(paths)}
        <circle cx="{cx}" cy="{cy}" r="{r_in}" fill="#ffffff" />
        <text x="{cx}" y="{cy-3}" font-size="10" font-weight="900" fill="#003b5c" text-anchor="middle">全市場</text>
        <text x="{cx}" y="{cy+11}" font-size="9" font-weight="700" fill="#64748b" text-anchor="middle">30,720億</text>
    </svg>'''
    return svg

print("Donut SVG test:")
svg = generate_donut_svg()
print(svg[:300])
