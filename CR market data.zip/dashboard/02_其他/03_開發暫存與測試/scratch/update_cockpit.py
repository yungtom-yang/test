# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import re

with open('scratch/build_dashboard.py', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Update Subnav button text to "00 總覽"
text = text.replace(
    '<button type="button" class="nav-tab-btn active" data-target="section-cockpit" onclick="switchMainSection(\'section-cockpit\')">\n        <span class="nav-num">00</span> 決策總覽\n      </button>',
    '<button type="button" class="nav-tab-btn active" data-target="section-cockpit" onclick="switchMainSection(\'section-cockpit\')">\n        <span class="nav-num">00</span> 總覽\n      </button>'
)

# 2. Update render_cockpit_section definition
donut_func_code = '''import math

def get_cockpit_donut_svg():
    slices = [
        {"name": "中國信託", "share": 19.5, "color": "#003b5c"},
        {"name": "國泰世華", "share": 18.6, "color": "#009e73"},
        {"name": "台北富邦", "share": 14.5, "color": "#2563eb"},
        {"name": "玉山銀行", "share": 14.1, "color": "#059669"},
        {"name": "其他同業", "share": 33.3, "color": "#cbd5e1"}
    ]
    cx, cy, r_out, r_in = 50, 50, 46, 27
    paths = []
    start_angle = -90.0
    for s in slices:
        angle_len = (s["share"] / 100.0) * 360.0
        end_angle = start_angle + angle_len
        rad_start = math.radians(start_angle)
        rad_end = math.radians(end_angle)
        x1_out = cx + r_out * math.cos(rad_start)
        y1_out = cy + r_out * math.sin(rad_start)
        x2_out = cx + r_out * math.cos(rad_end)
        y2_out = cy + r_out * math.sin(rad_end)
        x1_in = cx + r_in * math.cos(rad_end)
        y1_in = cy + r_in * math.sin(rad_end)
        x2_in = cx + r_in * math.cos(rad_start)
        y2_in = cy + r_in * math.sin(rad_start)
        large_arc = 1 if angle_len > 180 else 0
        path_d = f"M {x1_out:.2f} {y1_out:.2f} A {r_out} {r_out} 0 {large_arc} 1 {x2_out:.2f} {y2_out:.2f} L {x1_in:.2f} {y1_in:.2f} A {r_in} {r_in} 0 {large_arc} 0 {x2_in:.2f} {y2_in:.2f} Z"
        paths.append(f'<path d="{path_d}" fill="{s["color"]}" stroke="#ffffff" stroke-width="1.2"><title>{s["name"]}: {s["share"]}%</title></path>')
        start_angle = end_angle
    return f\'\'\'<svg viewBox="0 0 100 100" width="80" height="80" style="display:block; flex-shrink:0;">
        {''.join(paths)}
        <circle cx="{cx}" cy="{cy}" r="{r_in}" fill="#ffffff" />
        <text x="{cx}" y="{cy-2}" font-size="8" font-weight="900" fill="#003b5c" text-anchor="middle">全市場</text>
        <text x="{cx}" y="{cy+8}" font-size="7" font-weight="700" fill="#64748b" text-anchor="middle">30,720億</text>
    </svg>\'\'\'

def render_cockpit_section(d):
    b1 = d["block01_overview"]
    b2 = d["block02_acquiring"]
    b3 = d["block03_issuing"]
    b4 = d["block04_resilience"]

    donut_svg = get_cockpit_donut_svg()

    peers_list = [
        {"name": "中國信託", "val": 5980.0, "share": 19.5, "yoy": "+11.2%", "rank": 1, "is_me": False},
        {"name": "國泰世華", "val": 5726.0, "share": 18.6, "yoy": "+12.8%", "rank": 2, "is_me": True},
        {"name": "台北富邦", "val": 4450.0, "share": 14.5, "yoy": "+18.4%", "rank": 3, "is_me": False},
        {"name": "玉山銀行", "val": 4320.0, "share": 14.1, "yoy": "+9.6%", "rank": 4, "is_me": False}
    ]

    peer_rows_html = "".join([f\'\'\'
      <div class="cockpit-peer-row {"highlight" if p["is_me"] else ""}">
        <span class="p-rank">#{p["rank"]}</span>
        <span class="p-name">{p["name"]}</span>
        <span class="p-val">{p["val"]:,.0f} 億</span>
        <span class="p-share"><b>{p["share"]}%</b></span>
        <span class="p-yoy number-positive">{p["yoy"]}</span>
      </div>\'\'\' for p in peers_list])

    return f"""
  <!-- ========================================================
       SECTION 00: 信用卡營運總覽 (SINGLE-VIEWPORT NO-SCROLL COCKPIT)
       ======================================================== -->
  <section id="section-cockpit" class="dashboard-section main-section active">
    <div class="section-title section-orange">
      <span>00</span>
      <h2>信用卡營運總覽</h2>
      <i></i>
    </div>

    <div class="cockpit-grid">
      <!-- COLUMN 1: 01 全行概況 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <span class="cockpit-badge c-badge-orange">01 全行概況</span>
        </div>

        <!-- 總交易金額 & 總交易筆數 (含一般/分期絕對金額、筆數與佔比) -->
        <div class="cockpit-subbox">
          <!-- Card 1: 總交易金額 -->
          <div class="c-kpi-split-card">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">總交易金額</span>
              <div class="c-kpi-growth"><span class="number-positive">YoY +12.8%</span> <span class="number-positive">MoM +2.1%</span></div>
            </div>
            <div class="c-kpi-main-val">1,286.4 <em>億元</em></div>
            <div class="c-kpi-breakdown-row">
              <div class="c-breakdown-item">
                <span class="b-label">一般交易</span>
                <strong class="b-val">1,086.4 億</strong>
                <span class="b-share">佔比 84.4%</span>
              </div>
              <div class="c-breakdown-divider"></div>
              <div class="c-breakdown-item">
                <span class="b-label">分期交易</span>
                <strong class="b-val">200.0 億</strong>
                <span class="b-share">佔比 15.6%</span>
              </div>
            </div>
          </div>

          <!-- Card 2: 總交易筆數 -->
          <div class="c-kpi-split-card" style="margin-top: 6px;">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">總交易筆數</span>
              <div class="c-kpi-growth"><span class="number-positive">YoY +15.2%</span> <span class="number-positive">MoM +1.7%</span></div>
            </div>
            <div class="c-kpi-main-val">8,425 <em>萬筆</em></div>
            <div class="c-kpi-breakdown-row">
              <div class="c-breakdown-item">
                <span class="b-label">一般交易</span>
                <strong class="b-val">7,750 萬筆</strong>
                <span class="b-share">佔比 92.0%</span>
              </div>
              <div class="c-breakdown-divider"></div>
              <div class="c-breakdown-item">
                <span class="b-label">分期交易</span>
                <strong class="b-val">675 萬筆</strong>
                <span class="b-share">佔比 8.0%</span>
              </div>
            </div>
          </div>

          <!-- Mini Row: 預借現金 & 循環信用 -->
          <div class="c-kpi-mini-grid" style="margin-top: 6px;">
            <div class="c-mini-kpi">
              <span class="c-kpi-title">預借現金金額</span>
              <strong class="c-mini-val">18.6 <em>億元</em></strong>
              <div class="c-kpi-growth"><span class="number-negative">YoY -3.4%</span> <span class="c-hint">42.8萬筆</span></div>
            </div>
            <div class="c-mini-kpi">
              <span class="c-kpi-title">循環信用餘額</span>
              <strong class="c-mini-val">325.7 <em>億元</em></strong>
              <div class="c-kpi-growth"><span class="number-positive">YoY +6.7%</span> <span class="c-hint">生息資產</span></div>
            </div>
          </div>
        </div>

        <!-- 四大發卡行簽帳金額與市佔 (圓餅圖 + 表頭項目名稱 + 無註解) -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>四大發卡行簽帳金額與市佔</span>
            <span class="cockpit-tag-pill">2026 年 1–8 月</span>
          </div>

          <div class="cockpit-market-wrap">
            {donut_svg}
            <div class="cockpit-peer-table-box">
              <div class="cockpit-peer-header">
                <span class="p-rank">排名</span>
                <span class="p-name">發卡銀行</span>
                <span class="p-val">簽帳金額</span>
                <span class="p-share">市占率</span>
                <span class="p-yoy">YoY</span>
              </div>
              <div class="cockpit-peer-list">
                {peer_rows_html}
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- COLUMN 2: 02 收單業務 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <span class="cockpit-badge c-badge-blue">02 收單業務</span>
        </div>

        <!-- 自行收單核心概況 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>自行收單大盤</span>
            <span class="c-tag-green">活店率 83.0%</span>
          </div>
          <div class="c-mini-stat-banner">
            <div>
              <small>收單總金額</small>
              <strong>285.0<em>億</em></strong>
              <b class="number-positive">YoY +12.8%</b>
            </div>
            <div class="divider-v"></div>
            <div>
              <small>實體 / 線上 EPOS</small>
              <div class="c-split-bar">
                <span class="bar-phys" style="width: 65%;">65% 實體</span>
                <span class="bar-onl" style="width: 35%;">35% 線上</span>
              </div>
              <small class="c-foot-hint">平均客單：1,540 元（+1.2%）</small>
            </div>
          </div>
        </div>

        <!-- TWQR 業務分析專區 (特店進件 + 交易造血) -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>TWQR 國家共同標準業務分析</span>
            <span class="cockpit-tag-pill primary">特店拓點特刊</span>
          </div>

          <!-- TWQR Top Block: 特店進件分析 -->
          <div class="twqr-cockpit-section">
            <div class="twqr-subhead">
              <b>拓展 Pipeline</b>
              <span>通過率 91.2%</span>
            </div>
            <div class="c-twqr-stat-grid">
              <div class="c-twqr-cell">
                <span>當月申請進件數</span>
                <strong>3,850 <em>件</em></strong>
                <b class="number-positive">審查通過率 91.2%</b>
              </div>
              <div class="c-twqr-cell">
                <span>累計特店家數</span>
                <strong>22,100 <em>家</em></strong>
                <b class="number-positive">MoM +5.8% (+1,210家)</b>
              </div>
            </div>
          </div>

          <!-- TWQR Bottom Block: 交易狀態造血動能 -->
          <div class="twqr-cockpit-section" style="margin-top: 8px;">
            <div class="twqr-subhead">
              <b>交易造血動能</b>
              <span>動用特店率 68.2%</span>
            </div>
            <div class="c-twqr-stat-grid three-col">
              <div class="c-twqr-cell">
                <span>當月交易金額</span>
                <strong>14.8 <em>億</em></strong>
                <b class="number-positive">MoM +18.5%</b>
              </div>
              <div class="c-twqr-cell">
                <span>當月交易筆數</span>
                <strong>185 <em>萬筆</em></strong>
                <b class="number-positive">MoM +16.2%</b>
              </div>
              <div class="c-twqr-cell">
                <span>平均客單價</span>
                <strong>800 <em>元</em></strong>
                <b class="number-positive">MoM +2.0%</b>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- COLUMN 3: 03 發卡業務 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <span class="cockpit-badge c-badge-orange">03 發卡業務</span>
        </div>

        <!-- 徵審進件中樞 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>徵審進件中樞自動化</span>
            <span class="c-tag-green">STP 核准率 76.5%</span>
          </div>
          <div class="c-stat-row">
            <div class="c-stat-item">
              <small>當月申辦總量</small>
              <strong>85,400 <em>件</em></strong>
              <span>舊戶 4.7 萬 ｜ 新戶 3.84 萬</span>
            </div>
            <div class="c-stat-item highlight-box">
              <small>自動直接核准</small>
              <strong style="color:var(--green);">65,300 <em>件</em></strong>
              <span>綜合自動核准率 76.5%</span>
            </div>
          </div>
          <div class="c-progress-bar-wrap">
            <div class="c-progress-fill" style="width: 76.5%;">自動核准 76.5%</div>
            <div class="c-progress-rest" style="width: 23.5%;">人工 23.5%</div>
          </div>
        </div>

        <!-- 信用卡電子帳單數據 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>帳單數據與數位降本</span>
            <span class="cockpit-tag-pill">覆蓋率 91.8%</span>
          </div>
          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>電子帳單總本數</small>
              <strong>520.0 <em>萬本</em></strong>
              <span class="number-positive">YoY +6.8%</span>
            </div>
            <div class="c-stat-item">
              <small>紙本帳單節約</small>
              <strong>42.6 <em>萬本</em></strong>
              <span class="number-positive">YoY −8.0%</span>
            </div>
          </div>
        </div>

        <!-- 小樹點概況 (TAB 3 水庫循環) -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>小樹點水庫循環概況 (TAB 3)</span>
            <span class="c-tag-green">兌換率 84.2%</span>
          </div>
          <div class="c-twqr-stat-grid three-col">
            <div class="c-twqr-cell">
              <span>水庫流通累積</span>
              <strong>48.2 <em>億點</em></strong>
              <b class="number-positive">活水循環</b>
            </div>
            <div class="c-twqr-cell">
              <span>當月贈送點數</span>
              <strong>3.8 <em>億點</em></strong>
              <b class="number-positive">YoY +18.7%</b>
            </div>
            <div class="c-twqr-cell">
              <span>當月兌換點數</span>
              <strong>3.2 <em>億點</em></strong>
              <b class="number-positive">YoY +23.1%</b>
            </div>
          </div>
        </div>
      </div>

      <!-- COLUMN 4: 04 系統韌性 -->
      <div class="cockpit-col">
        <div class="cockpit-col-header">
          <span class="cockpit-badge c-badge-dark">04 系統韌性</span>
        </div>

        <!-- CardPool 授權核心主機 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>CardPool 授權核心主機</span>
            <span class="c-tag-green">可用率 99.999%</span>
          </div>
          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>交易響應時間</small>
              <strong style="color:var(--green);">85 <em>ms</em></strong>
              <span class="number-positive">零超時 (0筆)</span>
            </div>
            <div class="c-stat-item">
              <small>月授權交易量</small>
              <strong>6,820 <em>萬筆</em></strong>
              <span>成功率 98.8%</span>
            </div>
          </div>
        </div>

        <!-- Cardlink 核心帳務主機 -->
        <div class="cockpit-subbox">
          <div class="cockpit-box-title">
            <span>Cardlink 核心帳務主機</span>
            <span class="c-tag-green">SLA 100% 達標</span>
          </div>
          <div class="c-stat-row compact">
            <div class="c-stat-item">
              <small>月帳務處理量</small>
              <strong>1.42 <em>億筆</em></strong>
              <span>高可靠運作</span>
            </div>
            <div class="c-stat-item">
              <small>系統可用率 / 峰值</small>
              <strong>100.0%</strong>
              <span>峰值 4,850 TPS</span>
            </div>
          </div>
        </div>

        <!-- 三大資安防詐防線成果 (SFM & 3DS) -->
        <div class="cockpit-subbox flex-grow">
          <div class="cockpit-box-title">
            <span>三大資安防詐成果 (SFM & 3DS)</span>
            <span class="cockpit-tag-pill warning">全月防堵 4,280 萬</span>
          </div>

          <!-- Total Banner -->
          <div class="fraud-total-cockpit-bar">
            <div>
              <span>全月總防堵金額</span>
              <strong>4,280 <em>萬元</em></strong>
            </div>
            <div class="divider-v"></div>
            <div>
              <span>阻斷冒用卡數</span>
              <strong>2,684 <em>張</em></strong>
            </div>
          </div>

          <!-- 3-line Breakdown -->
          <div class="fraud-lines-list">
            <div class="f-line-item">
              <span class="f-tag sfm">SFM</span>
              <span class="f-name">申請詐欺防堵</span>
              <span class="f-amt">1,150 萬元</span>
              <span class="f-cnt">842 張</span>
            </div>
            <div class="f-line-item">
              <span class="f-tag tds">3DS</span>
              <span class="f-name">線上交易防堵</span>
              <span class="f-amt">860 萬元</span>
              <span class="f-cnt">620 張</span>
            </div>
            <div class="f-line-item">
              <span class="f-tag sfm">SFM</span>
              <span class="f-name">交易詐欺防堵</span>
              <span class="f-amt">2,270 萬元</span>
              <span class="f-cnt">1,222 張</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
"""
'''

start_idx = text.find('def render_cockpit_section(d):')
end_idx = text.find('b0_cockpit_html = render_cockpit_section(d)')

if start_idx != -1 and end_idx != -1:
    text = text[:start_idx] + donut_func_code + "\n\n" + text[end_idx:]
    print("Replaced render_cockpit_section definition!")
else:
    print("Failed to find start/end index for render_cockpit_section!")

# 3. Add Extra CSS for the breakdown and donut table
extra_cockpit_css = """
.c-kpi-split-card {
  background: #ffffff;
  border: 1px solid #e1ebe7;
  border-radius: 6px;
  padding: 6px 8px;
}
.c-kpi-header-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.c-kpi-main-val {
  font-size: 18px;
  font-weight: 900;
  color: var(--ink);
  line-height: 1.15;
  margin: 1px 0 4px;
}
.c-kpi-main-val em {
  font-size: 11px;
  font-style: normal;
  font-weight: 600;
  color: #72848c;
}
.c-kpi-breakdown-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #f8fafb;
  border-radius: 4px;
  padding: 4px 6px;
  border: 1px solid #edf2f0;
}
.c-breakdown-item {
  display: flex;
  flex-direction: column;
  gap: 1px;
  flex: 1;
}
.b-label {
  font-size: 9.5px;
  color: #62757d;
  font-weight: 700;
}
.b-val {
  font-size: 11.5px;
  font-weight: 800;
  color: var(--ink);
}
.b-share {
  font-size: 9.5px;
  font-weight: 800;
  color: var(--orange-dark);
}
.c-breakdown-divider {
  width: 1px;
  height: 24px;
  background: #e2ebe6;
  margin: 0 6px;
}
.c-kpi-mini-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
}
.c-mini-kpi {
  background: #ffffff;
  border: 1px solid #e1ebe7;
  border-radius: 5px;
  padding: 5px 7px;
  display: flex;
  flex-direction: column;
}
.c-mini-val {
  font-size: 14.5px;
  font-weight: 900;
  color: var(--ink);
  margin: 1px 0;
}
.c-mini-val em {
  font-size: 9.5px;
  font-style: normal;
  color: #72848c;
  font-weight: 600;
}
.c-hint {
  font-size: 9.5px;
  color: #7d8f96;
  font-weight: 600;
}
.cockpit-market-wrap {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 4px;
}
.cockpit-peer-table-box {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.cockpit-peer-header {
  display: grid;
  grid-template-columns: 20px 50px 1fr 38px 40px;
  align-items: center;
  font-size: 9.5px;
  font-weight: 800;
  color: #64748b;
  padding: 1px 4px;
  border-bottom: 1px solid #e2e8f0;
  margin-bottom: 1px;
}
.cockpit-peer-header .p-rank { text-align: center; }
.cockpit-peer-header .p-name { text-align: left; }
.cockpit-peer-header .p-val { text-align: right; }
.cockpit-peer-header .p-share { text-align: right; }
.cockpit-peer-header .p-yoy { text-align: right; }

.cockpit-peer-row {
  display: grid;
  grid-template-columns: 20px 50px 1fr 38px 40px;
  align-items: center;
  font-size: 10px;
  padding: 2px 4px;
  border-radius: 3px;
  background: #fff;
  border: 1px solid #edf2f0;
}
"""

if ".c-kpi-split-card" not in text:
    target_css = "/* SECTION 00: COCKPIT VIEWPORT STYLING (ZERO SCROLL FIT) */"
    text = text.replace(target_css, extra_cockpit_css + "\n" + target_css)
    print("Added extra CSS for Col 01 split and donut!")

with open('scratch/build_dashboard.py', 'w', encoding='utf-8') as f:
    f.write(text)

print("build_dashboard.py updated!")
