# -*- coding: utf-8 -*-
with open("01_儀表板執行環境/credit_card_full_dashboard.html", "r", encoding="utf-8") as f:
    text = f.read()

idx1 = text.find('id="acq-kpis"')
idx2 = text.find('<!-- 收單深入診斷圖表', idx1)

print("idx1:", idx1, "idx2:", idx2)
with open("02_其他/03_開發暫存與測試/scratch/slice_acq.txt", "w", encoding="utf-8") as out:
    out.write(text[idx1-60:idx2])
print("Wrote slice_acq.txt")
