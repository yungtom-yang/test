import re

with open('credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    text = f.read()

matches = re.finditer(r'<div class=["\']unified-insights["\']>([\s\S]*?)</div>', text)
for i, m in enumerate(matches):
    chunk = m.group(1)
    items = re.findall(r'<div><span>(.*?)</span><strong>(.*?)</strong><em>(.*?)</em></div>', chunk)
    print(f'Set {i+1} at index {m.start()} ({len(items)} items):')
    for label, val, sub in items:
        print(f'  - {label}: {val} ({sub})')
