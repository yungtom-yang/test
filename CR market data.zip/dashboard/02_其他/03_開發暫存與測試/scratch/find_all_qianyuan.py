import openpyxl, re, sys
sys.stdout.reconfigure(encoding='utf-8')

print("=== 1. dashboard_data.xlsx ===")
wb = openpyxl.load_workbook("01_儀表板執行環境/dashboard_data.xlsx", data_only=True)
for sheet in wb.sheetnames:
    ws = wb[sheet]
    for r_idx, row in enumerate(ws.iter_rows(values_only=True), start=1):
        for c_idx, cell in enumerate(row, start=1):
            if cell is not None and isinstance(cell, str) and "千元" in cell:
                print(f"Sheet [{sheet}] Row {r_idx} Col {c_idx}: {cell} (Row: {row[:4]})")

print("\n=== 2. sync_excel.py ===")
with open("01_儀表板執行環境/sync_excel.py", "r", encoding="utf-8") as f:
    lines = f.readlines()
for i, line in enumerate(lines, start=1):
    if "千元" in line:
        print(f"Line {i}: {line.strip()}")

print("\n=== 3. credit_card_full_dashboard.html ===")
with open("01_儀表板執行環境/credit_card_full_dashboard.html", "r", encoding="utf-8") as f:
    html_lines = f.readlines()
for i, line in enumerate(html_lines, start=1):
    if "千元" in line:
        print(f"Line {i}: {line.strip()[:120]}")
