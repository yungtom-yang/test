# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import re

with open('credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Nav button
btn_match = re.search(r'<button[^>]*data-target="section-cockpit"[^>]*>([\s\S]*?)</button>', html)
print("1. Subnav 00 button text:")
if btn_match:
    print("  ", ' '.join(re.sub(r'<[^<]+?>', ' ', btn_match.group(1)).split()))

# 2. Section Title
title_match = re.search(r'<section id="section-cockpit"[^>]*>[\s\S]*?<div class="section-title[^"]*">([\s\S]*?)</div>', html)
print("\n2. Section 00 Title:")
if title_match:
    print("  ", ' '.join(re.sub(r'<[^<]+?>', ' ', title_match.group(1)).split()))

# 3. Column headers in Section 00
cockpit_section = html.split('id="section-cockpit"')[1].split('</section>')[0]
col_headers = re.findall(r'<div class="cockpit-col-header">([\s\S]*?)</div>', cockpit_section)
print(f"\n3. Column headers ({len(col_headers)}):")
for ch in col_headers:
    print("  -", ' '.join(re.sub(r'<[^<]+?>', ' ', ch).split()))

# 4. Check Col 01 breakdown
print("\n4. Col 01 Breakdown check:")
for kw in ["1,086.4 億", "84.4%", "200.0 億", "15.6%", "7,750 萬筆", "92.0%", "675 萬筆", "8.0%"]:
    print(f"  [{'OK' if kw in cockpit_section else 'MISSING'}] {kw}")

# 5. Check Table Headers in Col 01
print("\n5. Peer table header check:")
for th in ["排名", "發卡銀行", "簽帳金額", "市占率", "YoY"]:
    print(f"  [{'OK' if th in cockpit_section else 'MISSING'}] {th}")

# 6. Check Donut SVG
has_svg = '<svg viewBox="0 0 130 130"' in cockpit_section
print(f"\n6. Donut SVG in cockpit (130x130): {'OK' if has_svg else 'MISSING'}")

# 7. Check foot-note count
fn_count = cockpit_section.count('cockpit-foot-note')
print(f"\n7. Footnotes in cockpit: {fn_count} (should be 0)")
