# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

transcript_path = "C:/Users/詠棠/.gemini/antigravity/brain/b95ecca9-971a-489b-ab53-ec5e0dbbb3cb/.system_generated/logs/transcript_full.jsonl"

with open(transcript_path, "r", encoding="utf-8") as f:
    for line in f:
        if "issuing-section" in line:
            obj = json.loads(line)
            idx = obj.get("step_index")
            print(f"Step {idx} had issuing-section")
            # see if there is CSS
            c = obj.get("content", "")
            if ".issuing-section" in c:
                p = c.find(".issuing-section")
                print("In content:", c[p:p+300])
            for call in obj.get("tool_calls", []):
                args = call.get("args", {})
                for k, v in args.items():
                    if isinstance(v, str) and ".issuing-section" in v:
                        p = v.find(".issuing-section")
                        print(f"In tool call arg {k}:", v[p:p+300])
