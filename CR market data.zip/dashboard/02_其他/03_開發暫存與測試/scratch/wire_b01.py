# -*- coding: utf-8 -*-
import re

html_path = 'credit_card_full_dashboard.html'
with open(html_path, 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Update Block 00 Column 1 markup to have clean target IDs
# Replace Card 1: 總交易金額 in cockpit
old_c00_card1 = """          <!-- Card 1: 總交易金額 -->
          <div class="c-kpi-split-card">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">總交易金額</span>
              <div class="c-kpi-growth"><span class="number-positive">YoY +12.8%</span> <span class="number-positive">MoM +2.1%</span></div>
            </div>
            <div class="c-kpi-main-val">1,286.4 <em>億元</em></div>
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-general" style="width: 84%;" title="一般交易: 84% (1,086.4 億)"></div>
                <div class="c-ratio-seg seg-install" style="width: 16%;" title="分期交易: 16% (200.0 億)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-general"></span>一般交易 <span class="r-pct r-pct-general">(84%)</span></span>
                <strong class="r-val">1,086.4<em>億</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-install"></span>分期交易 <span class="r-pct r-pct-install">(16%)</span></span>
                <strong class="r-val">200.0<em>億</em></strong>
              </div>
            </div>
          </div>"""

new_c00_card1 = """          <!-- Card 1: 總交易金額 -->
          <div class="c-kpi-split-card" id="c00-card-amt">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">總交易金額</span>
              <div class="c-kpi-growth" id="c00-amt-growth"><span class="number-positive">YoY +12.8%</span> <span class="number-positive">MoM +2.1%</span></div>
            </div>
            <div class="c-kpi-main-val" id="c00-amt-val">1,286.4 <em>億元</em></div>
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-general" id="c00-amt-seg-gen" style="width: 84.4%;" title="一般交易: 84.4% (1,086.4 億)"></div>
                <div class="c-ratio-seg seg-install" id="c00-amt-seg-inst" style="width: 15.6%;" title="分期交易: 15.6% (200.0 億)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-general"></span>一般交易 <span class="r-pct r-pct-general" id="c00-amt-gen-pct">(84.4%)</span></span>
                <strong class="r-val" id="c00-amt-gen-val">1,086.4<em>億</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-install"></span>分期交易 <span class="r-pct r-pct-install" id="c00-amt-inst-pct">(15.6%)</span></span>
                <strong class="r-val" id="c00-amt-inst-val">200.0<em>億</em></strong>
              </div>
            </div>
          </div>"""

if old_c00_card1 in html:
    html = html.replace(old_c00_card1, new_c00_card1)
    print("Replaced c00 Card 1")
else:
    print("c00 Card 1 pattern not matched directly, will check with regex")

# Replace Card 2: 總交易筆數 in cockpit
old_c00_card2 = """          <!-- Card 2: 總交易筆數 -->
          <div class="c-kpi-split-card" style="margin-top: 3px;">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">總交易筆數</span>
              <div class="c-kpi-growth"><span class="number-positive">YoY +15.2%</span> <span class="number-positive">MoM +1.7%</span></div>
            </div>
            <div class="c-kpi-main-val">8,425 <em>萬筆</em></div>
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-general" style="width: 92%;" title="一般交易: 92% (7,750 萬筆)"></div>
                <div class="c-ratio-seg seg-install" style="width: 8%;" title="分期交易: 8% (675 萬筆)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-general"></span>一般交易 <span class="r-pct r-pct-general">(92%)</span></span>
                <strong class="r-val">7,750<em>萬筆</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-install"></span>分期交易 <span class="r-pct r-pct-install">(8%)</span></span>
                <strong class="r-val">675<em>萬筆</em></strong>
              </div>
            </div>
          </div>"""

new_c00_card2 = """          <!-- Card 2: 總交易筆數 -->
          <div class="c-kpi-split-card" id="c00-card-cnt" style="margin-top: 3px;">
            <div class="c-kpi-header-row">
              <span class="c-kpi-title">總交易筆數</span>
              <div class="c-kpi-growth" id="c00-cnt-growth"><span class="number-positive">YoY +15.2%</span> <span class="number-positive">MoM +1.7%</span></div>
            </div>
            <div class="c-kpi-main-val" id="c00-cnt-val">8,425 <em>萬筆</em></div>
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-general" id="c00-cnt-seg-gen" style="width: 92.0%;" title="一般交易: 92.0% (7,750 萬筆)"></div>
                <div class="c-ratio-seg seg-install" id="c00-cnt-seg-inst" style="width: 8.0%;" title="分期交易: 8.0% (675 萬筆)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-general"></span>一般交易 <span class="r-pct r-pct-general" id="c00-cnt-gen-pct">(92.0%)</span></span>
                <strong class="r-val" id="c00-cnt-gen-val">7,750<em>萬筆</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-install"></span>分期交易 <span class="r-pct r-pct-install" id="c00-cnt-inst-pct">(8.0%)</span></span>
                <strong class="r-val" id="c00-cnt-inst-val">675<em>萬筆</em></strong>
              </div>
            </div>
          </div>"""

if old_c00_card2 in html:
    html = html.replace(old_c00_card2, new_c00_card2)
    print("Replaced c00 Card 2")

# Replace Mini row in cockpit
old_c00_mini = """          <!-- Mini Row: 預借現金 & 循環信用 -->
          <div class="c-kpi-mini-grid" style="margin-top: 3px;">
            <div class="c-mini-kpi">
              <span class="c-kpi-title">預借現金金額</span>
              <strong class="c-mini-val">18.6 <em>億元</em></strong>
              <div class="c-kpi-growth"><span class="number-negative">YoY -3.4%</span> <span class="c-hint">(42.8萬筆)</span></div>
            </div>
            <div class="c-mini-kpi">
              <span class="c-kpi-title">循環信用餘額</span>
              <strong class="c-mini-val">325.7 <em>億元</em></strong>
              <div class="c-kpi-growth"><span class="number-positive">YoY +6.7%</span></div>
            </div>
          </div>"""

new_c00_mini = """          <!-- Mini Row: 預借現金 & 循環信用 -->
          <div class="c-kpi-mini-grid" style="margin-top: 3px;">
            <div class="c-mini-kpi">
              <span class="c-kpi-title">預借現金金額</span>
              <strong class="c-mini-val" id="c00-cashadv-val">18.6 <em>億元</em></strong>
              <div class="c-kpi-growth" id="c00-cashadv-growth"><span class="number-negative">YoY -3.4%</span> <span class="c-hint" id="c00-cashadv-hint">(42.8萬筆)</span></div>
            </div>
            <div class="c-mini-kpi">
              <span class="c-kpi-title">循環信用餘額</span>
              <strong class="c-mini-val" id="c00-revolving-val">325.7 <em>億元</em></strong>
              <div class="c-kpi-growth" id="c00-revolving-growth"><span class="number-positive">YoY +6.7%</span></div>
            </div>
          </div>"""

if old_c00_mini in html:
    html = html.replace(old_c00_mini, new_c00_mini)
    print("Replaced c00 Mini")

# Replace Donut Side in cockpit
old_c00_donut_summary = """              <div class="cockpit-donut-summary-side">
                <div class="c-market-stat-label">全市場簽帳總額</div>
                <div class="c-market-stat-val">30,720 <em>億元</em></div>
                <div class="c-market-stat-sub">
                  <span class="number-positive">YoY +14.3%</span>
                  <span class="c-hint">四大行佔 66.7%</span>
                </div>
              </div>"""

new_c00_donut_summary = """              <div class="cockpit-donut-summary-side">
                <div class="c-market-stat-label">全市場簽帳總額</div>
                <div class="c-market-stat-val" id="c00-market-val">30,720 <em>億元</em></div>
                <div class="c-market-stat-sub" id="c00-market-sub">
                  <span class="number-positive" id="c00-market-yoy">YoY +14.3%</span>
                  <span class="c-hint" id="c00-top4-hint">四大行佔 66.7%</span>
                </div>
              </div>"""

if old_c00_donut_summary in html:
    html = html.replace(old_c00_donut_summary, new_c00_donut_summary)
    print("Replaced c00 Donut Summary")

# Make peer list container have id="c00-peer-list"
html = html.replace('<div class="cockpit-peer-list">', '<div class="cockpit-peer-list" id="c00-peer-list">')
html = html.replace('<div class="cockpit-donut-chart-wrap">', '<div class="cockpit-donut-chart-wrap" id="c00-donut-wrap">')

# Also in Section 01: overview-kpis
old_b01_cards = """      <!-- 1A: Monthly KPI Cards (2 Primary + 2 Secondary) -->
      <div class="monthly-kpi-layout-4" id="overview-kpis">
        
        <article class="monthly-kpi monthly-primary">
          <div class="monthly-kpi-title">總交易金額</div>
          <div class="monthly-kpi-value">1,286.4<em>億元</em></div>
          <div class="monthly-growth">
            <span class="number-positive"><b>YoY</b>+12.8%</span><span class="number-positive"><b>MoM</b>+2.1%</span>
          </div>
          <div class="monthly-ratio-box">
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-general" style="width: 84.4%;" title="一般交易: 84.4% (1,086.4 億)"></div>
                <div class="c-ratio-seg seg-install" style="width: 15.6%;" title="分期交易: 15.6% (200.0 億)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-general"></span>一般交易 <span class="r-pct r-pct-general">(84.4%)</span></span>
                <strong class="r-val">1,086.4<em>億</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-install"></span>分期交易 <span class="r-pct r-pct-install">(15.6%)</span></span>
                <strong class="r-val">200.0<em>億</em></strong>
              </div>
            </div>
          </div>
        </article>
        <article class="monthly-kpi monthly-primary">
          <div class="monthly-kpi-title">總交易筆數</div>
          <div class="monthly-kpi-value">8,425<em>萬筆</em></div>
          <div class="monthly-growth">
            <span class="number-positive"><b>YoY</b>+15.2%</span><span class="number-positive"><b>MoM</b>+1.7%</span>
          </div>
          <div class="monthly-ratio-box">
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-general" style="width: 92.0%;" title="一般交易: 92.0% (7,750 萬筆)"></div>
                <div class="c-ratio-seg seg-install" style="width: 8.0%;" title="分期交易: 8.0% (675 萬筆)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-general"></span>一般交易 <span class="r-pct r-pct-general">(92.0%)</span></span>
                <strong class="r-val">7,750<em>萬筆</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-install"></span>分期交易 <span class="r-pct r-pct-install">(8.0%)</span></span>
                <strong class="r-val">675<em>萬筆</em></strong>
              </div>
            </div>
          </div>
        </article>
        <!-- Card 3: 活卡率 (比照總交易金額版面，有效卡數 vs 流通卡數) -->
        <article class="monthly-kpi monthly-primary">
          <div class="monthly-kpi-title">活卡率</div>
          <div class="monthly-kpi-value">86.4<em>%</em></div>
          <div class="monthly-growth">
            <span class="number-positive"><b>YoY</b>+1.8pp</span><span class="number-positive"><b>MoM</b>+0.3pp</span>
          </div>
          <div class="monthly-ratio-box">
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-general" style="width: 86.4%;" title="有效卡數: 86.4% (741 萬卡)"></div>
                <div class="c-ratio-seg" style="width: 13.6%; background:#cbd5e1;" title="未動用卡: 13.6% (117 萬卡)"></div>
              </div>
            </div>
            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-general"></span>有效卡數 <span class="r-pct r-pct-general">(86.4%)</span></span>
                <strong class="r-val">741<em>萬卡</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot" style="background:#64748b;"></span>流通卡數</span>
                <strong class="r-val">858<em>萬卡</em></strong>
              </div>
            </div>
          </div>
        </article>
        <!-- Card 4: 信用業務 (循環信用餘額 在上 ｜ 預借現金金額 在下) -->
        <article class="monthly-kpi monthly-secondary monthly-credit-stacked">
          <!-- 上方: 循環信用餘額 -->
          <div class="credit-stacked-item">
            <div class="monthly-kpi-title">循環信用餘額</div>
            <div class="monthly-kpi-value">325.7<em>億元</em></div>
            <div class="monthly-growth">
              <span class="number-positive"><b>YoY</b>+6.7%</span><span class="number-positive"><b>MoM</b>+0.9%</span>
            </div>
          </div>

          <!-- 下方: 預借現金金額 (緊貼分隔線) -->
          <div class="credit-stacked-item credit-stacked-bottom">
            <div class="monthly-kpi-title">預借現金金額</div>
            <div class="monthly-kpi-value">18.6<em>億元</em></div>
            <div class="monthly-growth">
              <span class="number-negative"><b>YoY</b>-3.4%</span><span class="number-negative"><b>MoM</b>-0.8%</span>
            </div>
          </div>
        </article>"""

new_b01_cards = """      <!-- 1A: Monthly KPI Cards (2 Primary + 2 Secondary) -->
      <div class="monthly-kpi-layout-4" id="overview-kpis">
        
        <article class="monthly-kpi monthly-primary" id="b01-card-amt">
          <div class="monthly-kpi-title">總交易金額</div>
          <div class="monthly-kpi-value" id="b01-amt-val">1,286.4<em>億元</em></div>
          <div class="monthly-growth" id="b01-amt-growth">
            <span class="number-positive"><b>YoY</b>+12.8%</span><span class="number-positive"><b>MoM</b>+2.1%</span>
          </div>
          <div class="monthly-ratio-box">
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-general" id="b01-amt-seg-gen" style="width: 84.4%;" title="一般交易: 84.4% (1,086.4 億)"></div>
                <div class="c-ratio-seg seg-install" id="b01-amt-seg-inst" style="width: 15.6%;" title="分期交易: 15.6% (200.0 億)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-general"></span>一般交易 <span class="r-pct r-pct-general" id="b01-amt-gen-pct">(84.4%)</span></span>
                <strong class="r-val" id="b01-amt-gen-val">1,086.4<em>億</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-install"></span>分期交易 <span class="r-pct r-pct-install" id="b01-amt-inst-pct">(15.6%)</span></span>
                <strong class="r-val" id="b01-amt-inst-val">200.0<em>億</em></strong>
              </div>
            </div>
          </div>
        </article>
        <article class="monthly-kpi monthly-primary" id="b01-card-cnt">
          <div class="monthly-kpi-title">總交易筆數</div>
          <div class="monthly-kpi-value" id="b01-cnt-val">8,425<em>萬筆</em></div>
          <div class="monthly-growth" id="b01-cnt-growth">
            <span class="number-positive"><b>YoY</b>+15.2%</span><span class="number-positive"><b>MoM</b>+1.7%</span>
          </div>
          <div class="monthly-ratio-box">
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-general" id="b01-cnt-seg-gen" style="width: 92.0%;" title="一般交易: 92.0% (7,750 萬筆)"></div>
                <div class="c-ratio-seg seg-install" id="b01-cnt-seg-inst" style="width: 8.0%;" title="分期交易: 8.0% (675 萬筆)"></div>
              </div>
            </div>

            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-general"></span>一般交易 <span class="r-pct r-pct-general" id="b01-cnt-gen-pct">(92.0%)</span></span>
                <strong class="r-val" id="b01-cnt-gen-val">7,750<em>萬筆</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot dot-install"></span>分期交易 <span class="r-pct r-pct-install" id="b01-cnt-inst-pct">(8.0%)</span></span>
                <strong class="r-val" id="b01-cnt-inst-val">675<em>萬筆</em></strong>
              </div>
            </div>
          </div>
        </article>
        <!-- Card 3: 活卡率 (比照總交易金額版面，有效卡數 vs 流通卡數) -->
        <article class="monthly-kpi monthly-primary" id="b01-card-active">
          <div class="monthly-kpi-title">活卡率</div>
          <div class="monthly-kpi-value" id="b01-active-val">86.4<em>%</em></div>
          <div class="monthly-growth" id="b01-active-growth">
            <span class="number-positive"><b>YoY</b>+1.8pp</span><span class="number-positive"><b>MoM</b>+0.3pp</span>
          </div>
          <div class="monthly-ratio-box">
            <!-- 100% 比例進度條 -->
            <div class="c-ratio-bar-wrap">
              <div class="c-ratio-bar-track">
                <div class="c-ratio-seg seg-general" id="b01-active-seg-gen" style="width: 86.4%;" title="有效卡數: 86.4% (741 萬卡)"></div>
                <div class="c-ratio-seg" id="b01-active-seg-inact" style="width: 13.6%; background:#cbd5e1;" title="未動用卡: 13.6% (117 萬卡)"></div>
              </div>
            </div>
            <!-- 比例條下方實質數據 -->
            <div class="c-ratio-data-row">
              <div class="c-ratio-col">
                <span class="r-label"><span class="r-dot dot-general"></span>有效卡數 <span class="r-pct r-pct-general" id="b01-active-gen-pct">(86.4%)</span></span>
                <strong class="r-val" id="b01-active-act-val">741<em>萬卡</em></strong>
              </div>
              <div class="c-ratio-col align-right">
                <span class="r-label"><span class="r-dot" style="background:#64748b;"></span>流通卡數</span>
                <strong class="r-val" id="b01-active-iss-val">858<em>萬卡</em></strong>
              </div>
            </div>
          </div>
        </article>
        <!-- Card 4: 信用業務 (循環信用餘額 在上 ｜ 預借現金金額 在下) -->
        <article class="monthly-kpi monthly-secondary monthly-credit-stacked" id="b01-card-credit">
          <!-- 上方: 循環信用餘額 -->
          <div class="credit-stacked-item">
            <div class="monthly-kpi-title">循環信用餘額</div>
            <div class="monthly-kpi-value" id="b01-revolving-val">325.7<em>億元</em></div>
            <div class="monthly-growth" id="b01-revolving-growth">
              <span class="number-positive"><b>YoY</b>+6.7%</span><span class="number-positive"><b>MoM</b>+0.9%</span>
            </div>
          </div>

          <!-- 下方: 預借現金金額 (緊貼分隔線) -->
          <div class="credit-stacked-item credit-stacked-bottom">
            <div class="monthly-kpi-title">預借現金金額</div>
            <div class="monthly-kpi-value" id="b01-cashadv-val">18.6<em>億元</em></div>
            <div class="monthly-growth" id="b01-cashadv-growth">
              <span class="number-negative"><b>YoY</b>-3.4%</span><span class="number-negative"><b>MoM</b>-0.8%</span>
            </div>
          </div>
        </article>"""

if old_b01_cards in html:
    html = html.replace(old_b01_cards, new_b01_cards)
    print("Replaced b01 Cards")

with open(html_path, 'w', encoding='utf-8') as f:
    f.write(html)

print("Updated HTML markup successfully!")
