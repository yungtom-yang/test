import re

with open('01_儀表板執行環境/credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    html = f.read()

idx = html.find('function renderBlock04FromData(data)')
if idx == -1:
    print('Error: renderBlock04FromData not found!')
else:
    end_idx = html.find('document.addEventListener("DOMContentLoaded"', idx)
    code = html[idx:end_idx]
    ids = re.findall(r'getElementById\(["\']([^"\']+)["\']\)', code)
    print(f'Found {len(ids)} getElementById calls ({len(set(ids))} unique) in renderBlock04FromData.')
    missing = []
    for el_id in sorted(set(ids)):
        if f'id="{el_id}"' not in html and f"id='{el_id}'" not in html:
            missing.append(el_id)
    if missing:
        print('MISSING IDs in HTML:', missing)
    else:
        print('ALL IDs in renderBlock04FromData exist in HTML! (100% matched)')
        for el_id in sorted(set(ids)):
            print(f'  [OK] {el_id}')
