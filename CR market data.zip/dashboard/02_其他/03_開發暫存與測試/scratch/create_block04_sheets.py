import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
import os

wb_path = os.path.abspath('01_儀表板執行環境/dashboard_data.xlsx')
wb = openpyxl.load_workbook(wb_path)

header_fill = PatternFill(start_color="1B365D", end_color="1B365D", fill_type="solid")
header_font = Font(name="Microsoft JhengHei", size=11, bold=True, color="FFFFFF")
cell_font = Font(name="Microsoft JhengHei", size=10)
num_font = Font(name="Calibri", size=10)
align_left = Alignment(horizontal="left", vertical="center")
align_right = Alignment(horizontal="right", vertical="center")
align_center = Alignment(horizontal="center", vertical="center")
thin_border = Border(
    left=Side(style='thin', color='E0E0E0'),
    right=Side(style='thin', color='E0E0E0'),
    top=Side(style='thin', color='E0E0E0'),
    bottom=Side(style='thin', color='E0E0E0')
)

def style_sheet(ws, headers, rows):
    ws.append(headers)
    for col_idx in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = align_center

    for r_idx, row in enumerate(rows, start=2):
        ws.append(row)
        for col_idx in range(1, len(row) + 1):
            cell = ws.cell(row=r_idx, column=col_idx)
            val = cell.value
            cell.border = thin_border
            if isinstance(val, (int, float)):
                cell.font = num_font
                cell.alignment = align_right
            else:
                cell.font = cell_font
                cell.alignment = align_left if col_idx > 2 else align_center

    for col in ws.columns:
        max_len = max(len(str(cell.value or '')) for cell in col)
        col_letter = openpyxl.utils.get_column_letter(col[0].column)
        ws.column_dimensions[col_letter].width = max(max_len + 3, 12)

# 1. 04_系統月度指標
s1_name = "04_系統月度指標"
if s1_name in wb.sheetnames:
    del wb[s1_name]
ws1 = wb.create_sheet(title=s1_name)
h1 = ['指標代碼', '業務維度', '指標名稱', '當期數值', '去年同期', '上期數值', '單位', 'YoY (%)', 'MoM (%)', '備註說明', '子欄位1', '子欄位2']
r1 = [
    ['sys_cardpool_resp', 'CardPool授權主機', '交易響應時間', 85.0, 92.0, 88.0, 'ms', -7.61, -3.41, '零超時 (0筆)；SLA 100% 達標', '可用率 99.999%', 'SLA 100% 達標'],
    ['sys_cardpool_vol', 'CardPool授權主機', '月授權交易量', 6820.0, 5940.0, 6670.0, '萬筆', 14.81, 2.25, '月授權交易量；超時 0 筆，P99 < 120ms', 0.0, '< 120ms'],
    ['sys_cardpool_succ', 'CardPool授權主機', '授權成功率', 98.8, 98.5, 98.7, '%', 0.3, 0.1, '可用率 99.999%，無中斷運行 744 小時', '99.999%', '744 小時'],
    ['sys_cardlink_vol', 'Cardlink核心帳務', '月帳務處理量', 1.42, 1.28, 1.39, '億筆', 10.94, 2.16, '高可靠運作；系統可用率 100.0%', '100.0%', '4,850 TPS'],
    ['sys_cardlink_avail', 'Cardlink核心帳務', '系統可用率', 100.0, 100.0, 100.0, '%', 0.0, 0.0, '系統可用率 100.0%', '100.0%', '4,850 TPS'],
    ['sys_cardlink_tps', 'Cardlink核心帳務', '瞬時處理峰值', 4850.0, 4200.0, 4650.0, 'TPS', 15.48, 4.30, '峰值 4,850 TPS', '100.0%', ''],
    ['sys_cardlink_batch_time', 'Cardlink核心帳務', '批次作業完成時間', '03:20 AM', '', '', '時間', '', '', '平均完成：03:20 AM；提前 40 分鐘', '100%', '40 分鐘'],
    ['sys_cardlink_batch_limit', 'Cardlink核心帳務', '排程窗口上限時間', '04:00 AM', '', '', '時間', '', '', '排程上限：04:00 AM；裕度時間 40 分鐘', '安全裕度足', '40 分鐘'],
    ['sys_cardlink_batch_accounts', 'Cardlink核心帳務', '日均處理帳單戶數', 17.3, 15.8, 16.9, '萬戶', 9.49, 2.37, '日均 17.3 萬戶；平帳率 100% 零延宕', '100.0%', '零延宕'],
    ['sys_fraud_total_amt', '全行防詐防堵', '全月總防堵金額', 4280.0, 3650.0, 4120.0, '萬元', 17.26, 3.88, '全月總防堵金額 4,280 萬元', 2684.0, ''],
    ['sys_fraud_total_cnt', '全行防詐防堵', '總阻斷冒用卡數', 2684.0, 2250.0, 2560.0, '張', 19.29, 4.84, '全月總阻斷卡數 2,684 張', 4280.0, '']
]
style_sheet(ws1, h1, r1)

# 2. 04_活動日雲端服務監控
s2_name = "04_活動日雲端服務監控"
if s2_name in wb.sheetnames:
    del wb[s2_name]
ws2 = wb.create_sheet(title=s2_name)
h2 = ['活動代碼', '特定日期', '活動名稱', '特定尖峰時段', '系統規格', '實例數', '瞬時峰值TPS', '最高CPU負載(%)', '延遲(ms)', '運行備註']
r2 = [
    ['ev_618', '2026/06/18', '年中大促 618', '00:00–01:00', '32 vCPU / 128GB', '36 實例', 3850.0, 54.0, '< 80ms', '平穩運行，延遲 < 80ms'],
    ['ev_0808', '2026/08/08', '父親節檔期', '12:30–13:30', '32 vCPU / 128GB', '24 實例', 2420.0, 38.0, '< 75ms', '平穩運行，處於常態健康區'],
    ['ev_anniv', '2026/10/24', '百貨週年慶首週末', '14:30–16:30', '48 vCPU / 192GB', '48 實例', 4180.0, 62.0, '< 85ms', '平穩運行，實體與掃碼無延滯'],
    ['ev_1111', '2026/11/11', '雙11電商零點狂歡', '00:00–00:30', '64 vCPU / 256GB', '72 實例', 5420.0, 68.0, '< 90ms', '年度最高峰順暢通過，零中斷'],
    ['ev_1212', '2026/12/12', '雙12年終購物節', '20:00–22:00', '48 vCPU / 192GB', '48 實例', 3960.0, 58.0, '< 82ms', '平穩運行，延遲 < 82ms']
]
style_sheet(ws2, h2, r2)

# 3. 04_資安防詐成效明細
s3_name = "04_資安防詐成效明細"
if s3_name in wb.sheetnames:
    del wb[s3_name]
ws3 = wb.create_sheet(title=s3_name)
h3 = ['項目代碼', '系統名稱', '防詐防堵項目', '防堵金額 (萬元)', '去年同期', '上期數值', '單位', 'YoY (%)', '金額佔比 (%)', '防堵卡數 (張)', '卡均防堵金額 (萬元/張)', '色彩標記', '備註說明']
r3 = [
    ['fraud_sfm_tx', 'SFM', 'SFM 交易詐欺防堵', 2270.0, 1890.0, 2180.0, '萬元', 20.11, 53.0, 1222.0, 1.86, '#003b5c', 'SFM 交易詐欺；金額佔比 53.0%，1,222 張'],
    ['fraud_sfm_apply', 'SFM', 'SFM 申請詐欺防堵', 1150.0, 1020.0, 1110.0, '萬元', 12.75, 26.9, 842.0, 1.37, '#2d6a8f', 'SFM 申請詐欺；金額佔比 26.9%，842 張'],
    ['fraud_3ds_online', '3DS', '3DS 系統防堵', 860.0, 740.0, 830.0, '萬元', 16.22, 20.1, 620.0, 1.39, '#588ea8', '3DS 線上交易防堵；金額佔比 20.1%，620 張，OTP 異常攔阻率 99.6%']
]
style_sheet(ws3, h3, r3)

# 4. 04_紅利微服務量能監控
s4_name = "04_紅利微服務量能監控"
if s4_name in wb.sheetnames:
    del wb[s4_name]
ws4 = wb.create_sheet(title=s4_name)
h4 = ['服務代碼', '微服務名稱', '當月呼叫量 (萬次)', '去年同期 (萬次)', '上期數值 (萬次)', '單位', 'YoY (%)', 'MoM (%)', '瞬時峰值 (TPS)', '系統容量 (TPS)', '容量佔比 (%)', '色彩標記', '備註說明']
r4 = [
    ['ms_bonus_query', '小樹點查詢', 4850.0, 3680.0, 4620.0, '萬次', 31.79, 4.98, 1850.0, 2500.0, 74.0, '#009e73', '小樹點查詢服務；峰值 1,850 TPS / 2,500 容量 (74%)'],
    ['ms_reward_overview', '回饋總覽', 3420.0, 2450.0, 3250.0, '萬次', 39.59, 5.23, 1320.0, 2000.0, 66.0, '#003b5c', '回饋總覽查詢服務；峰值 1,320 TPS / 2,000 容量 (66%)'],
    ['ms_bonus_redeem', '小樹點兌換', 1180.0, 960.0, 1120.0, '萬次', 22.92, 5.36, 620.0, 1200.0, 51.6, '#c9892e', '小樹點兌換服務；峰值 620 TPS / 1,200 容量 (51.6%)'],
    ['ms_ticket_service', '票券服務', 580.0, 460.0, 540.0, '萬次', 26.09, 7.41, 380.0, 800.0, 47.5, '#7c4dff', '票券服務（雲端）；峰值 380 TPS / 800 容量 (47.5%)']
]
style_sheet(ws4, h4, r4)

wb.save(wb_path)
print("Successfully added 4 sheets for Block 04 to", wb_path)
