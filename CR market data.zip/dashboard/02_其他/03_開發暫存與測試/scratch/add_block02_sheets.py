# -*- coding: utf-8 -*-
"""
Add Block 02 sheets to dashboard_data.xlsx while preserving existing sheets.
"""
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

wb = openpyxl.load_workbook("01_儀表板執行環境/dashboard_data.xlsx")

# Styles
header_font = Font(name="Microsoft JhengHei", size=11, bold=True, color="FFFFFF")
header_fill_blue = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
header_fill_cyan = PatternFill(start_color="0369A1", end_color="0369A1", fill_type="solid")
header_fill_teal = PatternFill(start_color="0F766E", end_color="0F766E", fill_type="solid")
header_fill_purple = PatternFill(start_color="6D28D9", end_color="6D28D9", fill_type="solid")

title_font = Font(name="Microsoft JhengHei", size=13, bold=True, color="1E293B")
data_font = Font(name="Microsoft JhengHei", size=10)
bold_data_font = Font(name="Microsoft JhengHei", size=10, bold=True)
note_font = Font(name="Microsoft JhengHei", size=9, italic=True, color="64748B")

thin_border = Border(
    left=Side(style='thin', color='E2E8F0'),
    right=Side(style='thin', color='E2E8F0'),
    top=Side(style='thin', color='E2E8F0'),
    bottom=Side(style='thin', color='E2E8F0')
)

align_center = Alignment(horizontal="center", vertical="center")
align_left = Alignment(horizontal="left", vertical="center")
align_right = Alignment(horizontal="right", vertical="center")

# Helper to populate and style a sheet
def setup_sheet(ws, title, subtitle, headers, fill_color, rows, num_cols_align_right, bold_cols):
    ws.views.sheetView[0].showGridLines = True
    ws['A1'] = title
    ws['A1'].font = title_font
    ws['A2'] = subtitle
    ws['A2'].font = note_font
    
    # row 3 is blank
    for c_idx, h in enumerate(headers, start=1):
        cell = ws.cell(row=4, column=c_idx, value=h)
        cell.font = header_font
        cell.fill = fill_color
        cell.alignment = align_center

    for r_idx, row in enumerate(rows, start=5):
        for c_idx, val in enumerate(row, start=1):
            cell = ws.cell(row=r_idx, column=c_idx, value=val)
            cell.font = bold_data_font if c_idx in bold_cols else data_font
            cell.border = thin_border
            if c_idx in num_cols_align_right:
                cell.alignment = align_right
                if val is not None and isinstance(val, (int, float)):
                    cell.number_format = "#,##0.0" if isinstance(val, float) else "#,##0"
            elif c_idx in [1, 2]:
                cell.alignment = align_center
            else:
                cell.alignment = align_left

    # Column widths
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            if cell.row in [1, 2]:
                continue
            if cell.value is not None:
                val_str = str(cell.value)
                cell_len = sum(2 if ord(c) > 127 else 1 for c in val_str)
                if cell_len > max_len:
                    max_len = cell_len
        ws.column_dimensions[col_letter].width = max(max_len + 4, 12)

# ==============================================================================
# 1. 02_收單月度指標
# ==============================================================================
if "02_收單月度指標" in wb.sheetnames:
    wb.remove(wb["02_收單月度指標"])
ws_m = wb.create_sheet(title="02_收單月度指標")

headers_m = ["指標分類", "指標代碼", "指標名稱", "當月數值", "單位", "YoY (%)", "MoM (%)", "佔比/活店率(%)", "備註 / 計算規則"]
rows_m = [
    ["核心交易金額", "acq_amt_total", "自行收單交易金額", 285.0, "億元", 12.8, 2.1, 100.0, "核心指標；留空則自動累加實體+線上"],
    ["核心交易金額", "acq_amt_phys", "實體收單金額", 185.0, "億元", 8.5, None, 65.0, "留空則由 金額/總額 自動推算佔比"],
    ["核心交易金額", "acq_amt_onl", "線上EPOS+PH金額", 100.0, "億元", 21.8, None, 35.0, "留空則由 金額/總額 自動推算佔比"],
    ["核心交易筆數", "acq_cnt_total", "自行收單交易筆數", 1850, "萬筆", 15.2, 1.8, 100.0, "核心指標；留空則自動累加實體+線上"],
    ["核心交易筆數", "acq_cnt_phys", "實體收單筆數", 1295, "萬筆", 11.0, None, 70.0, "留空則由 筆數/總筆數 自動推算佔比"],
    ["核心交易筆數", "acq_cnt_onl", "線上EPOS+PH筆數", 555, "萬筆", 26.2, None, 30.0, "留空則由 筆數/總筆數 自動推算佔比"],
    ["核心特店家數", "acq_mcht_total", "收單特店總數", 48500, "家", 8.5, 0.7, 100.0, "核心指標；留空則自動累加實體+線上"],
    ["核心特店家數", "acq_mcht_phys", "實體特店家數", 38800, "家", None, None, 80.0, "留空則由 家數/總家數 自動推算佔比"],
    ["核心特店家數", "acq_mcht_onl", "線上特店家數", 9700, "家", None, None, 20.0, "留空則由 家數/總家數 自動推算佔比"],
    ["收單營運次指標", "acq_penetration_rate", "自行收單滲透率", 24.5, "%", 1.8, 0.3, None, "YoY/MoM 為百分點(pp)；自行收單一般交易 ÷ 全行一般交易"],
    ["收單營運次指標", "acq_active_mcht", "活躍自行特店數", 40250, "家", 6.2, None, 83.0, "佔比欄位填寫活店率(%)；當月有實質請款交易之特店"],
    ["收單營運次指標", "acq_estatement_rate", "電子對帳單覆蓋率", 92.4, "%", None, None, None, "電子對帳單服務比例"],
    ["收單營運次指標", "acq_fee_income", "收單手續費收入", 4.52, "億元", 11.5, None, None, "扣除通路成本後實質淨手續費收入"],
    ["TWQR業務指標", "twqr_apply_cnt", "TWQR當月申請進件數", 3850, "件", None, None, 91.2, "佔比欄位填寫審查通過率(%)"],
    ["TWQR業務指標", "twqr_new_mcht", "TWQR當月新增特店家數", 1210, "家", None, None, None, "當月審查通過並完成裝機特店"],
    ["TWQR業務指標", "twqr_total_mcht", "TWQR累計特店家數", 22100, "家", None, 5.8, None, "全行累計TWQR特店家數；MoM為成長率"],
    ["TWQR業務指標", "twqr_tx_amt", "TWQR當月交易金額", 12.8, "億元", None, 18.5, None, "TWQR實質掃碼交易總金額；MoM為成長率"],
    ["TWQR業務指標", "twqr_tx_cnt", "TWQR當月交易筆數", 185, "萬筆", None, 22.1, None, "TWQR實質掃碼交易總筆數；MoM為成長率"],
    ["TWQR業務指標", "twqr_avg_ticket", "TWQR平均每筆客單", 692, "元", None, None, None, "留空則由 金額/筆數 自動推算"],
    ["TWQR業務指標", "twqr_mcht_avg_amt", "TWQR店均交易金額", 5.79, "萬元", None, None, None, "留空則由 金額/動用特店數 自動推算"],
    ["TWQR業務指標", "twqr_active_mcht_rate", "TWQR動用特店比率", 78.5, "%", None, None, None, "實際產生交易特店數 ÷ 累計特店數"]
]
setup_sheet(ws_m, "國泰世華銀行 信用卡營運儀表板 - 02 收單月度指標維護表",
            "說明：維護收單業務當月核心KPI與TWQR數據。比例、總數留空時，系統將自動累加或推算；不可推算者留空將顯示為 -。",
            headers_m, header_fill_blue, rows_m, [4, 6, 7, 8], [1, 3, 4])

# ==============================================================================
# 2. 02_收單線上交易分析
# ==============================================================================
if "02_收單線上交易分析" in wb.sheetnames:
    wb.remove(wb["02_收單線上交易分析"])
ws_onl = wb.create_sheet(title="02_收單線上交易分析")

headers_onl = ["交易渠道", "交易金額(億元)", "金額佔比(%)", "金額YoY(%)", "交易筆數(萬筆)", "筆數YoY(%)", "平均客單價(元)", "客單價YoY(%)", "備註說明"]
rows_onl = [
    ["EPOS - 雲端", 69.1, 58.3, 32.5, 345, 35.1, 2002, -1.9, "線上主力大額，高成長引擎"],
    ["EPOS - 地端", 30.9, 26.1, -4.2, 210, -1.8, 1471, -2.5, "既有大型百貨量販架構"],
    ["Payment Hub掃碼交易", 18.5, 15.6, 38.2, 240, 42.0, 770, -2.8, "高頻小額日常餐飲交通場景"]
]
setup_sheet(ws_onl, "國泰世華銀行 信用卡營運儀表板 - 02 線上交易分析 (雲地端結構)",
            "說明：維護三大線上收單渠道之金額、筆數與客單價。金額佔比、平均客單價若留空，系統可自動除算補齊。",
            headers_onl, header_fill_cyan, rows_onl, [2, 3, 4, 5, 6, 7, 8], [1, 2])

# ==============================================================================
# 3. 02_特店集中度與矩陣
# ==============================================================================
if "02_特店集中度與矩陣" in wb.sheetnames:
    wb.remove(wb["02_特店集中度與矩陣"])
ws_conc = wb.create_sheet(title="02_特店集中度與矩陣")

headers_conc = ["項目類別", "特店/指標名稱", "業態/副標標籤", "請款金額(億元或%)", "YoY(%或pp)", "矩陣象限", "矩陣代表文字", "備註"]
rows_conc = [
    ["大盤集中度", "Top 10 特店請款佔比", "全行大盤集中度", 48.2, 1.5, "全行大盤", "全行大盤集中度指標", "單位為 %，YoY 單位為百分點(pp)"],
    ["核心特店", "特店 A", "量販巨頭", 35.6, 18.2, "核心成長區", "代表：特店 A、特店 B", "高成長 × 高佔比 ⭐"],
    ["核心特店", "特店 B", "綜合電商", 26.2, 25.4, "核心成長區", "代表：特店 A、特店 B", "高成長 × 高佔比 ⭐"],
    ["核心特店", "特店 C", "百貨生活", 23.9, 1.2, "重點維繫區", "代表：特店 C、特店 D", "低成長 × 高佔比 ⚠"],
    ["核心特店", "特店 D", "連鎖超商", 17.4, -3.5, "重點維繫區", "代表：特店 C、特店 D", "受競業分流影響 ⚠"],
    ["核心特店", "特店 E", "連鎖餐飲", 14.3, 32.0, "潛力開發區", "代表：特店 E 等", "高成長 × 低佔比"],
    ["長尾特店", "長尾特店群", "中小型特店", None, None, "一般維護區", "代表：長尾特店群", "低成長 × 低佔比"]
]
setup_sheet(ws_conc, "國泰世華銀行 信用卡營運儀表板 - 02 特店集中度與經營矩陣定位",
            "說明：維護 Top 10 大盤集中度與 Top 5 特店請款數據及 2x2 矩陣定位代表文字。",
            headers_conc, header_fill_teal, rows_conc, [4, 5], [1, 2, 4])

# ==============================================================================
# 4. 02_特店產業結構分布
# ==============================================================================
if "02_特店產業結構分布" in wb.sheetnames:
    wb.remove(wb["02_特店產業結構分布"])
ws_ind = wb.create_sheet(title="02_特店產業結構分布")

headers_ind = ["產業類別", "圖示標籤", "特店家數(家)", "家數佔比(%)", "請款金額(億元)", "金額佔比(%)", "店均請款(萬元/店)", "代表色碼(HEX)"]
rows_ind = [
    ["量販超市", "🛒 量販超市", 1920, 4.0, 74.1, 26.0, 385.9, "#003b5c"],
    ["綜合電商", "🌐 綜合電商", 850, 1.8, 59.8, 21.0, 703.5, "#0284c7"],
    ["百貨生活", "🏬 百貨生活", 4850, 10.0, 43.9, 15.4, 90.5, "#10b981"],
    ["餐飲美食", "🍽️ 餐飲美食", 18500, 38.1, 31.4, 11.0, 17.0, "#f59e0b"],
    ["交通旅遊", "✈️ 交通旅遊", 2400, 4.9, 22.8, 8.0, 95.0, "#8b5cf6"],
    ["其他各業", "📦 其他各業", 19980, 41.2, 53.0, 18.6, 26.5, "#94a3b8"]
]
setup_sheet(ws_ind, "國泰世華銀行 信用卡營運儀表板 - 02 特店產業結構分布 (蝴蝶圖)",
            "說明：維護 6 大產業特店家數與請款金額。佔比與店均請款若留空，系統會自動依總計推算。",
            headers_ind, header_fill_purple, rows_ind, [3, 4, 5, 6, 7], [1, 3, 5])

wb.save("01_儀表板執行環境/dashboard_data.xlsx")
print("Successfully added Block 02 sheets to dashboard_data.xlsx!")
