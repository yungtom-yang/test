# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import re

with open('credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    html = f.read()

print("File size:", len(html))

# Check nav buttons
nav_btns = re.findall(r'<button[^>]*class=["\'][^"\']*nav-tab-btn[^"\']*["\'][^>]*>([\s\S]*?)</button>', html)
print(f"Total Nav buttons ({len(nav_btns)}):")
for b in nav_btns:
    cleaned = ' '.join(re.sub(r'<[^<]+?>', ' ', b).split())
    print("  -", cleaned)

# Check sections
sections = re.findall(r'<section\s+id=[\'"]([^\'"]+)[\'"]\s+class=[\'"]([^\'"]+)[\'"]', html)
print(f"\nTotal Sections ({len(sections)}):")
for s_id, s_cls in sections:
    print(f"  - ID: {s_id} | Classes: {s_cls}")

# Check Section 00 keywords
keywords = [
    "信用卡營運與系統決策總覽",
    "總交易金額", "1,286.4",
    "總交易筆數", "8,425",
    "預借現金金額", "18.6",
    "循環信用餘額", "325.7",
    "四大發卡行簽帳金額與市占率", "30,720",
    "TWQR 國家共同標準業務分析", "3,850", "22,100", "14.8", "185", "800",
    "徵審進件中樞自動化", "85,400", "76.5%",
    "帳單數據與數位降本", "91.8%", "520.0",
    "小樹點水庫循環概況", "48.2", "84.2%",
    "CardPool 授權核心主機", "85", "99.999%",
    "Cardlink 核心帳務主機", "4,850",
    "三大資安防詐成果", "4,280", "2,684"
]

print("\nKeyword Checks:")
for kw in keywords:
    found = kw in html
    print(f"  [{'OK' if found else 'MISSING'}] {kw}")
