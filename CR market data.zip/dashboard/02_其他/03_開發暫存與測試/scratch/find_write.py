# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

transcript_path = "C:/Users/詠棠/.gemini/antigravity/brain/b95ecca9-971a-489b-ab53-ec5e0dbbb3cb/.system_generated/logs/transcript_full.jsonl"

with open(transcript_path, "r", encoding="utf-8") as f:
    for line in f:
        if "build_dashboard.py" in line:
            obj = json.loads(line)
            idx = obj.get("step_index")
            calls = obj.get("tool_calls", [])
            for c in calls:
                if c.get("name") == "write_to_file":
                    args = c.get("args", {})
                    if "build_dashboard.py" in args.get("TargetFile", ""):
                        print(f"Step {idx} wrote build_dashboard.py!")
                        with open(f"scratch/recovered_step_{idx}.py", "w", encoding="utf-8") as out:
                            out.write(args.get("CodeContent", ""))
                        print(f"Saved scratch/recovered_step_{idx}.py")
