# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import math
import json

with open('scratch/dashboard_data.json', 'r', encoding='utf-8') as f:
    d = json.load(f)

# Donut SVG generator
def get_donut_svg():
    slices = [
        {"name": "中國信託", "share": 19.5, "color": "#003b5c"},
        {"name": "國泰世華", "share": 18.6, "color": "#009e73"}, # Cathay Green
        {"name": "台北富邦", "share": 14.5, "color": "#2563eb"},
        {"name": "玉山銀行", "share": 14.1, "color": "#059669"},
        {"name": "其他同業", "share": 33.3, "color": "#cbd5e1"}
    ]
    cx, cy, r_out, r_in = 52, 52, 48, 28
    paths = []
    start_angle = -90.0
    for s in slices:
        angle_len = (s["share"] / 100.0) * 360.0
        end_angle = start_angle + angle_len
        rad_start = math.radians(start_angle)
        rad_end = math.radians(end_angle)
        x1_out = cx + r_out * math.cos(rad_start)
        y1_out = cy + r_out * math.sin(rad_start)
        x2_out = cx + r_out * math.cos(rad_end)
        y2_out = cy + r_out * math.sin(rad_end)
        x1_in = cx + r_in * math.cos(rad_end)
        y1_in = cy + r_in * math.sin(rad_end)
        x2_in = cx + r_in * math.cos(rad_start)
        y2_in = cy + r_in * math.sin(rad_start)
        large_arc = 1 if angle_len > 180 else 0
        path_d = f"M {x1_out:.2f} {y1_out:.2f} A {r_out} {r_out} 0 {large_arc} 1 {x2_out:.2f} {y2_out:.2f} L {x1_in:.2f} {y1_in:.2f} A {r_in} {r_in} 0 {large_arc} 0 {x2_in:.2f} {y2_in:.2f} Z"
        paths.append(f'<path d="{path_d}" fill="{s["color"]}" stroke="#ffffff" stroke-width="1.2"><title>{s["name"]}: {s["share"]}%</title></path>')
        start_angle = end_angle
    return f'''<svg viewBox="0 0 104 104" width="82" height="82" style="display:block; flex-shrink:0;">
        {''.join(paths)}
        <circle cx="{cx}" cy="{cy}" r="{r_in}" fill="#ffffff" />
        <text x="{cx}" y="{cy-2}" font-size="8.5" font-weight="900" fill="#003b5c" text-anchor="middle">全市場</text>
        <text x="{cx}" y="{cy+9}" font-size="7.5" font-weight="700" fill="#64748b" text-anchor="middle">30,720億</text>
    </svg>'''

donut_svg = get_donut_svg()
print("Generated donut svg length:", len(donut_svg))
