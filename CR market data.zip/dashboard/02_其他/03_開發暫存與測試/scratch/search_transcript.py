import json, sys
sys.stdout.reconfigure(encoding='utf-8')

transcript_path = 'C:/Users/user/.gemini/antigravity/brain/24d7569a-df32-4693-8937-b588a2c1a133/.system_generated/logs/transcript.jsonl'
with open(transcript_path, 'r', encoding='utf-8') as f:
    for line in f:
        data = json.loads(line)
        content = data.get('content', '')
        if '把html當中的' in content or ('億元' in content and '千元' in content):
            print(f"Step {data.get('step_index')}, Source: {data.get('source')}, Type: {data.get('type')}")
            print(content[:500])
            print("="*60)
