import os

for fname in ['credit_card_full_dashboard.html', 'sync_excel.py', 'dashboard_data.js', 'dashboard_data.json']:
    path = os.path.join('01_儀表板執行環境', fname)
    with open(path, 'r', encoding='utf-8') as f:
        text = f.read()
        c_wk = text.count('萬卡')
        c_z = text.count('張')
        print(f"{fname}: 萬卡 = {c_wk}, 張 = {c_z}")
