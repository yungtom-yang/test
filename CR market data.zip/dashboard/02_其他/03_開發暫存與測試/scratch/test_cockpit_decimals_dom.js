const fs = require('fs');

const html = fs.readFileSync('01_儀表板執行環境/credit_card_full_dashboard.html', 'utf-8');

// Check that .decimal-part is in CSS
const hasCss = html.includes('.decimal-part');
console.log('CSS .decimal-part defined:', hasCss);

// Check that applyCockpitDecimals is defined in script
const hasFunction = html.includes('function applyCockpitDecimals()');
console.log('Function applyCockpitDecimals defined:', hasFunction);

// Extract section-cockpit
const cockpitMatch = html.match(/<section id="section-cockpit"[\s\S]*?<\/section>/);
if (!cockpitMatch) {
  console.error('ERROR: section-cockpit not found');
  process.exit(1);
}
const cockpitHtml = cockpitMatch[0];

// Count decimal-part spans in cockpit
const cockpitSpans = [...cockpitHtml.matchAll(/class="decimal-part"/g)].length;
console.log(`Found ${cockpitSpans} decimal-part tags inside #section-cockpit.`);

// Check Blocks 01~04 do NOT have decimal-part tags yet
const restOfHtml = html.replace(cockpitHtml, '');
const restSpans = [...restOfHtml.matchAll(/class="decimal-part"/g)].length;
console.log(`Found ${restSpans} decimal-part tags outside #section-cockpit (should be 0).`);

if (restSpans > 0) {
  console.error('ERROR: decimal-part found outside #section-cockpit!');
  process.exit(1);
}

// Sample checks inside cockpit
const checks = [
  '1,286<span class="decimal-part">.4</span> <em>億元</em>',
  'YoY +12<span class="decimal-part">.8</span>%',
  '(84<span class="decimal-part">.4</span>%)',
  '18<span class="decimal-part">.6</span> <em>億元</em>',
  '325<span class="decimal-part">.7</span> <em>億元</em>',
  '26<span class="decimal-part">.6</span>%',
  '285<span class="decimal-part">.0</span> <em>億元</em>',
  '審查通過率 91<span class="decimal-part">.2</span>%',
  '78<span class="decimal-part">.5</span><em>%</em>',
  '468<span class="decimal-part">.6</span> 萬份',
  '318<span class="decimal-part">.3</span><em>萬份</em>',
  '淨增存量 +0<span class="decimal-part">.6</span> 百萬點',
  '15<tspan class="decimal-part" font-size="0.78em">.2</tspan>',
  '成功率 98<span class="decimal-part">.8</span>%',
  '1<span class="decimal-part">.42</span> <em>億筆</em>',
  '100<span class="decimal-part">.0</span>%',
  'YoY +31<span class="decimal-part">.8</span>%'
];

let allPassed = true;
checks.forEach(c => {
  const ok = cockpitHtml.includes(c);
  if (!ok) {
    console.error('FAILED check:', c);
    allPassed = false;
  }
});

if (allPassed) {
  console.log('ALL COCKPIT STATIC HTML DECIMAL CHECKS PASSED!');
} else {
  console.error('Some checks failed.');
  process.exit(1);
}
