# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

transcript_path = "C:/Users/詠棠/.gemini/antigravity/brain/b95ecca9-971a-489b-ab53-ec5e0dbbb3cb/.system_generated/logs/transcript_full.jsonl"

with open(transcript_path, "r", encoding="utf-8") as f:
    for line in f:
        obj = json.loads(line)
        if obj.get("step_index") == 257:
            # check tool calls
            calls = obj.get("tool_calls", [])
            for c in calls:
                print("Tool call:", c.get("name"))
                args = c.get("args", {})
                for k, v in args.items():
                    if isinstance(v, str) and len(v) > 200:
                        print(f"Arg {k} ({len(v)} chars):")
                        print(v[:500])
                        print("...")
            content = obj.get("content", "")
            if len(content) > 100:
                print(f"Content ({len(content)} chars):")
                print(content[:500])
