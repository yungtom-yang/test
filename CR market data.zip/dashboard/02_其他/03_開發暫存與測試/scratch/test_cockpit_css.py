# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json

cockpit_css = """
/* SECTION 00: COCKPIT VIEWPORT STYLING (ZERO SCROLL FIT) */
#section-cockpit {
  padding-bottom: 0;
}
.cockpit-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
  padding: 12px;
  background: var(--orange-soft);
  border: 1px solid var(--line);
  border-radius: 12px;
  height: calc(100vh - 165px);
  min-height: 600px;
  box-sizing: border-box;
}

@media (max-height: 800px) {
  .cockpit-grid {
    height: auto;
    min-height: 560px;
  }
}

.cockpit-col {
  background: #ffffff;
  border: 1px solid #d8e5e0;
  border-radius: 8px;
  padding: 10px 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  box-shadow: 0 1px 4px rgba(0,0,0,0.03);
}

.cockpit-col-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #e5ece9;
  padding-bottom: 6px;
}
.c-header-left {
  display: flex;
  align-items: center;
  gap: 6px;
}
.cockpit-badge {
  font-size: 11px;
  font-weight: 800;
  padding: 2px 6px;
  border-radius: 4px;
  color: #fff;
  letter-spacing: 0.02em;
}
.c-badge-orange { background: var(--orange); }
.c-badge-blue { background: var(--blue); }
.c-badge-dark { background: var(--blue-dark); }

.cockpit-col-header h3 {
  font-size: 13.5px;
  margin: 0;
  color: var(--ink);
  font-weight: 800;
  letter-spacing: -0.01em;
}
.cockpit-link-btn {
  background: none;
  border: 1px solid #cbd9df;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 700;
  color: var(--blue);
  padding: 2px 7px;
  cursor: pointer;
  transition: all 0.15s ease;
}
.cockpit-link-btn:hover {
  background: var(--blue);
  color: #fff;
  border-color: var(--blue);
}

.cockpit-subbox {
  background: #f8fafb;
  border: 1px solid #e6eeec;
  border-radius: 6px;
  padding: 8px 10px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.cockpit-subbox.flex-grow {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.cockpit-box-title {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 11.5px;
  font-weight: 800;
  color: #43555f;
}
.cockpit-tag-pill {
  font-size: 10px;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 10px;
  background: #e8eff2;
  color: #43555f;
}
.cockpit-tag-pill.primary { background: #eef5ff; color: var(--blue); }
.cockpit-tag-pill.warning { background: #fff7e7; color: #b8781c; }
.c-tag-green {
  font-size: 10.5px;
  font-weight: 800;
  color: var(--green);
  background: #eaf7f2;
  padding: 1px 5px;
  border-radius: 4px;
}

.cockpit-kpi-quad {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
}
.c-kpi-card {
  background: #ffffff;
  border: 1px solid #e1ebe7;
  border-radius: 5px;
  padding: 6px 8px;
  display: flex;
  flex-direction: column;
}
.c-kpi-card.highlight-glow {
  border-color: #b5e4d2;
  background: #fafdfc;
}
.c-kpi-title {
  font-size: 11px;
  color: #5a6d75;
  font-weight: 700;
}
.c-kpi-val {
  font-size: 18px;
  font-weight: 900;
  color: var(--ink);
  line-height: 1.15;
  margin: 2px 0;
  font-variant-numeric: tabular-nums;
}
.c-kpi-val em {
  font-size: 11px;
  font-weight: 600;
  font-style: normal;
  color: #72848c;
  margin-left: 2px;
}
.c-kpi-growth {
  font-size: 10.5px;
  display: flex;
  gap: 4px;
  align-items: center;
}
.c-kpi-sub {
  color: #7d8f96;
  font-size: 10.5px;
}

/* Peer Market Share Stacked Bar */
.market-stacked-bar {
  display: flex;
  height: 12px;
  border-radius: 6px;
  overflow: hidden;
  background: #e2e8f0;
  margin: 4px 0;
}
.market-bar-seg {
  height: 100%;
  transition: width 0.3s;
}
.market-bar-seg:nth-child(1) { background: #003b5c; }
.market-bar-seg:nth-child(2) { background: var(--green); }
.market-bar-seg:nth-child(3) { background: #5d7a88; }
.market-bar-seg:nth-child(4) { background: #94a3b8; }
.market-bar-seg:nth-child(5) { background: #cbd5e1; }

.cockpit-peer-list {
  display: flex;
  flex-direction: column;
  gap: 3px;
  margin-top: 4px;
}
.cockpit-peer-row {
  display: grid;
  grid-template-columns: 20px 58px 1fr 42px 46px;
  align-items: center;
  font-size: 11px;
  padding: 3px 6px;
  border-radius: 4px;
  background: #fff;
  border: 1px solid #edf2f0;
}
.cockpit-peer-row.highlight {
  background: #f0f9f5;
  border-color: #b5e4d2;
  font-weight: 800;
  color: var(--green);
}
.p-rank { font-weight: 800; color: #62757d; font-size: 10px; }
.p-name { font-weight: 700; color: var(--ink); }
.p-val { text-align: right; color: #4b5d66; font-variant-numeric: tabular-nums; }
.p-share { text-align: right; color: var(--ink); }
.p-yoy { text-align: right; font-size: 10px; font-weight: 700; }

.cockpit-foot-note {
  font-size: 10.5px;
  color: #61737a;
  background: #ffffff;
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid #e5ece9;
  text-align: center;
  margin-top: 4px;
}
.cockpit-foot-note b { color: var(--orange-dark); }

.c-mini-stat-banner {
  display: flex;
  align-items: center;
  justify-content: space-around;
  background: #fff;
  border: 1px solid #e2ebe6;
  border-radius: 5px;
  padding: 6px 8px;
}
.c-mini-stat-banner small {
  font-size: 10px;
  color: #61737a;
  display: block;
}
.c-mini-stat-banner strong {
  font-size: 16px;
  font-weight: 900;
  color: var(--ink);
  display: block;
  margin: 1px 0;
}
.c-mini-stat-banner strong em {
  font-size: 10.5px;
  font-style: normal;
  color: #72848c;
}
.divider-v {
  width: 1px;
  height: 32px;
  background: #e2ebe6;
  margin: 0 6px;
}
.c-split-bar {
  display: flex;
  height: 15px;
  border-radius: 3px;
  overflow: hidden;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  text-align: center;
  line-height: 15px;
  margin: 2px 0;
}
.bar-phys { background: var(--blue); }
.bar-onl { background: var(--orange); }
.c-foot-hint { font-size: 9.5px; color: #72848c; display: block; text-align: center; }

.twqr-cockpit-section {
  background: #fff;
  border: 1px solid #e2ebe6;
  border-radius: 5px;
  padding: 6px 8px;
}
.twqr-subhead {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 10.5px;
  color: var(--blue-dark);
  font-weight: 800;
  margin-bottom: 4px;
}
.c-twqr-stat-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
}
.c-twqr-stat-grid.three-col {
  grid-template-columns: 1fr 1fr 1fr;
}
.c-twqr-cell {
  background: #f8fafb;
  border: 1px solid #edf2f0;
  border-radius: 4px;
  padding: 4px 6px;
  text-align: center;
}
.c-twqr-cell span {
  font-size: 9.5px;
  color: #6b7e86;
  display: block;
  font-weight: 700;
  white-space: nowrap;
}
.c-twqr-cell strong {
  font-size: 14.5px;
  font-weight: 900;
  color: var(--ink);
  display: block;
  margin: 1px 0;
  font-variant-numeric: tabular-nums;
}
.c-twqr-cell strong em {
  font-size: 9.5px;
  font-style: normal;
  color: #7c8e96;
  font-weight: 600;
}
.c-twqr-cell b {
  font-size: 9.5px;
  font-weight: 800;
  display: block;
  white-space: nowrap;
}

.c-stat-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
}
.c-stat-row.compact {
  gap: 4px;
}
.c-stat-item {
  background: #fff;
  border: 1px solid #e2ebe6;
  border-radius: 5px;
  padding: 5px 7px;
}
.c-stat-item.highlight-box {
  background: #f5fcf9;
  border-color: #b5e4d2;
}
.c-stat-item small {
  font-size: 9.5px;
  color: #667982;
  display: block;
  font-weight: 700;
}
.c-stat-item strong {
  font-size: 14.5px;
  font-weight: 900;
  color: var(--ink);
  display: block;
  margin: 1px 0;
  font-variant-numeric: tabular-nums;
}
.c-stat-item strong em {
  font-size: 9.5px;
  font-style: normal;
  color: #7c8e96;
  font-weight: 600;
}
.c-stat-item span {
  font-size: 9.5px;
  color: #62757d;
  font-weight: 600;
  display: block;
}

.c-progress-bar-wrap {
  display: flex;
  height: 13px;
  border-radius: 3px;
  overflow: hidden;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  text-align: center;
  line-height: 13px;
  margin-top: 3px;
}
.c-progress-fill { background: var(--green); }
.c-progress-rest { background: #cbd5e1; color: #475569; }

.fraud-total-cockpit-bar {
  display: flex;
  align-items: center;
  justify-content: space-around;
  border: 1px solid #fed7aa;
  border-radius: 5px;
  padding: 5px 8px;
  background: #fffcf8;
}
.fraud-total-cockpit-bar span {
  font-size: 9.5px;
  color: #78350f;
  font-weight: 700;
  display: block;
}
.fraud-total-cockpit-bar strong {
  font-size: 15.5px;
  font-weight: 900;
  color: #c2410c;
  display: block;
  margin-top: 1px;
}
.fraud-total-cockpit-bar strong em {
  font-size: 9.5px;
  font-style: normal;
  font-weight: 600;
}
.fraud-lines-list {
  display: flex;
  flex-direction: column;
  gap: 3px;
  margin-top: 3px;
}
.f-line-item {
  display: grid;
  grid-template-columns: 28px 1fr 62px 46px;
  align-items: center;
  font-size: 10px;
  padding: 3px 5px;
  background: #fff;
  border: 1px solid #edf2f0;
  border-radius: 4px;
}
.f-tag {
  font-size: 8.5px;
  font-weight: 900;
  padding: 1px 3px;
  border-radius: 2px;
  text-align: center;
  color: #fff;
}
.f-tag.sfm { background: var(--orange-dark); }
.f-tag.tds { background: var(--blue); }
.f-name { font-weight: 700; color: var(--ink); padding-left: 3px; }
.f-amt { text-align: right; font-weight: 800; color: var(--orange-dark); }
.f-cnt { text-align: right; color: #62757d; font-size: 9.5px; }
"""

print("Cockpit CSS ready!")
