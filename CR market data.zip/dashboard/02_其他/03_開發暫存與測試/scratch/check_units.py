import openpyxl

files = [
    "01_儀表板執行環境/credit_card_full_dashboard.html",
    "01_儀表板執行環境/sync_excel.py",
    "01_儀表板執行環境/dashboard_data.json"
]

for fp in files:
    with open(fp, "r", encoding="utf-8") as f:
        c = f.read()
    print(f"{fp}: 千元={c.count('千元')}, 億元={c.count('億元')}")

wb = openpyxl.load_workbook("01_儀表板執行環境/dashboard_data.xlsx", data_only=True)
for sheet in wb.sheetnames:
    ws = wb[sheet]
    qian_cnt = 0
    yi_cnt = 0
    for row in ws.iter_rows(values_only=True):
        for cell in row:
            if cell is not None and isinstance(cell, str):
                qian_cnt += cell.count("千元")
                yi_cnt += cell.count("億元")
    if qian_cnt > 0 or yi_cnt > 0:
        print(f"Excel Sheet [{sheet}]: 千元={qian_cnt}, 億元={yi_cnt}")
