# 00_交接文件 (Project Handover Documentation)

本資料夾為本專案跨電腦開發與接續維護之專用入口。

## 檔案說明
- **[`PROJECT_HANDOVER_CONTEXT.md`](./PROJECT_HANDOVER_CONTEXT.md)**：專案全景交接總綱（含四大鐵律、歷史決策演進、14張工作表結構、一鍵喚醒 Prompt）。

## 快速使用方式
當在新電腦執行 Antigravity AI 時，請直接複製 `PROJECT_HANDOVER_CONTEXT.md` 第六節的「一鍵喚醒 Prompt」發送給 AI 即可無縫接續！
