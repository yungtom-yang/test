import os
import sys
import glob
import re
import argparse
import datetime
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Ensure UTF-8 output in Windows console
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

BANKS_CONFIG = [
    {'key': '中信', 'full_name': '中國信託商業銀行', 'short_name': '中國信託'},
    {'key': '國泰', 'full_name': '國泰世華商業銀行', 'short_name': '國泰世華'},
    {'key': '玉山', 'full_name': '玉山商業銀行', 'short_name': '玉山銀行'},
    {'key': '富邦', 'full_name': '台北富邦商業銀行', 'short_name': '台北富邦'},
    {'key': '台新', 'full_name': '台新國際商業銀行', 'short_name': '台新銀行'}
]

# 對應「五大發卡行信用卡重要資訊彙整」總表之欄位
METRICS_CONFIG = [
    {
        'key': '簽帳金額',
        'display_name': '當月簽帳金額',
        'type': 'flow',
        'type_desc': '期間累計',
        'unit': '千元',
        'format': '#,##0'
    },
    {
        'key': '有效卡數',
        'display_name': '有效卡數',
        'type': 'stock',
        'type_desc': '期末值',
        'unit': '張',
        'format': '#,##0'
    },
    {
        'key': '流通卡數',
        'display_name': '流通卡數',
        'type': 'stock',
        'type_desc': '期末值',
        'unit': '張',
        'format': '#,##0'
    },
    {
        'key': '活卡率',
        'display_name': '活卡率',
        'type': 'active_rate', # 衍生比率：有效/流通
        'type_desc': '期末比率',
        'unit': '%',
        'format': '0.00'
    },
    {
        'key': '循環信用餘額',
        'display_name': '循環信用餘額',
        'type': 'stock',
        'type_desc': '期末值',
        'unit': '千元',
        'format': '#,##0'
    },
    {
        'key': '未到期分期付款餘額',
        'display_name': '未到期分期付款餘額',
        'type': 'stock',
        'type_desc': '期末值',
        'unit': '千元',
        'format': '#,##0'
    },
    {
        'key': '預借現金金額',
        'display_name': '當月預借現金金額',
        'type': 'flow',
        'type_desc': '期間累計',
        'unit': '千元',
        'format': '#,##0'
    },
    {
        'key': '當年度轉銷呆帳金額累計',
        'display_name': '當年度轉銷呆帳金額累計',
        'type': 'bad_debt_cum',
        'type_desc': '期末累計',
        'unit': '千元',
        'format': '#,##0'
    },
    {
        'key': '備抵呆帳提足率',
        'display_name': '備抵呆帳提足率',
        'type': 'ratio',
        'type_desc': '期末比率',
        'unit': '%',
        'format': '0.00'
    }
]


def find_consolidated_summary_file(work_dir):
    """尋找已整合產出的最新彙整總表檔案"""
    candidates = glob.glob(os.path.join(work_dir, '五大發卡行信用卡重要資訊彙整_*.xlsx'))
    candidates = [f for f in candidates if not os.path.basename(f).startswith('~$')]
    if not candidates:
        return None
    candidates.sort(key=lambda x: os.path.getmtime(x), reverse=True)
    return candidates[0]


def load_consolidated_data(summary_path):
    """
    從整合總表「總表」頁讀取所有資料
    """
    wb = openpyxl.load_workbook(summary_path, data_only=True)
    if '總表' not in wb.sheetnames:
        raise ValueError(f"檔案「{os.path.basename(summary_path)}」中找不到「總表」工作表！")
    
    ws = wb['總表']
    data_by_month = {}

    for r in range(2, ws.max_row + 1):
        period_val = ws.cell(r, 1).value
        bank_val = ws.cell(r, 2).value
        if not period_val or not bank_val:
            continue
        
        period_str = str(period_val).strip()
        bank_name = str(bank_val).strip()

        if period_str not in data_by_month:
            data_by_month[period_str] = {}

        row_data = {}
        for c in range(3, ws.max_column + 1):
            row_data[c] = ws.cell(r, c).value
        data_by_month[period_str][bank_name] = row_data

    return data_by_month


def get_available_periods_from_summary(data_by_month):
    """取得彙整表中所有已收錄的月份代碼清單，例如 ['11401', '11402', ..., '11507']"""
    periods = []
    for p_str in data_by_month.keys():
        m = re.match(r'^(\d{3})/(\d{2})$', p_str)
        if m:
            periods.append(f"{m.group(1)}{m.group(2)}")
    periods.sort()
    return periods


def extract_metrics_for_period(data_by_month, year, start_m, end_m):
    """
    直接從已整合的資料字典中提取 9 項指標
    總表欄位對照：
      Col 3: 流通卡數, Col 4: 有效卡數, Col 5: 活卡率(%)
      Col 8: 循環信用餘額, Col 9: 未到期分期付款餘額
      Col 10: 當月簽帳金額, Col 11: 當月預借現金金額
      Col 14: 備抵呆帳提足率(%), Col 16: 當年度轉銷呆帳金額累計
    """
    bank_full_names = [b['full_name'] for b in BANKS_CONFIG]

    flow_sums = {b: {'簽帳金額': 0, '預借現金金額': 0} for b in bank_full_names}
    end_data = {b: {} for b in bank_full_names}

    for m in range(start_m, end_m + 1):
        p_str = f"{year}/{m:02d}"
        month_records = data_by_month.get(p_str, {})

        for b in bank_full_names:
            b_row = month_records.get(b, {})
            # 流量指標累加
            flow_sums[b]['簽帳金額'] += int(b_row.get(10) or 0)
            flow_sums[b]['預借現金金額'] += int(b_row.get(11) or 0)

            # 若為結束月份，擷取存量、期末比率、年度呆帳累計
            if m == end_m:
                circ = int(b_row.get(3) or 0)
                act = int(b_row.get(4) or 0)
                end_data[b]['流通卡數'] = circ
                end_data[b]['有效卡數'] = act
                
                # 活卡率（優先讀取總表 Col 5，若無則現場計算）
                if b_row.get(5) is not None:
                    end_data[b]['活卡率'] = round(float(b_row.get(5)), 2)
                else:
                    end_data[b]['活卡率'] = round(act / circ * 100, 2) if circ > 0 else 0.0

                end_data[b]['循環信用餘額'] = int(b_row.get(8) or 0)
                end_data[b]['未到期分期付款餘額'] = int(b_row.get(9) or 0)
                end_data[b]['當年度轉銷呆帳金額累計'] = int(b_row.get(16) or 0)
                end_data[b]['備抵呆帳提足率'] = round(float(b_row.get(14) or 0.0), 2)

    result = {}
    for b in bank_full_names:
        result[b] = {**flow_sums[b], **end_data[b]}
    return result


def generate_yoy_report(work_dir, target_year, start_m, end_m):
    # 1. 尋找已整合之彙整表檔案
    summary_file = find_consolidated_summary_file(work_dir)
    if not summary_file:
        print("\n[錯誤] 找不到已產出的彙整總表（五大發卡行信用卡重要資訊彙整_*.xlsx）！")
        print("  請先執行「執行更新_信用卡重要資訊.bat」建立彙整表後再進行計算。")
        return False

    summary_name = os.path.basename(summary_file)
    print(f"\n正在調用已整合總表：{summary_name}")
    try:
        data_by_month = load_consolidated_data(summary_file)
    except Exception as e:
        print(f"\n[錯誤] 讀取彙整總表失敗：{e}")
        return False

    prev_year = target_year - 1
    
    # 2. 檢驗目標期間與去年同期在總表中是否存在
    missing_target = []
    for m in range(start_m, end_m + 1):
        p_str = f"{target_year}/{m:02d}"
        if p_str not in data_by_month:
            missing_target.append(f"{target_year}年{m}月 ({p_str})")

    if missing_target:
        print(f"\n[錯誤] 彙整總表中缺少以下本期月份資料：")
        for item in missing_target:
            print(f"  - {item}")
        print("現有彙整資料不足，請先將新月份資料放入並執行「執行更新_信用卡重要資訊.bat」！")
        return False

    missing_prev = []
    for m in range(start_m, end_m + 1):
        p_str = f"{prev_year}/{m:02d}"
        if p_str not in data_by_month:
            missing_prev.append(f"{prev_year}年{m}月 ({p_str})")

    if missing_prev:
        print(f"\n[錯誤] 彙整總表中缺少以下去年同期資料（無法計算 YoY 年增率）：")
        for item in missing_prev:
            print(f"  - {item}")
        print("現有彙整資料不足以計算 YoY，程式即刻結束。")
        return False

    print(f"  [+] 本期區間資料：{target_year}年{start_m:02d}月 ～ {target_year}年{end_m:02d}月 (已就緒)")
    print(f"  [+] 去年同期資料：{prev_year}年{start_m:02d}月 ～ {prev_year}年{end_m:02d}月 (已就緒)")
    print("正在從總表萃取數據並計算累計與 YoY...")

    curr_data = extract_metrics_for_period(data_by_month, target_year, start_m, end_m)
    prev_data = extract_metrics_for_period(data_by_month, prev_year, start_m, end_m)

    # 計算合計列 (五大發卡行合計)
    bank_full_names = [b['full_name'] for b in BANKS_CONFIG]
    curr_total = {}
    prev_total = {}
    for metric in METRICS_CONFIG:
        m_key = metric['key']
        if metric['type'] == 'ratio':
            # 備抵呆帳提足率：不予加總
            curr_total[m_key] = None
            prev_total[m_key] = None
        elif metric['type'] == 'active_rate':
            # 活卡率合計：總有效卡數 / 總流通卡數 * 100
            tot_act_c = sum(curr_data[b]['有效卡數'] for b in bank_full_names)
            tot_circ_c = sum(curr_data[b]['流通卡數'] for b in bank_full_names)
            curr_total[m_key] = round(tot_act_c / tot_circ_c * 100, 2) if tot_circ_c else 0.0

            tot_act_p = sum(prev_data[b]['有效卡數'] for b in bank_full_names)
            tot_circ_p = sum(prev_data[b]['流通卡數'] for b in bank_full_names)
            prev_total[m_key] = round(tot_act_p / tot_circ_p * 100, 2) if tot_circ_p else 0.0
        else:
            curr_total[m_key] = sum(curr_data[b][m_key] for b in bank_full_names)
            prev_total[m_key] = sum(prev_data[b][m_key] for b in bank_full_names)

    # 3. 建立 Excel 活頁簿
    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    font_main_title = Font(name='微軟正黑體', size=14, bold=True, color='1F4E79')
    font_subtitle = Font(name='微軟正黑體', size=10, color='555555')
    
    font_header_top = Font(name='微軟正黑體', size=11, bold=True, color='FFFFFF')
    fill_header_top = PatternFill(start_color='1F4E79', end_color='1F4E79', fill_type='solid')

    font_header_sub = Font(name='微軟正黑體', size=10, bold=True, color='FFFFFF')
    fill_header_sub = PatternFill(start_color='2E5B82', end_color='2E5B82', fill_type='solid')

    font_data = Font(name='微軟正黑體', size=10)
    font_total = Font(name='微軟正黑體', size=10, bold=True)
    fill_total = PatternFill(start_color='E8EEF5', end_color='E8EEF5', fill_type='solid')
    fill_alt = PatternFill(start_color='F9FAFC', end_color='F9FAFC', fill_type='solid')

    thin_border_side = Side(border_style='thin', color='D9D9D9')
    double_border_side = Side(border_style='double', color='1F4E79')
    border_cell = Border(left=thin_border_side, right=thin_border_side, top=thin_border_side, bottom=thin_border_side)
    border_total = Border(left=thin_border_side, right=thin_border_side, top=thin_border_side, bottom=double_border_side)

    align_center = Alignment(horizontal='center', vertical='center')
    align_left = Alignment(horizontal='left', vertical='center')
    align_right = Alignment(horizontal='right', vertical='center')
    align_header = Alignment(horizontal='center', vertical='center', wrap_text=True)

    period_str_curr = f"{target_year}年{start_m:02d}-{end_m:02d}月"
    period_str_prev = f"{prev_year}年{start_m:02d}-{end_m:02d}月"
    today_str = datetime.date.today().strftime('%Y-%m-%d')

    # ==========================================
    # Sheet 1: 橫向綜合比較表
    # ==========================================
    ws_comp = wb.create_sheet(title='累計與YoY綜合比較表')
    ws_comp.views.sheetView[0].showGridLines = True
    
    ws_comp['A1'] = f"台灣五大發卡行 信用卡重要業務累計與 YoY 分析表"
    ws_comp['A1'].font = font_main_title
    ws_comp['A2'] = f"資料來源：{summary_name} │ 本期：{period_str_curr} │ 去年同期：{period_str_prev} │ 產表日期：{today_str} │ 註：金額與卡數合計採總額計算 YoY；比率以增減百分點 (ppt) 衡量"
    ws_comp['A2'].font = font_subtitle
    ws_comp.row_dimensions[1].height = 28
    ws_comp.row_dimensions[2].height = 18

    ws_comp.row_dimensions[4].height = 24
    ws_comp.row_dimensions[5].height = 22

    ws_comp.cell(4, 1, '金融機構名稱')
    ws_comp.merge_cells(start_row=4, start_column=1, end_row=5, end_column=1)
    c_b = ws_comp.cell(4, 1)
    c_b.font = font_header_top
    c_b.fill = fill_header_top
    c_b.alignment = align_header
    c_b.border = border_cell
    ws_comp.cell(5, 1).border = border_cell

    col_cursor = 2
    for metric in METRICS_CONFIG:
        start_c = col_cursor
        end_c = col_cursor + 3
        is_ratio_type = metric['type'] in ('ratio', 'active_rate')
        
        ws_comp.merge_cells(start_row=4, start_column=start_c, end_row=4, end_column=end_c)
        m_title = f"{metric['display_name']} ({metric['unit']})\n[{metric['type_desc']}]"
        c_m = ws_comp.cell(4, start_c, m_title)
        c_m.font = font_header_top
        c_m.fill = fill_header_top
        c_m.alignment = align_header
        for cx in range(start_c, end_c + 1):
            ws_comp.cell(4, cx).border = border_cell
        
        sub_headers = [
            f"本期 ({period_str_curr})",
            f"去年同期 ({period_str_prev})",
            "增減百分點(ppt)" if is_ratio_type else "增減差額",
            "YoY 年增率"
        ]
        for idx, sub_h in enumerate(sub_headers):
            curr_c = start_c + idx
            c_sub = ws_comp.cell(5, curr_c, sub_h)
            c_sub.font = font_header_sub
            c_sub.fill = fill_header_sub
            c_sub.alignment = align_header
            c_sub.border = border_cell

        col_cursor += 4

    row_idx = 6
    for b in BANKS_CONFIG:
        ws_comp.row_dimensions[row_idx].height = 20
        b_name = b['full_name']
        c_name = ws_comp.cell(row_idx, 1, b_name)
        c_name.font = font_data
        c_name.alignment = align_center
        c_name.border = border_cell
        is_alt = (row_idx % 2 == 1)
        if is_alt:
            c_name.fill = fill_alt

        col_c = 2
        for metric in METRICS_CONFIG:
            m_key = metric['key']
            val_c = curr_data[b_name][m_key]
            val_p = prev_data[b_name][m_key]
            is_ratio_type = metric['type'] in ('ratio', 'active_rate')

            if is_ratio_type:
                val_c = round(val_c, 2)
                val_p = round(val_p, 2)
                val_diff = round(val_c - val_p, 2)
                val_yoy = "-"  # 比率指標以百分點衡量
            else:
                val_diff = val_c - val_p
                val_yoy = (val_diff / val_p) if val_p != 0 else 0.0

            vals = [val_c, val_p, val_diff, val_yoy]
            for i, v in enumerate(vals):
                cell = ws_comp.cell(row_idx, col_c + i, v)
                cell.font = font_data
                cell.border = border_cell
                if is_alt:
                    cell.fill = fill_alt
                
                if is_ratio_type:
                    if i < 2:
                        cell.alignment = align_right
                        cell.number_format = '0.00'
                    elif i == 2:
                        cell.alignment = align_right
                        cell.number_format = '+0.00;-0.00;0.00'
                    else:
                        cell.alignment = align_center
                else:
                    cell.alignment = align_right
                    if i < 3:
                        cell.number_format = '#,##0'
                    else:
                        cell.number_format = '0.00%'

            col_c += 4
        row_idx += 1

    # 合計列 (五大發卡行合計)
    ws_comp.row_dimensions[row_idx].height = 22
    c_tot = ws_comp.cell(row_idx, 1, '五大發卡行合計')
    c_tot.font = font_total
    c_tot.alignment = align_center
    c_tot.fill = fill_total
    c_tot.border = border_total

    col_c = 2
    for metric in METRICS_CONFIG:
        m_key = metric['key']
        if metric['type'] == 'ratio':
            # 備抵呆帳提足率：不予加總
            vals = ["-", "-", "-", "-"]
        elif metric['type'] == 'active_rate':
            # 活卡率：以合計有效卡/合計流通卡計算
            val_c = curr_total[m_key]
            val_p = prev_total[m_key]
            val_diff = round(val_c - val_p, 2)
            val_yoy = "-"
            vals = [val_c, val_p, val_diff, val_yoy]
        else:
            val_c = curr_total[m_key]
            val_p = prev_total[m_key]
            val_diff = val_c - val_p
            val_yoy = (val_diff / val_p) if val_p != 0 else 0.0
            vals = [val_c, val_p, val_diff, val_yoy]

        for i, v in enumerate(vals):
            cell = ws_comp.cell(row_idx, col_c + i, v)
            cell.font = font_total
            cell.fill = fill_total
            cell.border = border_total
            
            if v == "-":
                cell.alignment = align_center
            elif metric['type'] == 'active_rate':
                if i < 2:
                    cell.alignment = align_right
                    cell.number_format = '0.00'
                elif i == 2:
                    cell.alignment = align_right
                    cell.number_format = '+0.00;-0.00;0.00'
                else:
                    cell.alignment = align_center
            else:
                cell.alignment = align_right
                if i < 3:
                    cell.number_format = '#,##0'
                else:
                    cell.number_format = '0.00%'
        col_c += 4

    ws_comp.freeze_panes = 'B6'
    for col in ws_comp.columns:
        col_letter = get_column_letter(col[0].column)
        max_len = 0
        for cell in col:
            val_str = str(cell.value or '')
            w = sum(2 if ord(ch) > 127 else 1 for ch in val_str)
            if w > max_len:
                max_len = w
        ws_comp.column_dimensions[col_letter].width = max(max_len + 3, 14)

    # ==========================================
    # Sheet 2: 縱向明細表
    # ==========================================
    ws_detail = wb.create_sheet(title='銀行別指標明細')
    ws_detail.views.sheetView[0].showGridLines = True

    ws_detail['A1'] = f"五大發卡行各行 信用卡業務指標累計與 YoY 縱向明細"
    ws_detail['A1'].font = font_main_title
    ws_detail['A2'] = f"資料來源：{summary_name} │ 本期：{period_str_curr} │ 去年同期：{period_str_prev} │ 註：金額與卡數合計採總額計算 YoY；比率以增減百分點 (ppt) 衡量"
    ws_detail['A2'].font = font_subtitle
    ws_detail.row_dimensions[1].height = 28
    ws_detail.row_dimensions[2].height = 18

    detail_headers = [
        '金融機構名稱',
        '指標項目',
        '指標屬性',
        '單位',
        f"本期數值 ({period_str_curr})",
        f"去年同期 ({period_str_prev})",
        '增減差額 / 百分點(ppt)',
        'YoY 年增率'
    ]
    ws_detail.append([])
    ws_detail.append(detail_headers)
    ws_detail.row_dimensions[4].height = 26

    for ci, h in enumerate(detail_headers, 1):
        cell = ws_detail.cell(4, ci)
        cell.font = font_header_top
        cell.fill = fill_header_top
        cell.alignment = align_header
        cell.border = border_cell

    d_row = 5
    all_banks_for_detail = [(b['full_name'], curr_data[b['full_name']], prev_data[b['full_name']]) for b in BANKS_CONFIG]
    all_banks_for_detail.append(('五大發卡行合計', curr_total, prev_total))

    for b_name, b_curr, b_prev in all_banks_for_detail:
        is_total_bank = (b_name == '五大發卡行合計')
        for metric in METRICS_CONFIG:
            ws_detail.row_dimensions[d_row].height = 20
            m_key = metric['key']
            is_ratio_type = metric['type'] in ('ratio', 'active_rate')

            if metric['type'] == 'ratio':
                if is_total_bank:
                    val_c = "-"
                    val_p = "-"
                    val_diff = "-"
                    val_yoy = "-"
                else:
                    val_c = round(b_curr[m_key], 2)
                    val_p = round(b_prev[m_key], 2)
                    val_diff = round(val_c - val_p, 2)
                    val_yoy = "-"
            elif metric['type'] == 'active_rate':
                val_c = round(b_curr[m_key], 2)
                val_p = round(b_prev[m_key], 2)
                val_diff = round(val_c - val_p, 2)
                val_yoy = "-"
            else:
                val_c = b_curr[m_key]
                val_p = b_prev[m_key]
                val_diff = val_c - val_p
                val_yoy = (val_diff / val_p) if val_p != 0 else 0.0

            row_content = [
                b_name,
                metric['display_name'],
                metric['type_desc'],
                metric['unit'],
                val_c,
                val_p,
                val_diff,
                val_yoy
            ]

            for ci, val in enumerate(row_content, 1):
                cell = ws_detail.cell(d_row, ci, val)
                cell.font = font_total if is_total_bank else font_data
                cell.border = border_total if is_total_bank else border_cell

                if is_total_bank:
                    cell.fill = fill_total
                elif (d_row % 2 == 1):
                    cell.fill = fill_alt

                if ci in (1, 2):
                    cell.alignment = align_left
                elif ci in (3, 4):
                    cell.alignment = align_center
                elif ci in (5, 6, 7):
                    if val == "-":
                        cell.alignment = align_center
                    else:
                        cell.alignment = align_right
                        if is_ratio_type:
                            if ci in (5, 6):
                                cell.number_format = '0.00'
                            else:
                                cell.number_format = '+0.00;-0.00;0.00'
                        else:
                            cell.number_format = '#,##0'
                elif ci == 8:
                    if val == "-":
                        cell.alignment = align_center
                    else:
                        cell.alignment = align_right
                        cell.number_format = '0.00%'

            d_row += 1

    ws_detail.freeze_panes = 'C5'
    for col in ws_detail.columns:
        col_letter = get_column_letter(col[0].column)
        max_len = 0
        for cell in col:
            val_str = str(cell.value or '')
            w = sum(2 if ord(ch) > 127 else 1 for ch in val_str)
            if w > max_len:
                max_len = w
        ws_detail.column_dimensions[col_letter].width = max(max_len + 3, 14)

    # ==========================================
    # Sheet 3: 01_同業對標明細 (國泰世華 1B PEER BENCHMARK)
    # ==========================================
    ws_bench = wb.create_sheet(title='01_同業對標明細')
    ws_bench.views.sheetView[0].showGridLines = True

    font_b_title = Font(name='Microsoft JhengHei', size=13, bold=True, color='1E293B')
    font_b_sub = Font(name='Microsoft JhengHei', size=10, color='555555')
    font_b_hdr = Font(name='Microsoft JhengHei', size=11, bold=True, color='FFFFFF')
    fill_b_hdr = PatternFill(start_color='C2410C', end_color='C2410C', fill_type='solid')
    font_b_cell = Font(name='Microsoft JhengHei', size=10)

    ad_year = target_year + 1911
    ws_bench['A1'] = "國泰世華銀行 信用卡營運儀表板 - 五大行經營比較 (1B PEER BENCHMARK YTD)"
    ws_bench['A1'].font = font_b_title
    ws_bench['A2'] = f"說明：維護五大發卡行各業務類別在 {ad_year} 年 1–{end_m} 月（民國 {target_year} 年 1–{end_m} 月）的累計經營數據。系統會自動計算五家平均/五家整體成長率與競爭差距。"
    ws_bench['A2'].font = font_b_sub

    bench_headers = [
        '業務主題', '指標名稱', '單位', '優良方向',
        '國泰數值', '國泰YoY(%)',
        '中信數值', '中信YoY(%)',
        '富邦數值', '富邦YoY(%)',
        '玉山數值', '玉山YoY(%)',
        '台新數值', '台新YoY(%)'
    ]
    ws_bench.append([])
    ws_bench.append(bench_headers)
    ws_bench.row_dimensions[4].height = 26

    for ci, h in enumerate(bench_headers, 1):
        cell = ws_bench.cell(4, ci)
        cell.font = font_b_hdr
        cell.fill = fill_b_hdr
        cell.alignment = align_header
        cell.border = border_cell

    bench_rows_def = [
        ('消費經營', '簽帳金額', '億元', 'up', '#,##0.00', '#,##0.0'),
        ('卡量經營', '有效卡數', '張', 'up', '#,##0', '#,##0.0'),
        ('卡量經營', '流通卡數', '張', 'up', '#,##0', '#,##0.0'),
        ('卡量經營', '活卡率', '%', 'up', '#,##0.0', '#,##0.0'),
        ('信用業務', '循環信用餘額', '億元', 'up', '#,##0.00', '#,##0.0'),
        ('信用業務', '預借現金金額', '億元', 'up', '#,##0.00', '#,##0.0'),
        ('資產品質', '備抵呆帳提足率', '%', 'up', '#,##0', '#,##0.0'),
        ('資產品質', '轉銷呆帳', '億元', 'down', '#,##0.00', '#,##0.0')
    ]

    bench_bank_order = [
        ('國泰世華商業銀行', 5, 6),
        ('中國信託商業銀行', 7, 8),
        ('台北富邦商業銀行', 9, 10),
        ('玉山商業銀行', 11, 12),
        ('台新國際商業銀行', 13, 14)
    ]

    bench_metric_map = {
        '簽帳金額': '簽帳金額',
        '有效卡數': '有效卡數',
        '流通卡數': '流通卡數',
        '活卡率': '活卡率',
        '循環信用餘額': '循環信用餘額',
        '預借現金金額': '預借現金金額',
        '備抵呆帳提足率': '備抵呆帳提足率',
        '轉銷呆帳': '當年度轉銷呆帳金額累計'
    }

    for b_r_idx, (theme, m_name, unit, direction, fmt_v, fmt_y) in enumerate(bench_rows_def, 5):
        ws_bench.row_dimensions[b_r_idx].height = 20
        m_key = bench_metric_map[m_name]
        
        ws_bench.cell(b_r_idx, 1, theme).alignment = align_center
        ws_bench.cell(b_r_idx, 2, m_name).alignment = align_left
        ws_bench.cell(b_r_idx, 3, unit).alignment = align_center
        ws_bench.cell(b_r_idx, 4, direction).alignment = align_center

        for ci in range(1, 5):
            c_item = ws_bench.cell(b_r_idx, ci)
            c_item.font = font_b_cell
            c_item.border = border_cell

        for b_full, col_v, col_y in bench_bank_order:
            val_c = curr_data[b_full][m_key]
            val_p = prev_data[b_full][m_key]

            if m_name in ('活卡率', '備抵呆帳提足率'):
                diff = round(val_c - val_p, 2)
                yoy_num = diff
            else:
                yoy_num = round((val_c - val_p) / val_p * 100, 2) if val_p else 0.0

            # 若單位為億元，由千元轉換為億元（除以 100,000）
            if unit == '億元':
                val_to_write = round(val_c / 100000.0, 2)
            else:
                val_to_write = val_c

            c_val = ws_bench.cell(b_r_idx, col_v, val_to_write)
            c_val.font = font_b_cell
            c_val.border = border_cell
            c_val.alignment = align_right
            c_val.number_format = fmt_v

            c_yoy = ws_bench.cell(b_r_idx, col_y, yoy_num)
            c_yoy.font = font_b_cell
            c_yoy.border = border_cell
            c_yoy.alignment = align_right
            c_yoy.number_format = fmt_y

    b_col_widths = {'A': 12, 'B': 18, 'C': 12, 'D': 13, 'E': 13, 'F': 14, 'G': 12, 'H': 14, 'I': 12, 'J': 14, 'K': 12, 'L': 14, 'M': 12, 'N': 14}
    for col_l, w in b_col_widths.items():
        ws_bench.column_dimensions[col_l].width = w

    # 4. 儲存輸出
    out_name = f"五大發卡行信用卡累計與YoY分析_{target_year}年_{start_m:02d}-{end_m:02d}月.xlsx"
    out_path = os.path.join(work_dir, out_name)

    try:
        wb.save(out_path)
    except PermissionError:
        alt_name = f"五大發卡行信用卡累計與YoY分析_{target_year}年_{start_m:02d}-{end_m:02d}月_最新.xlsx"
        alt_path = os.path.join(work_dir, alt_name)
        try:
            wb.save(alt_path)
            print(f"\n[提示] 原檔案「{out_name}」正由 Excel 開啟中！")
            print(f"  已為您另存最新邏輯修正版本至：")
            print(f"  👉 {alt_name}")
            out_name = alt_name
        except Exception:
            print(f"\n[錯誤] 無法寫入檔案「{out_name}」！")
            print("  原因：該 Excel 檔案正被開啟中，請先關閉後重試。")
            return False

    print("\n" + "=" * 54)
    print("  信用卡重要資訊 累計與 YoY 分析表 - 產出成功！")
    print(f"  調用來源：{summary_name} (總表)")
    print(f"  報告檔案名稱: {out_name}")
    print(f"  分析計算區間: {period_str_curr} vs {period_str_prev}")
    print(f"  工作表 1: 累計與YoY綜合比較表 (橫向 KPI 跨行矩陣)")
    print(f"  工作表 2: 銀行別指標明細 (縱向清楚好讀版)")
    print(f"  工作表 3: 01_同業對標明細 (同業基準對標版)")
    print("=" * 54)
    return True


def interactive_mode(work_dir):
    summary_file = find_consolidated_summary_file(work_dir)
    if not summary_file:
        print("\n[錯誤] 找不到已產出的彙整總表（五大發卡行信用卡重要資訊彙整_*.xlsx）！")
        print("  請先執行「執行更新_信用卡重要資訊.bat」建立彙整表後再進行計算。")
        return

    summary_name = os.path.basename(summary_file)
    try:
        data_by_month = load_consolidated_data(summary_file)
    except Exception as e:
        print(f"\n[錯誤] 讀取彙整總表失敗：{e}")
        return

    periods = get_available_periods_from_summary(data_by_month)
    if not periods:
        print("[錯誤] 彙整總表中未發現任何月份資料！")
        return

    latest_period = periods[-1] # e.g. '11507'
    default_year = int(latest_period[:3])
    default_end_m = int(latest_period[3:])
    default_start_m = 1

    print("\n" + "=" * 56)
    print("    台灣五大發卡行 信用卡累計數據與 YoY 分析工具")
    print("=" * 56)
    print(f"  已連接彙整來源：{summary_name}")
    print(f"  總表收錄資料範圍：{periods[0]} ～ {latest_period}")
    print(f"  最新可用年份為：{default_year} 年 (收錄至 {default_end_m} 月)")
    print("-" * 56)

    # 互動輸入年份
    while True:
        prompt_y = f"請輸入欲計算的年份 [預設: {default_year}] (直接按 Enter 採用): "
        val_y = input(prompt_y).strip()
        if not val_y:
            year = default_year
            break
        if val_y.isdigit() and len(val_y) == 3:
            year = int(val_y)
            break
        print("  [!] 年份格式請輸入 3 位民國年，例如 115")

    # 互動輸入開始月份
    while True:
        prompt_sm = f"請輸入起始月份 [預設: {default_start_m}] (直接按 Enter 採用): "
        val_sm = input(prompt_sm).strip()
        if not val_sm:
            start_m = default_start_m
            break
        if val_sm.isdigit() and 1 <= int(val_sm) <= 12:
            start_m = int(val_sm)
            break
        print("  [!] 月份請輸入 1 到 12 的整數")

    # 互動輸入結束月份
    while True:
        prompt_em = f"請輸入結束月份 [預設: {default_end_m}] (直接按 Enter 採用): "
        val_em = input(prompt_em).strip()
        if not val_em:
            end_m = default_end_m
            break
        if val_em.isdigit() and 1 <= int(val_em) <= 12:
            em = int(val_em)
            if em < start_m:
                print(f"  [!] 結束月份 ({em}) 不能小於起始月份 ({start_m})！")
                continue
            end_m = em
            break
        print("  [!] 月份請輸入 1 到 12 的整數")

    print(f"\n已設定計算條件：{year} 年 {start_m:02d} 月 ～ {end_m:02d} 月 (比對 {year-1} 年同期)")
    generate_yoy_report(work_dir, year, start_m, end_m)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='五大發卡行信用卡累計與YoY計算工具')
    parser.add_argument('--year', type=int, help='民國年份 (如 115)')
    parser.add_argument('--start', type=int, help='開始月份 (如 1)')
    parser.add_argument('--end', type=int, help='結束月份 (如 7)')

    args = parser.parse_args()
    script_dir = os.path.dirname(os.path.abspath(__file__))

    if args.year and args.start and args.end:
        generate_yoy_report(script_dir, args.year, args.start, args.end)
    else:
        interactive_mode(script_dir)
