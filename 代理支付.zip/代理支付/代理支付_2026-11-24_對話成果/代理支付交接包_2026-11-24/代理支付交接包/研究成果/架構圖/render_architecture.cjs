const {launchBrowser}=require('../browser_runtime.cjs');
const fs=require('node:fs');const path=require('node:path');const {pathToFileURL}=require('node:url');
(async()=>{
 const browser=await launchBrowser();
 const page=await browser.newPage({deviceScaleFactor:1.5});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 const data=JSON.parse(fs.readFileSync(path.join(__dirname,'architecture-data.json'),'utf8'));
 for(const g of data){
  await page.setViewportSize({width:g.width,height:g.height});
  await page.setContent('<!doctype html><html><body style="margin:0">'+fs.readFileSync(path.join(__dirname,g.id+'.svg'),'utf8')+'</body></html>');
  await page.screenshot({path:path.join(__dirname,g.id+'.png'),fullPage:true});
  const bounds=await page.evaluate(()=>[...document.querySelectorAll('text')].filter(t=>{const b=t.getBBox();const s=document.querySelector('svg').viewBox.baseVal;return b.x<0||b.y<0||b.x+b.width>s.width+1||b.y+b.height>s.height+1}).map(x=>x.textContent));
  if(bounds.length)throw Error(JSON.stringify({id:g.id,bounds}));
 }
 await page.goto(pathToFileURL(path.join(__dirname,'index.html')).href);
 for(const g of data){await page.locator(`[data-id="${g.id}"]`).click();if(await page.locator('#frame svg').count()!==1)throw Error('missing diagram');}
 if(errors.length)throw Error(errors.join('\n'));
 console.log(`Rendered and checked ${data.length} diagrams, SVG text bounds, and viewer switching.`);
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
