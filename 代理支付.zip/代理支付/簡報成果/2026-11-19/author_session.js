var fsDeck = await import('node:fs/promises');
var deckData = JSON.parse(await fsDeck.readFile('C:/Users/user/Documents/Codex/代理支付/簡報成果/2026-11-19/簡報內容.json','utf8'));
var deckFont = 'Microsoft JhengHei';
var deckColors = {navy:'#17384C',ink:'#253A46',muted:'#586B76',paper:'#F7F8FA',teal:'#007B83',orange:'#AE4E19',rule:'#D6E0E5'};
function deckText(s,txt,x,y,w,h,size,color,bold=false,align='left') {
 const a=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});
 a.text=txt;
 a.text.style={fontFamily:deckFont,fontSize:`${size}pt`,color,bold,alignment:align,verticalAlignment:'middle'};
 return a;
}
function deckNotes(d) {
 return `${d.title.replace(/\n/g,'：')}\n\n${d.notes}\n\n${d.callout?'提醒：'+d.callout+'\n\n':''}來源與證據範圍（截至2026-11-19）：\n`+d.refs.map(k=>`${k}｜${deckData.sources[k].title}\n${deckData.sources[k].url}\n${deckData.sources[k].status}`).join('\n\n');
}
function buildDeckSlide(p,d) {
 const s=p.slides.add();s.size={width:1280,height:720};s.background.fill=deckColors.paper;
 const accent=d.chapter==='Visa'?'#174A8B':d.chapter==='Mastercard'?deckColors.orange:deckColors.teal;
 if(d.kind==='cover') {
   s.background.fill=deckColors.navy;
   deckText(s,'研究教材  /  2026.11.19',72,80,1110,50,18,'#B5D8DF');
   deckText(s,d.title,72,220,1120,190,42,'#FFFFFF',true);
   deckText(s,d.sub,76,448,1110,80,22,'#DAE7EB');
   deckText(s,'公開官方文件、開放草案與案例｜逐頁講稿與來源附於備忘稿',76,614,1110,45,15,'#B5D8DF');
 } else {
   deckText(s,`${d.chapter}  /  ${d.tag}`,64,30,1152,35,14,accent,true);
   deckText(s,d.title,64,82,1152,82,32,deckColors.navy,true);
   if(d.kind==='table') {
     const col=d.rows[0].length;
     const widths=col===2?[300,852]:[246,476,430];
     const t=s.tables.add({rows:d.rows.length,columns:col,left:64,top:184,width:1152,height:420,columnWidths:widths,values:d.rows});
     t.borders.assign({style:'solid',fill:deckColors.rule,width:0.6});
     t.cells.block({row:0,column:0,rowCount:d.rows.length,columnCount:col}).assign({fill:'#FFFFFF',textStyle:{typeface:deckFont,fontSize:23,color:deckColors.ink},margins:{left:15,right:15,top:8,bottom:8},anchor:'center'});
     t.cells.block({row:0,column:0,rowCount:1,columnCount:col}).assign({fill:deckColors.navy,textStyle:{typeface:deckFont,fontSize:23,bold:true,color:'#FFFFFF'}});
     for(let r=1;r<d.rows.length;r++)if(r%2===0)t.cells.block({row:r,column:0,rowCount:1,columnCount:col}).fill='#EDF3F5';
   } else if(d.kind==='flow') {
     const nodes=d.nodes.length;const gap=32;const width=(1152-gap*(nodes-1))/nodes;const a=[];
     for(let i=0;i<nodes;i++){
       const sh=s.shapes.add({geometry:'rect',position:{left:64+i*(width+gap),top:232,width,height:132},fill:i===nodes-1?accent:'#E8F0F3',line:{fill:i===nodes-1?accent:'#99B2BF',width:1}});
       sh.text=d.nodes[i];sh.text.style={fontFamily:deckFont,fontSize:'20pt',color:i===nodes-1?'#FFFFFF':deckColors.navy,bold:true,alignment:'center',verticalAlignment:'middle'};
       a.push(sh);
       deckText(s,`${i+1}`,(64+i*(width+gap)),185,width,34,16,accent,true,'center');
     }
     for(let i=0;i<a.length-1;i++)s.shapes.connect(a[i],a[i+1],{kind:'straight',fromSide:'right',toSide:'left',line:{fill:accent,width:2},tail:{type:'arrow',width:'med',length:'med'}});
     d.points.forEach((txt,i)=>deckText(s,txt,74,418+i*83,1120,70,21,deckColors.ink));
   } else {
     d.points.forEach((txt,i)=>{
       deckText(s,String(i+1).padStart(2,'0'),64,186+i*98,64,70,18,accent,true);
       deckText(s,txt,144,181+i*98,1068,83,23,deckColors.ink);
     });
   }
   if(d.callout)deckText(s,d.callout,68,617,1144,41,15,accent,true);
   const refs=d.refs.join(' · ');
   deckText(s,`來源 ${refs}｜詳見本頁備忘稿`,64,677,850,24,11,deckColors.muted);
   deckText(s,`${d.focus?'主線  ·  ':''}${String(d.n).padStart(2,'0')} / ${deckData.slides.length}`,958,677,258,24,11,deckColors.muted,false,'right');
 }
 s.speakerNotes.text=deckNotes(d);
 return s;
}
nodeRepl.write({loadedSlides:deckData.slides.length});
