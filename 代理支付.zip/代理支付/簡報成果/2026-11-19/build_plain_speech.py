from pathlib import Path
from html import escape
import json,re

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent.parent
d=json.loads((ROOT/'小樹購檢核講稿.json').read_text(encoding='utf8'))
sources=json.loads((PROJECT/'研究成果/架構圖/檢核註記版/註記內容.json').read_text(encoding='utf8'))['sources']
assert [p['id'] for p in d['points']]==['P','A','B','C1','C2','C3','D','E1','E2','F']
spoken=d['opening']+[s for p in d['points'] for s in p['speech']+[p['transition']]]+d['closing']
characters=sum(len(re.findall(r'[\u4e00-\u9fff]',s)) for s in spoken)
glossary=[
 ('Agent','能理解需求、選擇下一個動作的AI助理；真正執行動作要經過工具與服務。'),
 ('DB','資料庫。此案用來保存委任、版本、狀態及發生過的事。'),
 ('API','兩套系統交換資料或要求操作的窗口。窗口可以分別處理查詢、下單或付款。'),
 ('版本','同一份需求或明細的不同版次，避免修改後還繼續使用舊內容。'),
 ('交易明細','具體列出商品、賣方、數量、費用與重要條件的資料，不只是助理的一段介紹。'),
 ('固定pattern','事先定義的欄位與比較規則；在本案中是程式可明確執行的基本檢查。'),
 ('付款參照／Token','都是討論付款資料時會遇到的名詞，但本行內部代號與網路支付Token的功能及受理範圍不一定相同。'),
 ('數位簽章','用密碼學驗證來源與指定資料完整性的方式；驗簽仍須有可信金鑰及正確的簽署範圍。'),
 ('雜湊','依固定算法算出的資料摘要，可協助核對內容是否相同；單靠雜湊不證明誰同意了交易。'),
 ('VI Immediate','VI草案中，由使用者確認最終交易值的模式；採用該模式概念與正式實作憑證機制，要分開說明。')
]
md=['# '+d['title'],'',d['subtitle'],'','整理日期：2026-11-19。主講依P、A、B、C1、C2、C3、D、E1、E2、F順序，對照flow.html檢核點。','',
 '**使用方式**：各點「可直接念」與轉場可連續報告；看圖提示、理解補充、組織對照與備詢不用全部念。所有咖啡機與金額均為教學假設。','',
 '## 共同案例','',d['scenario'],'','## 先看這張速記表','', '| 檢核點 | 主要在問什麼 | 一句話記住 |','|---|---|---|']
for p in d['points']:md.append(f'| {p["id"]} | {p["question"]} | {p["takeaway"]} |')
md+=['','## 開場｜可直接念','']+sum(([s,''] for s in d['opening']),[])
for p in d['points']:
 md+=['## '+p['id']+'｜'+p['title'],'','**看圖提示**：'+p['cue'],'','### 可直接念','']
 for s in p['speech']:md += [s,'']
 md+=['**轉場**：'+p['transition'],'','### 給自己理解的補充','', '**一句話記住**：'+p['takeaway'],'']
 md += ['- '+s for s in p['learning']]
 md += ['', '### 國際組織實際怎麼操作','',p['reference'],'']
 w=p['organization_walkthrough']
 for key,label in [('visa','Visa'),('master','Mastercard')]:
  md+=['**'+label+'**','']+[f'{i}. {s}' for i,s in enumerate(w[key],1)]+['']
 md+=['**放回本行怎麼做**：'+w['bank'],'','**尚須取得的規格／能力**：'+w['gap'],'','**本機研究**：'+'、'.join(f'[{f}](../../代理支付官方研究/{f})' for f in w['local']),'','**官方來源**：'+'、'.join(f'[{k} {sources[k][0]}]({sources[k][1]})' for k in p['sources']),'']
md+=['## 收尾｜可直接念','']
for s in d['closing']:md += [s,'']
md+=['## 備詢與容易混淆的問題','']
for f in d['faq']:md+=['### '+f['q'],'',f['a'],'']
md+=['## 名詞白話表','','| 名詞 | 怎麼理解 |','|---|---|']
for k,v in glossary:md.append(f'| {k} | {v} |')
md += ['', '## 資料範圍','', '本稿沿用目前flow.html十個檢核點及具體功能建議，以小樹購購物替換原教學案例。原圖的實際系統、平台能力與路由仍待確認；本稿不把自建建議當作已建置，也不把VI草案當作Mastercard全部生產流程。','', '檢核點資料：../../參考資料/flow首頁檢核改寫_2026-11-19/development_notes.json。','', f'主講中文字數約{characters:,}字（不含理解補充及備詢；實際講述時間依語速、停頓與現場互動而異）。']
(ROOT/'十個檢核點白話講稿_小樹購版.md').write_text('\n'.join(md),encoding='utf8')

def paras(items):return ''.join('<p>'+escape(s)+'</p>' for s in items)
def links(keys):return '、'.join(f'<a href="{escape(sources[k][1])}" target="_blank" rel="noopener">{escape(k+" "+sources[k][0])}</a>' for k in keys)
def walkthrough(p):
 w=p['organization_walkthrough']
 out='<div class="organization-walkthrough"><h3>國際組織實際怎麼操作</h3>'
 for key,label in [('visa','Visa'),('master','Mastercard')]:
  out+='<h3>'+label+'</h3><ol>'+''.join('<li>'+escape(s)+'</li>' for s in w[key])+'</ol>'
 out+='<h3>放回本行怎麼做</h3><p>'+escape(w['bank'])+'</p><h3>尚須取得的規格／能力</h3><p>'+escape(w['gap'])+'</p>'
 out+='<p class="sources">本機研究：'+'、'.join('<a href="../../代理支付官方研究/'+escape(f)+'">'+escape(f)+'</a>' for f in w['local'])+'</p></div>'
 return out
nav='<a href="#opening">開場</a>'+''.join(f'<a href="#point-{p["id"]}">{p["id"]}　{escape(p["question"])}</a>' for p in d['points'])+'<a href="#closing">收尾</a><a href="#faq">備詢與名詞</a>'
body='<section class="case"><h2>共同案例</h2><p>'+escape(d['scenario'])+'</p></section>'
body+='<details class="quick"><summary>先看10點速記表</summary><table><thead><tr><th>位置</th><th>主要在問什麼</th><th>一句話記住</th></tr></thead><tbody>'+''.join(f'<tr><td>{p["id"]}</td><td>{escape(p["question"])}</td><td>{escape(p["takeaway"])}</td></tr>' for p in d['points'])+'</tbody></table></details>'
body+='<section id="opening" class="speech"><p class="eyebrow">可直接念</p><h2>開場</h2>'+paras(d['opening'])+'</section>'
for p in d['points']:
 body+=f'<section id="point-{p["id"]}" class="speech"><p class="eyebrow">{p["id"]} · 可直接念</p><h2>{escape(p["title"])}</h2><p class="cue">看圖提示：{escape(p["cue"])}</p>'+paras(p['speech'])+f'<p class="transition"><b>接著說：</b>{escape(p["transition"])}</p>'
 body+='<details class="learning"><summary>操作詳解：Visa／Mastercard怎麼做、本行怎麼做</summary><p class="takeaway">'+escape(p['takeaway'])+'</p><ul>'+''.join('<li>'+escape(s)+'</li>' for s in p['learning'])+'</ul>'+walkthrough(p)+'<p class="sources">官方來源：'+links(p['sources'])+'</p></details></section>'
body+='<section id="closing" class="speech"><p class="eyebrow">可直接念</p><h2>收尾</h2>'+paras(d['closing'])+'</section>'
body+='<section id="faq" class="faq"><h2>備詢與容易混淆的問題</h2>'+''.join('<details><summary>'+escape(f['q'])+'</summary><p>'+escape(f['a'])+'</p></details>' for f in d['faq'])+'</section>'
body+='<section class="glossary"><h2>名詞白話表</h2><dl>'+''.join('<dt>'+escape(k)+'</dt><dd>'+escape(v)+'</dd>' for k,v in glossary)+'</dl></section>'
html='''<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>十個檢核點白話講稿｜小樹購版</title><style>
*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:24px}body{margin:0;background:#f1f5f8;color:#243e4e;font:18px/1.9 "Microsoft JhengHei",Arial,sans-serif}a{color:#1c6387;text-underline-offset:4px}a:focus-visible,summary:focus-visible{outline:3px solid #c88729;outline-offset:3px}.layout{display:grid;grid-template-columns:245px minmax(0,900px);max-width:1250px;margin:auto;gap:28px;padding:30px 24px}.toc{position:sticky;top:24px;align-self:start;font-size:15px;max-height:calc(100dvh - 48px);overflow:auto}.toc strong{display:block;color:#215b4b;font-size:16px;margin-bottom:10px}.toc a{display:block;text-decoration:none;padding:6px 10px;border-left:2px solid #d0dde5;line-height:1.6}.toc a:hover{background:#e2edf2}.paper{min-width:0;background:white;padding:38px 46px;border:1px solid #d9e3e9;border-radius:8px}h1{font-size:30px;line-height:1.45;margin:0 0 10px}h2{font-size:25px;line-height:1.5;margin:4px 0 18px;color:#183e55}h3{font-size:19px;margin:18px 0 8px}p{margin:0 0 20px}.subtitle,.meta{color:#587080}.subtitle{font-size:17px}.meta{font-size:14px}.case{background:#f0f7f4;padding:20px 24px;border-left:4px solid #4b8c73;margin:24px 0}.case h2{font-size:20px}.case p{margin:0;font-size:16px}.speech{padding-top:30px;margin-top:24px;border-top:1px solid #dce6ec;scroll-margin-top:24px}.eyebrow{font-size:14px;font-weight:700;letter-spacing:.05em;color:#2b775c;margin:0 0 5px}.cue{font-size:14px;color:#59768b;background:#f2f6fa;padding:9px 12px;border-radius:4px}.transition{font-size:17px;color:#456777}.learning,.quick{margin:22px 0;padding:13px 17px;border:1px solid #ccdde5;border-radius:6px;background:#f8fafc;font-size:16px}.learning summary,.quick summary{font-weight:700;color:#285c74;cursor:pointer}.learning p{margin:12px 0}.takeaway{font-weight:700;color:#2c6951}.learning li{margin:8px 0}.sources{font-size:14px;overflow-wrap:anywhere}table{width:100%;border-collapse:collapse;font-size:15px;margin-top:15px}th,td{text-align:left;vertical-align:top;padding:9px;border-bottom:1px solid #d7e2e9}.faq,.glossary{margin-top:40px;padding-top:25px;border-top:2px solid #cddce5}.faq details{border-bottom:1px solid #dce5eb;padding:13px 0;font-size:16px}.faq summary{font-weight:700;cursor:pointer}.faq p{margin:12px 0}.glossary dt{font-size:17px;font-weight:700;color:#2d6256;margin-top:16px}.glossary dd{font-size:16px;margin:4px 0 0}.footer{font-size:14px;color:#607989;border-top:1px solid #dbe5ea;padding-top:20px;margin-top:30px;overflow-wrap:anywhere}@media(max-width:900px){.layout{display:block;padding:14px}.toc{position:static;max-height:none;margin:0 0 18px;display:flex;flex-wrap:wrap;gap:5px}.toc strong{width:100%}.toc a{padding:5px 8px;border:1px solid #d1dfe7;border-radius:4px;font-size:14px}.paper{padding:25px 20px}h1{font-size:26px}h2{font-size:23px}.quick{overflow:auto}.quick table{min-width:550px}}@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}}@media print{@page{size:A4;margin:20mm}body{background:white;font-size:12pt;line-height:1.8}.layout{display:block;padding:0}.toc,.learning,.quick,.cue,.faq,.glossary,.footer,.meta{display:none}.paper{border:0;padding:0}.case{font-size:11pt;padding:12px}.speech{break-inside:auto}.speech h2{break-after:avoid}.speech p{orphans:3;widows:3}h1{font-size:21pt}h2{font-size:17pt}.transition{font-size:11pt}}
</style></head><body><div class="layout"><nav class="toc" aria-label="講稿段落"><strong>報告順序</strong>'''+nav+'''</nav><main class="paper"><header><h1>'''+escape(d['title'])+'''</h1><p class="subtitle">'''+escape(d['subtitle'])+'''</p><p class="meta">2026-11-19 · 主講約'''+str(characters)+'''個中文字（不含理解補充及備詢）</p><p class="meta">連續閱讀「可直接念」及轉場即可報告。每點的理解補充可自行展開；列印時保留主講內容。<br><a href="../../流程檢核點.html">對照檢核圖</a>　<a href="十個檢核點白話講稿_小樹購版.md">可編輯Markdown講稿</a></p></header>'''+body+'''<footer class="footer">內容沿用目前十個檢核點及已整理官方資料；本行功能為設計建議，平台能力與實際路由待確認。案例為教學假設，VI另標為公開草案。</footer></main></div></body></html>'''
(ROOT/'十個檢核點白話講稿_小樹購版.html').write_text(html,encoding='utf8')
print(json.dumps({'points':len(d['points']),'spokenChineseCharacters':characters,'qa':len(d['faq']),'outputs':['十個檢核點白話講稿_小樹購版.md','十個檢核點白話講稿_小樹購版.html']},ensure_ascii=False))
