from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET,html
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from pypdf import PdfReader

out=Path(__file__).resolve().parent
data=json.loads((out/'簡報內容.json').read_text(encoding='utf-8'))
slides=data['slides']
pdf=out/'Visa與Mastercard代理支付_固定版面閱讀版.pdf'
c=canvas.Canvas(str(pdf),pagesize=(960,540),pageCompression=1)
c.setTitle('Visa and Mastercard Agentic Payments - 2026-11-19')
c.setAuthor('Research materials prepared for the user')
for s in slides:
    c.drawImage(ImageReader(str(out/f"投影片預覽/slide-{s['n']}.png")),0,0,width=960,height=540)
    c.showPage()
c.save()
reader=PdfReader(str(pdf))
assert len(reader.pages)==len(slides)==88

pptx=out/'Visa與Mastercard代理支付_完整教材_修訂版.pptx'
if not pptx.exists(): pptx=out/'Visa與Mastercard代理支付_完整教材.pptx'
ns={'a':'http://schemas.openxmlformats.org/drawingml/2006/main','p':'http://schemas.openxmlformats.org/presentationml/2006/main'}
with zipfile.ZipFile(pptx) as z:
    assert z.testzip() is None
    sp=[n for n in z.namelist() if __import__('re').fullmatch(r'ppt/slides/slide\d+\.xml',n)]
    np=[n for n in z.namelist() if __import__('re').fullmatch(r'ppt/notesSlides/notesSlide\d+\.xml',n)]
    assert len(sp)==len(np)==88,(len(sp),len(np))
    tables=sum(len(ET.fromstring(z.read(n)).findall('.//a:tbl',ns)) for n in sp)
    connectors=sum(len(ET.fromstring(z.read(n)).findall('.//p:cxnSp',ns)) for n in sp)
    for n in np:
        txt=''.join(ET.fromstring(z.read(n)).itertext())
        assert '來源與證據範圍' in txt,n
    assert tables>=40 and connectors>=30,(tables,connectors)

problems=[]
for n in range(1,89):
    lay=json.loads((out/f'投影片預覽/slide-{n}.layout.json').read_text(encoding='utf-8'))
    for el in lay['elements']:
        p=el.get('position',{})
        if p and (p['left'] < -1 or p['top'] < -1 or p['left']+p['width']>1281 or p['top']+p['height']>721): problems.append((n,el['id']))
assert not problems,problems

main=[s['n'] for s in slides if s['focus']]
short=[1,4,5,7,9,14,15,16,20,35,39,41,42,55,57,60,62,67,68,70]
readme=f'''# 簡報閱讀入口｜2026-11-19

這份完整教材共88頁，面向第一次接觸Visa與Mastercard代理支付、需要準備報告的讀者。資料截至2026-11-19。

## 先開哪個檔案

- [可編輯 PowerPoint]({pptx.name})：原生文字、表格、流程圖；每頁備忘稿含解釋與來源。修訂版已更正第15頁VARS名稱及功能；舊檔因正被開啟而保留。
- [固定版面 PDF](Visa與Mastercard代理支付_固定版面閱讀版.pdf)：使用已檢視的投影片影像，避免字型差異；文字不可選取，完整文字請讀講稿。
- [離線逐頁閱讀](index.html)：圖面、講稿與來源放在一起；可切換主線或搜尋。
- [逐頁內容與完整講稿](逐頁內容與完整講稿.md)：文字可搜尋、複製與繼續改寫。
- [官方來源與查核紀錄](官方來源與查核紀錄.md)：41項一手資料來源，以及2項本案材料。

## 報告路線

- **第一次／約20頁的選讀路線：** {'、'.join(map(str,short))}。實際時間依講述深度調整，不是保證時長。
- **較完整主線（33頁）：** {'、'.join(map(str,main))}。
- **深入學習：** 1–14基礎、15–34 Visa、35–56 Mastercard、57–70比較與銀行導入、71–78技術附錄、79–88來源索引。

## 理解範圍

涵蓋公開文件的主要流程與關鍵細節，不宣稱取得所有保密指南、費率或本行生產契約。VI為v0.1草案；臺灣驗證政策、正式API、撤銷、責任與可用範圍需合作窗口確認。案例不外推為市場全面可用。

VI的L1簽發角色已校正：Issuer簽署L1，Credential Provider提供錢包基礎設施。部分舊研究與概覽採簡化用語，請以本輪明確角色定義為準。

## 搬到其他電腦

複製本資料夾即可使用PPTX、PDF、Markdown與離線閱讀頁。若要同時保留原始會議及flow.html，請複製整個「代理支付」資料夾。2026-11-17舊封存包不包含本輪簡報。外部官方原文未完整鏡像，開來源網址仍需網路。

`簡報內容.json`保留完整結構化內容；`build_content.py`產生文字資料；`author_session.js`是Artifact Session版型來源，並非可在一般瀏覽器直接執行的程式。
'''
(out/'README_簡報使用方式.md').write_text(readme,encoding='utf-8')

cards=[]
for s in slides:
    refs=''.join(f'<li><a href="{html.escape(data["sources"][k]["url"],quote=True)}" target="_blank" rel="noopener">{html.escape(k+" "+data["sources"][k]["title"])}</a></li>' for k in s['refs'])
    notes=html.escape(s['notes']).replace('\n','<br>')
    title=html.escape(s['title'].replace('\n','：'))
    cards.append(f'<article id="s{s["n"]}" data-main="{str(s["focus"]).lower()}" data-search="{html.escape(s["title"]+s["notes"],quote=True)}"><h2>{s["n"]:02d}｜{title}</h2><p class="meta">{html.escape(s["chapter"])} · {html.escape(s["tag"])}'+(' · 主線' if s['focus'] else '')+f'</p><img loading="lazy" src="投影片預覽/slide-{s["n"]}.png" alt="{title}"><details><summary>講者備忘稿與來源</summary><p>{notes}</p><ul>{refs}</ul></details></article>')
page='''<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Visa與Mastercard代理支付完整教材</title><style>
body{margin:0;background:#f2f5f7;color:#17384c;font:18px/1.8 'Microsoft JhengHei','Noto Sans TC',sans-serif}header,main{max-width:1160px;margin:auto;padding:24px}header p{max-width:1000px}nav{position:sticky;top:0;background:#17384c;color:white;padding:12px 24px;z-index:1;display:flex;gap:20px;align-items:center;flex-wrap:wrap}input[type=search]{font:inherit;width:min(70vw,560px);padding:6px 12px}article{background:white;margin:24px 0 50px;padding:24px;border-bottom:2px solid #cedae0}h1{font-size:36px;line-height:1.4}h2{font-size:26px;line-height:1.5;margin:0}img{width:100%;height:auto}details{padding:16px;background:#eef4f5}summary{cursor:pointer;font-weight:700}a{color:#006e80}.meta{color:#59717e;font-size:15px}[hidden]{display:none} @media print{nav{display:none}article{break-after:page;padding:0}details{display:none}}
</style><header><h1>Visa 與 Mastercard 代理支付完整教材</h1><p>88頁｜資料截至2026-11-19。流程、Token與憑證、驗證、風險、取消、銀行導入與案例。公開草案、正式產品能力與本案建議分開標示。</p><p><a href="Visa與Mastercard代理支付_完整教材.pptx">可編輯PowerPoint</a> · <a href="Visa與Mastercard代理支付_固定版面閱讀版.pdf">固定版面PDF</a> · <a href="逐頁內容與完整講稿.md">完整講稿</a> · <a href="官方來源與查核紀錄.md">來源紀錄</a></p></header><nav><input id="search" type="search" placeholder="搜尋名詞、流程或問題"><label><input id="main" type="checkbox">只看33頁主線</label><span id="count"></span></nav><main>'''+''.join(cards)+'''</main><script>const q=document.querySelector('#search'),m=document.querySelector('#main'),cards=[...document.querySelectorAll('article')];function filter(){let n=0;for(const a of cards){const show=(!m.checked||a.dataset.main==='true')&&a.dataset.search.toLowerCase().includes(q.value.toLowerCase());a.hidden=!show;if(show)n++}document.querySelector('#count').textContent=`顯示 ${n} / 88 頁`}q.addEventListener('input',filter);m.addEventListener('change',filter);filter();</script></html>'''
page=page.replace('href="Visa與Mastercard代理支付_完整教材.pptx"',f'href="{pptx.name}"')
(out/'index.html').write_text(page,encoding='utf-8')

report={'slides':88,'notesSlides':88,'nativeTables':tables,'nativeConnectors':connectors,'pdfPages':len(reader.pages),'sessionRenderedEverySlide':True,'visualReview':'88 pages reviewed individually; changed pages re-rendered and reviewed','geometryBoundsIssues':problems,'scope':'Session rendering and package checks; not opened in PowerPoint'}
(out/'投影片預覽/檢查紀錄.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
