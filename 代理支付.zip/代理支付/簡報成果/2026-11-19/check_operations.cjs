const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {pathToFileURL,fileURLToPath}=require('node:url');
const {launchBrowser}=require('../../研究成果/browser_runtime.cjs');
(async()=>{
 const browser=await launchBrowser(),page=await browser.newPage({viewport:{width:1500,height:950}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 const root=path.resolve(__dirname,'../..'),speech=path.join(__dirname,'十個檢核點白話講稿_小樹購版.html');
 await page.goto(pathToFileURL(speech).href);
 assert.equal(await page.locator('.organization-walkthrough').count(),10);
 await page.locator('#point-A .learning').evaluate(el=>el.open=true);
 const a=await page.locator('#point-A .organization-walkthrough').innerText();
 for(const term of ['Agentic Token','E2','DTVC','發卡','本行','完整Agent Pay API'])assert.ok(a.includes(term),term);
 const broken=await page.locator('a[href]').evaluateAll(els=>els.map(e=>e.href).filter(s=>s.startsWith('file:')));
 assert.deepEqual(broken.filter(s=>!fs.existsSync(fileURLToPath(s))),[]);
 await page.locator('#point-A .organization-walkthrough').scrollIntoViewIfNeeded();
 await page.screenshot({path:path.join(__dirname,'小樹購講稿_操作詳解預覽.png')});
 const data=JSON.parse(fs.readFileSync(path.join(__dirname,'小樹購檢核講稿.json'),'utf8'));
 await page.goto(pathToFileURL(path.join(root,'流程檢核點.html')).href);
 for(const p of data.points){
  await page.locator(`#screen-panel [data-home-check="${p.id}"]`).click();
  await page.locator('#screen-panel [data-advice-tab="reference"]').click();
  const text=await page.locator('#screen-panel [data-advice-view="reference"]').innerText();
  for(const s of [...p.organization_walkthrough.visa,...p.organization_walkthrough.master,p.organization_walkthrough.bank,p.organization_walkthrough.gap])assert.ok(text.includes(s),p.id);
 }
 assert.equal(await page.locator('.home-tools').count(),0);
 await page.locator('#screen-panel [data-home-check="A"]').click();
 await page.screenshot({path:path.join(__dirname,'流程檢核點_操作詳解預覽.png')});
 for(const file of [speech,path.join(root,'流程檢核點.html')]){
  await page.setViewportSize({width:390,height:844});await page.goto(pathToFileURL(file).href);
  assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'mobile overflow');
 }
 assert.deepEqual(errors,[]);
 fs.writeFileSync(path.join(__dirname,'操作詳解檢查紀錄.json'),JSON.stringify({checkpoints:10,speechAndDiagramMatch:true,localLinksExist:true,mobileOverflow:false,browserErrors:errors,originalAFDataPreserved:true},null,2));
 console.log('PASS: all 10 operation walkthroughs match; local links, desktop/mobile layout, removed toolbar and browser errors checked.');
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
