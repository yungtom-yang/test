from pathlib import Path
import json,re

root=Path(__file__).resolve().parents[2]
folder=root/'參考資料/flow首頁檢核改寫_2026-11-19'
target=root/'流程檢核點.html'
if not target.exists():target=root/'flow.html'
backup=folder/'flow_操作詳解修訂前備份_2026-11-19.html'
if not backup.exists():backup.write_bytes(target.read_bytes())
text=target.read_text(encoding='utf8')
pattern=r'const pages=(.*?);\s*const roles='
m=re.search(pattern,text,re.S)
pages=json.loads(m.group(1))
prior=json.dumps(pages[1:],ensure_ascii=False)
speech=json.loads((root/'簡報成果/2026-11-19/小樹購檢核講稿.json').read_text(encoding='utf8'))
points={p['id']:p for p in speech['points']}
for c in pages[0]['checks']:c['organization_walkthrough']=points[c['id']]['organization_walkthrough']
serialized=json.dumps(pages,ensure_ascii=False).replace('</','<\\/')
text=text[:m.start(1)]+serialized+text[m.end(1):]
panel=(folder/'home_panel.js').read_text(encoding='utf8')
text=re.sub(r'function homeDetail\(id\)\{.*?(?=function homeAdviceView)',lambda _:panel[panel.index('function homeDetail'):panel.index('function homeAdviceView')],text,count=1,flags=re.S)
text=text.replace('</style>','.home-reference ol{padding-left:22px;font-size:15px;line-height:1.8}.home-reference li{margin:0 0 12px}</style>',1)
assert json.dumps(json.loads(re.search(pattern,text,re.S).group(1))[1:],ensure_ascii=False)==prior
target.write_text(text,encoding='utf8')
# Resolve the diagram link to the current file name without creating a second copy.
builder=root/'簡報成果/2026-11-19/build_plain_speech.py'
s=builder.read_text(encoding='utf8').replace('href="../../flow.html"','href="../../'+target.name+'"')
builder.write_text(s,encoding='utf8')
readme=root/'README_先讀我.md'
s=readme.read_text(encoding='utf8').replace('](flow.html)',']('+target.name+')')
readme.write_text(s,encoding='utf8')
print(json.dumps({'checkpoints':len(points),'target':target.name,'backup':backup.name,'original_AF_preserved':True},ensure_ascii=False))
