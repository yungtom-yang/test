"""Build or verify the portable research package using Python's standard library."""
from pathlib import Path
from urllib.parse import unquote, urlsplit
from html.parser import HTMLParser
import argparse, hashlib, json, re, sys, zipfile
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
CHECK=ROOT/'移轉檢查'
MANIFEST=CHECK/'檔案清單.json'
ARCHIVE=ROOT/'搬遷封存'/'代理支付交接包_2026-11-17.zip'
SKIP={'搬遷封存','.git','.codex','.agents','.aws','node_modules','__pycache__','.venv'}
PREFIX='代理支付交接包/'

def payload():
    return sorted((p for p in ROOT.rglob('*') if p.is_file() and not any(s in SKIP for s in p.relative_to(ROOT).parts) and p!=MANIFEST),key=lambda p:p.relative_to(ROOT).as_posix())
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def local_link(origin,target,issues):
    if '${' in target or target.startswith('#') or target.startswith('data:'):return
    u=urlsplit(target)
    if u.scheme or u.netloc:return
    raw=unquote(u.path)
    if not raw:return
    dest=(origin.parent/raw).resolve()
    if not dest.exists():issues.append(f'{origin.relative_to(ROOT)} -> {target}')
class Links(HTMLParser):
    def __init__(self,p,issues):super().__init__();self.p=p;self.issues=issues
    def handle_starttag(self,tag,attrs):
        for k,v in attrs:
            if k in ('href','src') and v:local_link(self.p,v,self.issues)

def check_content(files):
    issues=[];types={};json_count=svg_count=drawio_pages=0
    for p in files:
        ext=p.suffix.lower();types[ext]=types.get(ext,0)+1
        if ext=='.md':
            text=p.read_text(encoding='utf-8-sig')
            for t in re.findall(r'\]\(([^)]+)\)',text):local_link(p,t.strip('<>'),issues)
        elif ext=='.html':Links(p,issues).feed(p.read_text(encoding='utf-8-sig'))
        elif ext=='.json':json.loads(p.read_text(encoding='utf-8-sig'));json_count+=1
        elif ext=='.svg':ET.parse(p);svg_count+=1
        elif ext=='.drawio':drawio_pages+=len(ET.parse(p).getroot().findall('diagram'))
    if issues:raise RuntimeError('Broken local links:\n'+'\n'.join(issues))
    required=['flow.html','1111代理支付研究會議逐字稿.txt','1111代理支付研究會議紀錄.md','交接文件.md','README_先讀我.md','參考資料/會議版方塊圖參考.png','代理支付官方研究/06_VIC與AgentPay能否取代自建功能.md','研究成果/flow-research.html','研究成果/架構圖/代理支付整體架構.drawio']
    for x in required:
        if not (ROOT/x).is_file():raise RuntimeError('Missing required file: '+x)
    if svg_count!=24 or drawio_pages!=3:raise RuntimeError(f'Unexpected diagram counts: {svg_count} SVG, {drawio_pages} Draw.io pages')
    return dict(fileTypes=types,svgDiagrams=svg_count,drawioPages=drawio_pages,validJsonFiles=json_count,brokenLocalLinks=0)

def verify():
    m=json.loads(MANIFEST.read_text(encoding='utf8'));bad=[]
    for x in m['files']:
        p=ROOT/x['path']
        if not p.is_file() or p.stat().st_size!=x['bytes'] or digest(p)!=x['sha256']:bad.append(x['path'])
    listed={x['path'] for x in m['files']}
    extra=[p.relative_to(ROOT).as_posix() for p in payload() if p.relative_to(ROOT).as_posix() not in listed]
    if bad or extra:raise RuntimeError(json.dumps(dict(changedOrMissing=bad,unlisted=extra),ensure_ascii=False))
    print(f'PASS: {len(m["files"])} files match the SHA-256 manifest; no unlisted payload files.')

def build():
    CHECK.mkdir(exist_ok=True)
    checked=check_content(payload())
    report='''# 搬遷檢查報告

整理日期：2026-11-17。

- 原始文件、更新會議紀錄、官方研究及最新功能查核已包含。
- 使用者原本位於暫存路徑的參考圖已複製至`參考資料/`。
- 共24張SVG：21張階段／概覽流程與3張整體架構；Draw.io共3頁。
- HTML與Markdown靜態本地連結已檢查，無缺檔。
- JSON及SVG／Draw.io XML已解析。
- 頁面42種狀態、手機寬度、3張架構圖與切換曾在本機瀏覽器檢查；相關結果見`研究成果/檢查紀錄.json`。
- 瀏覽器腳本已改為可攜式模組及瀏覽器尋找，不再硬編碼本機Codex安裝路徑。

本輪封存由`打包與驗證.py`產生，會逐項比對ZIP與檔案清單SHA-256後才回報成功。

清單不包含自身，以避免自我雜湊循環；ZIP另含清單檔。舊封存、node_modules、版本庫及工具設定不打包。

僅閱讀成果不需Python／Node／Playwright。官方頁面及完整API並未離線鏡像，也未進行實際付款測試。
'''
    (CHECK/'檢查報告.md').write_text(report,encoding='utf8')
    files=payload();checked=check_content(files)
    m=dict(createdDate='2026-11-17',timezone='Asia/Taipei',algorithm='SHA-256',manifestExcludesItself=True,checks=checked,files=[dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,sha256=digest(p)) for p in files])
    MANIFEST.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    ARCHIVE.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(ARCHIVE,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files+[MANIFEST]:z.write(p,PREFIX+p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(ARCHIVE) as z:
        if z.testzip():raise RuntimeError('ZIP CRC validation failed')
        if len(z.namelist())!=len(files)+1:raise RuntimeError('ZIP entry count mismatch')
        for x in m['files']:
            b=z.read(PREFIX+x['path'])
            if hashlib.sha256(b).hexdigest()!=x['sha256']:raise RuntimeError('ZIP content mismatch: '+x['path'])
        if z.read(PREFIX+MANIFEST.relative_to(ROOT).as_posix())!=MANIFEST.read_bytes():raise RuntimeError('ZIP manifest mismatch')
    verify()
    print(json.dumps(dict(archive=ARCHIVE.relative_to(ROOT).as_posix(),archiveBytes=ARCHIVE.stat().st_size,payloadFiles=len(files),archiveEntries=len(files)+1,zipContentHashesVerified=True,checks=checked),ensure_ascii=False,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--verify',action='store_true');args=ap.parse_args()
    try:verify() if args.verify else build()
    except Exception as exc:print('FAILED:',exc,file=sys.stderr);sys.exit(1)
