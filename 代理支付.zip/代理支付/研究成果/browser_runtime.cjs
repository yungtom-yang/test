// Portable helper: use local Playwright, or an explicitly configured module.
const fs=require('node:fs');
const path=require('node:path');
async function launchBrowser(){
 let chromium;
 try {({chromium}=require(process.env.PLAYWRIGHT_MODULE_PATH||'playwright'));}
 catch {throw new Error('找不到 Playwright。請在研究成果執行 npm install，或設定 PLAYWRIGHT_MODULE_PATH。');}
 const configured=process.env.BROWSER_EXECUTABLE_PATH;
 if(configured)return chromium.launch({executablePath:configured,headless:true});
 if(process.platform==='win32'){
  const bases=[process.env.ProgramFiles,process.env['ProgramFiles(x86)'],process.env.LOCALAPPDATA].filter(Boolean);
  for(const base of bases){
   for(const suffix of ['Google/Chrome/Application/chrome.exe','Microsoft/Edge/Application/msedge.exe']){
    const candidate=path.join(base,suffix);
    if(fs.existsSync(candidate))return chromium.launch({executablePath:candidate,headless:true});
   }
  }
 }
 return chromium.launch({headless:true});
}
module.exports={launchBrowser};
