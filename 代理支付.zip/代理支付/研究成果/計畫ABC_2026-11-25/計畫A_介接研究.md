# 計畫 A｜從小樹購接到外部商戶與卡組織

2026-11-25｜研究與詢證稿

**首家外部商戶建議由本行直接談商務 API，同時找卡組織及獲准合作方確認付款路徑。** 如果主車商與備援有既有整合平台，且平台能提供可成交報價、建單與查單，可改由平台提供商務接口。銀行可以請 Visa／Mastercard 引介合作商戶或商務平台，但是否能靠一家卡組織接齊所需商戶，要看具名覆蓋、區域、商戶授權與實際交付範圍。不應把「能刷這張卡」當成「Agent 能替客戶下這張單」。

## 同一筆訂單有兩條線

| 問題 | 商務線 | 付款線 |
|---|---|---|
| 本行要拿到什麼？ | 可成交報價、時間或庫存、條款、結帳版本、建單和查單結果 | 適用的驗身、受理的付款憑證、授權結果和付款參照 |
| 從哪裡取得？ | 商戶直接提供，或授權整合平台提供 | 卡組織方案直連或由獲准合作方代接。商戶的 PSP／收單方送授權 |
| 誰能確認或攔？ | 商戶確認供應、價錢及接單；本行控管服務核對委任、報價與逐筆核准，條件不符即停止 | 憑證服務檢查適用條件，收單方與卡網處理各自檢核，本行若為發卡端依既有及適用條件決策。每站可攔什麼要以介接證據確認 |
| 共用識別 | 本行任務 ID 連到委任版本、結帳版本、核准 ID、商戶訂單號 | 同一任務連到可查詢的付款參照及授權狀態。回傳事件須可用原始識別碼回查 |

商務與付款可以由同一合作方提供，驗收時仍逐項核對兩條線。模型只提出操作，受控服務確認交易版本、授權與重送狀態，再呼叫有權限的工具。

可先找目前接送服務的主車商，另以 Skymove 公告的 API／白標方案作為備援詢證線索。要求兩邊示範同一筆「舊單確認不可接、新單含費報價、付款後查回訂單」的流程。卡組織窗口可同時協助確認是否有既有整合方和可用收單路徑。[Skymove 通路合作](https://forbusiness.skymove.co/channel-cooperation/)

## 三條商務介接路徑

| 路徑 | 誰找商戶、誰提供 API | 下單、付款、查單 | 條件與用途 |
|---|---|---|---|
| **1. 本行直連** | 本行洽定一主一備，與各車商簽訂資料和 API 使用範圍。車商提供報價、保留或下單、查單與售後 | 本行 Agent 透過受控商戶工具操作；車商接單。用可受理憑證或經核可的既有結帳方式付款。付款由商戶 PSP／收單送出 | 首選詢證。能逐欄驗收，但逐家客製及維運有成本。若只提供搜尋或轉址，限於媒合 |
| **2. 卡組織商務整合** | 請 Visa／Mastercard 提供可引介的商戶及整合方，取得指定市場的具名覆蓋與接口清單 | Visa ICC 公開有目錄可發現性與支付協調；Mastercard Agent Connect 公開有商戶授權目錄、購物車與支付。下單、售後和接送所需欄位須逐家確認 | 有兩家以上目標商戶可用同標準、資料品質與收單路徑均通過時，才計入省下的擴接工作。[Visa ICC](https://corporate.visa.com/en/products/intelligent-commerce-connect.html) · [Mastercard Agent Connect](https://www.mastercard.com/global/en/business/artificial-intelligence/mastercard-agent-connect.html) |
| **3. 商務平台／支付夥伴** | 本行對接有供應的商務平台或具商務合作能力的支付夥伴。若支付方只接付款，商戶仍由本行或平台取得 | 平台可統一報價、下單及查單的程度依契約；付款可由適用 PSP 或卡組織合作方接。確認底層車商及每筆費用、退款單、責任人與事件格式 | 若同時涵蓋一主一備，且能回查終局結果，可優先於雙邊客製。Booking.com 的公開接送 Beta 是搜尋後轉址的反例；香港案則有具名 Agent 與交通平台，顯示角色可由不同公司承擔。[Booking.com 接送 Beta](https://developers.booking.com/demand/docs/transfers/search-transfers) · [Mastercard 香港案例](https://www.mastercard.com/hk/en/news-and-trends/press/2026/march/mastercard-first-live-agentic-transaction-hk.html) |

## Visa／Mastercard 放在哪一步

| 原流程 | Visa | Mastercard | 本行的工作 |
|---|---|---|---|
| P–A 註冊與卡片 | VARS 管理代理註冊，VTS 處理適用卡片代碼化，VPP 用於適用持卡人驗證。VIC 直連或經 Agent Enabler | 受理框架描述代理註冊及 Agentic Token。正式角色與配發介面需向組織取得 | 保持工具身分、卡片參照及權限控管。把發卡參與、Agent Provider 資格及授權的工具分開詢證 |
| B–C 送委任、查外部商戶 | TAP 供接收方辨識代理請求，ICC 是另一段商務整合入口 | Web Bot Auth 供採用方辨識代理請求，Agent Connect 是商務與支付連接入口 | 本行管理選購委任。可信商品、運能、含費報價和取消條款由商戶或授權平台回傳 |
| D–E 比對、核准與付款準備 | 本行先核對；VIC 取得付款憑證時依適用的購買指示與限制檢查，回傳適用的代碼化付款資料 | Agent Pay 公開框架描述 Agentic Token 與動態驗證資料；若採用 VI Immediate，可用客戶最終確認的可驗證證據，依適用實作 | 將核准綁定明細版本、商戶、幣別和總額。由安全層交付憑證。向窗口確認 API 結帳是否受支援，以及憑證交付後金額或商戶變更時誰能攔 |
| F 送授權及回報 | VIC 有結果回報及指示取消；發出憑證後的效力依規格 | Agent Pay 走適用受理與交易路徑；正式事件、撤回和爭議介面待確認 | 商戶透過 PSP／收單送授權，拿到商戶訂單號才可宣告成立。EPOS／PH 參與依實際角色與金流決定 |

官方公開資料支持產品定位和範例流程。本行在臺灣的卡片、商戶、正式資格與欄位仍需確認。星展臺灣案例證明逐筆協助預訂與支付可做出一筆交易，接送「舊單失效後跨車商補位」仍要另行驗證。國泰世華出現在 Visa 亞太發卡試點名單，可以由既有窗口確認是否可擴及本行經營 Agent 的角色。[VIC 工作流](https://developer.visa.com/docs/visa-intelligent-commerce/workflows) · [VIC 角色與接入](https://developer.visa.com/docs/visa-intelligent-commerce) · [Visa TAP](https://developer.visa.com/docs/trusted-agent-protocol/trusted-agent-protocol-specifications) · [Mastercard 受理框架](https://www.mastercard.com/global/en/news-and-trends/stories/2025/agentic-commerce-framework.html) · [VI 公開規格](https://www.verifiableintent.dev/spec/) · [星展臺灣案例](https://www.mastercard.com/tw/zh/news-and-trends/press/2026/march/first-agentic-transaction-in-taiwan.html) · [Visa 亞太發卡試點](https://www.visa.com.sg/about-visa/newsroom/press-releases/visa-launches-agentic-ready-program-in-asia-pacific-with-over-50-partners-advancing-agentic-commerce.html)

## 走查與驗收

1. **小樹購咖啡機**。客戶同意選購條件，本行 Agent 用商戶工具取得可信型號、庫存及含運價格，比對後交客戶核准。商戶回訂單號，付款結果另寫入。同一套委任、比對、核准與查單骨架可帶到外部；平台 API、支付與配送細節仍須確認。
2. **機場接送補位**。主車商確認舊單無法執行，受控工具查待退款和備援車型、時段及總價。客戶核准可成交的版本；安全付款服務交付適用憑證，由備援商戶送授權。付款核准後查到新訂單才通知成立，另追蹤舊單退款及派車。
3. **核准後漲價**。本行若在交付憑證前看見改價，立即停止並重新取得核准。交付後改價需由商戶、收單或卡組織提供可驗證的拒絕證據；在正式測試前只列為待確認能力。
4. **授權核准但未接單**。保存兩邊參照，查原交易與原單，交當班人員判斷撤銷、退款或重查。狀態未明時禁止無條件重送或重叫車。

完成第一家後，以相同操作清單詢第二家。能沿用報價、結帳、狀態事件與取消退款接口，才把共用介接的效益納入擴展計畫。

## 窗口詢證清單

| 窗口 | 要拿到的證據 | 會改變什麼 |
|---|---|---|
| 小樹購與行內金流 | SKU、含運試算、效期、庫存與配送、建單查單樣本；EPOS／PH 和適用 3DS 的實際路由 | POC 可從選購做到哪一步，哪些接口能沿用 |
| 一主一備車商 | 兩家共同提供報價、建單、查單、派車和售後樣本；報價時效、重送去重、舊單退款狀態 | 能否做端到端補位，何時應轉人工 |
| 商務平台／PSP／收單 | 具名商戶、可用地區、API 和責任表。證明本案憑證可在指定結帳欄位送出，逾時可查回 | 直連或平台代接，是否需要另找支付方 |
| Visa／Mastercard | 臺灣角色、卡別與商戶名單、直連與代接方案、正式測試介面。拿一筆改價或換商戶的拒絕樣本，逐站辨識誰驗什麼 | 決定認證、付費能力、憑證送件方式和實際風控邊界 |
| 行內風控及客服 | 放行、停止、在途查詢、撤銷退款、客服升級與稽核調閱責任。確認誰可用關聯識別查兩邊 | 決定試點可用範圍和恢復條件 |

本次走查是研究設計核對。未取得生產資格、未測試實際商戶 API 或支付。
