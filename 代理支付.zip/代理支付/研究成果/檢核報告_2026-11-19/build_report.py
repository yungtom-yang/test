from pathlib import Path
import json

ROOT=Path(__file__).resolve().parent
source=json.loads((ROOT.parent/'架構圖/檢核註記版/註記內容.json').read_text(encoding='utf8'))
# The report condenses existing, sourced control notes. Supplementary bank modules
# and responsibilities are proposals, not claims about implemented bank systems.
EXTRA={
'P': dict(name='代理身分與服務權限',phase='前置',question='來操作的是誰？',bankShort='登錄服務身分、金鑰與可用操作',visaShort='VARS＋VIC驗證代理來源',mcShort='註冊並驗證Agent',modules=['服務身分／金鑰管理','工具權限控管'],owner='銀行服務管理者配置；工具執行層與平台各自檢查自己的存取邊界。',check='服務身分、可信金鑰、請求來源與可用操作。模型產生的文字不能自行授予權限。',evidence='服務身分、金鑰識別、操作權限設定與呼叫紀錄。',talk='第一道先處理Agent是誰、可以使用哪些工具。參照Visa的VARS與Mastercard的代理註冊概念，本行可建立服務身分及權限管理；這還沒有證明客戶同意買東西。'),
'A': dict(name='卡片與安全付款參照',phase='前置',question='付款資料由誰保管？',bankShort='卡片留安全環境，Agent用受控參照',visaShort='VTS代碼化；VPP適用驗證',mcShort='Agentic Token；VI L1另綁身分',modules=['既有安全卡片保管','付款方式參照'],owner='既有付款／卡片保管服務處理；本行與平台先確認可沿用的關聯及介面。',check='客戶與付款方式關聯、卡片資格、適用驗證及資料可用範圍。',evidence='安全卡片參照、驗證紀錄及卡片／憑證狀態；模型不取得卡號或私鑰。',talk='這裡借鏡兩家把付款憑證與Agent分開處理的方式。本行先盤點既有安全保管與卡片參照能否沿用；自建參照不等於外部網路可受理的支付Token。'),
'B': dict(name='選購委任與確認證據',phase='B',question='客戶交代了什麼？',bankShort='保存條件、版本、期限與確認',visaShort='Purchase Instruction／Mandate',mcShort='VI區分最終確認與自主委任',modules=['委任／版本管理','客戶確認證據'],owner='客戶在安全入口確認；委任服務保存並提供有效版本。',check='指示來自哪個客戶、確認的條件與版本、有效期限，以及允許執行到哪一步。',evidence='原始需求、確認後的條件、客戶關聯、版本、狀態及確認時間。',talk='我們把搜尋與選購的委任先保存，讓Agent有明確邊界。但這版保留客戶最後核准，因此這筆選購委任不能直接當成Visa付款指示或VI自主模式的付款授權。'),
'C1': dict(name='平台驗證Agent請求',phase='C',question='平台為什麼接受這個請求？',bankShort='平台驗來源、權限與適用防重播',visaShort='TAP代理辨識簽章',mcShort='Web Bot Auth辨識Agent',modules=['API／請求驗證閘道','服務驗證與權限規則'],owner='平台或其網站防護服務驗Agent請求；本行工具層另外限制可發出的操作。',check='簽章或服務驗證、可信金鑰、請求對象與用途；效期及防重播須依採用機制設計。',evidence='服務／金鑰識別、請求識別、驗證結果、時間與操作紀錄。',talk='Agent開始查商品時就有檢核。Visa的TAP讓商戶驗代理請求，Mastercard框架使用Web Bot Auth。本行與小樹購可以評估既有API驗證或請求簽章；驗到可信Agent還不等於已核准付款。'),
'C2': dict(name='客戶辨識與資料存取',phase='C',question='它可以讀這位客戶的資料嗎？',bankShort='另查會員關聯與私人資料授權',visaShort='TAP Consumer Recognition',mcShort='受理框架的Consumer Identity',modules=['帳戶連結','客戶資料存取授權'],owner='平台確認客戶帳戶及授權；銀行入口取得所需同意並傳遞適用識別。',check='資料屬於哪位客戶，以及Agent能否讀取購物車、地址等指定資料。',evidence='帳戶關聯、授權範圍與效期、存取及撤回紀錄。',talk='Agent身分驗過後，仍要分開確認它在替誰服務，以及能讀哪些私人資料。TAP的客戶辨識與Mastercard的Consumer Identity可作參考，但辨識到人不等於取得全部資料權限。'),
'C3': dict(name='可信商品與結帳明細',phase='C',question='要買的內容有可信依據嗎？',bankShort='取得實際商品、賣方與含運總額',visaShort='TAP保護請求；交易仍須核對',mcShort='VI草案的商戶簽署checkout JWT',modules=['平台商品／結帳介面','可信明細及版本管理'],owner='平台提供商品／結帳資料；受控服務記錄來源並確認明細適用範圍。',check='商品、賣方、規格、數量、幣別、含運總額、資料時間及是否可能已形成正式訂單。',evidence='平台來源、結帳參照、完整明細及版本；若採簽章，再保存驗簽證據。',talk='推薦商品頁上的價格還不足以付款，我們要取得實際結帳內容。VI草案用商戶簽署的checkout JWT表達結帳資料，值得參考；但簽章或購物車都不保證平台已鎖價、保留庫存。'),
'D': dict(name='交易符合委任的檢查',phase='D',question='實際交易符合客戶要求嗎？',bankShort='受控規則比對委任與結帳明細',visaShort='取憑證前由Agent Provider核對',mcShort='VI自主模式驗限制；Immediate驗最終值',modules=['交易規則／比對能力','獨立取得可信資料'],owner='本行或合作服務的受控規則執行；不只接受Agent自行宣稱「符合」。',check='商品、賣方、數量、總額、期限及委任版本。偏好需另有判斷依據。',evidence='委任版本、結帳版本、逐項比對結果與決策理由。',talk='這是具體交易的符合性關卡。Visa要求Agent Provider在請求付款憑證前核對指示；VI自主模式另有L2限制與L3結果的驗證。本版採最後確認，不能把自主驗證流程原封套入。'),
'E1': dict(name='客戶核准具體交易',phase='E',question='客戶核准的就是這筆嗎？',bankShort='核准商品、賣方及總額並綁證據',visaShort='審閱交易並同意釋出Token',mcShort='VI Immediate L2＋checkout_hash',modules=['交易核准介面','核准內容綁定／驗證證據'],owner='客戶在安全介面核准；核准服務保存內容，執行系統核對一致性。',check='核准者、具體商品／賣方／總額、交易識別及效期；執行內容是否仍相同。',evidence='完整核准明細、交易參照、適用驗證證據與時間；關鍵內容變更重取核准。',talk='Agent已完成選購與準備，客戶此時核准具體交易。Visa要求適用的審閱與釋出Token同意；VI Immediate則把最終值簽進L2。確認購買、驗證身分與付款授權，仍是不同目的。'),
'E2': dict(name='受控付款與執行狀態',phase='E',question='能安全執行且避免重複嗎？',bankShort='重查核准、版本、效期與執行狀態',visaShort='VIC有效指示下取得付款憑證',mcShort='Agentic Token＋既有付款授權',modules=['購買執行／防重複控制','安全付款整合'],owner='購買執行與安全付款服務處理；實際交易仍由適用收單、網路及發卡行授權。',check='核准是否有效、明細是否變動、是否已執行、適用付款驗證及憑證狀態。',evidence='委任／核准／訂單／付款識別、執行狀態與付款結果；結果不明先查原交易。',talk='取得付款憑證還不代表發卡行核准，也不代表訂單成立。本行要在執行前重查核准及狀態，管理重複呼叫；付款結果不明時先查原交易，不能直接再買一次。'),
'F': dict(name='結果、取消與追蹤',phase='F',question='到底完成到哪裡？',bankShort='分開追蹤付款、接單及履約',visaShort='VIC交易事件回報與指示取消',mcShort='意圖證據可追查；退款另行處理',modules=['結果查詢／異常補償','交易證據與通知'],owner='平台提供訂單事實、付款服務提供交易結果；本行協調狀態與通知，責任待分工。',check='付款、接單、請款及出貨各自狀態，以及取消對進行中交易的實際效力。',evidence='全程關聯識別、狀態時間軸、取消／撤銷／退款處理與客戶通知。',talk='最後不能只記一個成功。Visa有交易事件回報與取消流程；VI主要處理證據，沒有包辦退款或爭議。本行仍要串起付款、訂單及後續處理，才能向客戶說明真實進度。'),
}
for c in source['controls']:
    c.update(EXTRA[c['id']])
    c['title']=c['name']
data={'controls':source['controls'],'sources':source['sources'],'date':'2026-11-19'}
template=(ROOT/'report.template.html').read_text(encoding='utf8')
result=template.replace('__REPORT_DATA__',json.dumps(data,ensure_ascii=False).replace('</','<\\/'))
(ROOT/'index.html').write_text(result,encoding='utf8')
print('Built self-contained report HTML: 10 control points, no external assets.')
