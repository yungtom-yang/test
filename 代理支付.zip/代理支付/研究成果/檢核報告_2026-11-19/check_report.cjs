const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {launchBrowser}=require('../browser_runtime.cjs');
(async()=>{
 const browser=await launchBrowser();
 const page=await browser.newPage({viewport:{width:1600,height:1000},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 const file=pathToFileURL(path.join(__dirname,'index.html')).href;
 await page.goto(file);
 const ids=await page.locator('tr[data-point]').evaluateAll(rows=>rows.map(r=>r.dataset.point));
 const checked=[];
 for(const id of ids){
  await page.locator(`button[data-select="${id}"]`).click();
  if(!await page.locator(`tr[data-point="${id}"]`).evaluate(e=>e.classList.contains('active')))throw Error('Selection failed '+id);
  const body=await page.locator('#detail-body').innerText();
  if(!body.includes('Visa 做了什麼')||!body.includes('Mastercard 做了什麼'))throw Error('Missing network comparison '+id);
  await page.locator('.check-details summary').click();
  if(!await page.locator('.check-details').evaluate(e=>e.open))throw Error('Missing details '+id);
  checked.push(id);
 }
 await page.locator('[data-stage="C1"]').click();
 await page.locator('#next').click();
 if(!await page.locator('#point-tag').innerText().then(t=>t.startsWith('C2')))throw Error('Next failed');
 await page.keyboard.press('ArrowLeft');
 if(!await page.locator('#point-tag').innerText().then(t=>t.startsWith('C1')))throw Error('Keyboard failed');
 await page.locator('#sources').click();
 if(await page.locator('dialog[open] a').count()<10)throw Error('Missing sources');
 await page.locator('#close-sources').click();
 const sizes=[];
 for(const [width,height] of [[1600,1000],[1440,900],[1366,768],[390,844]]){
  await page.setViewportSize({width,height});
  const layout=await page.evaluate(()=>{
   const sc=document.querySelector('.matrix-scroll'),last=document.querySelector('tbody tr:last-child');
   const frame=sc.getBoundingClientRect(),bottom=last.getBoundingClientRect();
   return {pageOverflow:document.documentElement.scrollWidth>window.innerWidth+1,tableAllVisible:bottom.bottom<=frame.bottom+1&&bottom.bottom<=window.innerHeight,frame:frame.height,content:sc.scrollHeight};
  });
  if(layout.pageOverflow)throw Error('Page overflow '+width);
  if(width===1440&&!layout.tableAllVisible)throw Error('Overview not visible in one screen at 1440x900 '+JSON.stringify(layout));
  sizes.push({width,height,...layout});
 }
 await page.setViewportSize({width:1366,height:768});
 await page.locator('#presentation').click();
 const smallReport=await page.evaluate(()=>{const b=document.querySelector('tbody tr:last-child').getBoundingClientRect(),s=document.querySelector('.matrix-scroll').getBoundingClientRect();return b.bottom<=s.bottom+1&&b.bottom<=innerHeight});
 if(!smallReport)throw Error('Report mode overview not visible at 1366x768');
 await page.locator('#presentation').click();
 await page.setViewportSize({width:1600,height:1000});
 await page.locator('[data-stage="C1"]').click();
 await page.screenshot({path:path.join(__dirname,'報告頁預覽.png'),fullPage:true});
 await page.locator('#presentation').click();
 if(!await page.locator('body').evaluate(e=>e.classList.contains('presenting')))throw Error('Presentation mode failed');
 await page.locator('#next').click();
 await page.locator('#presentation').click();
 // Verify the downloaded HTML retains embedded data and works independently.
 const downloadPromise=page.waitForEvent('download');
 await page.locator('#download').click();
 const download=await downloadPromise;
 await download.saveAs(path.join(__dirname,'代理支付檢核報告.html'));
 await page.goto(pathToFileURL(path.join(__dirname,'代理支付檢核報告.html')).href);
 if(await page.locator('tr[data-point]').count()!==10)throw Error('Downloaded copy broken');
 if(await page.locator('script[src],link[rel=stylesheet],img').count())throw Error('External assets found');
 if(errors.length)throw Error(errors.join('\n'));
 const report={controls:checked,sizes,selection:'passed',details:'passed',sources:'passed',keyboard:'passed',presentationMode:'passed',reportModeAllPointsAt1366x768:smallReport,downloadedStandaloneHtml:'passed',externalAssets:0,pageErrors:errors};
 fs.writeFileSync(path.join(__dirname,'檢查紀錄.json'),JSON.stringify(report,null,2));
 console.log(JSON.stringify(report));
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
