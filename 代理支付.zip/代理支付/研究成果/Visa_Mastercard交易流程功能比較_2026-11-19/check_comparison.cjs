const fs=require('node:fs/promises');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
let playwright;
if(process.env.PLAYWRIGHT_MODULE_PATH)playwright=require(process.env.PLAYWRIGHT_MODULE_PATH);
else {try{playwright=require('playwright')}catch{playwright=require('C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1117-835-0_26.1117.835.0_x64__3k8sg7r9htsxt/dependencies/node/node_modules/playwright')}}
const {chromium}=playwright;
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.BROWSER_EXECUTABLE_PATH||'C:/Program Files/Google/Chrome/Application/chrome.exe'});
 const page=await browser.newPage({viewport:{width:2080,height:1100},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 const sizes=[];
 for(const name of ['比較圖','比較圖_上半部','比較圖_下半部']){
  const svg=(await fs.readFile(path.join(__dirname,name+'.svg'),'utf8')).replace(/<\?xml[^>]*\?>/,'');
  await page.setContent('<!doctype html><html><head><style>html,body{margin:0;padding:0}svg{display:block}</style></head><body>'+svg+'</body></html>');
  await page.evaluate(()=>document.fonts.ready);
  const size=await page.locator('svg').first().evaluate(e=>({w:+e.getAttribute('width'),h:+e.getAttribute('height')}));
  if(name==='比較圖'){
   const overflow=await page.evaluate(()=>Array.from(document.querySelectorAll('text')).flatMap(e=>{
    const b=e.getBBox(),x=+(e.dataset.cellX||0),y=+(e.dataset.cellY||0),w=+(e.dataset.cellW||2080),h=+(e.dataset.cellH||1e5);
    return b.x<x-1||b.x+b.width>x+w-9||b.y<y||b.y+b.height>y+h-7?[{text:e.textContent,bbox:[b.x,b.y,b.width,b.height],cell:[x,y,w,h]}]:[];
   }));
   if(overflow.length)throw Error('Text exceeds boundaries: '+JSON.stringify(overflow));
  }
  await page.screenshot({path:path.join(__dirname,name+'.png'),fullPage:true});
  const png=await fs.readFile(path.join(__dirname,name+'.png'));
  if(png.readUInt32BE(16)!==size.w||png.readUInt32BE(20)!==size.h)throw Error('PNG dimension mismatch '+name);
  sizes.push({name,...size});
 }
 await page.setViewportSize({width:1440,height:1000});
 await page.goto(pathToFileURL(path.join(__dirname,'index.html')).href);
 if(await page.locator('details').count()!==13)throw Error('Expected 13 functional stages');
 await page.locator('#expand').click();if(await page.locator('details[open]').count()!==13)throw Error('Expand failed');
 await page.locator('#collapse').click();if(await page.locator('details[open]').count()!==0)throw Error('Collapse failed');
 const localLinks=await page.locator('a[href]').evaluateAll(es=>es.map(e=>e.getAttribute('href')).filter(s=>!s.startsWith('http')));
 for(const url of new Set(localLinks))await fs.access(path.resolve(__dirname,decodeURIComponent(url)));
 await page.setViewportSize({width:390,height:844});
 if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1))throw Error('Mobile page overflow');
 await page.locator('details').nth(8).evaluate(e=>e.open=true);
 await page.locator('details').nth(8).scrollIntoViewIfNeeded();
 await page.screenshot({path:path.join(__dirname,'手機閱讀預覽.png')});
 await page.setViewportSize({width:1440,height:1000});await page.evaluate(()=>window.scrollTo(0,0));
 await page.screenshot({path:path.join(__dirname,'閱讀頁預覽.png')});
 const drawio=await fs.readFile(path.join(__dirname,'比較圖.drawio'),'utf8');
 if(!drawio.includes('mxGraphModel')||drawio.includes('data:image'))throw Error('Draw.io is not a native diagram');
 await page.goto(pathToFileURL(path.join(__dirname,'比較圖_純圖版.html')).href);
 const pure=await page.evaluate(()=>({svg:document.querySelectorAll('body>svg').length,controls:document.querySelectorAll('a,button,[href],[src],script,iframe').length,bodyChildren:document.body.children.length,diagramText:document.querySelector('svg').textContent}));
 if(pure.svg!==1||pure.controls!==0||pure.bodyChildren!==1)throw Error('Standalone HTML has extra elements');
 for(const term of ['ID&V','支付代碼','通行密鑰','數位簽章','清算'])if(!pure.diagramText.includes(term))throw Error('Missing explanation '+term);
 const data=JSON.parse(await fs.readFile(path.join(__dirname,'比較資料.json'),'utf8'));
 if(data.rows.length!==13||Object.keys(data.sources).length!==27)throw Error('Content/source mismatch');
 for(const r of data.rows){if(r.details.length<4||![r.visa_body,r.mastercard_body,r.boundary].every(s=>s.length>35))throw Error('Overly abbreviated row '+r.stage)}
 if(errors.length)throw Error(errors.join('\n'));
 const result={date:'2026-11-19',stages:13,phases:4,officialSources:27,images:sizes,svgTextFits:true,drawio:'native editable cells',htmlButtons:'passed',localLinks:'passed',mobilePageOverflow:false,standaloneHTML:'embedded diagram only; no links or controls',language:'full Chinese explanation with official service names',pageErrors:errors};
 await fs.writeFile(path.join(__dirname,'檢查紀錄.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
