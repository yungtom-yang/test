from pathlib import Path
from html import escape
import json, re, os, xml.etree.ElementTree as ET
from PIL import ImageFont

ROOT = Path(__file__).resolve().parent
DATE = '2026-11-19'
SOURCES = {'S01': ('Visa Intelligent Commerce：代理商務概念與控制', 'https://developer.visa.com/docs/visa-intelligent-commerce/concepts'),
 'S02': ('Visa Intelligent Commerce：代理商務操作流程', 'https://developer.visa.com/docs/visa-intelligent-commerce/workflows'),
 'S03': ('Visa Intelligent Commerce：正式環境參與條件', 'https://developer.visa.com/docs/visa-intelligent-commerce/production-readiness'),
 'S04': ('Visa Intelligent Commerce Connect', 'https://corporate.visa.com/en/products/intelligent-commerce-connect.html'),
 'S05': ('Visa Trusted Agent Protocol：可信助理請求協定規格',
         'https://developer.visa.com/docs/trusted-agent-protocol/trusted-agent-protocol-specifications'),
 'S06': ('Visa Token Service', 'https://developer.visa.com/capabilities/vts/overview'),
 'S07': ('Visa Token Service：卡片支付代碼發行與狀態管理', 'https://developer.visa.com/capabilities/token-service-provisioning/overview'),
 'S08': ('Visa Payment Passkey：開始使用', 'https://developer.visa.com/docs/visa-payment-passkey/docs-getting-started'),
 'S09': ('Visa Payment Passkey：產品條款', 'https://developer.visa.com/docs/visa-payment-passkey/product-terms'),
 'S10': ('Visa Click to Pay：結帳詞彙與持卡人驗證定義', 'https://developer.visa.com/docs/visa-secure-remote-commerce/docs-glossary'),
 'S11': ('Mastercard Agent Suite：企業客製人工智慧助理',
         'https://www.mastercard.com/us/en/news-and-trends/press/2026/january/mastercard-launches-agent-suite-to-ready-enterprises-for-a-new-e.html'),
 'S12': ('Mastercard Agent Connect',
         'https://www.mastercard.com/global/en/business/artificial-intelligence/mastercard-agent-connect.html'),
 'S13': ('Mastercard：商戶購物助理與連接服務',
         'https://www.mastercard.com/us/en/news-and-trends/press/2026/september/mastercard-gives-merchants-a-simpler-way-to-build--connect-and-s.html'),
 'S14': ('Mastercard Agent Pay Acceptance Framework：商戶接受框架',
         'https://www.mastercard.com/global/en/news-and-trends/stories/2025/agentic-commerce-framework.html'),
 'S15': ('Mastercard：代碼化服務',
         'https://www.mastercard.com/global/en/business/payments/consumer-payments/network-processing/tokenization.html'),
 'S16': ('Mastercard Payment Passkeys：臺灣上線說明',
         'https://www.mastercard.com/tw/zh/news-and-trends/press/2025/july/payment-passkeys-launch.html'),
 'S17': ('Verifiable Intent：可驗證意圖規格總覽，0.1版草案', 'https://verifiableintent.dev/spec/'),
 'S18': ('Verifiable Intent：可驗證意圖的限制條件', 'https://verifiableintent.dev/spec/constraints/'),
 'S19': ('Verifiable Intent：可驗證意圖的安全模型', 'https://verifiableintent.dev/spec/security-model/'),
 'S20': ('Mastercard Identity Check：商戶與收單端導入指南',
         'https://static.developer.mastercard.com/content/identity-check/uploads/files/mc_idc_onboard_guide_Acquirer.pdf'),
 'S21': ('EMVCo：通行密鑰與線上刷卡驗證的運用', 'https://www.emvco.com/news-publications/understanding-the-use-of-passkeys-in-payments/'),
 'S22': ('Mastercard：代理商務信任與風險資訊服務',
         'https://www.mastercard.com/us/en/news-and-trends/press/2026/september/new-trust-and-intelligence-services.html'),
 'S23': ('Visa Click to Pay：結帳與驗證使用情境', 'https://developer.visa.com/docs/visa-secure-remote-commerce/docs-use-cases'),
 'S24': ('Mastercard交易處理規則（查得版本；概念參考）',
         'https://www.mastercard.com/content/dam/mccom/shared/business/support/rules-pdfs/transaction-processing-rules.pdf'),
 'S25': ('Visa Rules：官方規則入口', 'https://usa.visa.com/support/consumer/visa-rules.html'),
 'S26': ('Mastercard：可驗證意圖與代理支付意圖介面', 'https://www.mastercard.com/global/en/news-and-trends/stories/2026/verifiable-intent.html'),
 'S27': ('Visa：持卡人確認、卡片設定與通行密鑰流程', 'https://developer.visa.com/docs/visa-intelligent-commerce/docs-getting-started')}


from plain_language_content import ROWS, TERMS, INTRO_NOTES
from document_outputs import build_notes, build_html, build_pure_html

FONT_PATH=os.environ.get('COMPARISON_FONT_PATH','C:/Windows/Fonts/msjh.ttc')
def font(size): return ImageFont.truetype(FONT_PATH,size)
def wrap(s,width,size):
 # Wrap Chinese by glyph, Latin by word, so service names remain readable.
 f=font(size); lines=[]
 for para in s.split('\n'):
  raw=re.findall(r'[A-Za-z0-9][A-Za-z0-9&./_-]*|\s+|.',para)
  tokens=[]
  for token in raw:
   if tokens and (token in '，。、；：！？）》」』】' or tokens[-1] in '（《「『【'):
    tokens[-1]+=token
   else:tokens.append(token)
  cur=''
  for token in tokens:
   if f.getlength(cur+token)>width and cur:
    lines.append(cur.rstrip());cur=token.lstrip()
   else: cur+=token
  if cur: lines.append(cur.rstrip())
 return lines

def xmltag(tag,attrs=None,parent=None,text=None):
 e=ET.SubElement(parent,tag,attrs or {}) if parent is not None else ET.Element(tag,attrs or {})
 if text is not None:e.text=text
 return e

W=2080; X=[40,320,900,1480]; CW=[280,580,580,560]
BODY=26; TITLE=28; LABEL=25; LH=39
PALETTE={'ink':'#14283c','muted':'#4a6075','line':'#c7d3df','visa':'#164d9b','mc':'#9b3d10'}

def cell_blocks(r):
 stage={'12 請款、清算與結算':'12 請款、清算\n與結算','13 停用、退款與爭議':'13 停用、退款\n與爭議'}.get(r['stage'],r['stage'])
 return [
  [(stage,LABEL,True),(r['purpose'],24,False)],
  [(r['visa_title'],TITLE,True),(r['visa_body'],BODY,False)],
  [(r['mastercard_title'],TITLE,True),(r['mastercard_body'],BODY,False)],
  [(r['boundary'],BODY,False)]
 ]

def build_svg():
 # Native vector text, matching editable cells in Draw.io.
 layout=[];y=508;last=None
 for r in ROWS:
  if r['phase']!=last:
   layout.append(('phase',y,64,r));y+=64;last=r['phase']
  blocks=cell_blocks(r);heights=[]
  for i,b in enumerate(blocks):
   heights.append(36+sum(len(wrap(s,CW[i]-40,z))*LH+12 for s,z,bold in b))
  h=max(176,max(heights));layout.append(('row',y,h,r));y+=h
 footer=y+30;H=footer+220
 svg=xmltag('svg',{'xmlns':'http://www.w3.org/2000/svg','width':str(W),'height':str(H),'viewBox':f'0 0 {W} {H}','role':'img','aria-labelledby':'charttitle chartdesc'})
 xmltag('title',{'id':'charttitle'},svg,'Visa與Mastercard：代理支付服務功能比較')
 xmltag('desc',{'id':'chartdesc'},svg,'依交易流程分為四段、十三個功能位置；相似用途並排，另列不能直接互換的界線。')
 def rect(x,y,w,h,fill,stroke=None):
  a=dict(x=str(x),y=str(y),width=str(w),height=str(h),fill=fill)
  if stroke:a['stroke']=stroke
  xmltag('rect',a,svg)
 def text(x,y,s,size=25,color='#14283c',bold=False):
  return xmltag('text',{'x':str(x),'y':str(y),'font-size':str(size),'font-family':'Microsoft JhengHei, Noto Sans TC, sans-serif','font-weight':'700' if bold else '400','fill':color},svg,s)
 rect(0,0,W,H,'#ffffff');rect(0,0,W,16,'#14283c')
 text(40,85,'Visa × Mastercard',36,'#4a6075',True)
 text(40,151,'代理支付：依交易流程比較服務與作用',48,bold=True)
 text(40,202,'讀法：同一列處理相近問題；不代表兩家技術規格、介接方式或商業條件相同。',27)
 text(40,249,'購物助理（Agent）：理解需求、找商品，並依顧客允許範圍執行操作的人工智慧軟體。',28,bold=True)
 text(40,292,'本圖比較的方案：Visa Intelligent Commerce 與 Mastercard Agent Pay。',28,bold=True)
 text(40,337,'英文保留官方名稱，中文提供功能解釋；初次設定通常不必每筆重做。',26,'#4a6075')
 text(40,380,'以「助理先選購、顧客最後確認」排序；確認與驗身可整合，自主模式可能提前取得顧客同意。',26,'#4a6075')
 heads=['交易位置／共同目的','Visa｜服務與作用','Mastercard｜服務與作用','比較時要保留的差別']
 for i,s in enumerate(heads):
  rect(X[i],420,CW[i],88,['#14283c','#164d9b','#9b3d10','#36536d'][i]);
  text(X[i]+18,474,s,26,'#ffffff',True)
 for kind,y,h,r in layout:
  if kind=='phase':
   rect(40,y,2000,h,'#e7eef5');text(58,y+43,r['phase'],29,bold=True);continue
  colors=['#f4f7fa','#f0f5fc','#fff5ed','#fafbfc']
  for i,blocks in enumerate(cell_blocks(r)):
   rect(X[i],y,CW[i],h,colors[i],'#c7d3df');cy=y+41
   for s,z,bold in blocks:
    for line in wrap(s,CW[i]-40,z):
     t=text(X[i]+20,cy,line,z,[PALETTE['ink'],PALETTE['visa'],PALETTE['mc'],PALETTE['ink']][i] if bold else PALETTE['ink'],bold)
     for k,v in {'data-cell-x':X[i], 'data-cell-y':y,'data-cell-w':CW[i],'data-cell-h':h}.items():t.set(k,str(v))
     cy+=LH
    cy+=12
 text(40,footer+16,'範圍：代理支付會接觸的主要公開服務；不是兩家公司全部產品型錄。',26,bold=True)
 text(40,footer+61,'線上刷卡身分驗證不一定跳出畫面；通行密鑰不表示每筆再驗一次。正常付款仍須發卡端核准。',25)
 text(40,footer+106,'外部商戶通常經自己的支付服務商、收單行及卡片網路送發卡行，不必先進本行既有支付系統。',25)
 text(40,footer+151,f'查核日 {DATE}｜完整來源、術語、地區與草案限制：同資料夾「功能盤點與來源.md」',24,'#4a6075')
 ET.indent(svg);ET.ElementTree(svg).write(ROOT/'比較圖.svg',encoding='utf-8',xml_declaration=True)
 # Split reading/export views repeat the title and column headers.
 cut=next(y for kind,y,h,r in layout if kind=='phase' and r['phase'].startswith('C '))
 for name,start,end in [('上半部',508,cut),('下半部',cut,H)]:
  part=xmltag('svg',{'xmlns':'http://www.w3.org/2000/svg','width':str(W),'height':str(508+end-start),'viewBox':f'0 0 {W} {508+end-start}'})
  for py,vy,vh in [(0,0,508),(508,start,end-start)]:
   sub=xmltag('svg',{'x':'0','y':str(py),'width':str(W),'height':str(vh),'viewBox':f'0 {vy} {W} {vh}','overflow':'hidden'},part)
   # ET permits serializing the same tree under separate parents.
   sub.append(svg)
  ET.ElementTree(part).write(ROOT/f'比較圖_{name}.svg',encoding='utf-8',xml_declaration=True)
 return layout,H

def build_drawio(layout,H):
 mx=xmltag('mxfile',{'host':'app.diagrams.net','version':'24.7.17'});d=xmltag('diagram',{'name':'依交易流程功能比較','id':'comparison'},mx)
 model=xmltag('mxGraphModel',{'dx':str(W),'dy':str(H),'grid':'1','gridSize':'10','page':'1','pageWidth':str(W),'pageHeight':str(H)},d)
 root=xmltag('root',parent=model);xmltag('mxCell',{'id':'0'},root);xmltag('mxCell',{'id':'1','parent':'0'},root)
 n=1
 def box(x,y,w,h,html,fill='#ffffff',size=25,color='#14283c',border='#c7d3df'):
  nonlocal n;n+=1
  c=xmltag('mxCell',{'id':str(n),'value':html,'style':f'rounded=0;whiteSpace=wrap;html=1;fillColor={fill};strokeColor={border};fontColor={color};fontSize={size};fontFamily=Microsoft JhengHei;align=left;verticalAlign=top;spacing=18;overflow=hidden;','vertex':'1','parent':'1'},root)
  xmltag('mxGeometry',{'x':str(x),'y':str(y),'width':str(w),'height':str(h),'as':'geometry'},c)
 box(40,35,2000,110,'<b>Visa × Mastercard｜代理支付服務功能比較</b>',size=42,border='none')
 box(40,145,2000,180,'購物助理是理解需求並依顧客允許範圍操作的人工智慧軟體。<br>Visa Intelligent Commerce與Mastercard Agent Pay是本圖比較的支付方案。<br>英文保留官方名稱，中文提供功能解釋；按選購、同意、付款與交易後處理排序。',size=27,border='none')
 for i,s in enumerate(['交易位置／共同目的','Visa｜服務與作用','Mastercard｜服務與作用','比較時要保留的差別']):
  box(X[i],420,CW[i],88,'<b>'+s+'</b>',['#14283c','#164d9b','#9b3d10','#36536d'][i],26,'#ffffff')
 for kind,y,h,r in layout:
  if kind=='phase':box(40,y,2000,h,'<b>'+r['phase']+'</b>','#e7eef5',29);continue
  for i,blocks in enumerate(cell_blocks(r)):
   val=''.join('<div style="font-size:'+str(z)+'px;line-height:'+str(LH)+'px;margin-bottom:12px">'+('<b>' if bold else '')+'<br>'.join(escape(line) for line in wrap(s,CW[i]-40,z))+('</b>' if bold else '')+'</div>' for s,z,bold in blocks)
   box(X[i],y,CW[i],h,val,['#f4f7fa','#f0f5fc','#fff5ed','#fafbfc'][i],25)
 box(40,H-215,2000,205,'範圍：代理支付相關主要公開服務。<br>正常付款仍須發卡端核准；外部商戶經自己的支付服務商與收單行送卡片網路。<br>英文保留官方名稱，中文提供功能解釋。來源與限制見「功能盤點與來源.md」。整理日：'+DATE,size=25,border='none')
 ET.indent(mx);ET.ElementTree(mx).write(ROOT/'比較圖.drawio',encoding='utf-8',xml_declaration=True)

if __name__=='__main__':
 ROOT.mkdir(parents=True,exist_ok=True)
 (ROOT/'比較資料.json').write_text(json.dumps({'date':DATE,'rows':ROWS,'sources':{k:{'title':v[0],'url':v[1]} for k,v in SOURCES.items()}},ensure_ascii=False,indent=2),encoding='utf-8')
 layout,H=build_svg();build_drawio(layout,H)
 build_notes(ROOT,ROWS,SOURCES,TERMS,INTRO_NOTES,DATE)
 build_html(ROOT,ROWS,SOURCES,TERMS,INTRO_NOTES,DATE)
 build_pure_html(ROOT)
 (ROOT/'版面資料.json').write_text(json.dumps({'width':W,'height':H,'rows':[{'kind':kind,'y':y,'h':h,'stage':r['stage']} for kind,y,h,r in layout]},ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'rows':len(ROWS),'sources':len(SOURCES),'width':W,'height':H}))
