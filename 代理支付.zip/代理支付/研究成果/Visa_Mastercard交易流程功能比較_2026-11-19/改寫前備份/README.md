# Visa／Mastercard代理支付功能比較｜2026-11-19

先開啟 [離線閱讀頁](index.html)。依交易流程分四段、13個功能位置，將兩家相似用途放在同一列，並列出不能直接視為同一規格的差異。

- [完整比較圖PNG](比較圖.png)：固定外觀，可直接放報告。
- [上半部PNG](比較圖_上半部.png)／[下半部PNG](比較圖_下半部.png)：分別涵蓋準備與同意，以及付款與交易後處理；各自重複標題及欄位。
- [SVG向量圖](比較圖.svg)：放大不失真；另有兩個分段SVG。
- [Draw.io](比較圖.drawio)：原生儲存格與文字，可編輯，沒有把整張PNG嵌入冒充編輯圖。
- [功能盤點與來源](功能盤點與來源.md)：13步白話說明、術語、對本行的含意、待確認事項、26份官方來源。
- [比較資料JSON](比較資料.json)：結構化內容；[檢查紀錄](檢查紀錄.json)記錄圖文與閱讀頁驗證。

同一列代表用途相近，不代表產品、API、認證或商業條件相同。這是代理支付相關主要公開服務的盤點，不是兩家公司全產品型錄，也不是臺灣正式導入的規格承諾。VI仍標示公開草案；未取得的Mastercard介面不自行補寫。

複製本資料夾即可離線閱讀，沒有外部字型、CDN或網站程式依賴；官方連結需網路。PNG已固定字型外觀，SVG／Draw.io則取決於新電腦的中文字型。

只有重新產生才需Python 3、Pillow、Node.js、Playwright及Chrome／Edge。先執行`python build_comparison.py`，再以Node執行`check_comparison.cjs`輸出PNG及檢查。字型可用`COMPARISON_FONT_PATH`指定；Playwright模組與瀏覽器可用`PLAYWRIGHT_MODULE_PATH`及`BROWSER_EXECUTABLE_PATH`指定。程式附目前環境的備援路徑，搬遷後可改用一般安裝的Playwright。
