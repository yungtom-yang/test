from pathlib import Path
from html import escape
import json, re, os, xml.etree.ElementTree as ET
from PIL import ImageFont

ROOT = Path(__file__).resolve().parent
DATE = '2026-11-19'
SOURCES = {
 'S01': ('Visa VIC：概念與控制', 'https://developer.visa.com/docs/visa-intelligent-commerce/concepts'),
 'S02': ('Visa VIC：操作流程', 'https://developer.visa.com/docs/visa-intelligent-commerce/workflows'),
 'S03': ('Visa VIC：正式環境參與條件', 'https://developer.visa.com/docs/visa-intelligent-commerce/production-readiness'),
 'S04': ('Visa Intelligent Commerce Connect', 'https://corporate.visa.com/en/products/intelligent-commerce-connect.html'),
 'S05': ('Visa Trusted Agent Protocol：規格', 'https://developer.visa.com/docs/trusted-agent-protocol/trusted-agent-protocol-specifications'),
 'S06': ('Visa Token Service', 'https://developer.visa.com/capabilities/vts/overview'),
 'S07': ('Visa Token Service：Token發行與生命週期', 'https://developer.visa.com/capabilities/token-service-provisioning/overview'),
 'S08': ('Visa Payment Passkey：開始使用', 'https://developer.visa.com/docs/visa-payment-passkey/docs-getting-started'),
 'S09': ('Visa Payment Passkey：產品條款', 'https://developer.visa.com/docs/visa-payment-passkey/product-terms'),
 'S10': ('Visa Click to Pay：詞彙與Visa Secure定義', 'https://developer.visa.com/docs/visa-secure-remote-commerce/docs-glossary'),
 'S11': ('Mastercard Agent Suite：企業客製Agent', 'https://www.mastercard.com/us/en/news-and-trends/press/2026/january/mastercard-launches-agent-suite-to-ready-enterprises-for-a-new-e.html'),
 'S12': ('Mastercard Agent Connect', 'https://www.mastercard.com/global/en/business/artificial-intelligence/mastercard-agent-connect.html'),
 'S13': ('Mastercard：商戶Agent Suite與Shopping Agent', 'https://www.mastercard.com/us/en/news-and-trends/press/2026/september/mastercard-gives-merchants-a-simpler-way-to-build--connect-and-s.html'),
 'S14': ('Mastercard Agent Pay Acceptance Framework', 'https://www.mastercard.com/global/en/news-and-trends/stories/2025/agentic-commerce-framework.html'),
 'S15': ('Mastercard：代碼化服務', 'https://www.mastercard.com/global/en/business/payments/consumer-payments/network-processing/tokenization.html'),
 'S16': ('Mastercard Payment Passkeys：臺灣上線說明', 'https://www.mastercard.com/tw/zh/news-and-trends/press/2025/july/payment-passkeys-launch.html'),
 'S17': ('Verifiable Intent：規格總覽 v0.1-draft', 'https://verifiableintent.dev/spec/'),
 'S18': ('Verifiable Intent：限制條件', 'https://verifiableintent.dev/spec/constraints/'),
 'S19': ('Verifiable Intent：安全模型', 'https://verifiableintent.dev/spec/security-model/'),
 'S20': ('Mastercard Identity Check：商戶與收單端導入指南', 'https://static.developer.mastercard.com/content/identity-check/uploads/files/mc_idc_onboard_guide_Acquirer.pdf'),
 'S21': ('EMVCo：Passkey在支付與3DS的運用', 'https://www.emvco.com/news-publications/understanding-the-use-of-passkeys-in-payments/'),
 'S22': ('Mastercard：代理商務Trust & Intelligence', 'https://www.mastercard.com/us/en/news-and-trends/press/2026/september/new-trust-and-intelligence-services.html'),
 'S23': ('Visa Click to Pay：Use Cases', 'https://developer.visa.com/docs/visa-secure-remote-commerce/docs-use-cases'),
 'S24': ('Mastercard交易處理規則（查得版本；概念參考）', 'https://www.mastercard.com/content/dam/mccom/shared/business/support/rules-pdfs/transaction-processing-rules.pdf'),
 'S25': ('Visa Rules：官方規則入口', 'https://usa.visa.com/support/consumer/visa-rules.html'),
 'S26': ('Mastercard：Verifiable Intent與Agent Pay意圖API', 'https://www.mastercard.com/global/en/news-and-trends/stories/2026/verifiable-intent.html'),
}

def row(phase, stage, purpose, vt, vb, mt, mb, boundary, refs, details):
 return dict(phase=phase,stage=stage,purpose=purpose,visa_title=vt,visa_body=vb,mastercard_title=mt,mastercard_body=mb,boundary=boundary,refs=refs.split(),details=details)

ROWS = [
 row('A 交易前準備','01 建置購物Agent','誰來理解需求、推薦與操作？',
     'VIC ＋ 合作夥伴Agent','提供支付能力；Connect可整合商務。完整Agent須另定供應商與分工。',
     'Agent Suite／Shopping Agent','提供客製Agent支援；Shopping Agent偏商戶自有購物場景。',
     'VIC／Agent Pay皆非一接上就取得完整銀行購物Agent。',
     'S03 S04 S11 S12 S13',[
      '這是方案建置工作，不是每筆付款都重做。VIC和Agent Pay是支付與信任方案的總稱，不能當成一個負責所有選購工作的現成Agent。',
      'Mastercard另有Agent Suite客製服務與Shopping Agent商戶購物能力。官方銀行示例涉及銀行產品推薦，並不能直接證明已有可套用於本行的跨商戶購物Agent。Visa Connect與Mastercard Agent Connect屬商務／支付連接能力，也不等於完整Agent。',
      '本案若要完整委外，仍須指定誰負責對話、商品比較、商戶操作、失敗重試與售後；若保留銀行Agent，則可只購買其下方的支付與連接能力。']),
 row('A 交易前準備','02 註冊可信Agent','平台如何知道這個Agent是誰？',
     'VARS／VIC參與設定','登錄可信Agent及金鑰；適用情況下，取憑證時核驗Agent簽章。',
     'Agent Pay註冊與驗證','Acceptance Framework以已註冊、經驗證的Agent為基礎。',
     '兩家均管理可信參與者；公開資料未證明註冊API完全對等。',
     'S01 S03 S14',[
      'VARS是Visa Agent Registry Service，作用是Agent註冊與公鑰可信性，不是風險評分產品。VIC的請求簽章適用條件與參與角色有關。',
      'Mastercard公開框架先要求Agent註冊與驗證，再建立商戶端信任；本比較沒有把它補寫成與VARS同名、同欄位的註冊服務。',
      'Agent身分證明，只能回答「誰發出請求」及資料是否可驗證；仍要另外處理客戶同意、金額範圍與付款資格。']),
 row('A 交易前準備','03 綁卡與憑證設定','讓卡片可安全交給Agent使用。',
     'VTS ＋ Passkey註冊','卡片代碼化、必要ID&V；建立後續驗身所需的Passkey。',
     'MDES／Agentic Tokens','以代碼化保護卡號；配合Agent付款設定及Payment Passkeys。',
     '代碼化是基礎；MDES一般能力與Agent Pay特定介面須分開確認。',
     'S01 S06 S07 S08 S15 S16',[
      'VTS為Visa Token Service；MDES為Mastercard Digital Enablement Service。兩者可放在「用代碼取代敏感卡片資料」這一層比較。',
      'Mastercard Agentic Tokens是代理支付使用的憑證能力，不能因為底層有MDES，就假定每個Agent Pay方案都直接開放一套相同的MDES API給銀行。',
      '卡片資格與持卡人驗證（ID&V）、Token建立、Passkey註冊是不同工作；也不是每筆交易都重新綁卡。Token識別碼、可用於支付的網路Token、意圖憑證中的JWT以及單次動態密碼，不是同一種Token。']),
 row('B 購物與同意','04 Agent進入商戶','商戶辨認可信Agent請求。',
     'Trusted Agent Protocol（TAP）','用可驗證的簽章與相關資訊，向商戶表達可信Agent請求。',
     'Web Bot Auth／Acceptance','Acceptance Framework結合Web Bot Auth辨識Agent流量。',
     '這一列比較Agent辨識；不能把TAP直接對成Verifiable Intent。',
     'S05 S14',[
      'Visa TAP是讓商戶端理解、驗證Agent請求的協定；Mastercard框架則結合Web Bot Auth與商戶接受規格。它們是用途相近的對照，不表示金鑰來源、欄位、簽章與認證方式可互換。',
      'Mastercard公開描述可在CDN層支援辨識；也有既有結帳表單及更深商戶協定整合路徑。Visa也有不同整合路徑。實際採用哪條，取決於商戶、平台與方案。',
      '證明來訪Agent可信，不等於已證明顧客同意這筆商品與金額。顧客意圖與限制留在第06步單獨比較。']),
 row('B 購物與同意','05 商品與購物車','取得可買商品、庫存及最終費用。',
     'Intelligent Commerce Connect','連接商務與支付能力，支援商戶商品在AI購物體驗中被找到。',
     'Mastercard Agent Connect','連接商品目錄、購物車及支付；協調價格、運送與履約資訊。',
     '都是連接能力；支援參與商戶，不能推成任意外部商戶全通。',
     'S04 S12 S13',[
      '這一列才是Connect對Connect。兩者都跨越多個交易步驟，不能只當成最後取Token的API。',
      'Mastercard明列商品目錄、購物車協調及付款功能；即時商品資料需要對目錄發出API查詢。Visa Connect強調跨支付／Token服務的協調與AI可探索商品等功能。',
      'Agent仍要拿到商品、規格、數量、稅、運費與可履約資料，再給客戶確認。搜尋摘要不是商戶承諾；是否在AI介面內完成或回商戶頁面，須依實際整合路徑判定。']),
 row('B 購物與同意','06 客戶確認與意圖','確認買什麼及允許範圍。',
     'Purchase Instruction／Mandate','記錄購買指示與限制；配合客戶同意及驗身資料。',
     'Agent Pay控制／VI','意圖與授權控制；Verifiable Intent提供可驗證的意圖證據格式。',
     'VI目前公開為v0.1-draft；簽章不會自動判斷所有商品語意。',
     'S01 S02 S03 S17 S18 S19 S26',[
      '兩家要解決的共同問題是：Agent這次執行的行為，是否落在客戶同意的交易或授權範圍。這裡的「授權」指客戶許可，與第10步銀行同意付款是不同概念。',
      'Visa以購買指示及其Mandate處理可用範圍；Mastercard的Agent Pay強調同意與控制，與Google共同開發的VI則提供分層、可選擇揭露的意圖證據。官方2026年3月說明將整合到Agent Pay意圖API；公開草案本身不能證明所有正式服務已全面上線。VI不是TAP的對等替代，也不能等同整套Agent Pay API。',
      '先確認本案是每筆客戶確認，或在預先限定範圍內自主執行。後者的同意可能早於商品搜尋；圖上採每筆確認的教學順序，不宣稱唯一合法實作順序。',
      '限制是否真正被驗證，取決於收到哪些資料、哪一方執行檢查，以及是否維護累計用量狀態。不能只看到有簽章，就推定網路會讀懂商品描述並核對所有細節。']),
 row('B 購物與同意','07 驗證顧客本人','確認是有權同意的使用者。',
     'Visa Payment Passkey（VPP）','以裝置上的Passkey驗身，或採方案認可的其他驗證方式。',
     'Mastercard Payment Passkeys','由裝置指紋、臉部或PIN等機制完成使用者驗證。',
     '服務觸發驗證，顧客依要求操作；AI不能自行代替顧客解鎖。',
     'S01 S08 S09 S16 S21',[
      '第06及07步通常是一個確認旅程：系統呈現條件，顧客同意，並依需要呼叫驗證。不同方案可能合併畫面、交換局部順序或沿用仍有效的既有授權證據。',
      'Passkey使用裝置持有的私鑰簽署挑戰值；臉部、指紋或裝置PIN用於本機使用者驗證。金融服務接收可驗證的結果，並非AI讀取顧客指紋後代簽。',
      'Visa條款說明VPP仍須配合適用的Visa驗證方案取得支付可用的驗證結果。Passkey和3DS不是簡單互斥：可整合、也可能在不同位置出現。自主交易能否沿用證據、有效多久及何時重驗，必須依方案與地區規則。',
      'Mastercard Payment Passkeys在臺灣已有公開上線案例，但這不表示所有臺灣Agent Pay、卡片與商戶組合都已可直接使用。']),
 row('C 付款','08 取得付款憑證','提供商戶可用的付款資料。',
     'VIC憑證API ＋ VTS','依指示取得網路Token、動態cryptogram及ECI等付款資料。',
     'Agent Pay／Agentic Tokens','透過Agent、錢包或Enabler取得可供商戶使用的安全憑證。',
     '憑證可用不代表交易獲准；動態付款資料也不等於意圖證據。',
     'S01 S02 S14 S15',[
      'Visa公開API可對購買指示取得憑證；回應有簽署／加密的付款資料。這是「取得付款材料」，不是銀行已經扣款或同意授權。',
      'Mastercard公開框架描述Agentic Tokens及可用既有表單提交的Dynamic Token Verification Code等路徑；完整可用欄位、有效期與責任仍要取得所選合作方案的正式介面。不能仿照Visa自造一組Mastercard端點。',
      'cryptogram可理解為與這次使用相關的動態密碼學付款資料；ECI表達電子商務驗證情境。它們不能取代訂單內容、客戶同意紀錄或最後的銀行付款授權。Click to Pay是兩家既有結帳能力的另一相關選項，不是每個Agent Pay／VIC流程的必經前置。']),
 row('C 付款','09 商戶端適用3DS','商戶付款前向發卡端驗證持卡人。',
     'Visa Secure','Visa的EMV 3DS方案；依地區與交易方案決定如何適用。',
     'Mastercard Identity Check','Mastercard的EMV 3DS方案；發卡ACS評估驗證結果與挑戰。',
     '可無感驗證或要求操作；Passkey不表示每筆固定再驗一次。',
     'S01 S09 S10 S20 S21 S23',[
      '一般線上卡片3DS由商戶／PSP的3DS Server發起，經國際組織Directory Server路由至發卡ACS。ACS可能無感完成（Frictionless），也可能要求顧客完成Challenge，再將結果用於付款流程。',
      '若需要Challenge，可用方案支援的OTP、銀行App或Passkey／WebAuthn／SPC等方式；具體選項由發卡與3DS整合決定。沒有跳出OTP不等於沒有3DS。',
      '圖把它放在商戶接受付款資料、一般發卡授權之前。若整合結帳服務已在內部完成3DS，便不能再畫成必定另開一個獨立驗證頁。',
      'Visa VIC公開文件對美國Agent交易有特定處理，其他地區仍有地區化規則，不能套用成臺灣一律不跑3DS。Mastercard的具體Agent Pay Profile同樣需確認。']),
 row('C 付款','10 風控與付款授權','判斷這筆付款是否允許通過。',
     'VIC Signals／Visa網路','傳遞代理與訂單脈絡，配合網路及發卡端的核驗與風控。',
     'Agent Pay Trust & Intelligence','提供代理交易信任與風險脈絡，配合Mastercard網路及發卡端。',
     '核驗／風控貫穿流程；正常付款核准仍由發卡端處理。',
     'S01 S02 S04 S22 S24 S25',[
      '這一列呈現付款送入卡片網路與發卡端的決策位置，不表示前面幾步完全沒有風控。Agent可信性、限制與憑證有效性可能在多個環節檢查；正常付款授權則再檢查卡片、額度與相關風險。',
      'Mastercard於2026-09-30公告的代理商務Trust & Intelligence能力包含交易脈絡與風險判斷，其中新的AI發起機率分數先於美國測試，不能畫成臺灣已全面開通的功能。',
      'VIC Signals不是Visa VARS；前者是交易脈絡，後者是Agent Registry。支付經路應是外部商戶→其PSP／收單行→卡片網路→發卡行。若本行只當發卡行，不會因為Agent入口在本行，就強迫外部商戶繞回本行EPOS。']),
 row('D 交易後處理','11 回報結果與訂單','同步付款狀態，確認訂單是否成立。',
     'VIC confirmation／Signals','回報交易或執行情況；訂單成立與履約仍須商戶端資料。',
     'Agent Pay／Connect結果整合','依合作介面同步結果；仍要串接商戶訂單及履約狀態。',
     'Mastercard未取得對等公開API；付款核准不等於訂單完成。',
     'S01 S02 S04 S12',[
      'Visa有公開confirmation流程；用途包括讓VIC知道交易執行結果。Mastercard的完整結果回報API未在本輪取得，這裡只標示功能責任，不杜撰同名端點。',
      '必須分別追蹤：銀行授權是否成功、商戶訂單是否成立、是否已請款以及是否已出貨。付款成功而訂單未成立時，要查詢及處理補償，不能直接重送造成重複扣款。',
      '兩家的Connect也不會讓所有商戶的訂單編號、配送資訊與取消政策自動長成同一個API。售後資料的供應方仍要在合作時確認。']),
 row('D 交易後處理','12 請款、清算與結算','把已執行的卡片交易完成帳務處理。',
     '既有Visa卡片處理網路','沿商戶、收單與發卡端的既有清算／結算機制處理。',
     '既有Mastercard卡片網路','沿商戶、收單與發卡端的既有清算／結算機制處理。',
     '這是既有卡片底座；Agent方案不會讓清算與對帳消失。',
     'S24 S25',[
      '圖以常見的授權後請款模式說明。商戶先取得付款授權，再依其業務模式請款，收單與發卡端依網路規則交換清算與結算資料；某些模式可能把訊息合併處理。',
      '購物介面看到付款成功，與實際入帳、結算及商戶收款時點不同。本圖沒有把VIC／Agent Pay視為繞過卡組織清算的方案。',
      '此列為既有卡片流程的角色說明，並非新增Agent專屬產品；正式時限、費用與責任要以地區、會員及最新合約／規則為準，來源中的規則版本也不能直接當成本行上線承諾。']),
 row('D 交易後處理','13 停用、退款與爭議','停止後續代付並處理已發生交易。',
     'VIC cancel／VTS生命週期','停止後續取憑證或管理Token；退款、爭議另走既有流程。',
     'Token／授權控制與售後','依方案停用或限制後續使用；商戶退款與卡片爭議另外處理。',
     '取消委任≠作廢已發憑證≠取消訂單≠退款。',
     'S02 S07 S17 S19 S24 S25',[
      'Visa公開流程明確區分取消購買指示與已發出的付款憑證；不能把取消指示畫成對所有既有付款資料立即生效的萬用開關。Token生命週期又是另外一套控制。',
      'Mastercard Agent Pay正式撤銷與Token停用介面需向合作方取得；VI草案不是完整的線上撤銷服務，不應用它替代正式停用設計。',
      '本案應為委任、Token、訂單、付款授權／請款、退款與爭議分別保存狀態與編號，讓客服可以知道到底停了哪一層。'])
]

FONT_PATH=os.environ.get('COMPARISON_FONT_PATH','C:/Windows/Fonts/msjh.ttc')
def font(size): return ImageFont.truetype(FONT_PATH,size)
def wrap(s,width,size):
 # Wrap Chinese by glyph, Latin by word, so service names remain readable.
 f=font(size); lines=[]
 for para in s.split('\n'):
  raw=re.findall(r'[A-Za-z0-9][A-Za-z0-9&./_-]*|\s+|.',para)
  tokens=[]
  for token in raw:
   if tokens and (token in '，。、；：！？）》」』】' or tokens[-1] in '（《「『【'):
    tokens[-1]+=token
   else:tokens.append(token)
  cur=''
  for token in tokens:
   if f.getlength(cur+token)>width and cur:
    lines.append(cur.rstrip());cur=token.lstrip()
   else: cur+=token
  if cur: lines.append(cur.rstrip())
 return lines

def xmltag(tag,attrs=None,parent=None,text=None):
 e=ET.SubElement(parent,tag,attrs or {}) if parent is not None else ET.Element(tag,attrs or {})
 if text is not None:e.text=text
 return e

W=1800; X=[40,290,810,1330]; CW=[250,520,520,430]
BODY=25; TITLE=28; LABEL=24; LH=36
PALETTE={'ink':'#14283c','muted':'#4a6075','line':'#c7d3df','visa':'#164d9b','mc':'#9b3d10'}

def cell_blocks(r):
 stage={'12 請款、清算與結算':'12 請款、清算\n與結算','13 停用、退款與爭議':'13 停用、退款\n與爭議'}.get(r['stage'],r['stage'])
 return [
  [(stage,LABEL,True),(r['purpose'],24,False)],
  [(r['visa_title'],TITLE,True),(r['visa_body'],BODY,False)],
  [(r['mastercard_title'],TITLE,True),(r['mastercard_body'],BODY,False)],
  [(r['boundary'],BODY,False)]
 ]

def build_svg():
 # Native vector text, matching editable cells in Draw.io.
 layout=[];y=420;last=None
 for r in ROWS:
  if r['phase']!=last:
   layout.append(('phase',y,64,r));y+=64;last=r['phase']
  blocks=cell_blocks(r);heights=[]
  for i,b in enumerate(blocks):
   heights.append(36+sum(len(wrap(s,CW[i]-40,z))*LH+12 for s,z,bold in b))
  h=max(176,max(heights));layout.append(('row',y,h,r));y+=h
 footer=y+30;H=footer+220
 svg=xmltag('svg',{'xmlns':'http://www.w3.org/2000/svg','width':str(W),'height':str(H),'viewBox':f'0 0 {W} {H}','role':'img','aria-labelledby':'charttitle chartdesc'})
 xmltag('title',{'id':'charttitle'},svg,'Visa與Mastercard：代理支付服務功能比較')
 xmltag('desc',{'id':'chartdesc'},svg,'依交易流程分為四段、十三個功能位置；相似用途並排，另列不能直接互換的界線。')
 def rect(x,y,w,h,fill,stroke=None):
  a=dict(x=str(x),y=str(y),width=str(w),height=str(h),fill=fill)
  if stroke:a['stroke']=stroke
  xmltag('rect',a,svg)
 def text(x,y,s,size=25,color='#14283c',bold=False):
  return xmltag('text',{'x':str(x),'y':str(y),'font-size':str(size),'font-family':'Microsoft JhengHei, Noto Sans TC, sans-serif','font-weight':'700' if bold else '400','fill':color},svg,s)
 rect(0,0,W,H,'#ffffff');rect(0,0,W,16,'#14283c')
 text(40,85,'Visa × Mastercard',36,'#4a6075',True)
 text(40,151,'代理支付：依交易流程比較服務與作用',48,bold=True)
 text(40,202,'讀法：同一列＝處理相近問題；不代表API、規格或商業條件可直接互換。',27)
 text(40,249,'方案總稱  Visa Intelligent Commerce（VIC）  ↔  Mastercard Agent Pay',28,bold=True)
 text(40,292,'以「Agent選購、客戶最後確認」排序；同意與驗身可整合，自主模式可能提前建立委任。',25,'#4a6075')
 heads=['交易位置／共同目的','Visa｜服務與作用','Mastercard｜服務與作用','比較時要保留的差別']
 for i,s in enumerate(heads):
  rect(X[i],332,CW[i],88,['#14283c','#164d9b','#9b3d10','#36536d'][i]);
  text(X[i]+18,386,s,26,'#ffffff',True)
 for kind,y,h,r in layout:
  if kind=='phase':
   rect(40,y,1720,h,'#e7eef5');text(58,y+43,r['phase'],29,bold=True);continue
  colors=['#f4f7fa','#f0f5fc','#fff5ed','#fafbfc']
  for i,blocks in enumerate(cell_blocks(r)):
   rect(X[i],y,CW[i],h,colors[i],'#c7d3df');cy=y+41
   for s,z,bold in blocks:
    for line in wrap(s,CW[i]-40,z):
     t=text(X[i]+20,cy,line,z,[PALETTE['ink'],PALETTE['visa'],PALETTE['mc'],PALETTE['ink']][i] if bold else PALETTE['ink'],bold)
     for k,v in {'data-cell-x':X[i], 'data-cell-y':y,'data-cell-w':CW[i],'data-cell-h':h}.items():t.set(k,str(v))
     cy+=LH
    cy+=12
 text(40,footer+16,'範圍：代理支付會接觸的主要公開服務；不是兩家公司全部產品型錄。',26,bold=True)
 text(40,footer+61,'3DS不一定跳驗證畫面；Passkey不等於每筆必定再驗一次。正常付款核准仍由發卡端處理。',25)
 text(40,footer+106,'外部商戶通常沿其PSP／收單行送卡片網路；銀行只當發卡行時，不必回本行EPOS。',25)
 text(40,footer+151,f'查核日 {DATE}｜完整來源、術語、地區與草案限制：同資料夾「功能盤點與來源.md」',24,'#4a6075')
 ET.indent(svg);ET.ElementTree(svg).write(ROOT/'比較圖.svg',encoding='utf-8',xml_declaration=True)
 # Split reading/export views repeat the title and column headers.
 cut=next(y for kind,y,h,r in layout if kind=='phase' and r['phase'].startswith('C '))
 for name,start,end in [('上半部',420,cut),('下半部',cut,H)]:
  part=xmltag('svg',{'xmlns':'http://www.w3.org/2000/svg','width':str(W),'height':str(420+end-start),'viewBox':f'0 0 {W} {420+end-start}'})
  for py,vy,vh in [(0,0,420),(420,start,end-start)]:
   sub=xmltag('svg',{'x':'0','y':str(py),'width':str(W),'height':str(vh),'viewBox':f'0 {vy} {W} {vh}','overflow':'hidden'},part)
   # ET permits serializing the same tree under separate parents.
   sub.append(svg)
  ET.ElementTree(part).write(ROOT/f'比較圖_{name}.svg',encoding='utf-8',xml_declaration=True)
 return layout,H

def build_drawio(layout,H):
 mx=xmltag('mxfile',{'host':'app.diagrams.net','version':'24.7.17'});d=xmltag('diagram',{'name':'依交易流程功能比較','id':'comparison'},mx)
 model=xmltag('mxGraphModel',{'dx':str(W),'dy':str(H),'grid':'1','gridSize':'10','page':'1','pageWidth':str(W),'pageHeight':str(H)},d)
 root=xmltag('root',parent=model);xmltag('mxCell',{'id':'0'},root);xmltag('mxCell',{'id':'1','parent':'0'},root)
 n=1
 def box(x,y,w,h,html,fill='#ffffff',size=25,color='#14283c',border='#c7d3df'):
  nonlocal n;n+=1
  c=xmltag('mxCell',{'id':str(n),'value':html,'style':f'rounded=0;whiteSpace=wrap;html=1;fillColor={fill};strokeColor={border};fontColor={color};fontSize={size};fontFamily=Microsoft JhengHei;align=left;verticalAlign=top;spacing=18;overflow=hidden;','vertex':'1','parent':'1'},root)
  xmltag('mxGeometry',{'x':str(x),'y':str(y),'width':str(w),'height':str(h),'as':'geometry'},c)
 box(40,35,1720,110,'<b>Visa × Mastercard｜代理支付服務功能比較</b>',size=42,border='none')
 box(40,145,1720,180,'同一列＝用途相近；不代表API可互換。<br>VIC ↔ Agent Pay：支付與信任方案總稱。<br>按「Agent選購、客戶最後確認」排序；自主模式可提前建立委任。',size=27,border='none')
 for i,s in enumerate(['交易位置／共同目的','Visa｜服務與作用','Mastercard｜服務與作用','比較時要保留的差別']):
  box(X[i],332,CW[i],88,'<b>'+s+'</b>',['#14283c','#164d9b','#9b3d10','#36536d'][i],26,'#ffffff')
 for kind,y,h,r in layout:
  if kind=='phase':box(40,y,1720,h,'<b>'+r['phase']+'</b>','#e7eef5',29);continue
  for i,blocks in enumerate(cell_blocks(r)):
   val='<br><br>'.join(('<b>'+escape(s)+'</b>') if bold else escape(s) for s,z,bold in blocks)
   box(X[i],y,CW[i],h,val,['#f4f7fa','#f0f5fc','#fff5ed','#fafbfc'][i],25)
 box(40,H-215,1720,205,'範圍：代理支付相關主要公開服務。<br>正常付款授權仍由發卡端處理；外部商戶沿其PSP／收單行送網路。<br>來源與限制見「功能盤點與來源.md」。查核日：'+DATE,size=25,border='none')
 ET.indent(mx);ET.ElementTree(mx).write(ROOT/'比較圖.drawio',encoding='utf-8',xml_declaration=True)

def build_notes():
 md=['# Visa／Mastercard代理支付：依交易流程盤點功能',f'\n查核日期：{DATE}（Asia/Taipei）。範圍為本案代理支付流程會接觸的主要公開服務，不是兩家公司所有產品。',
 '\n[離線閱讀頁](index.html)｜[完整比較圖](比較圖.png)｜[向量圖](比較圖.svg)｜[可編輯Draw.io](比較圖.drawio)',
 '\n## 先建立四個概念',
 '\n1. **VIC與Agent Pay是方案總稱。** 其中有Token、驗身、信任、控制與交易處理能力；它們本身不能證明對方交付完整購物Agent。',
 '2. **用途相近不等於相同規格。** 例如VTS與MDES可在代碼化層比較，但不能直接交換API；TAP應對照Agent辨識層，不能直接當成VI。',
 '3. **本圖是一條便於報告的順序。** 以Agent選購、客戶最後確認為主；委任可提前建立、驗身可與確認整合、風控與結果訊息可能橫跨多個步驟，API也可能把幾個動作合併。',
 '4. **「客戶同意」與「銀行付款授權」分開。** 前者允許Agent做事；後者是發卡端准不准這筆付款。',
 '\n## 總覽比較',
 '\n|交易位置|Visa|Mastercard|比較界線|\n|---|---|---|---|']
 for r in ROWS:
  md.append('|'+r['stage']+'|'+r['visa_title']+'：'+r['visa_body']+'|'+r['mastercard_title']+'：'+r['mastercard_body']+'|'+r['boundary']+'|')
 md.append('\n## 逐步說明與來源')
 for r in ROWS:
  md+=['\n### '+r['phase']+'／'+r['stage'],'\n**目的：** '+r['purpose'], '\n**Visa：** '+r['visa_title']+'。'+r['visa_body'],'\n**Mastercard：** '+r['mastercard_title']+'。'+r['mastercard_body']]
  for p in r['details']:md.append('\n'+p)
  md.append('\n**對照依據：** '+ '；'.join(f'[{s} {SOURCES[s][0]}]({SOURCES[s][1]})' for s in r['refs']))
 md += ['\n## 套回本行原圖的讀法',
 '\n這是功能盤點，不是已核准的系統部署圖。Agent入口、購物Agent、商務整合、委任與支付能力可以由不同供應商負責，不能把前13步全縮成「國際組織會提供Agent」。',
 '\n- **銀行保留Agent：** 仍要負責顧客旅程、商品決策、同意內容與商戶／供應商分工；可以整合兩家的支付、Token、驗證與可信Agent能力。',
 '- **完整委外：** 可以把更多功能交付合作方，但須逐列確認合約是否含實作、維運、客服、失敗處理及責任。國際組織公告某能力，不等於合作報價自動包含。',
 '- **本行只當發卡行：** 外部商戶透過其PSP／收單行送網路，本行在發卡授權、ACS與相關服務承接自己的責任；不需要把所有外部交易強迫導入本行EPOS。',
 '\n## 尚需向兩家確認的事項',
 '\n- 臺灣適用參與角色、卡別、商戶與正式可用環境；特定試點及美國測試不能直接外推本行。',
 '- Agent／錢包／Enabler／Token Requestor由誰擔任；正式註冊、金鑰管理、Token生命週期及異常回報責任。',
 '- 本行場景中的客戶驗身時點、既有證據沿用條件、3DS Profile、Challenge能力與拒絕交易處理。',
 '- Mastercard完整憑證、確認、撤銷API，以及VI草案與正式服務的對應；Visa現行實作指南與本行適用地區條件。',
 '- 單筆與累計限制誰檢查；商品條件、商戶、金額與時間戳如何可信地取得及相互綁定。',
 '- 取消／停用對已發出的憑證及在途交易有何效力；退款、爭議、責任分配與對帳。',
 '\n## 常見名詞',
 '\n|名詞|白話意思|不是什麼|\n|---|---|---|',
 '|Tokenization|用代碼代表敏感卡片資料|不是把所有相關資料都變成無風險|',
 '|Passkey|用裝置內私鑰及本機驗證證明使用者|不是AI可代替客戶解鎖的密碼|',
 '|Cryptogram|動態、可驗證的付款密碼學資料|不是顧客購買內容全文，也不是付款核准|',
 '|Mandate／委任|使用者允許Agent執行的交易或範圍|不是銀行最後的付款授權|',
 '|3DS／ACS|付款前的持卡人驗證協定／發卡驗證系統|不是每筆都跳OTP，也不是額度授權主機|',
 '|Signals|提供代理或交易的脈絡資訊|不保證一定批准付款|',
 '\n## 官方來源索引與證據層級',
 '\n產品頁與新聞稿可證明公開能力定位，不當作完整API／臺灣上線承諾；技術規格可支持其定義範圍。VI明確標示草案；舊版3DS與交易規則僅用於穩定的角色／概念，正式導入須索取最新文件。本圖第12步與套回本行的分工說明，是依一般卡片流程作的架構整理。']
 for k,(title,url) in SOURCES.items():md.append(f'\n- **{k}** [{title}]({url})')
 (ROOT/'功能盤點與來源.md').write_text('\n'.join(md)+'\n',encoding='utf-8')

def build_html():
 css='''body{margin:0;background:#eef2f6;color:#14283c;font:17px/1.75 "Microsoft JhengHei",sans-serif}main{max-width:1340px;margin:auto;padding:36px 24px}h1{font-size:34px;line-height:1.4}h2{font-size:25px}a{color:#164d9b}nav{display:flex;flex-wrap:wrap;gap:12px;margin:22px 0}nav a{background:white;border:1px solid #c7d3df;border-radius:7px;padding:8px 14px}.intro,.guide,details{background:white;border:1px solid #c7d3df;border-radius:10px;padding:18px 24px;margin:18px 0}.diagram{background:white;border:1px solid #c7d3df;border-radius:10px;padding:14px}.diagram img{width:100%;height:auto;display:block}summary{cursor:pointer;font-weight:700;font-size:21px}.pair{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:16px}.v,.m{padding:14px 18px;border-radius:6px}.v{background:#f0f5fc}.m{background:#fff5ed}.pair h3{margin:0 0 6px;font-size:19px}.pair p{margin:0}.boundary{font-weight:bold}.sources{font-size:15px;overflow-wrap:anywhere}.sources a{margin-right:12px}.note{color:#4a6075}button{cursor:pointer;padding:8px 14px;font:inherit;background:#fff;border:1px solid #a5b5c7;border-radius:6px}footer{padding:20px 0} @media(max-width:650px){main{padding:18px 12px}h1{font-size:26px}.pair{grid-template-columns:1fr}.diagram{overflow:auto}.diagram img{width:1100px;max-width:none}.intro,.guide,details{padding:14px}summary{font-size:19px}} @media print{nav,button{display:none}main{padding:0}.diagram{break-after:page}details{break-inside:avoid}}'''
 parts=['<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Visa／Mastercard｜代理支付功能比較</title><style>'+css+'</style><main>',
 '<p class="note">依交易流程盤點｜查核日 '+DATE+'</p><h1>Visa／Mastercard代理支付<br>服務功能與作用比較</h1>',
 '<div class="intro"><b>同一列比較相近用途，不代表規格可以互換。</b><br>VIC與Agent Pay是方案總稱；Connect比較商務連接，TAP／Web Bot Auth比較Agent辨識，VI比較意圖證據。<br>以「Agent選購、客戶最後確認」排序；委任可以提前，驗身與確認可整合。範圍是代理支付相關主要公開服務。</div>',
 '<nav><a href="比較圖.png">完整PNG</a><a href="比較圖_上半部.png">上半部PNG</a><a href="比較圖_下半部.png">下半部PNG</a><a href="比較圖.svg">SVG向量圖</a><a href="比較圖.drawio">Draw.io可編輯圖</a><a href="功能盤點與來源.md">詳細筆記與來源</a></nav>',
 '<div class="diagram"><a href="比較圖.svg" title="開啟原尺寸向量圖"><img src="比較圖.svg" alt="依四大階段、十三個交易位置排列的Visa與Mastercard服務功能比較圖"></a></div>',
 '<h2>逐步說明</h2><p>點選各步驟展開白話說明及官方來源。手機也可直接閱讀以下文字。</p><button id="expand">全部展開</button> <button id="collapse">全部收合</button>']
 last=None
 for r in ROWS:
  if last!=r['phase']:parts.append('<h2>'+r['phase']+'</h2>');last=r['phase']
  parts+=['<details><summary>'+r['stage']+'｜'+r['purpose']+'</summary><div class="pair">', '<div class="v"><h3>Visa｜'+escape(r['visa_title'])+'</h3><p>'+r['visa_body']+'</p></div>', '<div class="m"><h3>Mastercard｜'+escape(r['mastercard_title'])+'</h3><p>'+r['mastercard_body']+'</p></div></div>','<p class="boundary">'+r['boundary']+'</p>']
  parts += ['<p>'+escape(p)+'</p>' for p in r['details']]
  parts += ['<p class="sources">對照依據：'+''.join('<a href="'+SOURCES[s][1]+'" target="_blank" rel="noopener">'+s+' '+escape(SOURCES[s][0])+'</a>' for s in r['refs'])+'</p></details>']
 parts+=['<div class="guide"><h2>套回本行原圖</h2><p>銀行保留Agent時，可依功能逐項外接支付與商務能力。完整委外時，仍須逐列確認供應商負責哪一部分；國際組織產品名稱不等於已包含完整Agent。</p><p>外部商戶通常經其PSP／收單行送國際組織，本行若只當發卡行，並不需要把交易先拉回本行EPOS。</p><p>臺灣正式可用角色、API、驗證Profile、責任與費用仍需合作方確認。VI為v0.1-draft；Mastercard新AI發起機率分數的官方公告是先於美國測試。</p></div>',
 '<footer><a href="../../README_先讀我.md">返回研究入口</a> · <a href="功能盤點與來源.md">完整筆記與來源索引</a> · 可離線閱讀；外部官方來源需網路。</footer></main><script>document.querySelector("#expand").onclick=()=>document.querySelectorAll("details").forEach(d=>d.open=true);document.querySelector("#collapse").onclick=()=>document.querySelectorAll("details").forEach(d=>d.open=false);</script></html>']
 (ROOT/'index.html').write_text(''.join(parts),encoding='utf-8')

if __name__=='__main__':
 ROOT.mkdir(parents=True,exist_ok=True)
 (ROOT/'比較資料.json').write_text(json.dumps({'date':DATE,'rows':ROWS,'sources':{k:{'title':v[0],'url':v[1]} for k,v in SOURCES.items()}},ensure_ascii=False,indent=2),encoding='utf-8')
 layout,H=build_svg();build_drawio(layout,H);build_notes();build_html()
 (ROOT/'版面資料.json').write_text(json.dumps({'width':W,'height':H,'rows':[{'kind':kind,'y':y,'h':h,'stage':r['stage']} for kind,y,h,r in layout]},ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'rows':len(ROWS),'sources':len(SOURCES),'width':W,'height':H}))
