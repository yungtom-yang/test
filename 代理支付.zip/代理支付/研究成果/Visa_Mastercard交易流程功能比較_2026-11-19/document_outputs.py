from html import escape
import re

def build_notes(root,rows,sources,terms,intro,date):
 md=['# Visa與Mastercard代理支付：完整白話比較',f'\n整理日期：{date}。中文名稱是功能解釋，英文保留官方名稱。',
 '\n[只看比較圖](比較圖_純圖版.html)｜[逐步閱讀頁](index.html)｜[可編輯圖](比較圖.drawio)',
 '\n## 閱讀前先知道']
 md+=['\n'+p for p in intro]
 md+=['\n這份文件盤點代理支付交易會接觸的主要公開能力，不是兩家公司所有產品型錄。公開產品頁不等於本行已取得臺灣正式參與資格或完整實作規格。',
 '\n## 按交易順序比較', '\n|交易位置與目的|Visa提供的能力與作用|Mastercard提供的能力與作用|理解這一列時要注意|\n|---|---|---|---|']
 for r in rows:
  clean=lambda s:s.replace('\n','；')
  md.append('|'+r['stage']+'：'+r['purpose']+'|'+clean(r['visa_title'])+'。'+r['visa_body']+'|'+clean(r['mastercard_title'])+'。'+r['mastercard_body']+'|'+r['boundary']+'|')
 md+=['\n## 逐步說明、例子與官方依據']
 for r in rows:
  md+=['\n### '+r['phase']+'／'+r['stage'], '\n**這一步要做什麼：** '+r['purpose'],
       '\n**Visa：** '+r['visa_title'].replace('\n','；')+'。'+r['visa_body'],
       '\n**Mastercard：** '+r['mastercard_title'].replace('\n','；')+'。'+r['mastercard_body'],
       '\n**比較重點：** '+r['boundary']]
  md+=['\n'+p for p in r['details']]
  md+=['\n**官方依據：** '+'；'.join(f'[{s} {sources[s][0]}]({sources[s][1]})' for s in r['refs'])]
 md+=['\n## 套回銀行原本的交易架構',
 '\n銀行保留自己的購物助理時，仍須安排顧客旅程、商品決策、同意內容、商戶操作與失敗處理；可依本圖逐列整合兩家的支付、驗身與連接服務。',
 '\n若採完整委外，要逐列確認合作方是否交付建置、維運、客服、異常處理與責任。不能把「有代理支付產品」直接當成「會提供完整購物助理」。',
 '\n外部商戶通常經自己的支付服務商、收單行與卡片網路送到發卡行。本行若只擔任發卡行，主要處理自己的持卡人驗證、付款授權與相關服務；不能把所有外部交易都畫成先進入本行既有支付系統。',
 '\n## 正式合作前仍要取得的答案',
 '\n- 本行可擔任哪些角色，哪些臺灣卡片、商戶、地區及交易模式正式可用。',
 '- 誰建置購物助理、管理付款憑證、保管金鑰、維護支付代碼，以及回報交易結果。',
 '- 顧客何時驗身、哪些結果可以沿用、何時必須重新確認，以及商戶刷卡前驗證的地區化規格。',
 '- 單筆金額、累計預算、商品條件與商戶限制由誰確實檢查，資料如何可信地取得。',
 '- 已發付款資料及在途交易如何停止；商戶取消、退款、刷卡爭議及客服責任如何分工。',
 '- Mastercard完整付款憑證、結果回報與停用介面；公開意圖草案與正式服務的實際對應。',
 '\n## 原縮寫與技術詞完整解釋',
 '\n主圖優先使用中文敘述；以下保留原圖曾出現的縮寫，方便對照官方文件。',
 '\n|名稱與原縮寫|完整白話解釋|\n|---|---|']
 md+=['|'+name+'|'+meaning+'|' for name,meaning in terms]
 md+=['\n## 官方來源與資料界線',
 '\n產品頁及新聞稿用來確認能力定位；技術規格只支持其實際列出的範圍。可驗證意圖規格仍標示草案，舊版驗證與卡片規則僅用於穩定的概念及角色說明，正式導入仍要取得適用版本。',
 '\n文中的買鞋情境是教學示例，不是官方案例、正式送交易資料或本行已獲准的執行方式。套回本行的分工是本案架構推論。']
 md+=['\n- **'+s+'** ['+title+']('+url+')' for s,(title,url) in sources.items()]
 (root/'功能盤點與來源.md').write_text('\n'.join(md)+'\n',encoding='utf-8')

def build_html(root,rows,sources,terms,intro,date):
 css='''body{margin:0;background:#eef2f6;color:#14283c;font:18px/1.85 "Microsoft JhengHei",sans-serif}main{max-width:1400px;margin:auto;padding:32px 24px}h1{font-size:34px;line-height:1.45}h2{font-size:26px}h3{font-size:21px}a{color:#164d9b}nav{display:flex;flex-wrap:wrap;gap:12px;margin:20px 0}nav a,button{background:#fff;border:1px solid #a9b9c9;border-radius:6px;padding:8px 14px}button{font:inherit;cursor:pointer}.intro,.guide,details{background:#fff;border:1px solid #c7d3df;border-radius:9px;padding:18px 24px;margin:18px 0}.diagram{background:#fff;padding:12px;border:1px solid #c7d3df}.diagram img{display:block;width:100%;height:auto}summary{cursor:pointer;font-weight:700;font-size:22px}.pair{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:18px}.v,.m{padding:16px 20px;border-radius:6px}.v{background:#f0f5fc}.m{background:#fff5ed}.pair h3{margin:0 0 10px}.pair p{margin:0}.boundary{font-weight:700}.sources{font-size:16px;overflow-wrap:anywhere}.sources a{display:block}.note{color:#4a6075}dt{font-weight:700;margin-top:18px}dd{margin:4px 0 14px}footer{padding:20px 0}@media(max-width:650px){main{padding:18px 12px}h1{font-size:27px}.pair{grid-template-columns:1fr}.diagram{overflow:auto}.diagram img{width:1250px;max-width:none}.intro,.guide,details{padding:14px}summary{font-size:20px}}@media print{nav,button{display:none}main{padding:0}.diagram{break-after:page}details{break-inside:avoid}}'''
 parts=['<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Visa與Mastercard代理支付：完整白話比較</title><style>'+css+'</style></head><body><main>',
 '<p class="note">整理日期：'+date+'</p><h1>Visa與Mastercard代理支付<br>服務功能與作用：完整白話比較</h1><div class="intro">']
 parts+=['<p>'+escape(p)+'</p>' for p in intro]
 parts+=['</div><nav><a href="比較圖_純圖版.html">只看比較圖</a><a href="比較圖.png">完整圖片</a><a href="比較圖_上半部.png">前半段圖片</a><a href="比較圖_下半部.png">後半段圖片</a><a href="比較圖.drawio">可編輯圖</a><a href="功能盤點與來源.md">完整文字與來源</a></nav>',
 '<div class="diagram"><img src="比較圖.svg" alt="依交易順序排列、附中文解釋的Visa與Mastercard服務比較圖"></div>',
 '<h2>按交易步驟閱讀</h2><p>每一步都有用途、兩家服務、比較重點與買鞋示例。以下保留官方來源供查核。</p><button id="expand">全部展開</button> <button id="collapse">全部收合</button>']
 last=None
 for r in rows:
  if last!=r['phase']:parts+=['<h2>'+r['phase']+'</h2>'];last=r['phase']
  title=lambda s:escape(s).replace('\n','<br>')
  parts+=['<details><summary>'+r['stage']+'｜'+r['purpose']+'</summary><div class="pair">',
   '<div class="v"><h3>Visa｜'+title(r['visa_title'])+'</h3><p>'+escape(r['visa_body'])+'</p></div>',
   '<div class="m"><h3>Mastercard｜'+title(r['mastercard_title'])+'</h3><p>'+escape(r['mastercard_body'])+'</p></div></div>',
   '<p class="boundary">'+escape(r['boundary'])+'</p>']
  parts+=['<p>'+escape(p)+'</p>' for p in r['details']]
  parts+=['<div class="sources">官方依據：'+''.join('<a href="'+sources[s][1]+'" target="_blank" rel="noopener">'+s+' '+escape(sources[s][0])+'</a>' for s in r['refs'])+'</div></details>']
 parts+=['<div class="guide"><h2>原縮寫與技術詞完整解釋</h2><p>主圖已優先改用中文；這裡另保留原縮寫供對照。</p><dl>']
 parts+=['<dt>'+escape(name)+'</dt><dd>'+escape(meaning)+'</dd>' for name,meaning in terms]
 parts+=['</dl></div><div class="guide"><h2>銀行如何使用這份盤點</h2><p>保留銀行自己的購物助理時，可依功能逐項外接支付與商務能力；完整委外時，則要逐項確認供應商是否負責建置、維運、失敗處理與售後。</p><p>外部商戶通常經自己的支付服務商、收單行與卡片網路送至發卡行。本行若只當發卡行，不需要把所有外部交易先拉回本行既有支付系統。</p><p>臺灣正式可用角色、驗證規格與責任仍須合作方確認。可驗證意圖規格是草案；買鞋例子只是教學情境。</p></div>',
 '<footer><a href="功能盤點與來源.md">完整文字、待確認事項與官方來源</a> · 可離線閱讀；官方網站連結需網路。</footer></main><script>document.querySelector("#expand").onclick=()=>document.querySelectorAll("details").forEach(d=>d.open=true);document.querySelector("#collapse").onclick=()=>document.querySelectorAll("details").forEach(d=>d.open=false);</script></body></html>']
 (root/'index.html').write_text(''.join(parts),encoding='utf-8')

def build_pure_html(root):
 svg=re.sub(r'^<\?xml[^>]*\?>\s*','',(root/'比較圖.svg').read_text(encoding='utf-8'))
 html='''<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Visa與Mastercard代理支付比較圖｜完整白話版</title><style>html,body{margin:0;padding:0;background:#fff}body{max-width:2080px;margin:0 auto}svg{display:block;width:100%;height:auto}@media print{body{max-width:none}svg{width:100%;height:auto}}</style></head><body>'''+svg+'</body></html>'
 (root/'比較圖_純圖版.html').write_text(html,encoding='utf-8')
