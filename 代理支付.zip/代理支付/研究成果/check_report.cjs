const {launchBrowser}=require('./browser_runtime.cjs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const fs=require('node:fs');
(async()=>{
 const browser=await launchBrowser();
 const page=await browser.newPage({viewport:{width:1440,height:1100},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',x=>errors.push(x.message));
 await page.goto(pathToFileURL(path.join(__dirname,'flow-research.html')).href);
 const results=[];
 for(const scenario of ['internal','visa','mastercard']){
  await page.locator(`[data-scenario="${scenario}"]`).click();
  for(const stage of ['overview','A','B','C','D','E','F']){
   await page.locator(`[data-stage="${stage}"]`).click();
   for(const mode of ['confirm','auto']){
    await page.locator(`input[value="${mode}"]`).check();
    const state=await page.evaluate(()=>({svg:!!document.querySelector('#diagram svg'),title:document.querySelector('#title').textContent,over:document.documentElement.scrollWidth>innerWidth+1, text:[...document.querySelectorAll('#diagram text')].filter(x=>x.getBBox().width>164 && x.classList.contains('line')).map(x=>x.textContent)}));
    if(!state.svg||state.over||state.text.length)throw Error(JSON.stringify({scenario,stage,mode,state}));
    results.push([scenario,stage,mode]);
   }
  }
 }
 await page.locator('[data-scenario="internal"]').click();await page.locator('[data-stage="D"]').click();await page.locator('input[value="confirm"]').check();
 await page.locator('#flows').scrollIntoViewIfNeeded();
 await page.screenshot({path:path.join(__dirname,'研究頁預覽.png'),fullPage:false});
 await page.locator('#diagram svg').screenshot({path:path.join(__dirname,'小樹購比對流程預覽.png')});
 await page.setViewportSize({width:390,height:844});
 await page.goto(pathToFileURL(path.join(__dirname,'flow-research.html')).href);
 const mobile=await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1);
 if(!mobile)throw Error('Mobile outer overflow');
 if(errors.length)throw Error(errors.join('\n'));
 fs.writeFileSync(path.join(__dirname,'檢查紀錄.json'),JSON.stringify({checkedStates:results.length,mobileOuterOverflow:false,pageErrors:errors,notes:'SVG時間軸可橫向捲動；未執行付款API或驗證實際介接。'},null,2));
 console.log(JSON.stringify({checkedStates:results.length,mobileOuterOverflow:false,pageErrors:errors}));
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
