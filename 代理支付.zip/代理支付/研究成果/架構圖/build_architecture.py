from pathlib import Path
from html import escape
import xml.etree.ElementTree as ET
import json

ROOT=Path(__file__).resolve().parent
ROOT.mkdir(exist_ok=True)
GRAPHS=[]

def graph(id,title,subtitle,width,height):
    g=dict(id=id,title=title,subtitle=subtitle,width=width,height=height,nodes=[],edges=[],groups=[],notes=[])
    GRAPHS.append(g); return g
def node(g,id,x,y,w,h,lines,kind='new'):
    g['nodes'].append(dict(id=id,x=x,y=y,w=w,h=h,lines=lines,kind=kind))
def edge(g,a,b,pts,label='',lx=0,ly=0,kind='main',both=False):
    g['edges'].append(dict(a=a,b=b,pts=pts,label=label,lx=lx,ly=ly,kind=kind,both=both))
def group(g,x,y,w,h,label):g['groups'].append(dict(x=x,y=y,w=w,h=h,label=label))

g=graph('internal','AI 智慧代理支付｜情境一：小樹購平台','沿用會議版系統方塊圖；近期研究以逐筆確認為基準，受限自主另確認資格。',1680,1100)
group(g,50,140,735,840,'平台與代理控管（邏輯角色；介接待確認）')
group(g,835,140,795,650,'既有信用卡付款處理（依原圖保留角色，實際路由待確認）')
node(g,'user',80,390,100,90,['客戶'],'user')
node(g,'entry',230,390,170,90,['Agent 入口','銀行 App／平台'],'plain')
node(g,'agent',470,390,180,90,['Agent','受控工具服務'],'plain')
node(g,'merchant',460,210,230,100,['小樹購商品／訂單 API','查詢・結帳・下單','API 能力待確認'],'unknown')
node(g,'match',470,620,220,90,['交易比對模組','獨立取得可信資料'],'new')
node(g,'db',180,810,230,130,['代理紀錄管理','委任版本／證據','DB'],'db')
node(g,'control',500,820,230,90,['委任與執行控管','狀態／次數／占用'],'new')
node(g,'epos',880,390,170,90,['EPOS','付款執行'],'existing')
node(g,'ph',880,620,170,90,['Payment Hub','安全卡片參照'],'existing')
node(g,'pool',1130,390,180,90,['Cardpool'],'existing')
node(g,'link',1390,390,180,90,['Cardlink'],'existing')
node(g,'issuer',1390,620,180,90,['發卡授權處理','實際介面待確認'],'unknown')
node(g,'verify',1115,210,455,105,['適用驗證及相關系統','MPI／V/M/J／ACS／Liberty','名稱沿原圖；角色與鏈路待確認'],'unknown')
edge(g,'user','entry',[(180,435),(230,435)],'①需求／確認',205,370,both=True)
edge(g,'entry','agent',[(400,435),(470,435)],'結果通知',435,490,both=True)
edge(g,'agent','merchant',[(560,390),(560,310)],'②查詢／下單／結果',665,350,both=True)
edge(g,'agent','match',[(560,480),(560,620)],'③請求獨立比對',560,550,both=True)
edge(g,'match','merchant',[(690,665),(755,665),(755,260),(690,260)],'查可信結帳明細',755,570,'data',True)
edge(g,'match','db',[(470,665),(295,665),(295,810)],'讀取確認版本',335,640,'data',True)
edge(g,'control','db',[(500,865),(410,865)],'狀態',455,840,'data',True)
edge(g,'merchant','epos',[(690,285),(810,285),(810,340),(965,340),(965,390)],'④可信訂單付款請求（介接待確認）',905,325,'pending')
edge(g,'epos','control',[(1050,460),(1080,460),(1080,760),(615,760),(615,820)],'⑤付款前有效性檢查／占用',770,755,'data',True)
edge(g,'epos','ph',[(965,480),(965,620)],'安全取用付款資料',975,550,'data',True)
edge(g,'epos','verify',[(1050,420),(1080,420),(1080,263),(1115,263)],'適用驗證',1085,350,'pending',True)
edge(g,'epos','pool',[(1050,435),(1130,435)],'⑥授權',1090,405,both=True)
edge(g,'pool','link',[(1310,435),(1390,435)],'既有處理',1350,405,both=True)
edge(g,'link','issuer',[(1480,480),(1480,620)],'授權／結果',1480,555,'pending',True)
g['notes']=[
 '⑦ 付款結果回查小樹購訂單，再經 Agent 入口通知客戶；付款、接單、請款與出貨各自追蹤。',
 '行內平台可縮小外部依賴；本圖不預設自行卡／自行收單即可完全不經國際組織。',
 'Cardpool、Cardlink 等為原圖角色參考；虛線付款及驗證鏈路不是已驗證的內部實作。'
]

def external(id,brand):
    visa=brand=='Visa'
    g=graph(id,f'AI 智慧代理支付｜情境二：外部商戶 × {brand}', '商務查詢、意圖／憑證與信用卡授權分開；本圖為邏輯架構，非正式串接規格。',1900,1130)
    group(g,50,210,750,750,'銀行代理與安全服務（建議分工）')
    group(g,880,330,350,510,'外部商戶與收單')
    group(g,1270,210,580,750,f'{brand} 相關服務與發卡端（須取得適用資格）')
    node(g,'user',80,450,100,90,['客戶'],'user')
    node(g,'entry',230,450,150,90,['Agent 入口','確認／驗證'],'plain')
    node(g,'agent',445,450,180,90,['Agent','受控工具服務'],'plain')
    node(g,'safe',550,240,220,105,['安全憑證整合服務','支付資料不進模型','可自建或由合作方承擔'],'new')
    node(g,'merchant',925,435,260,110,['外部商戶／結帳介面','商品・總價・條款','接入方式依商戶支援'],'plain')
    node(g,'match',445,690,190,90,['獨立交易比對','商品需求／委任'],'new')
    node(g,'control',655,825,120,95,['執行控管','次數／占用'],'new')
    node(g,'db',160,820,230,130,['代理紀錄管理','委任／版本／證據','DB'],'db')
    node(g,'psp',925,700,260,100,['商戶 PSP／收單','由商戶收單路徑送授權'],'existing')
    if visa:
        node(g,'trust',1305,260,240,110,['Visa VIC','購買指示／憑證','驗證與控制'],'new')
        node(g,'token',1615,260,195,110,['VTS 等前置能力','卡片 Token 設定','依適用整合'],'new')
        node(g,'recognition',925,210,260,90,['TAP／Agent 辨識','或雙邊安全介面'],'new')
        lab='④購買指示／驗證／憑證'; proof='⑤受控付款資料'
    else:
        node(g,'trust',1305,260,240,110,['Agent Pay／憑證提供者','適用意圖與付款能力','正式 API 待確認'],'unknown')
        node(g,'token',1615,260,195,110,['Agentic Token','卡片設定與生命週期','依適用整合'],'new')
        node(g,'recognition',925,210,260,90,['Agent 受理框架','Web Bot Auth 等'],'new')
        lab='④意圖證據／付款能力'; proof='⑤適用證據及付款資料'
    node(g,'network',1305,700,240,100,[f'{brand} 支付網路','適用檢查與授權路由'],'existing')
    node(g,'issuer',1615,700,195,100,['發卡行','授權／風險控制'],'existing')
    edge(g,'user','entry',[(180,495),(230,495)],'①需求',205,425,both=True)
    edge(g,'entry','agent',[(380,495),(445,495)],'確認／結果',412,570,both=True)
    edge(g,'agent','merchant',[(625,490),(925,490)],'②查詢／下單／結果',780,465,both=True)
    edge(g,'agent','match',[(535,540),(535,690)],'③獨立比對',535,625,both=True)
    edge(g,'match','db',[(445,735),(275,735),(275,820)],'讀取確認版本',335,710,'data',True)
    edge(g,'match','merchant',[(635,735),(840,735),(840,525),(925,525)],'查可信結帳資料',825,650,'data',True)
    edge(g,'agent','control',[(625,515),(715,515),(715,825)],'付款前執行控管',715,625,'data',True)
    edge(g,'control','db',[(655,875),(390,875)],'版本／狀態／執行紀錄',520,850,'data',True)
    edge(g,'agent','safe',[(535,450),(535,293),(550,293)],'準備適用證據',455,390,'data',True)
    edge(g,'safe','trust',[(660,240),(660,160),(1425,160),(1425,260)],lab,1060,140,both=True)
    edge(g,'trust','token',[(1545,315),(1615,315)],'依整合',1580,400,'data',True)
    edge(g,'safe','merchant',[(770,293),(825,293),(825,395),(1000,395),(1000,435)],proof,835,370,'pending')
    edge(g,'recognition','merchant',[(1110,300),(1110,435)],'辨識／接入',1110,365,'data')
    edge(g,'merchant','psp',[(1055,545),(1055,700)],'⑥付款請求',1055,625)
    edge(g,'psp','network',[(1185,750),(1305,750)],'⑦授權',1245,715,both=True)
    edge(g,'network','issuer',[(1545,750),(1615,750)],'⑧授權',1580,715,both=True)
    if visa:
        g['notes']=[
          '⑨ 商戶回傳訂購／付款結果；安全整合服務依 VIC 流程回報交易事件，行內保存關聯並通知客戶。',
          'TAP 用於商戶互動信任；取得 VIC 付款憑證不代表發卡核准。自主模式與臺灣驗證條件待確認。',
          '本行 EPOS／PH 是否擔任整合或收單角色須另確認，不預設代替外部商戶既有 PSP／收單。'
        ]
    else:
        g['notes']=[
          '⑨ 商戶回傳結果，行內核實訂單並保存證據；VI 不等同完整付款 API 或爭議處理機制。',
          'VI：Immediate 由客戶確認最終交易；Autonomous 另有 L2 委任與 L3a／L3b 證據，適用整合待確認。',
          'Agent 辨識、VI 意圖與 Agentic Token 是不同能力；不推定每筆資料都沿同一 API 傳遞。'
        ]
    return g
external('visa','Visa');external('mastercard','Mastercard')

PALETTE={'plain':('#ffffff','#627687'),'existing':('#dceaff','#6d91bc'),'new':('#e9f3ed','#739985'),'unknown':('#fff2d7','#bc9550'),'db':('#ffffff','#627687'),'user':('#ffffff','#627687')}
def svg(g):
    out=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{g["width"]}" height="{g["height"]}" viewBox="0 0 {g["width"]} {g["height"]}" role="img"><title>{escape(g["title"])}</title><desc>研究草案。白色為商務角色，藍色為既有付款能力，綠色為代理相關能力，黃色與虛線為待確認。</desc><defs>']
    for k,c in [('main','#3f6687'),('data','#748290'),('pending','#aa7c2e')]:
        out.append(f'<marker id="{k}" markerWidth="10" markerHeight="10" refX="8" refY="5" orient="auto-start-reverse"><path d="M0 0L9 5L0 10Z" fill="{c}"/></marker>')
    out+=['</defs><style>text{font-family:"Microsoft JhengHei","Noto Sans TC",Arial,sans-serif;fill:#203748} .title{font-size:29px;font-weight:600}.sub{font-size:18px;fill:#526879}.node{font-size:19px}.label{font-size:16px;paint-order:stroke;stroke:#fff;stroke-width:7;stroke-linejoin:round}.group{font-size:17px;fill:#526879}.foot{font-size:17px}</style>',f'<rect width="{g["width"]}" height="{g["height"]}" fill="#fff"/>',f'<text x="50" y="53" class="title">{escape(g["title"])}</text>',f'<text x="50" y="88" class="sub">{escape(g["subtitle"])}</text>']
    for a in g['groups']:
        out.append(f'<rect x="{a["x"]}" y="{a["y"]}" width="{a["w"]}" height="{a["h"]}" rx="12" fill="#f8fafc" stroke="#c9d5de" stroke-dasharray="7 5"/><text x="{a["x"]+18}" y="{a["y"]+29}" class="group">{escape(a["label"])}</text>')
    for a in g['edges']:
        color={'main':'#3f6687','data':'#748290','pending':'#aa7c2e'}[a['kind']]
        d='M'+' L'.join(f'{x},{y}' for x,y in a['pts'])
        out.append(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="2" marker-end="url(#{a["kind"]})" '+(f'marker-start="url(#{a["kind"]})" ' if a['both'] else '')+('stroke-dasharray="7 5" ' if a['kind']=='pending' else '')+'/>')
    for n in g['nodes']:
        fill,stroke=PALETTE[n['kind']];x,y,w,h=[n[k] for k in ('x','y','w','h')]
        if n['kind']=='db':
            out.append(f'<path d="M{x},{y+18}A{w/2},18 0 0 1 {x+w},{y+18}V{y+h-18}A{w/2},18 0 0 1 {x},{y+h-18}Z" fill="{fill}" stroke="{stroke}" stroke-width="1.7"/><ellipse cx="{x+w/2}" cy="{y+18}" rx="{w/2}" ry="18" fill="{fill}" stroke="{stroke}" stroke-width="1.7"/>')
        elif n['kind']=='user':
            cx=x+w/2
            out.append(f'<circle cx="{cx}" cy="{y+20}" r="13" fill="#fff" stroke="{stroke}" stroke-width="2"/><path d="M{cx},{y+33}V{y+60}M{cx-20},{y+45}H{cx+20}M{cx},{y+60}L{cx-17},{y+78}M{cx},{y+60}L{cx+17},{y+78}" fill="none" stroke="{stroke}" stroke-width="2"/>')
        else:out.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="{fill}" stroke="{stroke}" stroke-width="1.7"/>')
        if n['kind']=='user':out.append(f'<text x="{x+w/2}" y="{y+h+25}" text-anchor="middle" class="node">客戶</text>')
        else:
            start=y+h/2-(len(n['lines'])-1)*13+7+(11 if n['kind']=='db' else 0)
            for i,l in enumerate(n['lines']):out.append(f'<text x="{x+w/2}" y="{start+i*26}" text-anchor="middle" class="node">{escape(l)}</text>')
    for a in g['edges']:
        if a['label']:out.append(f'<text x="{a["lx"]}" y="{a["ly"]}" text-anchor="middle" class="label">{escape(a["label"])}</text>')
    fy=g['height']-100
    for i,t in enumerate(g['notes']):out.append(f'<text x="50" y="{fy+i*28}" class="foot">{escape(t)}</text>')
    out.append('</svg>');return ''.join(out)

def drawio():
    root=ET.Element('mxfile',host='app.diagrams.net',type='device')
    for g in GRAPHS:
        d=ET.SubElement(root,'diagram',id=g['id'],name=g['title']);m=ET.SubElement(d,'mxGraphModel',dx='1900',dy='1130',grid='1',gridSize='10',page='1',pageWidth=str(g['width']),pageHeight=str(g['height']))
        r=ET.SubElement(m,'root');ET.SubElement(r,'mxCell',id='0');ET.SubElement(r,'mxCell',id='1',parent='0')
        def box(id,value,x,y,w,h,style):
            c=ET.SubElement(r,'mxCell',id=id,value=value,style=style,vertex='1',parent='1');ET.SubElement(c,'mxGeometry',x=str(x),y=str(y),width=str(w),height=str(h),attrib={'as':'geometry'})
        base='html=1;whiteSpace=wrap;fontFamily=Microsoft JhengHei;fontColor=#203748;'
        box('title',g['title'],50,20,g['width']-100,45,base+'text;align=left;fontSize=29;fontStyle=1;')
        box('subtitle',g['subtitle'],50,65,g['width']-100,35,base+'text;align=left;fontSize=18;')
        for i,a in enumerate(g['groups']):box('group'+str(i),a['label'],a['x'],a['y'],a['w'],a['h'],base+'rounded=1;fillColor=#f8fafc;strokeColor=#c9d5de;dashed=1;verticalAlign=top;align=left;spacingTop=10;spacingLeft=15;fontSize=17;')
        for n in g['nodes']:
            fill,stroke=PALETTE[n['kind']];shape='shape=cylinder3;boundedLbl=1;backgroundOutline=1;size=18;' if n['kind']=='db' else 'shape=umlActor;' if n['kind']=='user' else 'rounded=1;arcSize=10;'
            box(n['id'],'<br>'.join(escape(l) for l in n['lines']),n['x'],n['y'],n['w'],n['h'],base+shape+f'fillColor={fill};strokeColor={stroke};fontSize=19;')
        for i,a in enumerate(g['edges']):
            # Explicit terminal points and waypoints preserve the reviewed orthogonal route.
            style=base+'edgeStyle=none;rounded=0;endArrow=block;endFill=1;strokeWidth=2;fontSize=16;labelBackgroundColor=#ffffff;'+('startArrow=block;startFill=1;' if a['both'] else '')+('dashed=1;' if a['kind']=='pending' else '')+'strokeColor='+{'main':'#3f6687','data':'#748290','pending':'#aa7c2e'}[a['kind']]+';'
            c=ET.SubElement(r,'mxCell',id='edge'+str(i),value='',style=style,edge='1',parent='1');geo=ET.SubElement(c,'mxGeometry',relative='1',attrib={'as':'geometry'})
            for pt,key in [(a['pts'][0],'sourcePoint'),(a['pts'][-1],'targetPoint')]:ET.SubElement(geo,'mxPoint',x=str(pt[0]),y=str(pt[1]),attrib={'as':key})
            if len(a['pts'])>2:
                ar=ET.SubElement(geo,'Array',attrib={'as':'points'})
                for pt in a['pts'][1:-1]:ET.SubElement(ar,'mxPoint',x=str(pt[0]),y=str(pt[1]))
            if a['label']:box('label'+str(i),escape(a['label']),a['lx']-170,a['ly']-22,340,32,base+'text;align=center;fontSize=16;fillColor=#ffffff;')
        for i,t in enumerate(g['notes']):box('foot'+str(i),t,50,g['height']-120+i*30,g['width']-100,30,base+'text;align=left;fontSize=17;')
    ET.indent(root);return ET.tostring(root,encoding='unicode')

for g in GRAPHS:(ROOT/(g['id']+'.svg')).write_text(svg(g),encoding='utf8')
(ROOT/'代理支付整體架構.drawio').write_text(drawio(),encoding='utf8')
(ROOT/'architecture-data.json').write_text(json.dumps(GRAPHS,ensure_ascii=False,indent=2),encoding='utf8')
labels={'internal':'小樹購平台','visa':'外部商戶・Visa','mastercard':'外部商戶・Mastercard'}
html='<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>代理支付整體架構圖</title><style>body{margin:0;background:#eef2f5;font-family:"Microsoft JhengHei",sans-serif;color:#203748}header{padding:18px 24px;background:white;display:flex;gap:12px;flex-wrap:wrap;align-items:center}button,a{font:inherit}button{padding:9px 16px;border:1px solid #9caebe;border-radius:6px;background:white;color:#203748;cursor:pointer}button[aria-pressed=true]{background:#203748;color:white}.tools{padding:12px 24px}.frame{overflow:auto;background:white;margin:0 20px 20px;border:1px solid #d8e0e6}.frame svg{display:block;width:100%;min-width:1100px;height:auto}p{margin:6px 0}a{color:#216579}#downloads{display:flex;gap:18px}button:focus-visible,a:focus-visible{outline:3px solid #ae7b25}@media print{header,.tools{display:none}.frame{border:0;margin:0;overflow:visible}.frame svg{min-width:0}}</style><header><b>交易整體架構圖</b>'+''.join(f'<button type="button" data-id="{i}" aria-pressed="{str(i=="internal").lower()}">{l}</button>' for i,l in labels.items())+'</header><div class="tools"><p>實線：商務／付款主要互動　灰線：資料與控管　金色虛線：介接或角色待確認　雙向箭頭包含請求與結果</p><p>藍色：既有付款能力　綠色：代理相關能力　黃色：待確認　白色：商務與資料角色</p><div id="downloads"></div></div><div class="frame" id="frame"></div><script>const diagrams='+json.dumps({g['id']:svg(g) for g in GRAPHS},ensure_ascii=False).replace('</','<\\/')+';function show(id){document.getElementById("frame").innerHTML=diagrams[id];document.querySelectorAll("button[data-id]").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.id===id)));document.getElementById("downloads").innerHTML=`<a href="${id}.png">PNG 圖片</a><a href="${id}.svg">SVG 向量圖</a><a href="代理支付整體架構.drawio">可編輯 Draw.io 三頁檔</a>`;}document.querySelectorAll("button[data-id]").forEach(b=>b.onclick=()=>show(b.dataset.id));show("internal");</script></html>'
(ROOT/'index.html').write_text(html,encoding='utf8')
print('Created 3 SVGs, HTML viewer, and editable 3-page Draw.io file.')
