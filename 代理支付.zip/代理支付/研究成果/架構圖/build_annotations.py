"""Build annotated architecture views without replacing the original research diagrams."""
from pathlib import Path
from html import escape
import json, copy, math, unicodedata
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
OUT = ROOT / '檢核註記版'
OUT.mkdir(exist_ok=True)
SOURCES = {
 'V1': ('Visa VIC Concepts', 'https://developer.visa.com/docs/visa-intelligent-commerce/concepts'),
 'V2': ('Visa Production Readiness', 'https://developer.visa.com/docs/visa-intelligent-commerce/production-readiness'),
 'V3': ('Visa TAP Specifications', 'https://developer.visa.com/docs/trusted-agent-protocol/trusted-agent-protocol-specifications'),
 'V4': ('Visa VIC Enrollment', 'https://developer.visa.com/docs/visa-intelligent-commerce/docs-getting-started'),
 'V5': ('Visa VIC Workflows', 'https://developer.visa.com/docs/visa-intelligent-commerce/workflows'),
 'M1': ('Mastercard Agent Pay Acceptance Framework', 'https://www.mastercard.com/global/en/news-and-trends/stories/2025/agentic-commerce-framework.html'),
 'M2': ('VI Overview · v0.1 draft', 'https://verifiableintent.dev/spec/'),
 'M3': ('VI Credential Format · v0.1 draft', 'https://verifiableintent.dev/spec/credential-format/'),
 'M4': ('VI Constraints · Autonomous only', 'https://verifiableintent.dev/spec/constraints/'),
 'M5': ('Mastercard Agent Pay 公告', 'https://investor.mastercard.com/investor-news/investor-news-details/2025/Mastercard-Unveils-Agent-Pay-Pioneering-Agentic-Payments-Technology-to-Power-Commerce-in-the-Age-of-AI/default.aspx'),
 'M6': ('VI Security Model · v0.1 draft', 'https://verifiableintent.dev/spec/security-model/'),
}
# Each bank action is a proposal. The two source columns describe different mechanisms,
# not a claim that both networks expose identical APIs or require identical modules.
CONTROLS = [
 dict(id='P',title='前置｜Agent 身分、金鑰與操作權限',
 bank='建立服務身分、可信金鑰與API權限；工具執行層限制可用操作，模型不保管私鑰。',
 visa='VARS供代理註冊／金鑰驗證；VIC另有API驗證與適用的agentSignature檢查。',
 mc='受理框架先註冊、驗證Agent，再啟用Agentic Token交易能力。',
 limit='註冊只確認身分／資格，不代表客戶已同意購買。', fail='來源不可信或權限不足：拒絕該次操作。',sources=['V1','V4','M1']),
 dict(id='A',title='A｜卡片準備與安全付款參照',
 bank='沿用合格安全介面與卡片保管服務；確認客戶與付款方式關聯，只讓Agent使用受控參照。',
 visa='VTS處理Token設定；VPP／裝置綁定支援適用的使用者驗證。',
 mc='Agentic Token提供代理付款的代碼化憑證；VI L1另綁使用者身分與公鑰。',
 limit='卡片參照、VI身分證據與網路支付Token不可互換；本行不可假定自發Token被外部受理。', fail='卡片或驗證不合格：停止付款設定。',sources=['V4','M3','M5']),
 dict(id='B',title='B｜建立選購委任與確認證據',
 bank='綁定客戶、條件、版本、期限、確認紀錄；本版僅授權選購及準備，購買須另核准。',
 visa='Purchase Instruction／Mandate把購買意圖、支出參數與驗證串接；Human-in-the-Loop記錄特定交易。',
 mc='VI Immediate在交易確定後簽最終值；Autonomous L2才是事先受限付款委任。',
 limit='本版B是選購委任，不直接等同Visa已成立的付款指示或VI自主L2。', fail='客戶未確認、版本失效或已取消：不可繼續執行。',sources=['V1','V2','M2','M4']),
 dict(id='C1',title='C1｜平台驗證Agent請求',
 bank='平台閘道驗服務來源及操作權限；可評估mTLS／請求簽章，依設計檢查效期與重播。',
 visa='TAP Agent Recognition Signature：商戶／防護服務驗簽；瀏覽及結帳皆有對應互動。',
 mc='Web Bot Auth：受理框架讓CDN等驗證代理身分，再接受代理互動。',
 limit='只涵蓋該機制簽署的資訊；不是整筆訂單正確或客戶付款同意的證明。', fail='驗證失敗：依平台政策拒絕或走另定安全路徑。',sources=['V3','M1']),
 dict(id='C2',title='C2｜客戶辨識與私人資料權限',
 bank='另設客戶帳戶連結及存取授權；讀購物車、地址、會員資料前檢查範圍與有效性。',
 visa='TAP Consumer Recognition Object將消費者辨識資料連結到代理請求，供商戶辨識關係。',
 mc='受理框架列Consumer Identity資料，用於代理互動中的客戶辨識及個人化。',
 limit='能辨識客戶不代表可讀全部資料，更不代表可付款；公開商品查詢未必需登入。', fail='無私人資料授權：只使用允許的公開資料或請求授權。',sources=['V3','M1']),
 dict(id='C3',title='C3｜可信商品資料與結帳明細',
 bank='由平台取得商品、賣方、數量及含運總額，保存來源與明細版本；確認準備動作是否形成訂單。',
 visa='TAP保護適用代理請求；商品是否符合需求仍須Agent Provider檢查，未保證鎖價。',
 mc='VI草案使用商戶簽署的checkout JWT描述結帳內容，供後續授權證據綁定。',
 limit='請求簽章不等於平台回應已簽；商戶簽結帳資料也不代表已保留庫存或保證履約。', fail='缺關鍵資料：不列為可核准交易；價格異動重新取得。',sources=['V2','V3','M3']),
 dict(id='D',title='D｜交易條件比對與規則執行',
 bank='由受控規則取得已確認委任與可信明細，核對品項、數量、總額、賣方及版本；留比對紀錄。',
 visa='正式參與要求：請求付款憑證前，Agent Provider須確認交易符合消費者指示。',
 mc='VI自主模式驗證者檢查L3是否符合L2限制；Immediate驗最終值，不套用自主限制流程。',
 limit='「好清潔」等偏好需有判斷依據；兩家機制都不等於自動完成所有自然語言需求比對。', fail='不符條件：重選或請客戶修改委任，不直接送付款。',sources=['V2','M2','M4']),
 dict(id='E1',title='E1｜客戶核准並綁定具體交易',
 bank='顯示商品、賣方、總額與取捨；保存具體核准內容及驗證證據，執行時核對同一份內容。',
 visa='除獲准例外，客戶須審閱交易並明確同意向商戶釋出Token；付款指示須適用驗證。',
 mc='VI Immediate由使用者對最終交易值簽署L2；checkout_hash連結結帳與付款內容。',
 limit='本版採客戶最後核准，不預設需要自主L3；按確認、身分驗證與付款授權仍有不同目的。', fail='拒絕或關鍵內容改變：停止或取得新核准。',sources=['V2','M2','M3']),
 dict(id='E2',title='E2｜受控付款與防重複執行',
 bank='付款層重查委任／核准／明細效期，管理交易識別與執行狀態；憑證留安全環境並走適用驗證。',
 visa='VIC在有效指示與mandate下取得付款憑證；Token／cryptogram供既有授權路徑使用。',
 mc='Agentic Token保護支付資料並支援交易控制；VI提供意圖證據，仍須既有支付授權。',
 limit='網路／發卡行檢查與本行執行控制分工另定；取得憑證不等於付款核准或訂單成立。', fail='結果不明：先查原交易，禁止直接重送購買。',sources=['V1','V5','M1','M5']),
 dict(id='F',title='F｜結果回報、取消及證據追蹤',
 bank='關聯委任、比對、核准、訂單與付款ID；核實各狀態，設計查詢、取消、撤銷／退款及通知。',
 visa='VIC有交易事件確認與指示取消流程；須依憑證及交易生命週期處理。',
 mc='框架含可供追查的意圖資料；VI是證據格式，未包辦完整取消、退款及爭議流程。',
 limit='取消委任不等於取消已送付款；VI v0.1未完整定義憑證撤銷協定。', fail='狀態不一致：進查詢與補償流程，保留待查狀態。',sources=['V5','M1','M6']),
]

def wrap(text, units):
    lines=[]; line=''; n=0
    for c in text:
        k=2 if unicodedata.east_asian_width(c) in 'WF' else 1
        if n+k>units: lines.append(line); line=''; n=0
        line+=c; n+=k
    if line: lines.append(line)
    return lines

graphs=copy.deepcopy(json.loads((ROOT/'architecture-data.json').read_text(encoding='utf8')))
bank=dict(id='bank',title='銀行自建代理支付｜檢核動作與國際組織參照',subtitle='研究基準：Agent完成選購與交易準備；客戶核准具體交易後，系統才執行購買。',width=1800,height=1130,nodes=[],edges=[],groups=[],notes=[
 'P～F標記對應下方註解卡；功能是邏輯責任，可沿用、合併或委外，不等同必須新建同名系統。',
 '本行動作為設計建議；API、卡片參照、庫存／鎖價、驗證及付款路由須確認。',
 '圖為工作關係；最終下單與付款先後依平台介面決定。實際交易全程仍須有效權限與狀態控制。'])
def n(id,x,y,w,h,lines,kind='new'):
    bank['nodes'].append(dict(id=id,x=x,y=y,w=w,h=h,lines=lines,kind=kind))
def e(a,b,pts,label,lx,ly,kind='main',both=False):
    bank['edges'].append(dict(a=a,b=b,pts=pts,label=label,lx=lx,ly=ly,kind=kind,both=both))
n('entry',100,220,270,110,['客戶安全入口','需求確認／交易核准','身分驗證與證據留存'],'plain')
n('agent',500,220,300,110,['銀行Agent／工具服務','需求理解・比較・選定','私鑰與支付資料不進模型'],'plain')
n('gateway',1000,220,320,110,['平台API／請求驗證','Agent辨識・操作權限','客戶資料存取授權'],'unknown')
n('merchant',1440,220,260,110,['小樹購／合作平台','商品・結帳明細','API及保留能力待確認'],'unknown')
n('db',500,490,300,110,['委任與證據管理','客戶／條件／版本／期限','狀態與確認紀錄'],'db')
n('guard',1000,490,320,110,['工具執行權限控管','查委任與允許的操作','核准前禁止正式購買'])
n('result',1440,490,260,110,['結果／異常處理','付款・接單・履約分開','回查後通知客戶'])
n('review',100,760,270,110,['具體交易核准','顯示商品／賣方／總額','保存核准內容與證據'])
n('match',500,760,300,110,['交易比對／規則執行','委任 × 可信結帳明細','符合後才供客戶核准'])
n('execute',1000,760,320,110,['購買執行與付款控制','重查核准／版本／狀態','一次性執行與結果查詢'])
n('payment',1440,760,260,110,['安全付款整合','適用驗證／付款授權','卡片參照及路由待確認'],'existing')
e('entry','agent',[(370,275),(500,275)],'B需求／委任',435,250,both=True)
e('agent','db',[(650,330),(650,490)],'保存／查有效版本',650,420,'data',True)
e('agent','guard',[(800,275),(870,275),(870,545),(1000,545)],'每次工具操作先控權',865,455,'data')
e('db','guard',[(800,545),(1000,545)],'委任／權限',900,520,'data')
e('guard','gateway',[(1160,490),(1160,330)],'允許後呼叫平台',1160,420)
e('gateway','merchant',[(1320,275),(1440,275)],'C查詢／準備',1380,250,'pending',True)
e('merchant','match',[(1700,275),(1740,275),(1740,660),(650,660),(650,760)],'可信結帳資料／核對',1210,645,'pending')
e('db','match',[(650,600),(650,760)],'已確認條件',650,715,'data')
e('match','review',[(500,815),(370,815)],'D通過後呈現',435,790)
e('review','execute',[(235,870),(235,940),(1160,940),(1160,870)],'E1客戶核准 → E2執行前重查；關鍵內容變動須重新核准',700,925)
e('execute','payment',[(1320,815),(1440,815)],'付款請求',1380,790,'pending',True)
e('payment','result',[(1570,760),(1570,600)],'付款／訂單結果',1570,705,'data')
graphs.insert(0,bank)

POSITIONS={
 'bank':{'P':(500,180),'A':(1440,720),'B':(500,450),'C1':(1000,180),'C2':(970,350),'C3':(1440,180),'D':(500,720),'E1':(100,720),'E2':(1000,720),'F':(1440,450)},
 'internal':{'P':(440,390),'A':(850,620),'B':(150,810),'C1':(430,210),'C2':(200,390),'C3':(720,210),'D':(440,620),'E1':(200,480),'E2':(850,390),'F':(760,900)},
 'visa':{'P':(415,450),'A':(1585,260),'B':(130,820),'C1':(895,210),'C2':(200,450),'C3':(1215,435),'D':(415,690),'E1':(200,540),'E2':(1275,260),'F':(1215,800)},
 'mastercard':{'P':(415,450),'A':(1585,260),'B':(130,820),'C1':(895,210),'C2':(200,450),'C3':(1215,435),'D':(415,690),'E1':(200,540),'E2':(1275,260),'F':(1215,800)},
}
for g in graphs:
    if g['id']!='bank':
        g['subtitle']='註記研究版｜P～F對照本行動作及兩家機制；客戶最後核准，非全部自主付款。'
        for a in g['edges']:
            if a['a']=='agent' and a['b']=='merchant':
                a['label']='C查詢／E核准後購買／F結果'
        # Explicitly point approval markers to the existing safe customer entry.
        for a in g['nodes']:
            if a['id']=='entry': a['lines']=['Agent入口','委任／交易核准']
    g['originalHeight']=g['height']
    g['cardsTop']=g['height']+55
    g['height']=g['cardsTop']+5*350+130

PALETTE={'plain':('#ffffff','#627687'),'existing':('#dceaff','#6d91bc'),'new':('#e9f3ed','#739985'),'unknown':('#fff2d7','#bc9550'),'db':('#ffffff','#627687'),'user':('#ffffff','#627687')}
COLORS={'main':'#3f6687','data':'#748290','pending':'#aa7c2e'}
mxroot=ET.Element('mxfile',host='app.diagrams.net',type='device')

def render(g):
    w,h=g['width'],g['height']
    d=ET.SubElement(mxroot,'diagram',id=g['id'],name=g['title'])
    m=ET.SubElement(d,'mxGraphModel',grid='1',gridSize='10',page='1',pageWidth=str(w),pageHeight=str(h))
    r=ET.SubElement(m,'root');ET.SubElement(r,'mxCell',id='0');ET.SubElement(r,'mxCell',id='1',parent='0')
    uid=0
    def cell(value,x,y,bw,bh,style):
        nonlocal uid
        uid+=1
        c=ET.SubElement(r,'mxCell',id='v'+str(uid),value=value,style='html=1;fontFamily=Microsoft JhengHei;fontColor=#203748;'+style,vertex='1',parent='1')
        ET.SubElement(c,'mxGeometry',x=str(x),y=str(y),width=str(bw),height=str(bh),attrib={'as':'geometry'})
    s=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><title>{escape(g["title"])}</title><desc>本行自建研究建議與國際組織公開機制對照。編號P至F對應檢核註記。</desc><defs>']
    for k,c in COLORS.items():s.append(f'<marker id="{k}" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto-start-reverse"><path d="M0 0L9 4.5L0 9Z" fill="{c}"/></marker>')
    s.append('</defs><style>text{font-family:"Microsoft JhengHei","Noto Sans TC",Arial,sans-serif;fill:#203748}</style>')
    s.append(f'<rect width="{w}" height="{h}" fill="white"/>')
    def rect(x,y,bw,bh,fill='#fff',stroke='#b8cbd5',radius=9):
        s.append(f'<rect x="{x}" y="{y}" width="{bw}" height="{bh}" rx="{radius}" fill="{fill}" stroke="{stroke}"/>')
        cell('',x,y,bw,bh,f'rounded=1;fillColor={fill};strokeColor={stroke};')
    def text(t,x,y,size=18,bold=False,anchor='start',color='#203748',width=None):
        s.append(f'<text x="{x}" y="{y}" text-anchor="{anchor}" style="font-size:{size}px;fill:{color};font-weight:{600 if bold else 400}">{escape(t)}</text>')
        bw=width or (w-100 if anchor=='start' else 360)
        cell(escape(t),x if anchor=='start' else x-bw/2,y-size,bw,size+8,f'text;align={"left" if anchor=="start" else "center"};verticalAlign=middle;fontSize={size};fontStyle={1 if bold else 0};whiteSpace=wrap;')
    text(g['title'],50,52,29,True)
    text(g['subtitle'],50,87,18)
    text('綠色：本行可考慮的功能　藍色：既有付款參考　黃色：介接待確認　圓點：下方對照卡',50,120,17,color='#526879')
    for q in g['groups']:
        rect(q['x'],q['y'],q['w'],q['h'],'#f8fafc','#d4dce3')
        text(q['label'],q['x']+18,q['y']+29,17)
    for a in g['edges']:
        path='M'+' L'.join(f'{x},{y}' for x,y in a['pts']);c=COLORS[a['kind']]
        s.append(f'<path d="{path}" fill="none" stroke="{c}" stroke-width="2" marker-end="url(#{a["kind"]})" '+(f'marker-start="url(#{a["kind"]})" ' if a['both'] else '')+('stroke-dasharray="6 5" ' if a['kind']=='pending' else '')+'/>')
        uid+=1
        ce=ET.SubElement(r,'mxCell',id='e'+str(uid),value='',edge='1',parent='1',style=f'edgeStyle=none;endArrow=block;strokeWidth=2;strokeColor={c};'+('startArrow=block;' if a['both'] else '')+('dashed=1;' if a['kind']=='pending' else ''))
        geo=ET.SubElement(ce,'mxGeometry',relative='1',attrib={'as':'geometry'})
        for p,k in [(a['pts'][0],'sourcePoint'),(a['pts'][-1],'targetPoint')]:ET.SubElement(geo,'mxPoint',x=str(p[0]),y=str(p[1]),attrib={'as':k})
        ar=ET.SubElement(geo,'Array',attrib={'as':'points'})
        for p in a['pts'][1:-1]:ET.SubElement(ar,'mxPoint',x=str(p[0]),y=str(p[1]))
    for n in g['nodes']:
        x,y,bw,bh=[n[k] for k in ('x','y','w','h')];fill,stroke=PALETTE[n['kind']]
        rect(x,y,bw,bh,fill,stroke)
        yy=y+bh/2-(len(n['lines'])-1)*13+7
        for j,t in enumerate(n['lines']):text(t,x+bw/2,yy+j*26,19,anchor='middle',width=bw)
    for a in g['edges']:
        if a['label']:
            # White stroke is confined to edge labels, keeping the route readable.
            s.append(f'<text x="{a["lx"]}" y="{a["ly"]}" text-anchor="middle" style="font-size:16px;paint-order:stroke;stroke:white;stroke-width:7;stroke-linejoin:round">{escape(a["label"])}</text>')
            cell(escape(a['label']),a['lx']-310,a['ly']-20,620,30,'text;align=center;fontSize=16;fillColor=#ffffff;')
    for key,(x,y) in POSITIONS[g['id']].items():
        if g['id']=='bank':
            ax,ay=(1000,330) if key=='C2' else (x,y+40)
            s.append(f'<path d="M{x},{y}L{ax},{ay}" stroke="#8299aa" fill="none"/>')
        s.append(f'<a href="#note-{key}"><circle cx="{x}" cy="{y}" r="23" fill="#123e59" stroke="white" stroke-width="3"/><text x="{x}" y="{y+6}" text-anchor="middle" style="font-size:17px;font-weight:600;fill:white">{key}</text></a>')
        cell(key,x-23,y-23,46,46,'ellipse;fillColor=#123e59;strokeColor=#ffffff;fontColor=#ffffff;fontSize=17;fontStyle=1;align=center;')
    for i,t in enumerate(g['notes']):text(t,50,g['originalHeight']-100+i*28,17)
    text('檢核對照｜本行動作是研究建議；Visa為公開產品文件，Mastercard的VI另標為草案',50,g['cardsTop']-15,23,True)
    cw=(w-130)/2
    for i,c in enumerate(CONTROLS):
        x=50+(i%2)*(cw+30);y=g['cardsTop']+(i//2)*350
        s.append(f'<g id="note-{c["id"]}">')
        rect(x,y,cw,328,'#f7fafc','#c4d5df')
        label=c['id']+'　'+(c['title'] if c['id']=='P' else c['title'].split('｜',1)[1])
        text(label,x+18,y+32,21,True,width=cw-36)
        yy=y+62
        for field,label,color in [('bank','本行建議','#245b40'),('visa','Visa','#264f8d'),('mc','Mastercard','#8b4818'),('limit','邊界','#5d6470'),('fail','未通過','#8a3030')]:
            lines=wrap(label+'｜'+c[field],int((cw-36)/9.2))
            for line in lines:
                text(line,x+18,yy,17,color=color,width=cw-36);yy+=23
        if yy>y+302:raise ValueError(f'Card overflow {g["id"]} {c["id"]}: {yy-y}')
        text('來源：'+ '／'.join(c['sources'])+'（詳見閱讀頁與來源說明）',x+18,y+309,15,color='#637783',width=cw-36)
        s.append('</g>')
    text('讀圖限制：身分可信 ≠ 有操作權限 ≠ 商品符合條件 ≠ 客戶核准 ≠ 付款核准 ≠ 訂單成立。',50,h-65,19,True)
    text('研究整理：2026-11-19｜所有本行介面與路由待盤點；簽章只保護指定範圍，自建證據不自動獲外部互認。',50,h-32,17)
    s.append('</svg>')
    return ''.join(s)

for g in graphs:(OUT/(g['id']+'.svg')).write_text(render(g),encoding='utf8')
ET.indent(mxroot)
(OUT/'代理支付檢核註記.drawio').write_text(ET.tostring(mxroot,encoding='unicode'),encoding='utf8')
(OUT/'註記內容.json').write_text(json.dumps(dict(graphs=graphs,controls=CONTROLS,sources=SOURCES),ensure_ascii=False,indent=2),encoding='utf8')
labels={'bank':'銀行自建・主圖','internal':'小樹購・原架構註記','visa':'外部Visa・註記','mastercard':'外部Mastercard・註記'}
buttons=''.join(f'<button data-id="{k}" aria-pressed="{str(k=="bank").lower()}">{v}</button>' for k,v in labels.items())
details=''
for c in CONTROLS:
    details+=f'<details id="detail-{c["id"]}"><summary>{escape(c["id"]+"　"+c["title"])}</summary>'
    for key,label in [('bank','本行建議'),('visa','Visa做法'),('mc','Mastercard做法'),('limit','檢核邊界'),('fail','未通過時')]:details+=f'<p><b>{label}：</b>{escape(c[key])}</p>'
    details+='<p>來源：'+'、'.join(f'<a href="{SOURCES[k][1]}" target="_blank" rel="noopener">{k} {escape(SOURCES[k][0])}</a>' for k in c['sources'])+'</p></details>'
html='''<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>代理支付｜銀行自建檢核註記</title><style>
*{box-sizing:border-box}body{margin:0;background:#edf2f6;color:#203748;font-family:"Microsoft JhengHei",Arial,sans-serif}header,main{max-width:1600px;margin:auto;padding:22px}h1{font-size:26px;margin:0 0 10px}p{line-height:1.75;margin:8px 0}nav,.downloads{display:flex;gap:10px;flex-wrap:wrap;margin:14px 0}button,a{font:inherit}button{background:white;color:#203748;border:1px solid #a8bdcb;border-radius:7px;padding:10px 14px;cursor:pointer}button[aria-pressed=true]{background:#123e59;color:white}a{color:#1d607e}button:focus-visible,a:focus-visible,summary:focus-visible{outline:3px solid #c78831;outline-offset:3px}.canvas{overflow:auto;background:white;border:1px solid #cbd9e2;border-radius:10px}.canvas svg{display:block;width:100%;min-width:1100px;height:auto}details{background:white;margin:10px 0;padding:14px 18px;border-radius:8px;border:1px solid #cedce4}summary{font-weight:bold;cursor:pointer}details p{overflow-wrap:anywhere}.legend{padding:12px 16px;background:#fff8e8;border-left:4px solid #b78535}#detail-list{max-width:1200px}.skip{display:inline-block;margin:4px 10px 4px 0}@media(max-width:600px){header,main{padding:14px}h1{font-size:23px}}@media print{nav,button,.downloads{display:none}.canvas{overflow:visible;border:0}.canvas svg{min-width:0}}
</style><header><h1>銀行自建代理支付｜檢核動作與兩家機制對照</h1><p>Agent完成選購與準備，客戶核准具體交易後才執行購買。圖上P～F標記對應下方註記卡；點標記可直接展開文字解說。</p><p class="legend">本行動作＝設計建議；Visa＝公開產品要求；Mastercard＝受理框架／Agentic Token及另標的VI公開草案。功能可沿用或合併，實際介接與外部互認待確認。</p><nav>'''+buttons+'''</nav><div class="downloads" id="downloads"></div><button id="zoom">切換原尺寸／適合寬度</button> <a href="#detail-list">跳到可展開的文字解說</a> <a href="../index.html">原架構圖</a></header><main><div class="canvas" id="canvas"></div><div id="detail-list"><h2>逐點解說與官方來源</h2>'''+details+'''</div><p>整理日期：2026-11-19。參照信任機制不代表本行自行簽發的Token或證據已被商戶／網路承認；此版未執行任何付款API。</p></main><script>const diagrams='''+json.dumps({g['id']:(OUT/(g['id']+'.svg')).read_text(encoding='utf8') for g in graphs},ensure_ascii=False).replace('</','<\\/')+''';let actual=false;function show(id){document.getElementById('canvas').innerHTML=diagrams[id];document.querySelectorAll('button[data-id]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.id===id)));document.getElementById('downloads').innerHTML=`<a href="${id}.png">PNG圖片</a><a href="${id}.svg">SVG向量圖</a><a href="代理支付檢核註記.drawio">可編輯Draw.io四頁檔</a><a href="檢核對照與來源.md">完整註解與來源</a>`;size();document.querySelectorAll('#canvas svg a').forEach(a=>a.onclick=e=>{e.preventDefault();const id=a.getAttribute('href').replace('#note-','');const d=document.getElementById('detail-'+id);d.open=true;d.scrollIntoView({behavior:'smooth',block:'start'});});}function size(){document.querySelector('#canvas svg').style.width=actual?'auto':'100%';}document.querySelectorAll('button[data-id]').forEach(b=>b.onclick=()=>show(b.dataset.id));document.getElementById('zoom').onclick=()=>{actual=!actual;size()};show('bank');</script></html>'''
(OUT/'index.html').write_text(html,encoding='utf8')
md=['# 代理支付檢核註記｜閱讀方式與來源','', '2026-11-19。以銀行自行開發為主線，沿用客戶最後核准的方向。原圖不覆寫。','',
    '[開啟註記閱讀頁](index.html)；[可編輯四頁Draw.io](代理支付檢核註記.drawio)。','',
    '銀行自建主圖重新安排了檢核與核准位置；其餘三頁在既有架構上加註。編號是對照索引，不是API呼叫序號。E1在原圖標於客戶入口；E2標於付款控制。F標於狀態管理或結果回傳的邏輯位置，並非新增網路付款節點。','',
    '本行欄為建議，不是Visa或Mastercard規定必建的系統。機制名稱、草案模式與角色不能混用；未取得本行能力、正式合約或完整Agent Pay API。','']
for c in CONTROLS:
    md += ['## '+c['id']+' '+c['title'],'']
    for key,label in [('bank','本行建議'),('visa','Visa做法'),('mc','Mastercard做法'),('limit','檢核邊界'),('fail','未通過時')]:md += ['- **'+label+'**：'+c[key]]
    md += ['- **官方來源**：'+'、'.join(f'[{k} {SOURCES[k][0]}]({SOURCES[k][1]})' for k in c['sources']),'']
md += ['## 需要向行內確認','', '- 小樹購的API驗證、服務身分及客戶帳戶授權能否沿用。','- 商品／結帳明細能否獨立取得，是否有保留、鎖價及期限。','- 既有卡片參照、安全保管與EPOS／PH的適用邊界。','- 客戶核准與付款驗證方式、核准內容變更的處理。','- 交易查詢、重複執行控制與取消／撤銷／退款的責任分工。','', '## 證據與查核範圍','', '本版依既有官方研究及本輪取得的官方資料整理。TAP、VIC Concepts／正式參與要求與Mastercard受理框架已在前續查核取得；本輪再讀VI Credential Format。部分Visa頁面直接開啟失敗時，使用官方頁面的搜尋索引文字，不把本版當成生產規格。VI為v0.1草案；無證據證明所有Agent Pay部署均使用這套草案。','', '原始研究參考：../../../代理支付官方研究/02_Visa的實際作法.md 與03_Mastercard的實際作法.md。']
(OUT/'檢核對照與來源.md').write_text('\n'.join(md),encoding='utf8')
print(json.dumps({'views':len(graphs),'controls':len(CONTROLS),'out':str(OUT)},ensure_ascii=False))
