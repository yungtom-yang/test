const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {launchBrowser}=require('../browser_runtime.cjs');
(async()=>{
 const dir=path.join(__dirname,'檢核註記版');
 const data=JSON.parse(fs.readFileSync(path.join(dir,'註記內容.json'),'utf8'));
 const browser=await launchBrowser();
 const page=await browser.newPage({deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 const results=[];
 for(const g of data.graphs){
  await page.setViewportSize({width:g.width,height:g.height});
  await page.setContent('<!doctype html><html><body style="margin:0">'+fs.readFileSync(path.join(dir,g.id+'.svg'),'utf8')+'</body></html>');
  await page.screenshot({path:path.join(dir,g.id+'.png'),fullPage:true});
  const checks=await page.evaluate(()=>{
   const root=document.querySelector('svg');const v=root.viewBox.baseVal;
   const outside=[...root.querySelectorAll('text')].filter(t=>{const b=t.getBBox();return b.x<0||b.y<0||b.x+b.width>v.width+1||b.y+b.height>v.height+1}).map(t=>t.textContent);
   const cards=[...root.querySelectorAll('g[id^="note-"]')].map(c=>{
    const r=c.querySelector('rect').getBBox();
    const bad=[...c.querySelectorAll('text')].filter(t=>{const b=t.getBBox();return b.x<r.x||b.y<r.y||b.x+b.width>r.x+r.width||b.y+b.height>r.y+r.height}).map(t=>t.textContent);
    return {id:c.id,outside:bad};
   });return {outside,cards};
  });
  if(checks.outside.length||checks.cards.some(c=>c.outside.length))throw Error(JSON.stringify({id:g.id,...checks}));
  if(g.id==='bank'){
   await page.screenshot({path:path.join(dir,'銀行自建主圖預覽.png'),clip:{x:0,y:0,width:g.width,height:g.originalHeight}});
   await page.screenshot({path:path.join(dir,'註記卡預覽.png'),clip:{x:0,y:g.cardsTop-45,width:g.width,height:750}});
  }
  results.push({view:g.id,cards:checks.cards.length,textBounds:'passed'});
 }
 await page.goto(pathToFileURL(path.join(dir,'index.html')).href);
 await page.setViewportSize({width:1500,height:900});
 for(const g of data.graphs){
  await page.locator(`button[data-id="${g.id}"]`).click();
  if(await page.locator('#canvas svg').count()!==1)throw Error('Missing diagram '+g.id);
  if(await page.locator('button[aria-pressed=true]').getAttribute('data-id')!==g.id)throw Error('Wrong selection');
  await page.locator('#canvas a[href="#note-C1"]').click();
  if(!await page.locator('#detail-C1').evaluate(e=>e.open))throw Error('Missing linked note');
 }
 await page.locator('button[data-id=bank]').click();
 await page.locator('#zoom').click();
 const actual=await page.locator('#canvas svg').evaluate(e=>e.getBoundingClientRect().width);
 if(actual!==1800)throw Error('Original-size zoom failed '+actual);
 await page.locator('#zoom').click();
 await page.setViewportSize({width:390,height:844});
 const mobileOverflow=await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth+2);
 if(mobileOverflow)throw Error('Mobile document overflow');
 if(errors.length)throw Error(errors.join('\n'));
 const report={views:results,viewerSwitching:'passed',markerLinks:'passed',zoom:'passed',mobileOverflow:false,pageErrors:errors,paymentApisExecuted:false};
 fs.writeFileSync(path.join(dir,'檢查紀錄.json'),JSON.stringify(report,null,2));
 console.log(JSON.stringify(report));
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
