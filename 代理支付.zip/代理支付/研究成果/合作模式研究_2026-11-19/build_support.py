from pathlib import Path
import re,json,csv,html,xml.etree.ElementTree as E

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent.parent
REPORT=ROOT/'代理支付官方研究/08_國際組織合作與整套代理服務委外研究.md'
text=REPORT.read_text(encoding='utf-8')
urls=dict(re.findall(r'^\[(R\d+)\]: (https://\S+)',text,re.M))
def expand_refs(m):
    value=m.group(1)
    if not re.fullmatch(r'R\d+(?:[–、]R\d+)*',value):return m.group(0)
    parts=value.split('、');ids=[]
    for p in parts:
        if '–' in p:
            a,b=p.split('–');ids.extend(f'R{n:02d}' for n in range(int(a[1:]),int(b[1:])+1))
        else:ids.append(p)
    return '、'.join(f'[{i}]' for i in ids)
text=re.sub(r'\[([^\]\n]+)\](?!:)',expand_refs,text)
text=text.replace('\\n','<br/>')
REPORT.write_text(text,encoding='utf-8')

items=[
('R01','Visa VIC能力','Visa','產品／既有研究與本輪複查','Agent提出指示、取憑證及對商戶購買；未承諾完整Agent交付','不要把支援Agent的API當成Agent成品'),
('R02','VIC Production Readiness','Visa','既有正文閱讀；本輪以已查版本對照','Agent Provider仍有同意、交易核對、紀錄及例外核准義務','須核對本行正式版本及地區'),
('R03','Intelligent Commerce Connect產品頁','Visa','本輪直接正文','多網路協調、目錄可發現性及付款相關能力','沒有完整銀行跨商戶Agent的交付契約'),
('R04','Connect發布公告，2026-04-08','Visa','本輪直接正文','單一Acceptance Platform介接；支付與商戶目錄；發布時為選定夥伴試點','發布時狀態不直接當成11月全部可用範圍'),
('R05','亞太Agentic Ready擴展，2026-11-18','Visa','直接開啟失敗；本輪官方搜尋索引可讀正文與頁面日期','區分發卡及受理端，列商務協作者與測試工作','就緒計畫與列名不等於已取得本行完整採購資格'),
('R06','Agent Suite發布，2026-01-27','Mastercard','本輪直接正文','可客製Agent及建置支援；銀行例子是卡片／帳戶等產品推薦','銀行產品推薦不等於外部商品購買；當時寫預定Q2'),
('R07','Agent Connect與Suite擴展，2026-09-09','Mastercard','直接頁取用失敗；官方搜尋索引可讀正文','商戶自有Agent、目錄、購物車與付款連接；由美國起步','計畫參與、未來功能與已可用功能分開'),
('R08','Agent Connect產品頁','Mastercard','直接頁取用失敗；官方搜尋索引可讀正文','Catalog、Cart、Payment能力；Shopping Agent偏商戶自有通路','未證明銀行跨商戶白牌即插即用'),
('R09','Merchant Cloud AI commerce產品頁','Mastercard','官方搜尋索引可讀正文','商戶通路中的對話、個人化、購物車與付款方向','will support等措辭不能一概當成全量生產可用'),
('R10','香港CardInfoLink／hoppa交易，2026-03-27','Mastercard','官方搜尋索引可讀正文','具名揭露CardInfoLink提供Agent及hoppa商戶網絡','未揭露銀行入口、全部API、臺灣範圍與白牌契約'),
('R11','臺灣星展機場接送，2026-03-26','Mastercard','官方搜尋索引可讀正文；正文標題與摘要標題不同，按正文辨識','使用者選定、驗證、綁定卡與Agentic Token完成接送交易','未揭露實際Agent供應商，不由香港案例倒推'),
('R12','機票四方交易，2026-11-12','Mastercard','前輪正文研讀；本輪官方新聞索引核對日期','Booked AI、Travelport、Basis Theory及Agent Pay分工，完成付款與出票','未承諾本行白牌、臺灣或完整退改票服務'),
('R13','Europe trusted agentic commerce','Mastercard','本輪官方搜尋索引可讀正文','受控真實交易、Priceless.com、Passkey與PayOS協調','發卡網路就緒不等於銀行已有購物Agent'),
('R14','Agenzo與Agent Gateway正式部署，2026-06-17','Affinidi，交易合作方','本輪一手合作方公告正文','CardInfoLink平台與獨立治理層；接送、機票、飯店逐筆確認的敘述','供應商／合作方陳述，不是每個卡網路profile均已核准'),
('R15','firmly Series A與Ask Agent，2026-11-05','Firmly','本輪供應商官網正文','具名商務客戶及Ask Agent商戶站內用途','具名上線屬供應商陳述；未逐一實測'),
('R16','Embedded Checkout','Firmly','本輪官方開發文件索引正文','入口保留外觀與對話，iframe承接特定結帳工作','結帳元件不是完整Agent；實際模式影響資料範圍'),
('R17','Marketplace Integration Patterns','Firmly','本輪官方開發文件索引正文','列銀行App嵌入商務模式與單一商戶購物車','前台多商戶體驗不等於單一訂單／付款跨商戶原子完成'),
('R18','Agentic Pay API','Firmly','本輪官方開發文件索引正文','抽象多網路設定、intent與完成付款階段','Firmly端點不是卡組織原生端點，網路需為destination啟用'),
('R19','Headless SDK','Firmly','本輪官方開發文件索引正文','封裝兩網路驗證與Token狀態；不提供UI','前端、調度與Agent仍須明確提供者'),
('R20','Consent & Disclosure','Firmly','本輪官方開發文件索引可讀完整相關正文','同意、留存、溝通等由入口負責，通用checkout不代為包辦','不能用通用checkout說明推翻特定支付profile要求'),
('R21','Autonomous Agent Purchasing','Firmly','直接開啟失敗；官方開發文件索引可讀正文','委任儲存與建構由destination負責；Firmly路由網路付款','持續使用等強烈敘述需對齊網路規則、效期及例外'),
('R22','Security Model','Firmly','本輪官方開發文件索引正文','真實資料流仍涉及PCI範圍；合規資料可於商業程序取得','與其他頁簡化文案不可混為全模式零PCI'),
('R23','Destination Onboarding','Firmly','本輪官方開發文件索引正文','商戶適配、付款路由及下單由服務端承接的定位','無法由輕量整合推定無營運及法遵工作'),
('R24','Agentic Tokens／PaymentSheet','PayOS','本輪供應商產品頁索引正文；版本網址有斜線差異','嵌入付款元件、Passkey及憑證；元件不完成實際購買','不是完整搜尋／選購Agent；PCI-exempt等文案需實際評估'),
('R25','PayOS＋Browserbase，2026-09-02','PayOS','直接頁取用失敗；本輪供應商索引可讀正文','瀏覽器操作與付款基礎設施分工，開發者組合','any website等文案不是所有商戶允許或可交易保證'),
('R26','Visa myfone臺灣試點，2026-06-16','Visa','本輪官方搜尋索引可讀正文','特定合作、限定環境與特定卡友，涉及VIC與TAP','不當成全市場正式開放或已完成所有未來功能'),
('R27','PayOS Wallet Terms','PayOS','本輪定向檢索Network Token Programs及VIC退出條款','可了解錢包與網路Token方案同意及退出的產品分工','不是本行的企業商業合約或所有條文審閱'),
('R28','Agentic Commerce Integration Patterns','Firmly','本輪官方開發文件索引正文','不同整合模式與商務操作由服務端承接','Hosting／Checkout／支付選項需按組合判斷'),
('R29','Agent Pay Acceptance Framework，2025-10-14','Mastercard','沿用既有正文閱讀','代理註冊、商戶受理與深入商務資料交換','不把既有表單受理路徑當成所有網站均可自動購買'),
('R30','Visa VIC Workflows','Visa','沿用既有閱讀及前輪2026-11-19複查','指示、憑證、商戶／收單送授權及結果回報分工','不是本行臺灣正式profile及整套Agent交付契約')
]
sources=[]
for i,title,owner,read,claim,limit in items:sources.append(dict(id=i,title=title,owner=owner,url=urls[i],checked='2026-11-19',read=read,claim=claim,limit=limit))
(OUT/'研究來源.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),encoding='utf-8')
lines=['# 官方來源與證據索引','','查核日：2026-11-19，Asia/Taipei。國際組織官方與供應商自述分開判讀。只列實際採用的30份來源，不把未採用搜尋結果計為研究證據。未宣稱所有原文完整封存，未執行付款API或取得報價。','','來源狀態沿用其頁面日期；搜尋引擎的相對日期不代替發布日。R05的頁面顯示2026-11-18，並非以檢索的「今天」推算。','']
for s in sources:lines.extend([f"## {s['id']}｜{s['title']}",'',f"- 一手發布者：{s['owner']}",f"- 網址：[{s['title']}]({s['url']})",f"- 閱讀方式：{s['read']}",f"- 重要證據：{s['claim']}",f"- 限制：{s['limit']}",''])
(OUT/'官方來源與證據索引.md').write_text('\n'.join(lines),encoding='utf-8')

rows=[
['候選路徑','類型','Agent供應證據','可承接內容','本輪未確認','適合比較模式','來源'],
['CardInfoLink／Agenzo＋商戶＋Agent Pay','垂直整合服務候選','卡組織具名真實案例；合作方正式部署公告','接送／旅遊Agent、商務連接、付款與治理的組合線索','銀行白牌嵌入、臺灣範圍、正式API、售後與報價','完整委外優先訪談','R10 R14'],
['Mastercard Agent Suite／Shopping Agent＋Connect＋Agent Pay','國際組織協助建置與連接','可客製Agent；Shopping Agent偏商戶站內','Agent建置支援、目錄、購物車及支付連接','銀行跨商戶profile、臺灣商戶、託管與維運契約','完整委外或共建；均待明確提案','R06 R07 R08 R09'],
['Visa Intelligent Commerce Connect＋具名Agent提供者','多網路商務／支付整合','Connect本身未證明交付完整銀行Agent','支付協調、Token、驗證及目錄可發現性等','完整Agent提供者、銀行入口、商戶操作及臺灣profile','銀行保留Agent；也可詢問整合商組案','R01 R03 R04 R05'],
['Firmly商務／Agentic Pay＋銀行指定Agent','商務與支付底層','Headless SDK不是Agent；另有商戶Ask Agent','部分目錄、購物車、結帳、下單、兩網路付款抽象','銀行跨商戶Agent交付、正式臺灣網路／商戶、完整同意及營運責任','銀行保留Agent的底層整合','R15 R16 R17 R18 R19 R20 R21 R22 R23'],
['PayOS付款元件＋銀行指定Agent','支付與驗證底層','產品明說你的Agent執行購買','卡片設定、Passkey、Token及相關付款資料','商品搜尋、Agent決策、商戶操作、全套售後','銀行保留Agent、減少付款整合','R24 R27'],
['PayOS＋Browserbase＋Agent整合者','付款與瀏覽器執行組合','瀏覽器工具／執行平台，不證明完整銀行Agent產品','受控瀏覽器操作能力＋網路付款憑證','商戶允許、銀行策略、語意核對、穩定性、全部角色合規','工程組合或交整合商；不是零開發承諾','R25'],
['Booked AI＋Travelport＋Basis Theory＋Mastercard','具名機票真實交易組合','官方明確Booked AI提供Agent','搜尋、預訂、付款、出票的四方分工實例','白牌採購、臺灣覆蓋、退改票、定價與SLA','垂直整合參考；不先推定可買現成整套','R12']
]
with (OUT/'候選方案與能力邊界.csv').open('w',encoding='utf-8-sig',newline='') as f:csv.writer(f).writerows(rows)

diagrams=[
dict(id='A',title='銀行經營Agent，採購商務與支付底層',desc='概念架構：銀行指定Agent提供者，可把商務與支付底層交給合作服務；本行EPOS是否參與另依收單角色確認。',nodes=[
('u',['客戶'],40,170,150,90,'user'),('app',['銀行入口'],240,170,200,90,'bank'),('agent',['銀行經營的Agent','自建或委外開發'],490,170,260,90,'bank'),('commerce',['商務整合服務','或直接商戶API'],820,170,260,90,'partner'),('merchant',['外部商戶'],1150,170,260,90,'merchant'),('pay',['VIC／Agent Pay','及Wallet／Enabler'],650,380,300,100,'network'),('acq',['商戶PSP／收單行'],1150,380,260,100,'merchant'),('net',['卡組織支付網路'],1150,600,260,90,'network'),('issuer',['實際發卡行','可為本行'],650,600,300,90,'bank'),('record',['銀行指定的紀錄與控制','可委外，須可取得證據'],200,600,330,90,'bank')],edges=[('u','app',''),('app','agent',''),('agent','commerce',''),('commerce','merchant',''),('agent','pay','雙向：憑證／證據'),('merchant','acq',''),('acq','net',''),('net','issuer',''),('agent','record','虛線：責任與紀錄')]),
dict(id='B',title='銀行入口嵌入合作方整合代理服務',desc='待驗證採購模型：合作方承接Agent、商務與支付協調；必須取得具名交付與責任承諾，不能只把大方塊寫成Agent Pay。',nodes=[
('u',['客戶'],40,170,150,90,'user'),('app',['銀行入口','登入與客戶服務'],240,170,220,90,'bank'),('service',['合作方整合代理服務','Agent＋商務＋支付協調'],560,160,370,110,'partner'),('merchant',['已支援的外部商戶'],1150,170,260,90,'merchant'),('pay',['VIC／Agent Pay','及相關合作服務'],650,380,300,100,'network'),('acq',['商戶PSP／收單行'],1150,380,260,100,'merchant'),('net',['卡組織支付網路'],1150,600,260,90,'network'),('issuer',['實際發卡行','可為本行'],650,600,300,90,'bank'),('record',['銀行可取得的紀錄','客訴、監督與調查'],200,600,330,90,'bank')],edges=[('u','app',''),('app','service',''),('service','merchant',''),('service','pay','雙向：憑證／證據'),('merchant','acq',''),('acq','net',''),('net','issuer',''),('service','record','虛線：證據與責任')]),
dict(id='C',title='銀行先做發卡就緒，交易在外部Agent發生',desc='概念架構：本行承接發卡准駁與相關營運；這不等於銀行已有自己的購物入口或購物Agent。',nodes=[
('u',['客戶'],60,210,180,90,'user'),('agent',['外部Agent平台'],360,210,310,90,'partner'),('merchant',['外部商戶'],1000,210,310,90,'merchant'),('pay',['代理支付服務'],360,440,310,90,'network'),('acq',['商戶PSP／收單行'],1000,440,310,90,'merchant'),('net',['卡組織支付網路'],1000,650,310,90,'network'),('issuer',['本行發卡端','授權、風控與客服'],360,650,310,90,'bank')],edges=[('u','agent',''),('agent','merchant',''),('agent','pay','雙向：憑證／證據'),('merchant','acq',''),('acq','net',''),('net','issuer','')]),
dict(id='D',title='銀行另兼任參與商戶的收單／支付閘道',desc='條件架構：只有商戶實際使用本行相關收單／閘道時，才把本行EPOS放進這段路徑；內部Cardpool、PH等連接須由行內核實。',nodes=[
('agent',['銀行或合作方Agent'],90,210,310,100,'partner'),('merchant',['外部商戶／其PSP'],510,210,310,100,'merchant'),('epos',['本行適用EPOS／閘道','及收單系統'],930,210,410,100,'bank'),('pay',['VIC／Agent Pay','相關合作服務'],90,500,310,100,'network'),('issuer',['實際發卡行','可能是本行或他行'],510,600,310,100,'bank'),('net',['卡組織支付網路'],930,600,410,100,'network')],edges=[('agent','merchant',''),('agent','pay','雙向：憑證／證據'),('merchant','epos','商戶採本行服務'),('epos','net',''),('net','issuer','')])
]
COLORS={'user':('#FFFFFF','#6B7E88'),'bank':('#E3EFF7','#3F6E94'),'partner':('#E4F3EE','#3E8270'),'merchant':('#FFF0DF','#A56B31'),'network':('#EBE8F8','#75659C')}
def route(a,b):
    _,_,ax,ay,aw,ah,_=a;_,_,bx,by,bw,bh,_=b
    acx,acy=ax+aw/2,ay+ah/2;bcx,bcy=bx+bw/2,by+bh/2
    if abs(bcy-acy)>abs(bcx-acx)*0.7:
        sy=ay+ah if bcy>acy else ay;ty=by if bcy>acy else by+bh
        return [(acx,sy),(acx,(sy+ty)/2),(bcx,(sy+ty)/2),(bcx,ty)]
    sx=ax+aw if bcx>acx else ax;tx=bx if bcx>acx else bx+bw
    return [(sx,acy),((sx+tx)/2,acy),((sx+tx)/2,bcy),(tx,bcy)]
mx=E.Element('mxfile',host='app.diagrams.net',version='24.7.17')
for d in diagrams:
    nmap={n[0]:n for n in d['nodes']}
    svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1500" height="850" viewBox="0 0 1500 850"><defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 Z" fill="#556C79"/></marker></defs><rect width="1500" height="850" fill="#F7F9FB"/>',f'<text x="40" y="55" font-size="30" font-weight="700" fill="#17384C" font-family="Microsoft JhengHei,sans-serif">方案 {d["id"]}｜{html.escape(d["title"])}</text>',f'<text x="40" y="100" font-size="17" fill="#536A76" font-family="Microsoft JhengHei,sans-serif">研究概念圖｜2026-11-19｜不是任何合作案的已確認生產部署圖</text>']
    dia=E.SubElement(mx,'diagram',id=d['id'],name=d['id']+' '+d['title']);g=E.SubElement(dia,'mxGraphModel',dx='1500',dy='850',grid='1',gridSize='10',page='1',pageWidth='1500',pageHeight='850');r=E.SubElement(g,'root');E.SubElement(r,'mxCell',id='0');E.SubElement(r,'mxCell',id='1',parent='0')
    title=E.SubElement(r,'mxCell',id='title',value='方案 '+d['id']+'｜'+d['title'],style='text;html=1;align=left;fontSize=26;fontStyle=1;fontFamily=Microsoft JhengHei;',vertex='1',parent='1');E.SubElement(title,'mxGeometry',x='40',y='20',width='1400',height='70',attrib={'as':'geometry'})
    for i,(a,b,label) in enumerate(d['edges']):
        pts=route(nmap[a],nmap[b]);both=label.startswith('雙向');dashed=label.startswith('虛線')
        if d['id']=='B' and dashed: pts=[(600,270),(600,540),(365,540),(365,600)]
        path='M '+' L '.join(f'{x:g},{y:g}' for x,y in pts)
        svg.append(f'<path d="{path}" fill="none" stroke="#556C79" stroke-width="2.2" marker-end="url(#arrow)"'+(' marker-start="url(#arrow)"' if both else '')+(' stroke-dasharray="7 5"' if dashed else '')+'/>')
        edge=E.SubElement(r,'mxCell',id=f'e{i}',value=label.replace('雙向：','').replace('虛線：',''),style='edgeStyle=orthogonalEdgeStyle;rounded=0;html=1;endArrow=block;endFill=1;fontFamily=Microsoft JhengHei;fontSize=14;'+('startArrow=block;startFill=1;' if both else '')+('dashed=1;' if dashed else ''),edge='1',parent='1',source=a,target=b);E.SubElement(edge,'mxGeometry',relative='1',attrib={'as':'geometry'})
    for id,ls,x,y,w,h,kind in d['nodes']:
        fill,stroke=COLORS[kind];svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="7" fill="{fill}" stroke="{stroke}" stroke-width="1.5"/>')
        for i,line in enumerate(ls):svg.append(f'<text x="{x+w/2}" y="{y+h/2+(i-(len(ls)-1)/2)*29+8}" text-anchor="middle" font-family="Microsoft JhengHei,sans-serif" font-size="21" fill="#17384C">{html.escape(line)}</text>')
        cell=E.SubElement(r,'mxCell',id=id,value='<br>'.join(ls),style=f'rounded=1;whiteSpace=wrap;html=1;fillColor={fill};strokeColor={stroke};fontColor=#17384C;fontSize=20;fontFamily=Microsoft JhengHei;',vertex='1',parent='1');E.SubElement(cell,'mxGeometry',x=str(x),y=str(y),width=str(w),height=str(h),attrib={'as':'geometry'})
    svg.append('<text x="40" y="805" font-family="Microsoft JhengHei,sans-serif" font-size="17" fill="#536A76">實線：主要互動／付款方向；雙向箭頭：服務交換；虛線：證據與責任關聯。結果回傳及失敗分支已省略。</text></svg>')
    (OUT/f'方案{d["id"]}.svg').write_text(''.join(svg),encoding='utf-8')
E.ElementTree(mx).write(OUT/'合作模式四種架構.drawio',encoding='utf-8',xml_declaration=True)

sections=[]
for d in diagrams:sections.append(f'<section id="p{d["id"]}"'+(' hidden' if d['id']!='A' else '')+f'><h2>{html.escape(d["title"])}</h2><p>{html.escape(d["desc"])}</p><img src="方案{d["id"]}.svg" alt="{html.escape(d["title"])}"></section>')
page='''<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>代理支付合作模式研究</title><style>body{margin:0;background:#f1f5f8;color:#17384c;font:18px/1.8 'Microsoft JhengHei',sans-serif}main{max-width:1450px;margin:auto;padding:28px}h1{font-size:32px;line-height:1.5}h2{font-size:25px}nav{display:flex;gap:10px;flex-wrap:wrap;margin:25px 0}button{font:inherit;padding:8px 18px;background:white;border:1px solid #7893a3;color:#17384c;cursor:pointer}button[aria-selected=true]{background:#17384c;color:white}section{background:white;padding:22px}section img{display:block;width:100%;height:auto}a{color:#006b80}p{max-width:1250px}[hidden]{display:none}.links{margin:18px 0} @media(max-width:700px){main{padding:14px}h1{font-size:26px}section{padding:10px}}</style><main><h1>國際組織合作與代理服務委外研究</h1><p><strong>研究結論：合作方提供Agent與商務串接已有具名實例；銀行要少建系統，可以研究整合服務採購，但還不能把VIC／Agent Pay單一名稱當成完整交付承諾。</strong></p><p>比較完整委外、銀行經營Agent、發卡就緒及收單參與。下列皆為研究概念架構，地區、商戶、責任與生產可用性須逐案確認。查核截至2026-11-19。</p><p class="links"><a href="../../代理支付官方研究/08_國際組織合作與整套代理服務委外研究.md">完整研究報告</a> · <a href="官方來源與證據索引.md">30份一手來源</a> · <a href="候選方案與能力邊界.csv">候選能力對照</a> · <a href="窗口訪談與POC驗收清單.md">訪談及驗收清單</a> · <a href="合作模式四種架構.drawio">可編輯Draw.io</a></p><nav role="tablist">'''+''.join(f'<button role="tab" aria-selected="{str(d["id"]=="A").lower()}" data-target="p{d["id"]}">{d["id"]} '+{'A':'銀行經營Agent','B':'整合服務委外','C':'發卡就緒','D':'另兼收單'}[d['id']]+'</button>' for d in diagrams)+'''</nav>'''+''.join(sections)+'''<p>圖面會省略回傳、驗身及失敗分支；請搭配完整報告及第07章驗身流程閱讀。複製整個「代理支付」資料夾即可保留相對連結；外部官方原文仍需網路。</p></main><script>for(const b of document.querySelectorAll('button[data-target]'))b.onclick=()=>{for(const x of document.querySelectorAll('section'))x.hidden=x.id!==b.dataset.target;for(const x of document.querySelectorAll('button[data-target]'))x.setAttribute('aria-selected',String(x===b))}</script></html>'''
(OUT/'index.html').write_text(page,encoding='utf-8')
(OUT/'README.md').write_text('''# 合作模式研究｜2026-11-19

- [完整研究報告](../../代理支付官方研究/08_國際組織合作與整套代理服務委外研究.md)
- [四種架構圖切換頁](index.html)
- [30份一手來源與證據邊界](官方來源與證據索引.md)
- [候選方案與能力邊界CSV](候選方案與能力邊界.csv)
- [窗口訪談與POC驗收清單](窗口訪談與POC驗收清單.md)
- [可編輯Draw.io四頁圖](合作模式四種架構.drawio)

此輪依使用者選擇，同時研究完整委外與銀行保留Agent、不預設銀行角色及品類。重點成果是找到CardInfoLink／hoppa的具名Agent實例、Mastercard Suite／Shopping Agent／Connect的交付差別，以及Firmly和PayOS開發文件中的能力與責任邊界。未聯絡廠商、未取得本行正式提案、未實測付款。

本成果是2026-11-19新增內容，11月17日舊封存包不包含。搬遷請複製目前完整專案；SVG、Draw.io、HTML及Markdown可離線閱讀，官方原文未完整鏡像。
''',encoding='utf-8')

assert len(urls)==len(items)==30
for f in OUT.glob('*.svg'): E.parse(f)
assert len(E.parse(OUT/'合作模式四種架構.drawio').getroot().findall('diagram'))==4
print(json.dumps({'sources':len(sources),'diagrams':len(diagrams),'candidates':len(rows)-1},ensure_ascii=False))
