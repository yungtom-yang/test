const fs=require('node:fs/promises');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {chromium}=require('C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1117-835-0_26.1117.835.0_x64__3k8sg7r9htsxt/dependencies/node/node_modules/playwright');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
 const page=await browser.newPage({viewport:{width:1500,height:850},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 for(const id of ['A','B','C','D']){
   await page.goto(pathToFileURL(path.join(__dirname,`方案${id}.svg`)).href);
   await page.screenshot({path:path.join(__dirname,`方案${id}.png`)});
 }
 await page.goto(pathToFileURL(path.join(__dirname,'index.html')).href);
 const seen=[];
 for(const id of ['A','B','C','D']){
  await page.locator(`button[data-target="p${id}"]`).click();
  const visible=await page.locator('section:visible').getAttribute('id');
  if(visible!==`p${id}`)throw new Error('Wrong tab '+id);
  const loaded=await page.locator(`#p${id} img`).evaluate(e=>e.complete&&e.naturalWidth===1500);
  if(!loaded)throw new Error('Missing diagram '+id);
  seen.push(id);
 }
 await page.locator('button[data-target="pB"]').click();
 await page.screenshot({path:path.join(__dirname,'閱讀頁預覽.png'),fullPage:true});
 await page.setViewportSize({width:390,height:844});
 if(await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth+2))throw new Error('Mobile page overflow');
 if(errors.length)throw new Error(errors.join('\n'));
 const r={tabs:seen,images:4,pageErrors:errors,svgXml:'parsed',drawioPages:4,paymentApisExecuted:false};
 await fs.writeFile(path.join(__dirname,'檢查紀錄.json'),JSON.stringify(r,null,2));
 console.log(JSON.stringify(r));await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
