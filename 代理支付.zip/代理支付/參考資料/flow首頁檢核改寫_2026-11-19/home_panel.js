function homePanel(p,uid){
 return `<div class="section-head"><div><h2>檢核位置與功能建議</h2><p class="subtitle">點選圖上編號，右側說明與小樹購版講稿對照。</p></div><div class="legend">沿用原架構</div></div>
 <div class="home-workspace"><section class="home-map" aria-label="原架構圖與檢核點"><div class="home-graph">${p.overviewSvg}</div><nav class="home-picks" aria-label="選擇檢核點">${p.checks.map(c=>`<button type="button" data-home-check="${c.id}" title="${esc(c.title)}" aria-label="${esc(c.id+' '+c.title)}">${esc(c.id)}</button>`).join('')}</nav></section>
 <aside class="home-sidebar" aria-label="選定檢核點的處理建議"><div class="home-detail" aria-live="polite"></div><div class="home-pager"><button type="button" data-home-prev>上一點</button><span class="home-progress"></span><button type="button" data-home-next>下一點</button></div></aside></div>
 <div class="home-note">示例：小樹購買一台咖啡機，含運上限8,000元；商品7,480＋運費200＝7,680元，客戶最後核准。金額及介面能力為教學假設。<br>原架構、DB與固定比對保留；PH等付款角色及平台能力待盤點。標示「原版」的A–F分頁未同步首頁新增的核准流程。</div>`;
}
function homeDetail(id){
 const p=pages[0],index=p.checks.findIndex(x=>x.id===id),c=p.checks[index];if(!c)return;
 const d=c.development;
 const panel=document.querySelector('#screen-panel'),host=panel.querySelector('.home-detail');
 host.innerHTML=`<header class="home-detail-head"><span class="home-point">${esc(c.id)} · 檢核點</span><h3>${esc(c.title)}</h3><p>${esc(c.stage)}</p></header>
 <nav class="home-detail-tabs" aria-label="檢核點說明頁籤"><button type="button" data-advice-tab="build">功能設計</button><button type="button" data-advice-tab="data">資料與例子</button><button type="button" data-advice-tab="reference">組織對照</button></nav>
 <div class="home-detail-body"><section data-advice-view="build" class="home-development"><h4 class="home-module">${esc(d.module)}</h4><p>${esc(d.purpose)}</p><details class="home-placement"><summary>放置位置與可沿用能力</summary><p>${esc(d.placement)}</p></details><h4>具體做法</h4><ol class="home-functions">${d.functions.map(f=>`<li><strong>${esc(f.name)}</strong><p>${esc(f.logic)}</p></li>`).join('')}</ol><section class="home-limit"><h4>檢核範圍</h4><p>${esc(c.limit)}</p></section></section>
 <section data-advice-view="data" hidden><h4>一次檢核的資料進出</h4><dl class="home-io">${[['input','收到什麼'],['rules','怎麼判斷'],['output','回傳或留下什麼'],['deny','不通過怎麼辦']].map(([key,label])=>`<dt>${label}</dt><dd>${esc(d[key])}</dd>`).join('')}</dl><div class="home-example"><h4>小樹購購物示例</h4><p>${esc(d.example)}</p></div><h4>待確認能力</h4><p>${esc(d.scope)}</p></section>
 <section data-advice-view="reference" hidden><section class="home-reference visa"><h4>Visa實際怎麼做</h4><ol>${c.organization_walkthrough.visa.map(s=>`<li>${esc(s)}</li>`).join('')}</ol></section>
 <section class="home-reference master"><h4>Mastercard實際怎麼做</h4><ol>${c.organization_walkthrough.master.map(s=>`<li>${esc(s)}</li>`).join('')}</ol></section>
 <h4>放回本行怎麼做</h4><p>${esc(c.organization_walkthrough.bank)}</p><h4>尚須取得的規格／能力</h4><p>${esc(c.organization_walkthrough.gap)}</p>
 <details class="home-source"><summary>官方來源（${c.sources.length}項）</summary>${c.sources.map(k=>`<a href="${esc(p.checkSources[k][1])}" target="_blank" rel="noopener">${esc(k+' '+p.checkSources[k][0])}</a>`).join('')}</details>
 <p class="home-context">「本行借鏡」是設計推導，不代表兩家已提供同名模組。VI為公開草案，實際介面與適用條件待確認。</p></section></div>`;
 panel.dataset.homeSelected=id;
 panel.querySelectorAll('[data-home-check]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.homeCheck===id)));
 panel.querySelectorAll('.home-graph [data-check]').forEach(a=>{a.classList.toggle('is-active',a.dataset.check===id);a.setAttribute('aria-current',String(a.dataset.check===id))});
 panel.querySelector('[data-home-prev]').disabled=index===0;panel.querySelector('[data-home-next]').disabled=index===p.checks.length-1;
 panel.querySelector('.home-progress').textContent=`${index+1} / ${p.checks.length}`;
 panel.querySelectorAll('[data-advice-tab]').forEach(b=>b.onclick=()=>homeAdviceView(b.dataset.adviceTab));
 homeAdviceView(panel.dataset.adviceView||'build');
}
function homeAdviceView(view){const panel=document.querySelector('#screen-panel');panel.dataset.adviceView=view;panel.querySelectorAll('[data-advice-view]').forEach(s=>s.hidden=s.dataset.adviceView!==view);panel.querySelectorAll('[data-advice-tab]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.adviceTab===view)));const body=panel.querySelector('.home-detail-body');if(body)body.scrollTop=0;}
function setFlowContext(index){const h=document.querySelector('main>h1'),intro=document.querySelector('main>.intro');h.textContent=index===0?'銀行自建代理支付｜檢核總覽':'原始A–F流程｜機場接送（舊版參考）';intro.textContent=index===0?'以小樹購購物說明檢核目的與自建功能；Agent完成選購，客戶最後核准具體交易。':'此分頁保留會議原始內容，尚未同步首頁檢核與最後核准流程；目前報告以首頁及小樹購版講稿為準。';}
function bindHome(){
 const host=document.querySelector('#screen-panel');if(!host.querySelector('.home-graph'))return;
 host.querySelectorAll('[data-check]').forEach(a=>a.onclick=e=>{e.preventDefault();homeDetail(a.dataset.check)});
 host.querySelectorAll('[data-home-check]').forEach(b=>b.onclick=()=>homeDetail(b.dataset.homeCheck));
 for(const [selector,delta] of [['[data-home-prev]',-1],['[data-home-next]',1]])host.querySelector(selector).onclick=()=>{const list=pages[0].checks,index=list.findIndex(c=>c.id===host.dataset.homeSelected),next=list[index+delta];if(next)homeDetail(next.id)};
 homeDetail('D');
}
