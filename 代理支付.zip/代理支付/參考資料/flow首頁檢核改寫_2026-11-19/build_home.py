"""Annotate flow.html's original homepage; preserve all A–F page objects."""
from pathlib import Path
import re,json,base64,struct,urllib.parse,copy,unicodedata
from html import escape
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent.parent
FLOW=PROJECT/'流程檢核點.html' if (PROJECT/'流程檢核點.html').exists() else PROJECT/'flow.html'
BACKUP=ROOT/'flow_改寫前備份.html'
if not BACKUP.exists():BACKUP.write_bytes(FLOW.read_bytes())
original=BACKUP.read_text(encoding='utf8')
pattern=r'const pages=(.*?);\s*const roles='
match=re.search(pattern,original,re.S)
pages=json.loads(match.group(1));prior=copy.deepcopy(pages[1:])
png=base64.b64decode(pages[0]['image'].split(',',1)[1])
(ROOT/'原首頁架構圖.png').write_bytes(png)
pos=8
while pos<len(png):
    length=struct.unpack('>I',png[pos:pos+4])[0];kind=png[pos+4:pos+8]
    if kind==b'tEXt':
        key,val=png[pos+8:pos+8+length].split(b'\0',1)
        if key==b'mxfile':xml=urllib.parse.unquote(val.decode())
    pos+=length+12
(ROOT/'原首頁架構圖.drawio').write_text(xml,encoding='utf8')
old=json.loads((PROJECT/'研究成果/架構圖/檢核註記版/註記內容.json').read_text(encoding='utf8'))
base={c['id']:c for c in old['controls']}

POINTS=[
 dict(id='P',stage='C14／E27前及每次工具呼叫',title='工具執行前：先驗身分與操作權限',
 action='受控工具層驗服務身分、委任範圍與允許操作；核准前不可正式購買。',
 visaShort='VARS／VIC代理驗證',mcShort='Agent註冊／驗證',
 where='Agent入口→Agent，以及Agent呼叫商戶API／下訂前。',
 check='由受控程式檢查服務來源、工具權限及本次允許的動作；必要的服務金鑰與授權設定須事先建好。避免模型以自己的文字擴張操作權。',
 failure='身分或權限不符，拒絕本次工具呼叫；不交由模型自行放行。',anchor=(820,645)),
 dict(id='A',stage='A02–05；F33–35',title='綁卡／取付款資料：安全層把關',
 action='EPOS／PH驗介接權限、卡片參照與適用驗證；原始卡號不進Agent。',
 visaShort='VTS／VPP',mcShort='Agentic Token；VI L1另用',
 where='EPOS↔Payment Hub；進入既有付款與適用驗證流程的位置。',
 check='由EPOS／PH等安全付款服務核對呼叫權限、客戶與卡片參照的關聯及狀態，執行適用的卡片／客戶驗證。原圖MPI等既有路由先保留，實際角色須確認。',
 failure='卡片、參照或適用驗證未通過，不得進入付款；依既有安全流程處理。',anchor=(1030,815)),
 dict(id='B',stage='B06–11；C12–13',title='委任啟用／讀取：查DB有效狀態',
 action='確認客戶、條件、版本、期限；受控服務讀寫DB，保存狀態與軌跡。',
 visaShort='Purchase Instruction／Mandate',mcShort='VI最終值／自主委任之區分',
 where='客戶確認條件→代理管理DB啟用；Agent讀取委任後開始執行。',
 check='DB保存原始需求、確認後條件、確認紀錄、版本、期限、狀態與執行軌跡。由受控程式判斷是否有效，不讓Agent自行宣告已核准或已完成。B僅是本版選購委任。',
 failure='未確認、取消、到期或版本不符：不啟動或停止本次執行；需要時重取條件確認。',anchor=(720,795)),
 dict(id='C1',stage='C14／17；E27的API互動',title='商戶入口：驗Agent來源與請求',
 action='商戶API／閘道驗服務來源及操作範圍；依方案檢查簽章、效期及重播。',
 visaShort='TAP Agent Recognition',mcShort='Web Bot Auth',
 where='Agent→上方商戶API的查詢、保留，以及後續下訂請求。',
 check='驗證者在商戶或其防護／API閘道；本行可評估既有API驗證、mTLS或請求簽章，設計請求對象、時間與防重播規則。這與工具層的本行權限控管是兩個邊界。',
 failure='依平台契約拒絕或走另定安全路徑，不因Agent聲稱可信就接受請求。',anchor=(899,625)),
 dict(id='C2',stage='B入口；C私人資料查詢時',title='使用客戶資料：另查帳戶授權',
 action='若要讀會員、地址或購物車，另驗客戶關聯及存取範圍。',
 visaShort='TAP Consumer Recognition',mcShort='Consumer Identity資料',
 where='Agent入口的客戶識別，以及商戶API需要會員／私人資料時。',
 check='能認出Agent不等於它能讀此客戶的所有資料。由入口及平台處理帳戶連結與授權，確認資料範圍及效期；公開商品資料未必需要客戶登入。',
 failure='無私人資料授權時，停止該存取或只使用允許的公開資料。',anchor=(600,645)),
 dict(id='C3',stage='C15–19；D24',title='商戶回傳：取得可信交易明細',
 action='由商戶取得訂單識別、品項／服務、總額與期限，固定待比對版本。',
 visaShort='TAP範圍＋Agent端交易查核',mcShort='VI商戶簽署checkout JWT',
 where='上方商戶API回傳候選／保留單；比對模組向下方商戶API獨立取明細。',
 check='資料須來自正式商戶介面或另一個可驗證來源，不只相信Agent摘要。原接送場景須確認保留／鎖價／期限確有介面支援；查詢、保留與正式購買的效果要分清楚。',
 failure='缺明細、來源不可信、保留失效或內容改變：不列為可付款交易，重新查詢／比對。',anchor=(870,955)),
 dict(id='D',stage='D20–26',title='固定pattern：基本符合性檢查',
 action='比對模組自行取DB＋商戶明細，以固定程式規則核對，不再請模型自行判分。',
 visaShort='取付款憑證前核對客戶指示',mcShort='VI依模式驗最終值或限制',
 where='原交易比對模組：Agent送委任／訂單識別，模組獨立查DB與商戶API。',
 check='用固定欄位與規則檢查：必填／型別、委任版本與狀態、日期時間／起訖地或SKU、數量、幣別與含費總額、保留期限、可結構化的必要條款。主觀偏好或無法結構化的條件須標成未涵蓋。',
 failure='欄位不足或基本條件不符：不放行，回Agent重選或請客戶處理；不可悄悄忽略規則。',anchor=(880,815)),
 dict(id='E1',stage='D26後；正式購買／付款前',title='新增：客戶核准具體交易',
 action='入口顯示商品／服務、商戶與總額；保存核准內容及驗證證據。',
 visaShort='審閱交易／同意釋出Token',mcShort='VI Immediate L1＋L2',
 where='比對通過後回到原Agent入口，請客戶核准；核准後才可發出具義務的購買／付款動作。',
 check='本版按VI Immediate概念對照：客戶核准的是具體交易，與B確認選購條件不同。若E27只建立無義務待付款單，可依介面調整位置；一旦動作會成立訂單、產生費用或付款，就須先核准。',
 failure='拒絕則停止；商品／服務、商戶或金額等關鍵內容變動，重新比對並取得新核准。',anchor=(600,740)),
 dict(id='E2',stage='E28–32；F35前',title='付款前：EPOS重查並占用執行',
 action='查最新委任＋比對＋客戶核准＋付款請求關聯，原子登記執行並防重複。',
 visaShort='VIC有效指示／mandate／憑證',mcShort='Agentic Token＋既有授權',
 where='原EPOS→右側代理管理DB，以及EPOS送付款前的檢查位置。',
 check='受控服務將付款請求的商戶、訂單、幣別、金額連結到有效比對與具體核准；查最新委任版本、效期與使用狀態，以一致的交易識別及原子更新登記執行中。DB保存狀態，服務執行規則。',
 failure='不一致、取消、到期或已執行則停止；同筆處理中／結果不明先查原交易，不直接重送。',anchor=(1179,735)),
 dict(id='F',stage='F36–42a',title='結果查核：分開付款與訂單狀態',
 action='核實付款及商戶成立結果，再回寫DB狀態與軌跡；不確定就保留待查。',
 visaShort='交易事件確認／指示取消',mcShort='意圖證據；退款及爭議另處理',
 where='既有付款回應→Agent查商戶結果→DB回寫／入口通知；原首頁省略的回傳方向另標示。',
 check='關聯委任版本、比對ID、核准ID、訂單ID、付款ID及工具操作軌跡。分開付款成功、訂單成立與履約進度，不以Agent自行宣稱完成作唯一依據。',
 failure='付款核准但訂單未成立，進查詢與撤銷／退款協調；結果不明先待查，不立即重新購買。',anchor=(1339,875)),
]
for p in POINTS:
    b=base[p['id']]
    p.update(visa=b['visa'],mc=b['mc'],limit=b['limit'],sources=b['sources'])
    if p['id']=='D':p['limit']='固定pattern只能攔截可表達的基本不符，不能保證Agent無幻覺；也不取代來源驗證、客戶核准、資安或付款授權。'
    if p['id']=='B':p['limit']='DB是狀態與軌跡資料來源；讀寫授權、狀態轉移與原子更新由受控程式實作，不是DB自行理解需求。'

development=json.loads((ROOT/'development_notes.json').read_text(encoding='utf8'))
walkthroughs={p['id']:p['organization_walkthrough'] for p in json.loads((PROJECT/'簡報成果/2026-11-19/小樹購檢核講稿.json').read_text(encoding='utf8'))['points']}
assert set(development)=={p['id'] for p in POINTS}
for p in POINTS:
    spec=development[p['id']]
    assert len(spec['functions'])==3
    p.update(development=spec,action=spec['summary'],failure=spec['deny'])
    p['organization_walkthrough']=walkthroughs[p['id']]
    if 'title' in spec:p['title']=spec['title']
    p['check']=spec['rules']

# Short, mode-specific reference text for the presentation homepage.
clear_limits={
 'P':'P管工具與階段權限；不驗商品是否符合需求。購買前仍須E1核准與E2執行檢查。',
 'A':'內部卡片參照不一定是網路支付Token；綁卡成功也不代表客戶已核准這筆購買。',
 'B':'DB保存版本、狀態與軌跡，受控程式執行規則。B確認選購範圍，具體購買在E1核准。',
 'C1':'只保護約定的請求範圍；驗過服務來源，不代表商品、客戶資料權限或付款同意都已確認。',
 'C2':'辨識客戶與授權讀資料是兩個問題；允許讀地址也不代表允許購買。',
 'C3':'取得明細不等於符合需求、鎖價或保留庫存；D再比條件，平台能力另確認。',
 'D':'固定pattern只能攔截可表達的基本不符，不能保證沒有幻覺。缺資料或主觀條件不能寫成已驗證。',
 'E1':'服務概念對應Immediate；普通確認畫面與DB紀錄不等於已符合VI憑證及簽署要求。',
 'E2':'E1留下核准，E2查現在是否仍可執行。只鎖行內DB，無法單獨保證外部不會重複處理。',
 'F':'付款核准、訂單成立與履約各自追蹤；取消委任也不直接等同訂單取消或退款完成。'
}
for p in POINTS:p['limit']=clear_limits[p['id']]
by_id={p['id']:p for p in POINTS}
by_id['A'].update(mcShort='Agentic Token',mc='Agentic Token提供代理付款的代碼化憑證，與最終交易核准及既有付款授權分開處理。')
by_id['A']['sources']=['V4','M5']
by_id['B'].update(mcShort='VI Immediate的最終交易證據',mc='VI Immediate以使用者確認的最終交易值作證據；本案的具體交易核准在E1。')
by_id['B']['sources']=['V1','V2','M2']
by_id['D'].update(mcShort='VI Immediate的具體交易內容',mc='VI Immediate記錄客戶確認的最終值，並連結結帳與付款內容；不會自動替本行檢查所有選購偏好。')
by_id['D']['sources']=['V2','M2','M3']
by_id['E1'].update(mc='VI Immediate以L1連結身分與公鑰、L2承載使用者確認的最終交易值，並連結結帳與付款內容。')
by_id['F']['where']='既有付款回應→Agent向平台查訂單結果→DB回寫／入口通知；首頁未展開所有回應方向。'

def wrap(t,units):
    result=[];s='';n=0
    for c in t:
        k=2 if unicodedata.east_asian_width(c) in 'WF' else 1
        if n+k>units:result.append(s);s='';n=0
        s+=c;n+=k
    if s:result.append(s)
    return result

def text(t,x,y,size=18,bold=False,color='#20394c'):
    sv.append(f'<text x="{x}" y="{y}" style="font-size:{size}px;font-weight:{700 if bold else 400};fill:{color}">{escape(t)}</text>')
def box(id,value,x,y,w,h,style):
    c=ET.SubElement(rr,'mxCell',id='check-'+id,value=value,style='html=1;whiteSpace=wrap;fontFamily=Microsoft JhengHei;fontColor=#20394c;'+style,vertex='1',parent='1');ET.SubElement(c,'mxGeometry',x=str(x),y=str(y),width=str(w),height=str(h),attrib={'as':'geometry'})
# The on-screen/exported diagram now retains only the original drawing and markers.
# Advice lives in an adjacent HTML panel, avoiding annotation leaders across the flow.
W,H=1140,840
sv=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" role="img" aria-label="原架構圖及十個可點選檢核點"><title>原首頁架構圖｜檢核點</title><style>text{{font-family:"Microsoft JhengHei",Arial,sans-serif;fill:#20394c}}a{{cursor:pointer}}a:hover circle,a:focus-visible circle{{stroke:#00a18f;stroke-width:5}}a.is-active circle{{stroke:#00a18f;stroke-width:6}}</style><rect width="1140" height="840" fill="white"/>']
text('點選檢核編號，右側同步顯示建議與兩家做法',24,35,23,True)
sv.append(f'<image x="40" y="80" width="1060" height="682" href="{pages[0]["image"]}"/>')
mx=ET.fromstring(xml);model=mx.find('.//mxGraphModel');model.set('pageWidth',str(W));model.set('pageHeight',str(H));rr=model.find('root')
for c in rr.findall('.//mxCell'):
    geo=c.find('mxGeometry')
    if geo is None:continue
    if c.get('vertex')=='1':geo.set('y',str(float(geo.get('y','0'))+20))
    for q in geo.findall('.//mxPoint'):q.set('y',str(float(q.get('y','0'))+20))
box('header','原架構圖｜保留檢核點，對應做法見flow.html右側面板',24,5,1090,50,'text;align=left;fontSize=22;fontStyle=1;')
for p in POINTS:
    ax,ay=p['anchor'];ax-=430;ay-=270;p['anchor']=(ax,ay)
    color='#277255' if p['id'] in ['B','D'] else '#926322' if p['id'] in ['A','E1','E2','F'] else '#285f86'
    sv.append(f'<a href="#check-{p["id"]}" data-check="{p["id"]}" aria-label="{escape(p["id"]+" "+p["title"])}"><title>{escape(p["id"]+"｜"+p["title"])}</title><circle cx="{ax}" cy="{ay}" r="21" fill="{color}" stroke="white" stroke-width="3"/><text x="{ax}" y="{ay+6}" text-anchor="middle" style="fill:white;font-size:17px;font-weight:700">{p["id"]}</text></a>')
    box(p['id']+'-marker',p['id'],ax-21,ay-21,42,42,f'ellipse;fillColor={color};strokeColor=#ffffff;fontColor=#ffffff;fontSize=17;fontStyle=1;')
sv.append('<rect x="536" y="383" width="88" height="30" rx="4" fill="#fff4de" stroke="#ddc18a"/>')
text('E1核准後',543,404,17,True,color='#8a5d20')
box('approval-on-path','E1核准後',536,383,88,30,'rounded=1;fillColor=#fff4de;strokeColor=#ddc18a;fontColor=#8a5d20;fontSize=17;fontStyle=1;')
text('綠色：委任／固定比對　藍色：身分／來源　金色：核准／付款／結果',24,801,18)
sv.append('</svg>');svg=''.join(sv)
(ROOT/'首頁原圖_檢核註記.svg').write_text(svg,encoding='utf8')
ET.indent(mx);(ROOT/'首頁原圖_檢核註記.drawio').write_text(ET.tostring(mx,encoding='unicode'),encoding='utf8')
pages[0].update(title='代理支付交易流程圖｜原圖檢核註記',subtitle='以原首頁圖為baseline；保留代理管理DB與固定pattern比對。此輪僅改首頁，A–F分段頁仍是原版。',overviewSvg=svg,checks=POINTS,checkSources=old['sources'])
serialized=json.dumps(pages,ensure_ascii=False).replace('</','<\\/')
modified=original[:match.start(1)]+serialized+original[match.end(1):]
newpanel=(ROOT/'home_panel.js').read_text(encoding='utf8')
modified=modified.replace('function panel(p,i,uid=i){','function panel(p,i,uid=i){if(p.overviewSvg)return homePanel(p,uid);')
modified=modified.replace('function panel(p,i,uid=i){',newpanel+'function panel(p,i,uid=i){',1)
modified=modified.replace('document.querySelector(\'#next\').disabled=i===pages.length-1;}','document.querySelector(\'#next\').disabled=i===pages.length-1;setFlowContext(i);if(i===0)bindHome();}')
modified=modified.replace('b.textContent=p.title;b.onclick=',"b.textContent=i===0?'檢核首頁（小樹購示例）':'原版 '+p.title;b.onclick=")
modified=re.sub(r'<title>.*?</title>','<title>代理支付｜檢核總覽與原始流程</title>',modified,count=1)
css=(ROOT/'home.css').read_text(encoding='utf8')
modified=modified.replace('</style>',css+'</style>',1)
FLOW.write_text(modified,encoding='utf8')
assert json.loads(re.search(pattern,modified,re.S).group(1))[1:]==prior
(ROOT/'檢核位置與原步驟.json').write_text(json.dumps(POINTS,ensure_ascii=False,indent=2),encoding='utf8')
md=['# flow.html首頁改寫說明','','本次直接修改根目錄flow.html首頁，保留原圖片及A–F分段頁。原圖PNG包含Draw.io資料，已取出作可編輯baseline；此版在原PNG上保留檢核標記，移除註解連線及兩側卡片；點選檢核點於圖右側顯示建議，未搬動原方塊。','', '代理管理DB用於狀態與軌跡；實際授權檢查與狀態轉移由受控服務執行。交易比對模組使用固定pattern做可結構化的基本符合性檢查，不宣稱消除全部幻覺。','', '改寫前完整備份：flow_改寫前備份.html。改寫前原圖與完整備份留存在本資料夾。A–F分段頁逐項資料保持相同；E1最終核准是首頁新增關卡，後續另同步分頁。','']
for c in POINTS:
    md += ['## '+c['id']+' '+c['title'],'', '**原步驟**：'+c['stage'],'','**原圖位置**：'+c['where'],'','**本行檢查**：'+c['check'],'','**未通過時**：'+c['failure'],'','**功能邊界**：'+c['limit'],'','**Visa**：'+c['visa'],'','**Mastercard**：'+c['mc'],'','**來源**：'+'、'.join(f'[{k} {old["sources"][k][0]}]({old["sources"][k][1]})' for k in c['sources']),'']
    spec=c['development']
    md += ['### 本行可開發或沿用的功能','','**功能概念**：'+spec['module'],'','**作用**：'+spec['purpose'],'','**放置與沿用**：'+spec['placement'],'']
    for item in spec['functions']:md += ['- **'+item['name']+'**：'+item['logic']]
    for field,label in [('input','輸入'),('rules','判斷'),('output','輸出'),('deny','不通過'),('example','教學例子'),('borrowVisa','借鏡Visa'),('borrowMaster','借鏡Mastercard'),('scope','實作範圍與待確認')]:md += ['', '**'+label+'**：'+spec[field]]
    md += ['']
(ROOT/'改寫說明與來源.md').write_text('\n'.join(md),encoding='utf8')
print('Updated flow.html homepage with 10 annotations. A–F page data unchanged; backup retained.')
