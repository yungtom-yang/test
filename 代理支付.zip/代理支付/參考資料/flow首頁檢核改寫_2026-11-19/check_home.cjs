const fs=require('node:fs'),path=require('node:path');
const {pathToFileURL}=require('node:url');
const {launchBrowser}=require('../../研究成果/browser_runtime.cjs');
(async()=>{
 const browser=await launchBrowser();
 const page=await browser.newPage({viewport:{width:1140,height:840},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.setContent('<!doctype html><html><body style="margin:0;background:white">'+fs.readFileSync(path.join(__dirname,'首頁原圖_檢核註記.svg'),'utf8')+'</body></html>');
 const bounds=await page.locator('svg').evaluate(svg=>{
  const v=svg.viewBox.baseVal;
  return [...svg.querySelectorAll('text')].filter(t=>{const b=t.getBBox();return b.x<0||b.y<0||b.x+b.width>v.width+1||b.y+b.height>v.height+1}).map(t=>t.textContent);
 });
 if(bounds.length)throw Error('SVG overflow '+JSON.stringify(bounds));
 if(await page.locator('.check-card,svg path').count())throw Error('Annotation cards or leaders still present');
 if(await page.locator('a[data-check]').count()!==10)throw Error('Missing checkpoint markers');
 await page.screenshot({path:path.join(__dirname,'首頁原圖_檢核註記.png'),fullPage:true});
 await page.setViewportSize({width:1600,height:1000});
 await page.goto(pathToFileURL(path.resolve(__dirname,'../../flow.html')).href);
 if(!await page.locator('main>.intro').innerText().then(t=>t.includes('小樹購')&&!t.includes('接送')))throw Error('Homepage context is not aligned with speech');
 if(!await page.locator('#tab-1').innerText().then(t=>t.startsWith('原版')))throw Error('Legacy A–F pages not labeled');
 if(await page.locator('#screen-panel .home-graph svg').count()!==1)throw Error('Homepage SVG missing');
 const position=await page.evaluate(()=>{const graph=document.querySelector('#screen-panel .home-map').getBoundingClientRect(),side=document.querySelector('#screen-panel .home-sidebar').getBoundingClientRect();return {right:side.left>=graph.right-1,aligned:Math.abs(side.top-graph.top)<1}});
 if(!position.right||!position.aligned)throw Error('Sidebar is not beside the graph');
 const points=['P','A','B','C1','C2','C3','D','E1','E2','F'];
 for(const id of points){
  await page.locator(`#screen-panel [data-home-check="${id}"]`).click();
  if(await page.locator('#screen-panel').getAttribute('data-home-selected')!==id)throw Error('Point failed '+id);
  if(await page.locator('#screen-panel .home-graph a.is-active').count()!==1)throw Error('Active marker missing '+id);
  await page.locator('#screen-panel [data-advice-tab="build"]').click();
  if(await page.locator('#screen-panel [data-advice-view="build"] .home-functions li').count()!==3)throw Error('Concrete functions missing '+id);
  if(!await page.locator('#screen-panel .home-module').innerText().then(t=>t.length>3))throw Error('Module concept missing '+id);
  await page.locator('#screen-panel [data-advice-tab="data"]').click();
  if(await page.locator('#screen-panel .home-io dd').count()!==4)throw Error('Input/output details missing '+id);
  if(!await page.locator('#screen-panel .home-example').innerText().then(t=>t.includes('教學例')))throw Error('Example missing '+id);
  const example=await page.locator('#screen-panel .home-example').innerText();
  if(/接送|預訂|1,280|1,500|1,580|1,380/.test(example))throw Error('Old scenario remains '+id);
  await page.locator('#screen-panel [data-advice-tab="reference"]').click();
  if(await page.locator('#screen-panel [data-advice-view="reference"] .home-reference').count()!==2)throw Error('Network derivation missing '+id);
 }
 await page.locator('#screen-panel [data-advice-tab="build"]').click();
 const stationary=await page.evaluate(()=>{window.scrollTo(0,0);const before=window.scrollY;document.querySelector('#screen-panel a[data-check="C1"]').dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));return before===window.scrollY});
 if(!stationary)throw Error('Selecting point scrolls the page');
 await page.locator('#screen-panel [data-home-next]').click();
 if(await page.locator('#screen-panel').getAttribute('data-home-selected')!=='C2')throw Error('Next point failed');
 await page.locator('#screen-panel a[data-check="D"]').first().click();
 if(!await page.locator('#screen-panel .home-detail').innerText().then(t=>t.includes('固定pattern只能攔截')))throw Error('Pattern boundary missing');
 if(await page.locator('#screen-panel .home-tools,#screen-panel [data-home-original],#screen-panel [data-home-zoom]').count())throw Error('Removed toolbar still present');
 for(let i=1;i<=6;i++){
  await page.locator('#tab-'+i).click();
  if(await page.locator('#screen-panel svg').count()!==1)throw Error('A–F view failed '+i);
  if(!await page.locator('main>h1').innerText().then(t=>t.includes('舊版參考')))throw Error('Legacy context not clear '+i);
 }
 await page.locator('#tab-0').click();
 await page.locator('#screen-panel [data-advice-tab="build"]').click();
 await page.evaluate(()=>window.scrollTo(0,0));
 await page.screenshot({path:path.join(__dirname,'首頁預覽.png'),fullPage:true});
 await page.locator('#screen-panel [data-advice-tab="reference"]').click();
 await page.screenshot({path:path.join(__dirname,'組織對照預覽.png'),fullPage:true});
 await page.locator('#screen-panel [data-advice-tab="build"]').click();
 await page.setViewportSize({width:390,height:844});
 if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+2))throw Error('Mobile overflow');
 if(errors.length)throw Error(errors.join('\n'));
 const report={homepageChanged:true,baselineImageRetained:true,points,coffeeMachineExamples:'passed',legacyPagesLabeled:true,concreteFunctions:30,adviceTabsChecked:30,svgBounds:'passed',annotationLeaders:0,annotationCards:0,rightSidebar:position,selectWithoutPageScroll:stationary,detailSelection:'passed',removedToolbar:'passed',AFViews:'passed',mobileOverflow:false,pageErrors:errors,paymentApisExecuted:false};
 fs.writeFileSync(path.join(__dirname,'檢查紀錄.json'),JSON.stringify(report,null,2));
 console.log(JSON.stringify(report));await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
