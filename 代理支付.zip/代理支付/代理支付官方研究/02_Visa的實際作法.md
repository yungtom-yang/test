# Visa 的實際作法

研究日期：2026-11-17。以下以本輪讀到的公開版本為準，數值與 API 必須在正式整合前重新核對。

## 1. 先辨認產品分工

| 名稱 | 在流程中的位置 |
|---|---|
| Visa Intelligent Commerce（VIC） | 代理支付能力與相關控制；公開開發文件描述購買指示、驗證及付款憑證生命週期。 |
| Visa Token Service（VTS） | 卡片 Token 化及相關生命週期。 |
| Visa Payment Passkeys（VPP） | 消費者驗證相關能力。 |
| Visa Agent Registry Service（VARS） | 公開文件所述的 Agent 註冊及金鑰驗證相關服務。 |
| Trusted Agent Protocol（TAP） | 商戶／網站保護服務辨識 Agent，並交換連結的消費者、付款資訊。 |
| Intelligent Commerce Connect | 整合及協調多網路、平台、Token 提供者與商務能力的產品；不能直接視為 VIC API 的另一名稱。 |

來源：[VIC Getting Started](https://developer.visa.com/docs/visa-intelligent-commerce)、[Connect](https://corporate.visa.com/en/products/intelligent-commerce-connect.html)、[TAP Getting Started](https://developer.visa.com/docs/trusted-agent-protocol)。

## 2. 客戶先做什麼：卡片設定與委任是兩件事

公開 enrollment 文件描述：先透過 VTS 登錄卡片並建立 provisioned token，取得 `vProvisionedTokenID`；另有 Passkey 與裝置綁定流程。這個 ID 是後續使用的參照，不必等同保存 16 位支付 Token。

這表示本案「PH 綁卡成功」能否直接接到 VIC，仍須確認是否有符合資格的 VTS Token、裝置與驗證設定。VIC 文件要求可 Token 化且符合 CTF 等條件的卡片；持卡銀行有一般發卡資格，不代表所有前置設定已齊全。[Visa Enrollment／Getting Started](https://developer.visa.com/docs/visa-intelligent-commerce/docs-getting-started)

## 3. 購買指示與付款憑證怎麼串起來

以下是概念性流程，依官方 workflow 簡化，並非臺灣銀行已核准架構：

```mermaid
sequenceDiagram
    actor U as 客戶
    participant A as Agent服務
    participant V as Visa VIC
    participant M as 商戶或PSP
    participant N as Visa支付網路
    participant I as 發卡行
    U->>A: 確認購買指示並完成適用驗證
    A->>V: 指示、mandate、驗證資料及交易資料
    V-->>A: 指示ID與付款憑證
    A->>M: 提交訂購及付款所需資訊
    M->>N: 經商戶收單路徑送授權
    N->>I: 網路檢查後送發卡授權
    I-->>N: 核准或拒絕
    N-->>M: 授權結果
    M-->>A: 訂購與付款結果
    A->>V: 回報適用交易事件
    A-->>U: 通知結果
```

官方 workflow 保留了交易對照、商戶／收單送授權，以及發卡行既有控制。取得 VIC 憑證不是付款核准；向 Visa 回報事件也不是要求車隊履約。[Visa Workflows](https://developer.visa.com/docs/visa-intelligent-commerce/workflows)

## 4. 公開 API 讓我們確認了什麼

| API 路徑 | 公開描述的用途 |
|---|---|
| `POST /vacp/v2/credentials-for-instruction` | 將消費者加入 VIC、建立購買指示並取得第一個憑證。 |
| `POST /vacp/v2/instructions/{instructionId}/credentials` | 對既有有效指示取得後續付款憑證。 |
| `POST /vacp/v2/instructions/{instructionId}/confirmation` | 回報交易事件；依完成條件更新指示。 |
| `PUT /vacp/v2/instructions/{instructionId}/cancel` | 取消指示。 |

公開 workflow 說明指示變更採取消後重建，不能把行內 DB 的版本更新視為已同步變更 Visa 指示。[Visa API workflow](https://developer.visa.com/docs/visa-intelligent-commerce/workflows)

API 頁面一般 HTML 未完整顯示 schema，但其官方 Markdown 匯出可讀。可見裝置／應用資訊、`assuranceData`、交易參照、mandate reference、價格與政策等結構；回傳有 `instructionId`，憑證 payload 區分 JWS 與 JWE。這些欄位表示整合涉及驗證、裝置、交易與憑證處理，不是只送一句提示詞。[官方 API Markdown](https://developer.visa.com/api-reference/visa-intelligent-commerce/post-vacp-v2-credentials-for-instruction.md)

## 5. Concepts 中的物件與控制

官方列出 Token、Purchase Instruction、Mandate 與 Credential。指示可包含不同 mandate；憑證取用要指向特定指示及 mandate，並受金額、商戶、期限等適用檢查。支付 Token 與一次性 cryptogram 不能混為一談。

值得核對的數值包括：每個指示最多十個 mandate，cryptogram 描述為單次使用、效期 72 小時；這些是本輪讀到的產品文字，不能當成車隊保留訂單期限，也不能外推到 Mastercard。

官方也區分 VIC 的 mTLS、請求內 Agent signature 及消費者驗證。VIC JSON 內的 `client.agent.agentSignature`，不能直接拿商戶端 TAP HTTP header 當替代品。[Visa Concepts](https://developer.visa.com/docs/visa-intelligent-commerce/concepts)

## 6. TAP 在商戶端實際怎麼運作

TAP 起始文件與商戶規格描述三類連結的簽署資料：Agent recognition、consumer／device recognition、payment container。概念步驟是由 Agent 簽署適用請求資訊，商戶或保護服務取得公鑰、重建簽章基底、驗證來源及涵蓋資料，再使用相應辨識或付款資訊。

規格明說，雙邊合作可使用既有安全介面；TAP 的核心適用情況是商戶原先不認識該 Agent。商戶也可以不採用或忽略相關簽章。故「所有外部商戶都必須支援 TAP，否則絕對不能交易」不成立；但實際能否進站、下單與付款仍受商戶政策和實作限制。[TAP Merchant Specifications](https://developer.visa.com/docs/trusted-agent-protocol/trusted-agent-protocol-specifications)

官方也提供公鑰、signature base 及驗證範例。這些範例可用於理解簽署與驗證，但不等於完整 Agent、付款閘道或上線認證。必須以正式規格指定的簽署範圍為準，不能假設整個 HTTP body 都自動受到保護。[Visa 官方 TAP 程式庫](https://github.com/visa/trusted-agent-protocol)

## 7. 自主交易與 3DS：必須同時讀功能和參與條件

Concepts 列有 `Human-in-the-Loop`、`Autonomous` 與 `Autonomous Recurring`，並對三者要求適用的使用者驗證與意圖紀錄；3DS 另有地區處理差異。文件中的美國特殊處理不能視為臺灣規則。[Visa Concepts：Purchase types／3DS](https://developer.visa.com/docs/visa-intelligent-commerce/concepts)

**重要限制**：Production readiness 同時要求 Agent 在取用憑證前核對交易；除非 Visa 核准例外，客戶須審閱交易細節並明確同意將 Token 交給商戶。自主模式的存在不等於本行已取得例外。正式路徑也包含 Sandbox、Certification 與 Production，並涉及註冊、PCI、合約及相關服務 onboarding。[Visa Production Readiness](https://developer.visa.com/docs/visa-intelligent-commerce/production-readiness)

本案推論：要問的應是「臺灣本行這種受限委任，可使用哪種核准驗證及自主模式、需要哪些條件」，而非先自行決定所有後續交易免 3DS。

## 8. 為什麼取消與結果回報很重要

官方 workflow 區分取消交易憑證與取消整個指示；並明示取消指示後，已發出的憑證仍可能對商戶有效。因此本案不能只改 DB 的委任狀態，就承諾所有已開始的付款都會被立即阻止。必須查清已發憑證、進行中授權、撤銷與退款的關係。[Visa Workflows：Confirmation／Cancel](https://developer.visa.com/docs/visa-intelligent-commerce/workflows)

錯誤文件要求依失敗原因處理，包括更新驗證資料、修正參數、識別過期指示或 Token，不能盲目重送。公開說明沒有給我們可保證防止重複扣款的完整端到端契約；這須另問系統與產品窗口。[Visa Errors and Troubleshooting](https://developer.visa.com/docs/visa-intelligent-commerce/errors-and-troubleshooting)

## 9. 規則文件補充了什麼

2026-10-24 公開 Visa Rules 的 §4.1.23，涵蓋代理服務註冊、交易前同意、驗證、商戶政策、交易後確認、重複交易與責任等要求。這表明條款和產品義務不應只靠技術 API 推定。

其中亦有持卡人責任相關條文，但不能單憑一句推導成「銀行或商戶永遠免責」；需連同適用爭議規則、合約及當地法律，由專業單位判斷。公開版自述省略部分專有及安全資訊。[Visa Rules §4.1.23，印刷頁 263–269](https://corporate.visa.com/content/dam/VCOM/download/about-visa/visa-rules-public.pdf)

## 10. 臺灣案例與尚待回答的問題

Visa 2026-06-16 公告為與台灣大哥大合作的 myfone 試點，涉及限定測試環境及特定卡友，足以支持「臺灣已有特定合作」，不足以支持「所有臺灣銀行可立即正式使用」。[Visa 臺灣官方公告](https://www.visa.com.tw/about-visa/newsroom/press-releases/nr-tw-260616.html)

待向 Visa 確認：

1. 本行可扮演哪些角色、需要哪些登錄與產品合約？
2. 臺灣卡片及商戶適用哪種 3DS、Passkey 與自主執行處理？
3. 已發憑證在取消時如何停用，與已送授權的競態如何處理？
4. Concepts 描述一般指示預設 30 天（美國），workflow 又提非週期指示可能一週後需重新驗證；究竟依何種地區、模式及版本計算？
5. 限額、商戶條件與累計控制哪些由網路保證，哪些由 Agent 或本行執行？
6. 限制 MCC、正式費率、證據欄位及責任規則的本行適用版本為何？

以上是公開文件讀後尚未消除的問題，不以自行假設填補。
