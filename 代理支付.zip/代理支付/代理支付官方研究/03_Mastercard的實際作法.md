# Mastercard 的實際作法

研究日期：2026-11-17。應將 Agent Pay 的商業方案、商戶受理方式、VI 公開草案及實際生產 API 分開閱讀。

## 1. 名稱與產品範圍

| 名稱 | 本輪官方資料支持的定位 |
|---|---|
| Mastercard Agent Pay | 代理式付款方案，運用 Agentic Tokens、代理辨識、使用者意圖及相關控制。 |
| Agentic Token | 延伸網路代碼化能力的代理支付憑證；不能和 VI 授權證據互換。 |
| Agent Pay Acceptance Framework | 商戶受理框架，描述代理註冊、Web Bot Auth、既有表單及更深資料交換。 |
| Verifiable Intent（VI） | 可驗證的授權／委任憑證格式與驗證模型，並非完整付款 API。 |
| Agent Connect | 連接代理、商戶、商品與付款能力的整合產品。 |
| Agent Suite for Merchants | 商戶導入 Agent 商務的服務與能力組合。 |
| Agent Pay for Machines | 延伸機器／代理間交易與多支付軌道的產品方向，不能把它的結算描述直接套用消費信用卡。 |

來源：[Agent Pay 產品頁](https://www.mastercard.com/us/en/business/artificial-intelligence/mastercard-agent-pay.html)、[Agent Connect 公告](https://www.mastercard.com/us/en/news-and-trends/press/2026/september/mastercard-gives-merchants-a-simpler-way-to-build--connect-and-s.html)、[Machines 公告](https://www.mastercard.com/my/en/news-and-trends/press/2026/june/mastercard-launches-agent-pay-for-machines.html)。

## 2. 商戶如何認出 Agent 並接受付款

2025-10-14 官方框架文章描述兩條可並存的路徑：

- 在 CDN 等層級使用 Web Bot Auth 辨識註冊及驗證過的 Agent，配合既有結帳表單使用 Dynamic Token Verification Code 相關方式。
- 進一步整合商務介面及協議，交換代理辨識、消費者身分、購買意圖與付款資料。

因此，並非所有商戶都必須先開發一套 AI Agent，或一定要重新製作專屬 API，才可能參與。反過來，官方的低程式修改路徑也不保證所有網站都能直接完成所有代理工作；庫存、配送、登入、條款與商戶政策仍須處理。[Mastercard Acceptance Framework](https://www.mastercard.com/global/en/news-and-trends/stories/2025/agentic-commerce-framework.html)

Web Bot Auth 的 HTTP 簽章與 VI 的授權證據是不同層次。Cloudflare 官方實作說明包括金鑰目錄、註冊及簽署請求，並明說其當前實作不以 nonce 資料庫處理防重播；不應推定「有這個 header 就已防止所有重播」。這是 Cloudflare 的特定實作行為，不能概括所有 TAP 或 Mastercard 系統。[Cloudflare Web Bot Auth](https://developers.cloudflare.com/bots/reference/bot-verification/web-bot-auth/)

## 3. VI 為什麼存在

假設 Agent 說：「客戶答應我買了。」商戶與銀行若只能相信 Agent 的文字，就難以獨立核驗。VI 要把憑證提供者、使用者及代理的權限關係連成可驗證證據鏈。

Mastercard 官方文章將 VI 定位為與 Google 共同開發、可跨協議使用的開放信任層；官方連結的網站及程式庫標示 Draft v0.1。2026 年 FIDO 公告亦將 AP2 與 VI 列為標準工作的初始貢獻；不能稱其為已完成全球一致部署的最終產業標準。[Mastercard VI 公告](https://www.mastercard.com/global/en/news-and-trends/stories/2026/verifiable-intent.html)、[FIDO 官方進度](https://fidoalliance.org/fido-alliance-to-develop-standards-for-trusted-ai-agent-interactions/)

## 4. 三層憑證用白話怎麼理解

| 層次 | 誰簽署 | 表達的意思 |
|---|---|---|
| L1 | 憑證提供者，例如符合角色的金融機構或代其作業的網路 | 將支付相關身分與使用者公鑰連起來。 |
| L2 | 使用者對應私鑰 | 直接同意最終交易，或將有邊界的權限委託給 Agent。 |
| L3（自主模式） | 被 L2 指定的代理私鑰 | 在這份委任下，選出了哪筆具體交易。 |

Immediate 模式採 L1、L2；Autonomous 模式再增加 L3。自主模式的 L3 分成付款用 L3a 與商務結帳用 L3b，分別提供相關參與者。驗證者須沿金鑰綁定及簽章檢查授權鏈，不能只確認最後一層簽章。[VI Specification Overview §3](https://www.verifiableintent.dev/spec/)

```mermaid
flowchart TD
    A[憑證提供者簽L1：綁定使用者公鑰] --> B[使用者簽L2]
    B --> C[Immediate：同意具體交易]
    B --> D[Autonomous：限制條件與代理公鑰]
    D --> E[代理依條件選定交易]
    E --> F[L3a：付款證據給支付端]
    E --> G[L3b：結帳證據給商戶]
    F --> H[核驗與既有付款處理]
    G --> I[核驗與商戶訂單處理]
```

圖是草案概念教學，不是 Mastercard 臺灣案例的實際系統圖。

## 5. 為什麼把購物與付款分開

購物資料回答商品、數量及商戶；付款資料回答付款工具、收款方、金額。不同參與者需要的資料不同，因此 VI 使用選擇性揭露，讓各方取得對其角色必要的資料。

但分開後仍須證明「付的款對應這張訂單」。Credential Format 描述以商戶簽署 checkout JWT 的雜湊連結 checkout 與 payment；自主模式的 `checkout_hash` 與 `transaction_id` 彼此對應。這不是把對話文字丟上區塊鏈，而是依規格計算雜湊、驗簽與檢查關聯。[VI Credential Format §5–6](https://www.verifiableintent.dev/spec/credential-format/)

## 6. 哪些條件真的可檢查

Constraints 文件定義商戶、商品項目、收款方、金額範圍、累計預算及週期等規則，金額以幣別最小單位的整數表達，並要求相關比對。文字商品描述不應直接等同機器已理解的約束。

一個重要細節是商品 `acceptable_items` 若為空，草案描述為允許任何項目；因此「欄位存在」不等於「有約束」。未知規則的處理模式也會影響保護範圍。[VI Constraints，尤其 §7](https://www.verifiableintent.dev/spec/constraints/)

本案推論：像「車子舒服」「不要太早到機場」必須先轉成可確認條件；免費取消期限、乘客數、行李數等是否有對應可執行欄位，要逐項確認。不能假設 VI 自動替我們理解全部自然語言。

## 7. 為什麼簽章之外還要資料庫

合法代理可簽出多個不同的交易證據，這與同一封訊息被重播不同。安全模型要求支付網路追蹤委任已使用情況及適用的交易次數、累計金額。沒有狀態，共同上限就無法僅靠每筆驗簽達成。

VI v0.1 也沒有完整定義憑證層撤銷協定；短效期及既有發卡／網路控管只是不同層次的緩解方式。這對本案「客戶剛取消，但 Agent 已準備付款」尤其重要。[VI Security Model §4.2、§6](https://www.verifiableintent.dev/spec/security-model/)

## 8. 草案有什麼需要再問清楚

Credential Format §8.3 把多次交易擴展列為 planned；Constraints、安全模型及設計理由則已描述 `agent_recurrence` 與累計預算的執行。這可能反映文件更新進度不一致，不能自行判定所有能力都已生產可用。[Credential Format](https://www.verifiableintent.dev/spec/credential-format/)、[Design Rationale §8–9](https://www.verifiableintent.dev/spec/design-rationale/)

VI 程式庫 README 明確把傳輸、金鑰設定、enrollment、代理平台 API、爭議解決與法規對照等列在核心格式範圍之外。讀懂 VI 不等於取得完整 Agent Pay 串接規格。[官方連結之 VI 程式庫](https://github.com/agent-intent/verifiable-intent/)

此外，VI 與 WebAuthn 的驗證、簽署工作互補；設計理由明確表示 VI 不取代 SCA。不能從「使用生物辨識」推論「自動免除所有其他驗證或規則」。[VI Design Rationale](https://www.verifiableintent.dev/spec/design-rationale/)

## 9. Agent Pay 本身有哪些可確定資訊

2025-04-29 公告介紹 Agentic Tokens，並指出方案與既有代碼化能力、收單及結帳參與者合作。它支持「代理付款延伸既有網路」的理解，未提供本案可直接照做的完整 MDES 設定、API 欄位或責任分配。[Mastercard Agent Pay 發布公告](https://investor.mastercard.com/investor-news/investor-news-details/2025/Mastercard-Unveils-Agent-Pay-Pioneering-Agentic-Payments-Technology-to-Power-Commerce-in-the-Age-of-AI/default.aspx)

2026 年 9 月白皮書把信任框架分成 Identity、Intent、Controls、Trusted execution、Intelligence 五項，進一步說明身份、委任、限制、付款保護與持續風險判斷需共同運作。它是架構及策略說明，不是 API reference。[Trust for Agentic Commerce，§Framework](https://preview.mastercard.com/content/dam/mccom/shared/news-and-trends/stories/2026/trust-for-agentic-commerce-white-paper/Trust%20for%20agentic%20commerce%20white%20paper.pdf)

本輪由官方文章連往 Mastercard Developers 的 Agent Pay use case 路徑，查閱回應為 404；不能據此推定 API 不存在、全面未公開或一定需要帳號。確切取用方式須向窗口確認。

## 10. 臺灣機場接送案例對我們有何意義

2026-03-26 官方公告描述與星展銀行（台灣）的機場接送交易：客戶提出地點、時間及人數，Agent 推薦方案，消費者選定後，以綁定的 Mastercard 完成預訂及支付；公告也提到代理專屬 Agentic Token。

這個案例證明特定合作交易已發生，且其描述包含使用者選擇與授權。公告未揭露完整 API、3DS／Passkey 執行細節、委任證據格式或爭議分配；尤其不能推論這筆案例一定用了後來公開的 VI v0.1 完整流程。[Mastercard 臺灣官方案例](https://www.mastercard.com/tw/zh/news-and-trends/press/2026/march/first-agentic-transaction-in-taiwan.html)

## 11. 下一步應向 Mastercard 詢問

1. 本行自建 Agent 的參與角色、註冊、認證及商業條件。
2. 臺灣可實際使用哪些 Agent Pay API、Agentic Token 及驗證方式。
3. Agentic Token、VI 與 Web Bot Auth 如何在本案串接，哪些是必要條件。
4. 自主與多次交易能力的正式版本、撤銷及狀態執行方式。
5. 既有商戶表單路徑與深度 API 路徑，各需什麼 PSP／收單能力。
6. 臺灣機場接送案例的可分享架構、使用者確認節點與適用限制。
7. 購買錯誤、未授權、商戶未履約及重複扣款，分別依什麼規則處理。
