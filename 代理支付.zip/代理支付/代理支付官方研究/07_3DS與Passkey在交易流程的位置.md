# 3DS、Passkey與代理交易：在哪裡驗、由誰驗、客戶做什麼

查核日期：2026-11-19，Asia/Taipei。這是公開文件教學與本案流程映射，不是臺灣本行已核准的生產介接規格。部分直接網址取用失敗，改以官方搜尋索引可讀正文交叉確認。

## 1. 先回答核心問題

**一般電商付款若走3DS，主要位於「商戶結帳、送信用卡付款授權之前」。代理支付還多出較早的「客戶建立付款工具、確認購買指示或委任」驗證；那一段可使用Payment Passkey或其他核准方法，不能一律叫做3DS。**

Agent可以發起驗證、呼叫SDK、把客戶導向適當畫面及傳遞結果；系統可以自動驗證密碼學證據。但需要客戶完成的刷臉、指紋或裝置PIN，仍由客戶在受信裝置／驗證介面操作。**「系統驗簽」與「客戶當下驗身」是兩件事。**

也不是每筆都必須「先Passkey，再跳OTP」。Passkey可以用在Agent端，也可能用於3DS挑戰；先前驗證資訊亦可能支援無感判斷。是否仍需挑戰，依方案、風險、地區政策及參與者支援決定。

來源：[EMVCo Passkeys與3DS](https://www.emvco.com/news-publications/understanding-the-use-of-passkeys-in-payments/)、[Visa VIC Concepts](https://developer.visa.com/docs/visa-intelligent-commerce/concepts)、[VI Design Rationale §3–4](https://verifiableintent.dev/spec/design-rationale/)。

## 2. 交易全程的四個驗證／決策位置

| 時間點 | 問題 | 常見參與者與方法 | 客戶是否要操作 |
|---|---|---|---|
| A 加入卡片、建立Token及Passkey | 這個人有權使用這張卡嗎？裝置／憑證如何建立？ | 發卡行、Token及驗證服務；ID&V、銀行App、OTP或適用方式 | 初次設定或要求升級驗證時通常需要 |
| B 同意具體購買或建立受限委任 | 是本人允許Agent做這件事嗎？批准什麼範圍？ | Agent／錢包發起；Payment Passkey或核准方法；產生指示／委任證據 | 有人確認時參與；自主模式在建立委任時參與，後續依政策 |
| C 商戶結帳的適用3DS | 這筆電商付款的持卡人驗證如何處理？ | 商戶3DS Server、卡網路DS、發卡端ACS；無感或挑戰 | 無感可能不用；挑戰需依要求操作 |
| D 信用卡付款授權 | 卡況、額度與風險是否允許付款？ | 商戶／收單→卡網路→發卡授權系統 | 通常為系統處理；核准與否不等於3DS驗身結果 |

同一銀行可以同時提供App驗證、ACS與發卡授權服務，但三者的工作仍不同。登入銀行App、用App刷臉、以App完成3DS挑戰，外觀可能相似，後端驗證語意卻不同。

這張表是跨來源的教學整理，不表示兩家公司有完全相同的A–D API。

## 3. 一般3DS如何執行

Visa的3DS品牌是Visa Secure；Mastercard的是Identity Check。兩者的3DS流程建立在EMV 3DS架構上。

```mermaid
sequenceDiagram
    participant M as 商戶／PSP與3DS Server
    participant DS as 卡網路Directory Server
    participant ACS as 發卡端ACS
    actor U as 客戶
    participant I as 發卡授權系統
    M->>DS: 3DS驗證請求及交易／裝置資料
    DS->>ACS: 路由驗證請求
    alt 可無感處理
      ACS-->>DS: 驗證結果，不要求客戶挑戰
      DS-->>M: 回傳驗證結果
    else 需要額外驗證
      ACS-->>M: 經3DS流程要求Challenge
      M->>U: 顯示／導向驗證流程
      U->>ACS: 依支援方式完成OTP、銀行App或Passkey等
      ACS-->>M: 經適用3DS路徑回傳結果
    end
    M->>I: 經收單與卡網路提交付款授權及適用驗證資料
    I-->>M: 沿支付鏈回覆核准或拒絕
```

圖省略Challenge的訊息細節、SDK／瀏覽器差異與部分回傳中介，不表示ACS直接在所有情況連到商戶。也不涵蓋所有非付款驗證、3RI或解耦驗證變體。

- **3DS Server**：代表商戶端發起與管理3DS驗證；可能由PSP或服務商提供。
- **DS**：Directory Server，卡網路的驗證路由等服務角色，不是直接要求客戶輸入OTP的唯一端點。
- **ACS**：Access Control Server，發卡端的3DS驗證系統，可由發卡行或其服務商營運。
- **發卡授權系統**：判斷卡片付款能否核准；與ACS角色不同。

**Frictionless仍可能是有經過3DS的驗證結果；沒有看到OTP，不代表完全沒做3DS。** Challenge則可採多種支援方法，不能固定等同簡訊OTP。Passkey與3DS不是必然互斥，EMVCo明確說明WebAuthn／SPC可用在Challenge。

來源：[EMVCo Passkeys與3DS](https://www.emvco.com/news-publications/understanding-the-use-of-passkeys-in-payments/)、[EMVCo裝置／風險資料與3DS角色](https://www.emvco.com/dynamic/emv-3-d-secure-whitepaper-v2/improving-risk-emv-3-d-secure-whitepaper-v2-analysis-and-frictionless-flow/technical-features/)、[WebAuthn與SPC](https://www.emvco.com/dynamic/emv-3-d-secure-whitepaper-v2/challenge-flow/webauthn-and-spc/)、[Mastercard Identity Check介紹](https://www.mastercard.com/news/ap/en/newsroom/press-releases/en/2019/december/mastercard-identity-check-program-makes-india-debut-with-federal-bank/)。後者為歷史品牌介紹，不用來判斷2026年完整規則。

## 4. Passkey實際怎麼驗：Agent不會自己替人刷臉

以下為典型公鑰驗證機制的教學概述；確切SDK、金鑰範圍及回應由方案決定。

1. Agent／錢包／商戶應用請驗證服務開始一個驗證流程，取得挑戰值及必要參數。
2. 前端透過受支援SDK或WebAuthn等機制，呼叫客戶裝置的驗證功能。
3. 裝置依政策要求客戶刷臉、指紋、裝置PIN或其他支援操作。這裡的PIN通常是裝置解鎖PIN，不可直接稱為信用卡PIN。
4. 客戶完成本機驗證後，驗證器以對應私鑰產生受保護的回應／簽署證據；Agent不需要取得客戶臉部影像、指紋樣板或私鑰。
5. 接收證據的驗證服務以對應公鑰及協定規則核驗；檢查挑戰、來源／用途、時間與必要的使用者驗證結果。
6. 成功結果再依產品格式與此次指示或交易關聯，例如Visa的assuranceData；失敗、取消或過期時，不應自行當成已驗證。

「系統發現已有Passkey」只代表可以走使用既有憑證的路徑，**不是說找到Passkey就已完成本人驗證**。同樣，「使用者曾登入銀行App」不代表任何付款服務都會接受那次登入結果；須有核准的資料關聯與驗證傳遞。

來源：[Visa Enrollment](https://developer.visa.com/docs/visa-intelligent-commerce/docs-getting-started)、[Mastercard臺灣Payment Passkeys公告](https://www.mastercard.com/tw/zh/news-and-trends/press/2025/july/payment-passkeys-launch.html)、[Mastercard臺灣FAQ](https://www.mastercard.com/tw/zh/personal/get-support/frequently-asked-questions.html)、[VI Design Rationale](https://verifiableintent.dev/spec/design-rationale/)。

## 5. Visa：完整交易順序

### 5.1 初次設定

1. 由受控流程加入卡片，經VTS設定適用Token，取得Token參照。
2. 依要求完成卡片ID&V、裝置與Passkey流程。官方流程會檢查既有Passkey：AUTHENTICATE走既有驗證路徑，REGISTER則需處理新註冊。
3. 裝置綁定若回CHALLENGE，依提供的方法請客戶完成升級驗證；例如導向銀行App，等待成功通知。Passkey設定失敗不能自行略過，除非方案已獲特別核准。

這一段是工具與憑證設定，不能一概標為「每次商戶付款的3DS」。來源：[Visa Enrollment](https://developer.visa.com/docs/visa-intelligent-commerce/docs-getting-started)。

### 5.2 客戶批准購買指示

1. 客戶提出需求；Agent取得或整理商品、商戶、總價與條件。
2. 依購買模式呈現具體交易或受限委任，請客戶確認。
3. Agent應用發起Payment Passkey或核准方法；需客戶操作時，由客戶完成裝置驗證。
4. 將驗證結果連結到購買指示，送VIC首次取憑證操作；workflow以assuranceData傳遞驗證資料。
5. VIC驗證適用資料與指示，再提供付款憑證。此時仍未得到發卡付款核准。

VIC Concepts列有FIDO2、App-based、OTP及VTS step-up等assuranceData方法；欄位支援不表示本行可任選且免核准。來源：[Visa VIC產品流程](https://developer.visa.com/capabilities/visa-intelligent-commerce)、[Workflows](https://developer.visa.com/docs/visa-intelligent-commerce/workflows)、[Concepts](https://developer.visa.com/docs/visa-intelligent-commerce/concepts)。

### 5.3 商戶結帳與付款

1. Agent將必要付款資料交給商戶受理鏈。
2. **適用3DS時，商戶／PSP按方案發起3DS，經DS至發卡端ACS。** 前段Passkey不代表全球一律免3DS，也不代表固定再驗一次OTP。
3. 若要求持卡人Challenge，Agent需將客戶帶回受支援驗證流程。人在別處或無法完成時，依正式支援等待、暫停或失敗，不可代答。
4. 商戶經收單→Visa→發卡授權系統提交付款。發卡行按卡況、額度、風險及適用證據核准／拒絕。
5. 商戶確認訂單，Agent處理結果與VIC confirmation；驗證成功、授權核准及訂單成立分別管理。

**地區邊界：** VIC Concepts明說美國代理交易的3DS有Program Not Supported的特殊處理，其他地區有地區性3DS處理。臺灣不能直接照搬美國。取得付款Token中的cryptogram／ECI，也不能一概叫作已完成某種3DS挑戰。

來源：[Visa Concepts](https://developer.visa.com/docs/visa-intelligent-commerce/concepts)、[Workflows](https://developer.visa.com/docs/visa-intelligent-commerce/workflows)。

### 5.4 Visa自主交易仍有哪些條件

```mermaid
flowchart TD
    A[客戶確認指示並完成適用驗證] --> B[Agent依有效範圍搜尋與執行]
    B --> C{指示與驗證是否仍有效且符合上線條件}
    C -->|否| D[找客戶重新同意或驗證]
    C -->|是| E[依核准方式取得付款憑證]
    E --> F[商戶結帳及地區適用3DS]
    F --> G{是否要求客戶Challenge}
    G -->|是| H[將客戶帶回驗證；無法完成則不繼續假裝成功]
    G -->|否或已完成| I[送付款授權並確認訂單]
    H -->|成功且仍可付款| I
```

不是每次後續取憑證都代表客戶重新刷臉：有效驗證／委任可能被依規則使用。可是有效期、重新驗證與上線批准要一起看。尤其Production Readiness要求：**除非Visa核准例外，客戶要審閱交易細節並明確批准將Token交商戶。**「已有自主模式」不能自動免除這項要求。

來源：[Visa Production Readiness](https://developer.visa.com/docs/visa-intelligent-commerce/production-readiness)。

## 6. Mastercard：能確認的流程與不能補造的細節

### 6.1 先完成付款工具及驗證能力

Agent、錢包／付款提供者、發卡行與Token服務依合作方式設定卡片與Agentic Token；客戶在適用流程建立或使用Payment Passkey等驗證能力。臺灣Payment Passkeys公告說明可使用臉部、指紋或裝置PIN，但**該產品已在臺灣上線，不等於任一銀行的Agent Pay自主情境都可直接套用**。

來源：[Mastercard臺灣Payment Passkeys](https://www.mastercard.com/tw/zh/news-and-trends/press/2025/july/payment-passkeys-launch.html)。

### 6.2 人在場確認具體交易

1. Agent找好商品／服務，客戶看到確切內容與金額並批准。
2. 依合作流程執行裝置端強驗證，如Payment Passkey；應用發起、客戶在裝置完成所需操作。
3. 若採VI Immediate模型，由Issuer簽的L1連結使用者金鑰，使用者對應金鑰簽L2，表達最終批准交易。
4. Agent用適當Token與證據進行商戶結帳。
5. 若該受理路徑適用3DS，經Mastercard Identity Check的DS／ACS處理；不保證每筆新增挑戰，也不保證一律免除。
6. 商戶經收單與Mastercard送發卡付款授權；之後確認訂單及處理交易後狀態。

這是產品、VI及EMV角色的教學組合，**不是聲稱每筆Agent Pay都依同一VI profile、同一API順序或每次固定刷臉**。公開資料尚不足以逐支端點確認本行的生產呼叫序列。

### 6.3 預先委任、自主執行

1. 客戶先確認具體可執行條件並完成適用驗證；若採VI Autonomous，L2委任Agent金鑰及限制。
2. Agent稍後選定交易，以自己的委任金鑰簽L3a／L3b；此時是**Agent證明執行符合先前委任**，不是冒充客戶重新完成Passkey。
3. 商戶／支付相關驗證方按其角色驗簽、查限制與狀態，再執行受理及付款。
4. 如果超出範圍、證據到期或要求持卡人挑戰，就需要重新取得客戶參與或停止；Agent自己的簽章不會消除該要求。

Mastercard 2026年4月商戶白皮書第9–10頁，將預先授予限制內購買權限、VI、Agentic Tokens及Passkey等驗證放在同一信任模型。這支持「可在先前授權範圍內自主執行」的理解，**不支持無條件永久免驗身或全球免3DS**。VI Design Rationale又明確說明WebAuthn驗證與VI授權簽署是分開操作、不同用途的金鑰；VI不取代SCA。

來源：[Mastercard商戶白皮書，第9–10頁](https://www.mastercard.com/content/dam/mccom/eu/news-and-trends/business-thought-leadership/digital-payments/pdfs/Get_ready_for_AI-powered_shopping_experiences.pdf)、[VI Overview](https://verifiableintent.dev/spec/)、[VI Design Rationale](https://verifiableintent.dev/spec/design-rationale/)。

## 7. 放回原始A–F流程

| 原流程 | 驗身／控制標記建議 |
|---|---|
| A 綁卡 | 卡片ID&V、Token設定、Passkey註冊及裝置相關流程；不統稱為商戶3DS |
| B 委任 | 客戶看懂並同意範圍；執行適用強驗證，產生可關聯的意圖證據 |
| C 搜尋／保留 | Agent操作商戶，商戶驗Agent來源；通常不表示客戶每次重新驗身 |
| D 比對／E 最後檢查 | 核對交易、委任、驗證有效期及最新金額；不符合則回客戶 |
| F 付款 | 拆成F1適用3DS／Challenge、F2付款授權、F3訂單結果確認 |

若特定產品把驗證或付款資料取得放在結帳服務內，圖上位置要跟著實際介面調整。不要硬把所有驗證都畫在同一個「國際組織」方塊裡。

## 8. 機場接送例子

以下數字與時間僅為教學設定。

- 客戶今天委任：「明天上午找四人接送，含行李與費用不超過NT$1,500，只買一次。」客戶先確認條件並在要求時完成裝置驗證。
- Agent之後找到NT$1,400方案。若有效委任、驗證與正式模式允許，可使用既有證據繼續，不代表重新用客戶指紋。
- 若需要客戶審閱最終交易（例如Visa正式路徑未取得例外），此時仍須請客戶確認。
- 若商戶付款時要求Challenge，須再把客戶帶入所需驗證；先前的NT$1,500委任不保證此次可無感通過。
- 若含費用變成NT$1,600，應重新取得同意或放棄，不能只因Token可用就付款。
- 驗證通過後，發卡行仍可能因額度或風險拒絕。付款核准後，仍須確認車隊訂單成立。

## 9. 導入前請兩家與PSP共同回答

1. 本行臺灣情境中，驗身發生在卡片設定、委任、最終結帳的哪一點？誰是relying party及驗證結果接收方？
2. Agent端Payment Passkey結果如何交商戶／PSP／DS／ACS？能否被接受為既有驗證資料，需哪些欄位及協議版本？
3. 什麼條件走frictionless、Challenge、重新驗證或拒絕？哪些是正式方案要求，哪些是發卡／商戶風險判斷？
4. 自主Agent沒有即時客戶裝置時，若要求Challenge要怎麼喚回客戶、多久到期、如何恢復訂單？
5. 委任有效期、Passkey assertion／assurance有效期、付款憑證有效期各是多少？取消、裝置更換與Token停用如何影響？
6. 是否有正式核准的自主例外、臺灣適用驗證規則與生產案例可供對照？

## 10. 本輪附帶更正

88頁簡報第15頁備忘稿先前將VARS誤展開為Visa Advanced Risk Signals，現已校正為 **Visa Agent Registry Service**，負責Agent註冊與相關金鑰驗證。這項更正不改變本章3DS、Passkey與付款授權的分工。
