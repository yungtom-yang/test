# VIC／Agent Pay 能否取代原流程中的自建功能

查核日期：2026-11-17。此章補存本次交談最後形成的判斷，閱讀先後上優先於前面圖面可能造成的「全部模組一定要自建」印象。

## 問題背景

使用者轉述前輩構想：若與 VIC 或 Agent Pay 合作，是否可以將原本自行規劃的 Agent、代理紀錄及比對等部分取代，簡化為「客戶 → 入口 → Agent Pay → 自行既有交易流程」？

## 核實結論

**合作可以減少自建，但僅使用 VIC／Agent Pay，不足以證明整套購物代理、商品介接、紀錄、比對及營運功能已全部由對方提供。**

需要區分功能是否仍須存在、由誰承擔、是否須獨立成模組，以及是否由銀行自己開發。這四件事不能畫等號。

1. Visa 官方 workflow 仍由 Agent 取得及整理購買指示，向 VIC 取得付款憑證，再提交給商戶，經商戶／收單與支付網路送發卡行處理。
2. Visa 正式參與要求仍包括 Agent Provider 的交易符合性檢查、適當同意、控管及紀錄留存；不能推定全部由 Visa 代為處理。
3. Mastercard 官方受理框架描述註冊 Agent 使用 Agentic Tokens 交易；Agent 與 Agent Pay 不能直接視為同一套完整購物軟體。
4. Mastercard 另外提供 Agent Suite／Agent Connect 等商務或代理相關能力。因此若採購的是包含相關能力的整合服務，銀行自建範圍可能更小，但須按實際產品、合約及市場資格確認。

## 依原圖功能對照

| 原本功能 | 最新判讀 |
|---|---|
| Agent 理解需求、查詢與選擇 | 須有實際提供者，可自建或委外；單接 VIC／Agent Pay 不保證包含。 |
| 委任、意圖與授權證據 | 可使用外部機制，整合範圍依服務契約；不必預設全部自己重做。 |
| 獨立比對 | 應盤點網路及合作服務已強制哪些條件、還缺哪些商品檢查；不必預設保留原獨立模組，也不能一律刪除。 |
| 支付Token及動態憑證 | 可大量採用國際組織／合作方能力；本行安全整合邊界須確認。 |
| 狀態、交易紀錄、異常與客服 | 須明確分工，可由合作服務執行，不能因付款合作就認定責任消失。 |

## 應比較的兩種合作／建置方式

- **銀行經營購物代理，接組織付款能力**：銀行或其委外開發者提供商務決策與服務，VIC／Agent Pay 提供適用的信任、憑證及付款能力。
- **採購整套代理服務**：合作方另提供 Agent、商戶介接、委任、交易檢查與付款整合；銀行整合入口及適用既有系統。這種方式的中間方塊應稱「合作方整合代理服務」，並註明使用 VIC／Agent Pay，而非僅寫 Agent Pay。

第二種為本案可評估的採購模型，尚未取得供應商承諾或本行可用證據。

## 「自行既有交易流程」的兩種意思

- 若指本行**發卡授權**，外部交易可經商戶／收單及國際組織回到本行；仍須確認適用訊息與規則。
- 若指本行**EPOS／PH收單或付款入口**，不能推定所有外部商戶都改走本行；須看本行對該商戶的實際合作角色。

## 對現有圖表的影響

目前圖表是「銀行側保留代理控管責任」的研究視圖，不是唯一解，也不是必須建立相同數量系統的需求清單。下一步應補畫「整套代理服務委外」替代視圖，並建立功能與責任分工表，取得合作方規格後再判斷可刪除、合併或委外的模組。

## 本輪重新核對的官方來源

- [Visa Workflows](https://developer.visa.com/docs/visa-intelligent-commerce/workflows)：Agent、VIC、商戶、收單及發卡處理分工。
- [Visa Production Readiness](https://developer.visa.com/docs/visa-intelligent-commerce/production-readiness)：Agent Provider 同意、交易核對、紀錄及正式參與要求。
- [Mastercard Acceptance Framework](https://www.mastercard.com/global/en/news-and-trends/stories/2025/agentic-commerce-framework.html)：代理註冊、受理與付款能力。
- [Mastercard Agent Pay 發布公告](https://investor.mastercard.com/investor-news/investor-news-details/2025/Mastercard-Unveils-Agent-Pay-Pioneering-Agentic-Payments-Technology-to-Power-Commerce-in-the-Age-of-AI/default.aspx)：Agentic Token 與既有AI及付款參與者合作。
- [Mastercard Agent Suite／Agent Connect 公告](https://www.mastercard.com/us/en/news-and-trends/press/2026/september/mastercard-gives-merchants-a-simpler-way-to-build--connect-and-s.html)：商務／代理服務與Agent Pay的產品分工。

以上按官方描述判斷公開功能邊界；沒有取得本行合約、完整API或正式採購範圍。
