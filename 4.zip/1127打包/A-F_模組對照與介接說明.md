# Visa 與 Mastercard A–F｜機場接送首次預約

這一版使用一筆機場接送首次預約。客戶希望 12 月 10 日 20:00 從桃園機場到臺北市飯店，兩位乘客、兩件大行李，含費預算上限 NT$1,600。可成交的示意報價為 NT$1,480。客戶逐筆核准，外部 Agent 與合作方經營前段，本行以發卡行身分參與。日期、費用與路線均為示意。

[Visa 總圖與時序圖](Visa_A-F_時序圖.html) · [Mastercard 總圖與時序圖](Mastercard_A-F_時序圖.html) · [可編輯 A–F 圖](Visa_Mastercard_A-F_時序圖.drawio) · [逐節點核對與介接驗收](../計畫A_前段委外與本行發卡_2026-11-26/端到端逐節點對照與本行介接清單.md)

## 依階段比較模組

| 階段 | Visa | Mastercard | 本案交接 |
|---|---|---|---|
| **P 上線前** | 核對 VIC 的 Agent Provider 直連或 Agent Enabler 代接資格，以及適用發卡與受理準備。 | 核對 Agent Pay 的代理註冊、身分驗證和受理資格。取得具名介接方及正式測試計畫。 | 向車商確認空車、報價、結帳、建單、查單與取消接口。向 PSP／收單方核對付款格式，向本行核對卡別、帳務、測試和營運窗口。 |
| **A 卡片準備** | VTS 準備卡片代碼。VIC 用的 Token 須符合 ID&V。視卡片、裝置和方案完成適用 VPP 設定及發卡驗證。 | Agent Pay 支援 Agentic Token。實際卡片設定、請領方、配發時點和驗身方式依選定方案。 | 客戶在外部入口選卡。安全介接方取得可供本案付款的參照。本行在適用時回覆資格或驗身。 |
| **B 交代需求** | 外部服務留存查車條件。VIC 的購買指示在 E1 隨核准、驗證與請領處理。 | 外部服務留存查車條件。若採 VI Immediate，所需證據在 E1 與最終結帳關聯。 | B 確認路線、時間、人數、行李、預算及查車範圍。具體付款由客戶在 E1 核准。 |
| **C 查車與報價** | TAP 可辨識可信代理，ICC 可協助商務及付款介接，依具名覆蓋評估。 | Web Bot Auth 可辨識可信代理，Agent Connect 可協助參與商戶發現、購物車與付款銜接，依具名覆蓋評估。 | 外部 Agent 直連車商 API，或經有授權的整合方。車商回空車、承載、含費報價、條款及結帳版本。 |
| **D 核對預約條件** | VIC 要求 Agent Provider 取憑證前核對交易是否符合客戶指示。 | Agent Pay 支持可信代理及付款控制。接送條件由前段按車商資料核對。 | 外部 Agent 營運方核對委任與車商明細。無車、報價失效、不符承載或超預算，先停止。 |
| **E1 核准及取憑證** | 客戶核准後先用 VPP 或核可方式驗證指示。前段帶驗證結果呼叫 VIC Credentials for Instruction。VIC 核對後回受保護憑證。 | 客戶逐筆核准，前段依正式 Agent Pay 方案使用 Agentic Token 與適用動態資料。若採 VI Immediate，須將商戶簽署的最終結帳與客戶付款證據綁定。 | 車商、日期路線、車型、含費 NT$1,480、卡片及取消條款固定在同一版結帳。改價或改車時重核，取得客戶再次同意。 |
| **E2 依條件做結帳驗身** | 受理路徑支援且要求時，送授權前另走商戶 3DS／本行 ACS。VIC 購買指示驗證已在 E1。 | 3DS 的發起方、發卡 ACS 銜接與是否適用，由受理方案確認。若採 VI，E1 處理付款意圖證據。 | 核對商戶 PSP、卡組織與發卡端的驗證資料交換。額外驗身完成後才依路徑送 F1。 |
| **F1 卡片授權與接單** | 經 VisaNet 送本行發卡授權。依 VIC 方案回報適用交易事件。 | 經 Mastercard 卡網送本行發卡授權。代理標示、事件與證據欄位須拿正式樣本。 | 車商經 PSP／收單送卡網，銀行回核准或拒絕。車商另外回接單與訂單號。兩邊成功後由外部入口通知已預約。 |
| **F2、F3 同筆預約的例外** | 已取憑證且要取消仍有效的 VIC 指示，先回報交易事件。支付撤銷、退款與爭議另依卡網規則。 | 依交易狀態走 Mastercard 既有撤銷、退款與爭議流程。新增 Agent Pay／VI 證據通道待合作方確認。 | 逾時先查同一筆訂單及付款。依原付款狀態及適用規則處理撤銷或退款。發卡爭議由本行受理並按案由調閱。 |

## 報告者講稿

**P｜先把能成交的路徑談清楚。** 我們要示範一筆接送從零到成立。先找一家具名車商，確認外部 Agent 能透過 API 查到有空的車、拿到含費報價、建單並查回狀態。車商的 PSP 或收單行要能接這種支付，卡組織確認適用方案，本行驗證發卡端能受理。

**A｜客人先選卡。** 外部入口讓客戶選一張本行卡。付款介接方依所選卡組織準備適用的代碼化付款能力。若有新增設卡驗身，本行在這時提供驗證。已設定且有效的卡可依方案沿用。

**B｜客人說他要哪一趟。** 12 月 10 日晚上八點，要從桃園機場到臺北市飯店。兩個人、兩件大行李，費用最多 1,600 元。外部 Agent 先回顯條件，客人同意在這個範圍查車。

**C、D｜車商報價，外部 Agent 核對。** Agent 透過合作車商 API 拿到含費 1,480 元的方案，再核對時段、路線、承載、效期與取消條款。即使價格在預算內，行李放不下就不能送進結帳。Visa 有適用的 TAP 和 ICC，Mastercard 有 Web Bot Auth 和 Agent Connect。車商是否可查和可下單，以實際合作覆蓋與接口為準。

**E｜客人看過這一筆，再同意付款。** 外部入口出示車商、車型、時間、路線、1,480 元、取消條款及付款卡。走 Visa 時，客戶先完成購買指示驗證，前段再經 VIC 取憑證。走 Mastercard 時，由具資格的介接方按 Agent Pay 方案準備 Token 與適用付款資料。商戶路徑若另要求 3DS，就在送授權前完成。

**F1｜銀行核准卡片，車商確認訂單。** 車商或 PSP 把這筆授權送收單，卡網轉到本行，本行回覆能不能用這張卡付這筆錢。外部服務還會查車商的接單結果。付款授權和車商接單都確認後，外部入口才告訴客人「已預約」，並給他訂單編號。

**F2、F3｜同一筆預約的例外。** 若訂單或付款逾時，先查同一筆。取消、退款或帳務爭議依原訂單與付款參照追查。

## 官方依據

- [Visa VIC 接入與卡片設定](https://developer.visa.com/docs/visa-intelligent-commerce/docs-getting-started) · [VIC 購買指示、憑證與事件工作流程](https://developer.visa.com/docs/visa-intelligent-commerce/workflows) · [Visa 正式接入責任](https://developer.visa.com/docs/visa-intelligent-commerce/production-readiness)
- [Visa TAP](https://developer.visa.com/capabilities/trusted-agent-protocol) · [Visa ICC](https://corporate.visa.com/en/products/intelligent-commerce-connect.html) · [Visa 公開規則](https://usa.visa.com/content/dam/VCOM/download/about-visa/visa-rules-public.pdf)
- [Mastercard Agent Pay 受理框架](https://www.mastercard.com/global/en/news-and-trends/stories/2025/agentic-commerce-framework.html) · [Mastercard Agent Connect](https://www.mastercard.com/global/en/business/artificial-intelligence/mastercard-agent-connect.html) · [VI Immediate 憑證格式](https://www.verifiableintent.dev/spec/credential-format/) · [Mastercard 交易處理規則](https://www.mastercard.com/content/dam/mccom/shared/business/support/rules-pdfs/transaction-processing-rules.pdf)
- [EMVCo 3-D Secure](https://www.emvco.com/emv-technologies/3-d-secure/) · [Mastercard 臺灣機場接送案例](https://www.mastercard.com/tw/zh/news-and-trends/press/2026/march/first-agentic-transaction-in-taiwan.html)

公開文件支持上述產品功能和基礎流程。臺灣本行卡別、具名商戶、收單訊息、使用權限及售後證據通道，仍須取得合作方正式規格並進行端到端測試。
