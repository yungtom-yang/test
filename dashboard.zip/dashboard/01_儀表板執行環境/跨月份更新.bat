@echo off
chcp 65001 >nul
cd /d "%~dp0"

python rollover_month.py

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ========================================================
    echo  [OK] 月份滾動與舊數據平移完成！
    echo  請開啟 dashboard_data.xlsx 填寫最新當期數據，
    echo  填畢後執行 [更新數據.bat] 即可發布至儀表板。
    echo ========================================================
) else (
    echo.
    echo ========================================================
    echo  [ERROR] 滾動失敗！請檢查 Excel 是否被鎖定或月份格式是否正確。
    echo ========================================================
)

echo.
pause
