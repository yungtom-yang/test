# 國泰世華銀行 信用卡暨支付維運全景儀表板
## 獨立交付正式環境 (Production Standalone Package)

本目錄為**可直接獨立交付與部署**的儀表板正式環境。整體設計具備 100% 自包含性，無需依賴外部專案目錄，可複製或壓縮後交付給業務單位或維運團隊直接使用。

---

## 目錄檔案清單 (File Inventory)

| 檔案名稱 | 類型 | 說明 |
| :--- | :--- | :--- |
| **`credit_card_full_dashboard.html`** | 核心入口 | 儀表板前端主頁面（純淨 HTML 結構，離線雙擊即可開啟） |
| **`dashboard.css`** | 樣式表 | 專用 UI/UX 樣式庫（深淺主題、高對比佈局與模組卡片樣式） |
| **`dashboard_app.js`** | 前端邏輯 | 核心互動控制器（頁籤切換、圖表渲染、數據勾稽綁定與動態計算） |
| **`dashboard_data.xlsx`** | 數據源 | 業務與維運數據維護工作簿（包含 Cockpit、Overview、Acquiring、Issuing、Resilience 等分頁） |
| **`dashboard_data.js`** | 數據檔 | 編譯後數據本機封裝檔（提供 `file://` 協議本機免伺服器跨域讀取） |
| **`dashboard_data.json`** | 數據檔 | 編譯後標準 JSON 格式數據 |
| **`sync_excel.py`** | 編譯腳本 | Excel 數據抽取、勾稽校驗、指標計算與 JS/JSON 生成工具 |
| **`更新數據.bat`** | 快速執行檔 | Windows 一鍵數據更新捷徑（雙擊即可自動執行同步與檢核） |
| **`README.md`** | 交付說明 | 本使用與維護指南文件 |

---

## 快速使用指南 (Quick Start)

### 1. 日常查閱與瀏覽
* **操作方式**：直接滑鼠雙擊 **`credit_card_full_dashboard.html`**。
* **相容環境**：支援 Google Chrome、Microsoft Edge 等現代瀏覽器。
* **特性**：本系統支援完全離線運行（`file://` 協議），無需架設 Web Server，亦無需對外連網。

### 2. 維運與業務數據更新流程
當每月或每週有新營運數據需要匯入時，請依循以下步驟：
1. **編輯數據**：開啟 **`dashboard_data.xlsx`**，更新對應工作表內的數值並儲存、關閉 Excel。
2. **一鍵同步**：雙擊執行 **`更新數據.bat`**。
   * 腳本將自動讀取 Excel 各工作表。
   * 執行嚴格的欄位防呆、型態轉換與數據勾稽。
   * 自動更新 `dashboard_data.js` 與 `dashboard_data.json`。
   * 命令提示字元視窗將顯示 `[OK] Sync completed!`。
3. **即時檢視**：切換回瀏覽器視窗，按下鍵盤 **`F5`** 重新整理，即可立即看見最新圖表與指標。

---

## 架構特色與技術亮點

1. **專業解耦架構**：
   * 遵循現代前端標準，將 HTML（結構 DOM）、CSS（視覺美化）與 JS（業務邏輯）徹底拆分。
   * 維護代碼清晰俐落，避免單一檔案龐大難以協作。
2. **100% 真實數據勾稽 (Zero Mock Data)**：
   * 所有儀表板數值皆動態綁定至 `dashboard_data.xlsx`。
   * 尚未填寫或尚未發生的未來月份均標準化顯示為 `-` 或預設佔位符，杜絕任何未經檢驗的靜態假數據。
3. **無縫本機相容性**：
   * 採用全域物件載入技術，完美相容內網或無網環境本機雙擊開啟，完全不受瀏覽器 CORS（跨來源資源共用）限制。

---

## 💻 數據更新環境需求與問題排查 (Troubleshooting)

若僅**瀏覽儀表板**，無需安裝任何環境，雙擊 HTML 即可開啟。  
若需要執行 **`更新數據.bat`** 重新同步 Excel 數據，新電腦需具備以下環境：

1. **Python 3.8+**：
   - 請至 [Python 官網](https://www.python.org/) 安裝，安裝時務必勾選 **`Add Python to PATH`**。
2. **安裝 openpyxl 套件**：
   - 開啟命令提示字元 (CMD) 執行：
     ```bash
     pip install openpyxl
     ```

### 常見問題與排查：
* **問題：執行 `更新數據.bat` 顯示錯誤？**
  - **排查一**：請確認 `dashboard_data.xlsx` 是否剛編輯完未關閉？**請存檔並「完全關閉 Excel 視窗」**，避免檔案被 Windows 獨佔鎖定。
  - **排查二**：請確認新電腦是否有安裝 `openpyxl` 套件。
  - **排查三**：請查看命令提示字元視窗內的具體 Python 報錯提示 (Traceback)。

