# -*- coding: utf-8 -*-
"""
rollover_month.py
國泰世華銀行 信用卡數據儀表板 - 跨月份自動滾動與歷史數據平移工具

功能：
1. 自動偵測目前 Excel 內之營運月份。
2. 完整自動備份現有 Excel 與編譯檔案至歷史備份資料夾（零風險）。
3. 自動將全 25 張工作表之「當期」數據平移至「前期」欄位，表頭自動更換為新月份。
4. 清空當期儲存格，供各業務小組直接填報最新數據。
5. 完整保留原儲存格格式、字型、公式與顏色標記（如小樹點千點黃色提醒）。
"""
import openpyxl
import os
import sys
import shutil
import re
from datetime import datetime

if sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, ".."))
EXCEL_FILE = os.path.join(BASE_DIR, "dashboard_data.xlsx")
JSON_FILE = os.path.join(BASE_DIR, "dashboard_data.json")
JS_FILE = os.path.join(BASE_DIR, "dashboard_data.js")
BACKUP_DIR = os.path.join(PROJECT_ROOT, "02_其他", "02_歷史備份與原型")


def detect_current_period(wb):
    """偵測目前 Excel 的最新月份 (year, month)"""
    candidates = []
    for s_name in ['收單一組_EPOS', '收單一組_PH', '收單一組_ERM']:
        if s_name in wb.sheetnames:
            ws = wb[s_name]
            for row in list(ws.iter_rows(values_only=True))[3:8]:
                if row and row[0]:
                    m = re.search(r'(20\d{2})[/-](\d{1,2})', str(row[0]))
                    if m:
                        candidates.append((int(m.group(1)), int(m.group(2))))
    for s_name in ['授權交易數', '徵審發卡_數位進件', '帳單_信用卡帳單']:
        if s_name in wb.sheetnames:
            ws = wb[s_name]
            for row in list(ws.iter_rows(values_only=True))[2:5]:
                for cell in row:
                    if cell and any(k in str(cell) for k in ['當期', '本期']):
                        m = re.search(r'(20\d{2})[/-](\d{1,2})', str(cell))
                        if m:
                            candidates.append((int(m.group(1)), int(m.group(2))))
    if candidates:
        return max(candidates)
    return (2026, 8)


def backup_existing_files(old_y, old_m):
    """安全備份目前 Excel 與衍生數據檔"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder_name = f"{timestamp}_{old_y}{old_m:02d}_月報完整備份"
    target_backup_path = os.path.join(BACKUP_DIR, folder_name)
    os.makedirs(target_backup_path, exist_ok=True)

    files_to_backup = [EXCEL_FILE, JSON_FILE, JS_FILE]
    backed_count = 0
    for f in files_to_backup:
        if os.path.exists(f):
            shutil.copy2(f, os.path.join(target_backup_path, os.path.basename(f)))
            backed_count += 1

    print(f"   [OK] 已安全備份現有檔案至歷史備份資料夾：\n        {target_backup_path} (共 {backed_count} 個檔案)")
    return target_backup_path


def execute_rollover(target_year, target_month):
    if not os.path.exists(EXCEL_FILE):
        print(f"錯誤：找不到 Excel 檔案：{EXCEL_FILE}")
        return False

    print("\n" + "=" * 66)
    print("   國泰世華銀行 信用卡儀表板 - 跨月份自動滾動與數據平移工具")
    print("=" * 66)

    # 1. 讀取並檢測目前月份
    wb = openpyxl.load_workbook(EXCEL_FILE)
    old_y, old_m = detect_current_period(wb)
    print(f"1. 目前 Excel 基礎期別：{old_y} 年 {old_m:02d} 月")

    curr_y = int(target_year)
    curr_m = int(target_month)
    prev_y = curr_y if curr_m > 1 else curr_y - 1
    prev_m = curr_m - 1 if curr_m > 1 else 12
    ly_y = curr_y - 1
    ly_m = curr_m

    curr_str = f"{curr_y}/{curr_m:02d}"
    prev_str = f"{prev_y}/{prev_m:02d}"
    ly_str = f"{ly_y}/{ly_m:02d}"

    print(f"2. 目標滾動新期別：")
    print(f"   - 當期 (最新月份)   : {curr_str}")
    print(f"   - 前期 (上月對比)   : {prev_str}")
    print(f"   - 去年同期 (YoY對比): {ly_str}")

    # 2. 自動執行安全備份
    print("3. 執行舊月份安全備份中...")
    backup_existing_files(old_y, old_m)

    # 3. 逐表執行數據平移與表頭置換
    print("4. 正在執行 25 張工作表數據平移與表頭滾動...")

    def update_header_dates(text):
        if not text or not isinstance(text, str):
            return text
        s = text
        if "當期" in s or "本期" in s:
            s = re.sub(r'\(20\d{2}[/-]\d{1,2}\)', f'({curr_str})', s)
        elif "前期" in s or "上期" in s or "上月" in s:
            s = re.sub(r'\(20\d{2}[/-]\d{1,2}\)', f'({prev_str})', s)
        elif "去年" in s:
            s = re.sub(r'\(20\d{2}[/-]\d{1,2}\)', f'({ly_str})', s)
        return s

    # A. 縱向時間序列表 (Type B: 單項目)
    type_b_simple = [
        '收單一組_EPOS', '收單一組_PH', '收單一組_ERM', '收單一組_MP',
        '收單三組_數位化進件', '收單三組_手續費收入', '收單三組_特店分期'
    ]
    for s_name in type_b_simple:
        if s_name not in wb.sheetnames:
            continue
        ws = wb[s_name]
        max_col = ws.max_column
        for c in range(2, max_col + 1):
            ws.cell(row=6, column=c).value = ws.cell(row=5, column=c).value
            ws.cell(row=5, column=c).value = None
            if ws.max_row >= 7:
                ws.cell(row=7, column=c).value = None
        ws.cell(row=5, column=1).value = curr_str
        ws.cell(row=6, column=1).value = prev_str
        if ws.max_row >= 7:
            ws.cell(row=7, column=1).value = ly_str

    # B. 縱向時間序列表 (Type B: 表 6 收單二組_發卡面數據)
    if '收單二組_發卡面數據' in wb.sheetnames:
        ws = wb['收單二組_發卡面數據']
        for i in range(3):
            curr_r = 5 + i
            prev_r = 8 + i
            ly_r = 11 + i
            ws.cell(row=prev_r, column=2).value = ws.cell(row=curr_r, column=2).value
            ws.cell(row=prev_r, column=3).value = ws.cell(row=curr_r, column=3).value
            ws.cell(row=curr_r, column=2).value = None
            ws.cell(row=curr_r, column=3).value = None
            if ws.max_row >= ly_r:
                ws.cell(row=ly_r, column=2).value = None
                ws.cell(row=ly_r, column=3).value = None
            ws.cell(row=curr_r, column=1).value = curr_str
            ws.cell(row=prev_r, column=1).value = prev_str
            if ws.max_row >= ly_r:
                ws.cell(row=ly_r, column=1).value = ly_str

    # C. 縱向時間序列表 (Type B: 表 7 收單三組_整體信用卡與TWQR特店請款量)
    if '收單三組_整體信用卡與TWQR特店請款量' in wb.sheetnames:
        ws = wb['收單三組_整體信用卡與TWQR特店請款量']
        # 信用卡 (Rows 5..7)
        for c in range(3, ws.max_column + 1):
            ws.cell(row=6, column=c).value = ws.cell(row=5, column=c).value
            ws.cell(row=5, column=c).value = None
            ws.cell(row=7, column=c).value = None
        ws.cell(row=5, column=1).value = curr_str
        ws.cell(row=6, column=1).value = prev_str
        ws.cell(row=7, column=1).value = ly_str

        # TWQR (Rows 8..10)
        for c in range(3, ws.max_column + 1):
            ws.cell(row=9, column=c).value = ws.cell(row=8, column=c).value
            ws.cell(row=8, column=c).value = None
            ws.cell(row=10, column=c).value = None
        ws.cell(row=8, column=1).value = curr_str
        ws.cell(row=9, column=1).value = prev_str
        ws.cell(row=10, column=1).value = ly_str

    # D. 橫向指標表 (Type A: 指標項目 | 當期 | 前期 | 去年同期 | ...)
    type_a_sheets = [
        '授權交易數', '帳單處理數', '徵審發卡_數位進件',
        '徵審發卡_新戶自動審核', '徵審發卡_舊戶自動審核',
        '帳單_銀行列印中心', '帳單_信用卡帳單', '帳單_銀行帳單', '帳單_通知函',
        '紅利分期_小樹點經營', '紅利分期_點數折抵通路', '紅利分期_紅利服務交易量',
        '發卡利息收入'
    ]
    for s_name in type_a_sheets:
        if s_name not in wb.sheetnames:
            continue
        ws = wb[s_name]
        for c in range(1, ws.max_column + 1):
            val = ws.cell(row=4, column=c).value
            if val:
                ws.cell(row=4, column=c).value = update_header_dates(str(val))

        for r in range(5, ws.max_row + 1):
            row_title = ws.cell(row=r, column=1).value
            if not row_title or str(row_title).strip() == "":
                continue
            ws.cell(row=r, column=3).value = ws.cell(row=r, column=2).value
            ws.cell(row=r, column=2).value = None
            if ws.max_column >= 4:
                ws.cell(row=r, column=4).value = None
            for c in range(5, ws.max_column + 1):
                ws.cell(row=r, column=c).value = None

    # E. 表 22: 紅利分期_分期交易
    if '紅利分期_分期交易' in wb.sheetnames:
        ws = wb['紅利分期_分期交易']
        for c in range(1, ws.max_column + 1):
            val = ws.cell(row=4, column=c).value
            if val:
                ws.cell(row=4, column=c).value = update_header_dates(str(val))
        for r in range(5, ws.max_row + 1):
            row_title = ws.cell(row=r, column=1).value
            if not row_title or str(row_title).strip() == "":
                continue
            ws.cell(row=r, column=4).value = ws.cell(row=r, column=2).value
            ws.cell(row=r, column=5).value = ws.cell(row=r, column=3).value
            ws.cell(row=r, column=2).value = None
            ws.cell(row=r, column=3).value = None
            if ws.max_column >= 6:
                ws.cell(row=r, column=6).value = None
            if ws.max_column >= 7:
                ws.cell(row=r, column=7).value = None

    # F. 表 24: 01_全行月度指標
    if '01_全行月度指標' in wb.sheetnames:
        ws = wb['01_全行月度指標']
        for r in range(5, ws.max_row + 1):
            code = ws.cell(row=r, column=2).value
            if not code or str(code).strip() == "":
                continue
            ws.cell(row=r, column=6).value = ws.cell(row=r, column=4).value
            ws.cell(row=r, column=4).value = None
            ws.cell(row=r, column=5).value = None
            ws.cell(row=r, column=8).value = None
            ws.cell(row=r, column=9).value = None
            ws.cell(row=r, column=10).value = None

    # G. 表 25: 01_同業對標明細
    if '01_同業對標明細' in wb.sheetnames:
        ws = wb['01_同業對標明細']
        t1 = ws.cell(row=1, column=1).value
        if t1 and isinstance(t1, str):
            ws.cell(row=1, column=1).value = re.sub(r'1[–-]\d{1,2}\s*月', f'1–{curr_m} 月', t1)

    # 4. 存檔更新
    try:
        wb.save(EXCEL_FILE)
        print("   [OK] Excel 25 張工作表數據平移與表頭更新已成功存檔！")
    except PermissionError:
        print("\n[錯誤] 無法存檔！dashboard_data.xlsx 正由 Excel 開啟鎖定中。")
        print("請先關閉 Excel 後，重新執行此程式。")
        return False

    print("\n" + "=" * 66)
    print(f"🎉 跨月份滾動完成！目前儀表板基期已成功推進至：{curr_str}")
    print("=" * 66)
    print("【後續操作提醒】：")
    print(f"1. 請開啟 dashboard_data.xlsx，由各業務小組填入最新【{curr_str} 當期】數據。")
    print("2. 填寫完畢存檔後，雙擊執行【更新數據.bat】，儀表板即會自動完成單位轉換與勾稽呈現！")
    print("=" * 66 + "\n")
    return True


def main():
    if not os.path.exists(EXCEL_FILE):
        print(f"找不到檔案：{EXCEL_FILE}")
        return

    # 偵測目前月份與預設建議
    wb_temp = openpyxl.load_workbook(EXCEL_FILE, data_only=True)
    old_y, old_m = detect_current_period(wb_temp)
    next_y = old_y if old_m < 12 else old_y + 1
    next_m = old_m + 1 if old_m < 12 else 1
    default_target = f"{next_y}{next_m:02d}"

    if len(sys.argv) > 1:
        raw_in = sys.argv[1].strip()
        if raw_in in ("-h", "--help", "/?"):
            print("使用方式：")
            print("  python rollover_month.py          (互動式模式，會提示輸入目標月份)")
            print("  python rollover_month.py 202609   (直接指定目標月份為 2026 年 09 月)")
            print("  python rollover_month.py 2026/09  (直接指定目標月份為 2026 年 09 月)")
            return
    else:
        print("\n========================================================")
        print(f" 目前 Excel 數據月份為：{old_y} 年 {old_m:02d} 月")
        print(f" 建議推進至下一月份  ：{next_y} 年 {next_m:02d} 月 ({default_target})")
        print("========================================================")
        raw_in = input(f"請輸入要建立的最新月份 (直接按 Enter 採用 {default_target}): ").strip()
        if not raw_in:
            raw_in = default_target

    m = re.search(r'^(20\d{2})[/-]?(\d{1,2})$', raw_in)
    if not m:
        print(f"格式錯誤！請輸入有效之月份格式，例如 202609 或 2026/09 (輸入值: {raw_in})")
        return

    ty, tm = int(m.group(1)), int(m.group(2))
    if not (1 <= tm <= 12):
        print(f"月份數值無效：{tm}，必須介於 1 到 12 之間。")
        return

    execute_rollover(ty, tm)


if __name__ == '__main__':
    main()
