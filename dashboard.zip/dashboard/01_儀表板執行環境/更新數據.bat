@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ========================================================
echo   國泰世華銀行 信用卡儀表板 - 數據更新同步程序
echo ========================================================
echo.

:: 1. 偵測 Python 指令 (優先 python，其次 py)
set "PY_CMD="
python --version >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set "PY_CMD=python"
) else (
    py --version >nul 2>&1
    if %ERRORLEVEL% EQU 0 (
        set "PY_CMD=py"
    )
)

if "%PY_CMD%"=="" (
    echo.
    echo ========================================================
    echo  [錯誤] 未偵測到 Python 環境！
    echo ========================================================
    echo  可能原因：
    echo  1. 此電腦尚未安裝 Python 3。
    echo  2. 安裝 Python 時未勾選「Add Python to PATH（加入環境變數）」。
    echo.
    echo  解決方式：
    echo  請至 https://www.python.org 下載安裝 Python，
    echo  安裝時務必勾選「Add Python to PATH」。
    echo ========================================================
    echo.
    pause
    exit /b 1
)

:: 2. 檢查 openpyxl 套件
%PY_CMD% -c "import openpyxl" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ========================================================
    echo  [錯誤] 缺少 Python 必要套件：openpyxl
    echo ========================================================
    echo  解決方式：
    echo  請在命令提示字元 (CMD) 中執行以下指令安裝：
    echo.
    echo      pip install openpyxl
    echo.
    echo ========================================================
    echo.
    pause
    exit /b 1
)

:: 3. 執行同步與檢核
echo 正在讀取 dashboard_data.xlsx 並執行數據檢核...
echo.
%PY_CMD% sync_excel.py

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ========================================================
    echo  [OK] 同步完成！請於瀏覽器按下 F5 重新整理查看最新數據。
    echo ========================================================
) else (
    echo.
    echo ========================================================
    echo  [ERROR] 同步中斷！排查建議：
    echo ========================================================
    echo  1. Excel 檔案被鎖定：若 dashboard_data.xlsx 開啟中，
    echo     請儲存並【完全關閉 Excel 視窗】後再執行一次。
    echo  2. 請查看上方詳細的 Python 報錯內容以定位原因。
    echo ========================================================
)

echo.
pause
