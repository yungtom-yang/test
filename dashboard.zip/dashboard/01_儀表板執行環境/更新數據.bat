@echo off
chcp 65001 >nul
cd /d "%~dp0"

python sync_excel.py

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ========================================================
    echo  [OK] Sync completed! Press F5 in browser to view.
    echo ========================================================
) else (
    echo.
    echo ========================================================
    echo  [ERROR] Sync failed! Please check Excel file lock.
    echo ========================================================
)

echo.
pause
