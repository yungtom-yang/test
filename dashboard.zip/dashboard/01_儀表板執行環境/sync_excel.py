# -*- coding: utf-8 -*-
"""
sync_excel.py
Reads team-based worksheets in dashboard_data.xlsx (aligned with 現有資料欄位內容.md)
and compiles them into:
  - dashboard_data.js (for browser direct loading)
  - dashboard_data.json (for standard JSON storage)

單位轉換與稽核規則：
1. 數據提供單位填報規範：
   - 除「18. 紅利分期_小樹點經營」與「19. 紅利分期_點數折抵通路」填報單位為「千點」外，
     其餘所有工作表皆由數據提供單位直接填寫「實際原始數據」（元、筆、家、件、份、張、次、%）。
2. 系統編譯時自動將原始數據轉換為儀表板呈現單位（億元、萬元、萬筆、萬家、萬份、萬次、百萬點）。
3. 嚴格不使用硬編碼預設假數據（No Hardcoded Defaults）。
"""
import openpyxl
import json
import os
import sys
import re

if sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
EXCEL_FILE = os.path.join(BASE_DIR, "dashboard_data.xlsx")
JSON_FILE = os.path.join(BASE_DIR, "dashboard_data.json")
JS_FILE = os.path.join(BASE_DIR, "dashboard_data.js")


def safe_f(v):
    if v is None or str(v).strip() == "":
        return None
    s = str(v).strip().replace(",", "").replace("%", "")
    if s in ("-", "—", "None", "null"):
        return None
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def to_yi(v, digits=4):
    """將實際原始數據（元）除以 100,000,000 轉換為儀表板呈現單位（億元）"""
    if v is None:
        return None
    return round(v / 100000000.0, digits)


def to_wan(v, digits=4):
    """將實際原始數據（元、筆、家、份、次）除以 10,000 轉換為儀表板呈現單位（萬元、萬筆、萬家、萬份、萬次）"""
    if v is None:
        return None
    return round(v / 10000.0, digits)


def to_million_pts(v, digits=3):
    """【唯一特例】將小樹點填報數據（千點）除以 1,000 轉換為儀表板呈現單位（百萬點）"""
    if v is None:
        return None
    return round(v / 1000.0, digits)


def calc_pct_change(curr, base, is_pp=False, digits=1):
    if curr is None or base is None:
        return None
    if is_pp:
        return round(curr - base, digits)
    if base == 0:
        return None
    return round(((curr - base) / abs(base)) * 100.0, digits)


ACTIVE_PERIOD = {"year": 2026, "month": 8}


def detect_current_period(wb):
    """從 Excel 各工作表動態偵測當前營運最新月份 (year, month)"""
    candidates = []
    # 1. 優先檢查收單渠道 (EPOS, PH, ERM)
    for s_name in ['收單一組_EPOS', '收單一組_PH', '收單一組_ERM']:
        if s_name in wb.sheetnames:
            ws = wb[s_name]
            for row in list(ws.iter_rows(values_only=True))[3:8]:
                if row and row[0]:
                    m = re.search(r'(20\d{2})[/-](\d{1,2})', str(row[0]))
                    if m:
                        candidates.append((int(m.group(1)), int(m.group(2))))
    # 2. 檢查指標表之表頭
    for s_name in ['授權交易數', '徵審發卡_數位進件', '帳單_信用卡帳單']:
        if s_name in wb.sheetnames:
            ws = wb[s_name]
            for row in list(ws.iter_rows(values_only=True))[2:5]:
                for cell in row:
                    if cell and any(k in str(cell) for k in ['當期', '本期']):
                        m = re.search(r'(20\d{2})[/-](\d{1,2})', str(cell))
                        if m:
                            candidates.append((int(m.group(1)), int(m.group(2))))
    if candidates:
        return max(candidates)
    return (2026, 8)


def classify_period(m_str, curr_y=None, curr_m=None):
    """
    動態判斷月份字串屬於 curr (當期), prev (前期), 或 ly (去年同期)
    消除寫死 2026/08 盲點，依據動態偵測之期別精準匹配
    """
    if curr_y is None or curr_m is None:
        curr_y = ACTIVE_PERIOD["year"]
        curr_m = ACTIVE_PERIOD["month"]
    s = str(m_str or "").strip()
    if not s:
        return s

    # 1. 語義關鍵字優先判定
    if any(k in s for k in ["前期", "上期", "上月", "上一期"]):
        return "prev"
    if "去年" in s:
        return "ly"
    if any(k in s for k in ["當期", "本期", "本月"]):
        return "curr"

    # 2. 動態年月比對
    prev_y = curr_y if curr_m > 1 else curr_y - 1
    prev_m = curr_m - 1 if curr_m > 1 else 12
    ly_y = curr_y - 1
    ly_m = curr_m

    curr_strs = [f"{curr_y}/{curr_m:02d}", f"{curr_y}-{curr_m:02d}", f"{curr_y}{curr_m:02d}"]
    prev_strs = [f"{prev_y}/{prev_m:02d}", f"{prev_y}-{prev_m:02d}", f"{prev_y}{prev_m:02d}"]
    ly_strs = [f"{ly_y}/{ly_m:02d}", f"{ly_y}-{ly_m:02d}", f"{ly_y}{ly_m:02d}"]

    for cs in curr_strs:
        if cs in s:
            return "curr"
    for ps in prev_strs:
        if ps in s:
            return "prev"
    for ls in ly_strs:
        if ls in s:
            return "ly"
    return s


def parse_indicator_sheet(ws, min_row=5):
    """
    通用解析指標結構工作表，動態由第 4 列表頭識別當期、前期、去年同期欄位位置
    回傳 dict: { 指標名稱: {"curr": ..., "prev": ..., "ly": ..., "col4": ..., "col5": ..., "col6": ..., "raw": row} }
    """
    col_map = {}
    for r in list(ws.iter_rows(values_only=True))[:min_row]:
        if r and any(k in str(c) for c in r if c for k in ['當期', '本期', '指標項目', '202']):
            for c_idx, cell in enumerate(r):
                if cell is not None and c_idx > 0:
                    c_str = str(cell).strip()
                    if any(k in c_str for k in ['佔比', '成長率', '成長量', '增減', '比率', '成長', 'TPS', '%']):
                        continue
                    pk = classify_period(cell)
                    if pk in ("curr", "prev", "ly") and pk not in col_map:
                        col_map[pk] = c_idx
            break

    c_i = col_map.get("curr", 1)
    p_i = col_map.get("prev", 2)
    l_i = col_map.get("ly", 3)

    res = {}
    for row in ws.iter_rows(min_row=min_row, values_only=True):
        if not row or row[0] is None or str(row[0]).strip() == "":
            continue
        name = str(row[0]).strip()
        if name == "指標項目":
            continue
        res[name] = {
            "curr": safe_f(row[c_i]) if len(row) > c_i else None,
            "prev": safe_f(row[p_i]) if len(row) > p_i else None,
            "ly": safe_f(row[l_i]) if len(row) > l_i else None,
            "col4": safe_f(row[4]) if len(row) > 4 else None,
            "col5": safe_f(row[5]) if len(row) > 5 else None,
            "col6": safe_f(row[6]) if len(row) > 6 else None,
            "raw": row
        }
    return res


def load_data_from_excel():
    new_excel = os.path.join(BASE_DIR, "dashboard_data_new.xlsx")
    target_excel = EXCEL_FILE
    if os.path.exists(new_excel):
        try:
            os.replace(new_excel, EXCEL_FILE)
            print("已自動將最新工作表結構覆蓋至 dashboard_data.xlsx")
        except PermissionError:
            target_excel = new_excel
            print("提示：dashboard_data.xlsx 目前正由 Excel 開啟鎖定中，本次先讀取最新產出之 dashboard_data_new.xlsx 進行編譯。")

    if not os.path.exists(target_excel):
        raise FileNotFoundError(f"找不到 Excel 檔案：{target_excel}")

    wb = openpyxl.load_workbook(target_excel, data_only=True)
    detected_y, detected_m = detect_current_period(wb)
    ACTIVE_PERIOD["year"] = detected_y
    ACTIVE_PERIOD["month"] = detected_m
    curr_y, curr_m = detected_y, detected_m
    prev_y = curr_y if curr_m > 1 else curr_y - 1
    prev_m = curr_m - 1 if curr_m > 1 else 12
    print(f"動態識別營運月報期別：{curr_y} 年 {curr_m:02d} 月 (前期：{prev_y}/{prev_m:02d})")

    derivable_items = []
    non_derivable_items = []

    base_data = {
        "meta": {
            "title": "國泰世華銀行 信用卡營運整合數據儀表板",
            "year": str(curr_y),
            "month": f"{curr_m:02d}",
            "period_label": "營運月報",
            "brand": "國泰世華"
        },
        "block01": {
            "section_title": "信用卡整體經營概況",
            "section_num": "01",
            "monthly_kpis": {},
            "cockpit_peer_donut": {},
            "peer_benchmark": []
        },
        "block02": {
            "section_title": "收單業務",
            "section_num": "02",
            "monthly_kpis": {},
            "online_channels": [],
            "merchant_concentration": {
                "top10_share": None,
                "top10_yoy": None,
                "top_merchants": [
                    {"name": "特店 A", "sub": "量販巨頭", "amount": None, "yoy": None, "quadrant": "核心成長區"},
                    {"name": "特店 B", "sub": "綜合電商", "amount": None, "yoy": None, "quadrant": "核心成長區"},
                    {"name": "特店 C", "sub": "百貨生活", "amount": None, "yoy": None, "quadrant": "重點維繫區"},
                    {"name": "特店 D", "sub": "連鎖超商", "amount": None, "yoy": None, "quadrant": "重點維繫區"},
                    {"name": "特店 E", "sub": "連鎖餐飲", "amount": None, "yoy": None, "quadrant": "潛力開發區"}
                ],
                "matrix_reps": {
                    "core": "代表：特店 A、特店 B",
                    "potential": "代表：特店 E 等",
                    "maintain": "代表：特店 C、特店 D",
                    "general": "代表：特店 X"
                }
            },
            "industry_structure": [
                {"name": "量販超市", "label": "🛒 量販超市", "merchant_count": None, "merchant_share": None, "amount": None, "amount_share": None, "avg_per_merchant": None, "color": "#003b5c"},
                {"name": "綜合電商", "label": "🌐 綜合電商", "merchant_count": None, "merchant_share": None, "amount": None, "amount_share": None, "avg_per_merchant": None, "color": "#0284c7"},
                {"name": "百貨生活", "label": "🏬 百貨生活", "merchant_count": None, "merchant_share": None, "amount": None, "amount_share": None, "avg_per_merchant": None, "color": "#10b981"},
                {"name": "餐飲美食", "label": "🍽️ 餐飲美食", "merchant_count": None, "merchant_share": None, "amount": None, "amount_share": None, "avg_per_merchant": None, "color": "#f59e0b"},
                {"name": "交通旅遊", "label": "✈️ 交通旅遊", "merchant_count": None, "merchant_share": None, "amount": None, "amount_share": None, "avg_per_merchant": None, "color": "#8b5cf6"},
                {"name": "其他各業", "label": "📦 其他各業", "merchant_count": None, "merchant_share": None, "amount": None, "amount_share": None, "avg_per_merchant": None, "color": "#94a3b8"}
            ],
            "twqr": {}
        },
        "block03": {
            "section_title": "發卡業務",
            "section_num": "03",
            "monthly_kpis": {},
            "application_approval": {},
            "billing_center": {},
            "bonus_points": {},
            "installment_structure": {},
            "collection_asset": {
                "m1_defense": {
                    "col_m1_entry": {"name": "M1當期進案", "value": None, "unit": "億元", "count": None, "note": ""},
                    "col_cure_rate": {"name": "催收回復正常率", "value": None, "unit": "%", "count": None, "note": ""},
                    "col_to_m2": {"name": "轉入M2催收流程", "value": None, "unit": "%", "count": None, "note": ""}
                },
                "aging_buckets": [
                    {"code": "aging_m1", "name": "M1 (1–30天)", "amount": None, "unit": "億元", "share": None, "count": None, "rec_ratio": None, "color": "#003b5c", "note": ""},
                    {"code": "aging_m2", "name": "M2 (31–60天)", "amount": None, "unit": "億元", "share": None, "count": None, "rec_ratio": None, "color": "#c9892e", "note": ""},
                    {"code": "aging_m3", "name": "M3+ (61天以上)", "amount": None, "unit": "億元", "share": None, "count": None, "rec_ratio": None, "color": "#b84a4a", "note": ""}
                ],
                "loss_settlement": {
                    "loss_writeoff": {"name": "當月轉銷呆帳 (損)", "value": None, "unit": "億元", "note": ""},
                    "loss_recovery": {"name": "當月呆帳回收 (益)", "value": None, "unit": "億元", "note": ""},
                    "loss_net": {"name": "當月淨信用損失", "value": None, "unit": "億元", "note": ""}
                }
            }
        },
        "block04": {
            "section_title": "系統韌性",
            "section_num": "04",
            "monthly_kpis": {
                "sys_cardpool_resp": {"dimension": "CardPool授權主機", "name": "交易響應時間", "value": None, "unit": "ms", "last_year": None, "prev_month": None, "yoy": None, "mom": None, "note": "", "sub1": "可用率 99.999%", "sub2": "SLA 100% 達標"},
                "sys_cardpool_vol": {"dimension": "CardPool授權主機", "name": "月授權交易量", "value": None, "unit": "萬筆", "last_year": None, "prev_month": None, "yoy": None, "mom": None, "note": "", "sub1": 0, "sub2": "< 120ms"},
                "sys_cardpool_succ": {"dimension": "CardPool授權主機", "name": "授權成功率", "value": None, "unit": "%", "last_year": None, "prev_month": None, "yoy": None, "mom": None, "note": "", "sub1": "99.999%", "sub2": "744 小時"},
                "sys_cardlink_vol": {"dimension": "Cardlink核心帳務", "name": "月帳務處理量", "value": None, "unit": "億筆", "last_year": None, "prev_month": None, "yoy": None, "mom": None, "note": "", "sub1": "100.0%", "sub2": "4,850 TPS"},
                "sys_cardlink_avail": {"dimension": "Cardlink核心帳務", "name": "系統可用率", "value": None, "unit": "%", "last_year": None, "prev_month": None, "yoy": None, "mom": None, "note": "", "sub1": "100.0%", "sub2": "4,850 TPS"},
                "sys_cardlink_tps": {"dimension": "Cardlink核心帳務", "name": "瞬時處理峰值", "value": None, "unit": "TPS", "last_year": None, "prev_month": None, "yoy": None, "mom": None, "note": "", "sub1": "100.0%", "sub2": None},
                "sys_cardlink_batch_time": {"dimension": "Cardlink核心帳務", "name": "批次作業完成時間", "value": None, "unit": "時間", "last_year": None, "prev_month": None, "yoy": None, "mom": None, "note": "", "sub1": "100%", "sub2": "40 分鐘"},
                "sys_cardlink_batch_limit": {"dimension": "Cardlink核心帳務", "name": "排程窗口上限時間", "value": None, "unit": "時間", "last_year": None, "prev_month": None, "yoy": None, "mom": None, "note": "", "sub1": "安全裕度足", "sub2": "40 分鐘"},
                "sys_cardlink_batch_accounts": {"dimension": "Cardlink核心帳務", "name": "日均處理帳單戶數", "value": None, "unit": "萬戶", "last_year": None, "prev_month": None, "yoy": None, "mom": None, "note": "", "sub1": "100.0%", "sub2": "零延宕"},
                "sys_fraud_total_amt": {"dimension": "全行防詐防堵", "name": "全月總防堵金額", "value": None, "unit": "萬元", "last_year": None, "prev_month": None, "yoy": None, "mom": None, "note": "", "sub1": 2684, "sub2": None},
                "sys_fraud_total_cnt": {"dimension": "全行防詐防堵", "name": "總阻斷冒用卡數", "value": None, "unit": "張", "last_year": None, "prev_month": None, "yoy": None, "mom": None, "note": "", "sub1": 4280, "sub2": None}
            },
            "cloud_events": [],
            "fraud_defense": {"channels": [], "total": {}},
            "microservices": {"services": []}
        }
    }

    # ==========================================================================
    # BLOCK 01: 01_全行月度指標 (表 22) & 01_同業對標明細 (表 23)
    # ==========================================================================
    if "01_全行月度指標" in wb.sheetnames:
        ws1 = wb["01_全行月度指標"]
        metrics = {}
        yi_codes = {"amt_total", "amt_general", "amt_installment", "rev_balance", "cash_amount"}
        wan_codes = {"cnt_total", "cnt_general", "cnt_installment", "cash_count"}

        for row in ws1.iter_rows(min_row=5, values_only=True):
            if not row or not row[1]:
                continue
            cat = str(row[0]).strip() if row[0] is not None else ""
            code = str(row[1]).strip()
            name = str(row[2]).strip() if len(row) > 2 and row[2] is not None else code
            raw_val = safe_f(row[3]) if len(row) > 3 else None
            raw_y_base = safe_f(row[4]) if len(row) > 4 else None
            raw_m_base = safe_f(row[5]) if len(row) > 5 else None
            raw_unit = str(row[6]).strip() if len(row) > 6 and row[6] is not None else ""
            yoy = safe_f(row[7]) if len(row) > 7 else None
            mom = safe_f(row[8]) if len(row) > 8 else None
            share = safe_f(row[9]) if len(row) > 9 else None
            note = str(row[10]).strip() if len(row) > 10 and row[10] is not None else ""

            if code in yi_codes:
                val = to_yi(raw_val, 4)
                y_base = to_yi(raw_y_base, 4)
                m_base = to_yi(raw_m_base, 4)
                disp_unit = "億元"
            elif code in wan_codes:
                val = to_wan(raw_val, 4)
                y_base = to_wan(raw_y_base, 4)
                m_base = to_wan(raw_m_base, 4)
                disp_unit = "萬筆"
            else:
                val = raw_val
                y_base = raw_y_base
                m_base = raw_m_base
                disp_unit = raw_unit

            final_yoy = yoy if yoy is not None else calc_pct_change(val, y_base, is_pp=(disp_unit == "%"), digits=2)
            if yoy is None and final_yoy is not None:
                derivable_items.append(f"01_全行月度指標 -> {name} YoY: 自動推算為 {final_yoy}%")

            final_mom = mom if mom is not None else calc_pct_change(val, m_base, is_pp=(disp_unit == "%"), digits=2)
            if mom is None and final_mom is not None:
                derivable_items.append(f"01_全行月度指標 -> {name} MoM: 自動推算為 {final_mom}%")

            metrics[code] = {
                "cat": cat, "name": name, "value": val, "y_base": y_base, "m_base": m_base,
                "unit": disp_unit or "", "yoy": final_yoy, "mom": final_mom, "share": share, "note": note
            }

        # 1. 總交易金額
        gen_amt = metrics.get("amt_general", {})
        inst_amt = metrics.get("amt_installment", {})
        tot_amt = metrics.get("amt_total", {})
        g_val, i_val, t_val = gen_amt.get("value"), inst_amt.get("value"), tot_amt.get("value")

        if t_val is None and g_val is not None and i_val is not None:
            t_val = round(g_val + i_val, 2)
            derivable_items.append(f"01_全行月度指標 -> 總交易金額: 由 一般({g_val}) + 分期({i_val}) 自動累加為 {t_val} 億元")
        if g_val is None and t_val is not None and i_val is not None:
            g_val = round(t_val - i_val, 2)
        if i_val is None and t_val is not None and g_val is not None:
            i_val = round(t_val - g_val, 2)

        g_share = gen_amt.get("share")
        i_share = inst_amt.get("share")
        if g_share is None and g_val is not None and t_val and t_val > 0:
            g_share = round((g_val / t_val) * 100, 2)
            derivable_items.append(f"01_全行月度指標 -> 一般交易金額佔比: 自動推算為 {g_share}%")
        if i_share is None and i_val is not None and t_val and t_val > 0:
            i_share = round((i_val / t_val) * 100, 2)
            derivable_items.append(f"01_全行月度指標 -> 分期交易金額佔比: 自動推算為 {i_share}%")

        # 2. 總交易筆數
        gen_cnt = metrics.get("cnt_general", {})
        inst_cnt = metrics.get("cnt_installment", {})
        tot_cnt = metrics.get("cnt_total", {})
        g_cnt, i_cnt, t_cnt = gen_cnt.get("value"), inst_cnt.get("value"), tot_cnt.get("value")

        if t_cnt is None and g_cnt is not None and i_cnt is not None:
            t_cnt = round(g_cnt + i_cnt, 2)
            derivable_items.append(f"01_全行月度指標 -> 總交易筆數: 由 一般({g_cnt}) + 分期({i_cnt}) 自動累加為 {t_cnt} 萬筆")

        g_cnt_share = gen_cnt.get("share")
        i_cnt_share = inst_cnt.get("share")
        if g_cnt_share is None and g_cnt is not None and t_cnt and t_cnt > 0:
            g_cnt_share = round((g_cnt / t_cnt) * 100, 2)
            derivable_items.append(f"01_全行月度指標 -> 一般交易筆數佔比: 自動推算為 {g_cnt_share}%")
        if i_cnt_share is None and i_cnt is not None and t_cnt and t_cnt > 0:
            i_cnt_share = round((i_cnt / t_cnt) * 100, 2)
            derivable_items.append(f"01_全行月度指標 -> 分期交易筆數佔比: 自動推算為 {i_cnt_share}%")

        # 3. 活卡表現
        card_rate_item = metrics.get("card_active_rate", {})
        card_act = metrics.get("card_active", {})
        card_iss = metrics.get("card_issued", {})
        act_val, iss_val, rate_val = card_act.get("value"), card_iss.get("value"), card_rate_item.get("value")
        act_rate = rate_val if rate_val is not None else card_act.get("share")
        if act_rate is None and act_val is not None and iss_val and iss_val > 0:
            act_rate = round((act_val / iss_val) * 100, 2)
        inact_val = round(iss_val - act_val, 2) if (iss_val is not None and act_val is not None) else None
        inact_share = round(100.0 - act_rate, 2) if act_rate is not None else None

        # 4. 信用業務
        rev = metrics.get("rev_balance", {})
        cash = metrics.get("cash_amount", {})
        cash_cnt = metrics.get("cash_count", {})

        base_data["block01"]["monthly_kpis"] = {
            "total_amount": {
                "title": tot_amt.get("name", "總交易金額"),
                "value": t_val, "unit": tot_amt.get("unit") or "億元",
                "yoy": tot_amt.get("yoy"), "mom": tot_amt.get("mom"),
                "general": {"label": "一般交易", "amount": g_val, "unit": gen_amt.get("unit") or "億元", "share": g_share, "yoy": gen_amt.get("yoy"), "mom": gen_amt.get("mom")},
                "installment": {"label": "分期交易", "amount": i_val, "unit": inst_amt.get("unit") or "億元", "share": i_share, "yoy": inst_amt.get("yoy"), "mom": inst_amt.get("mom")}
            },
            "total_count": {
                "title": tot_cnt.get("name", "總交易筆數"),
                "value": t_cnt, "unit": tot_cnt.get("unit") or "萬筆",
                "yoy": tot_cnt.get("yoy"), "mom": tot_cnt.get("mom"),
                "general": {"label": "一般交易", "count": g_cnt, "unit": gen_cnt.get("unit") or "萬筆", "share": g_cnt_share, "yoy": gen_cnt.get("yoy"), "mom": gen_cnt.get("mom")},
                "installment": {"label": "分期交易", "count": i_cnt, "unit": inst_cnt.get("unit") or "萬筆", "share": i_cnt_share, "yoy": inst_cnt.get("yoy"), "mom": inst_cnt.get("mom")}
            },
            "active_card": {
                "title": "活卡率", "rate": act_rate, "unit": "%",
                "yoy_pp": card_rate_item.get("yoy"), "mom_pp": card_rate_item.get("mom"),
                "active_cards": act_val, "active_cards_unit": card_act.get("unit") or "張",
                "active_share": card_act.get("share") if card_act.get("share") is not None else act_rate,
                "issued_cards": iss_val, "issued_cards_unit": card_iss.get("unit") or "張",
                "inactive_cards": inact_val, "inactive_cards_unit": "張", "inactive_share": inact_share
            },
            "credit_business": {
                "revolving": {"title": rev.get("name", "循環信用餘額"), "balance": rev.get("value"), "unit": rev.get("unit") or "億元", "yoy": rev.get("yoy"), "mom": rev.get("mom")},
                "cash_advance": {"title": cash.get("name", "預借現金金額"), "amount": cash.get("value"), "unit": cash.get("unit") or "億元", "yoy": cash.get("yoy"), "mom": cash.get("mom"), "count_wan": cash_cnt.get("value")}
            }
        }

    if "01_同業對標明細" in wb.sheetnames:
        ws3 = wb["01_同業對標明細"]
        categories_dict = {}
        cockpit_donut_built = False
        yi_metrics = {"簽帳金額", "循環信用餘額", "未到期分期付款餘額"}

        for row in ws3.iter_rows(min_row=5, values_only=True):
            if not row or not row[0] or not row[1]:
                continue
            cat_label = str(row[0]).strip()
            if cat_label == "資產品質":
                continue
            metric_label = str(row[1]).strip()
            raw_unit = str(row[2]).strip() if len(row) > 2 and row[2] is not None else ""
            direction = str(row[3]).strip() if len(row) > 3 and row[3] is not None else "up"
            c_v, c_y = safe_f(row[4]), safe_f(row[5])
            ct_v, ct_y = safe_f(row[6]), safe_f(row[7])
            fb_v, fb_y = safe_f(row[8]), safe_f(row[9])
            es_v, es_y = safe_f(row[10]), safe_f(row[11])
            ts_v, ts_y = safe_f(row[12]), safe_f(row[13])

            if metric_label in yi_metrics or raw_unit == "元":
                c_v = to_yi(c_v, 2)
                ct_v = to_yi(ct_v, 2)
                fb_v = to_yi(fb_v, 2)
                es_v = to_yi(es_v, 2)
                ts_v = to_yi(ts_v, 2)
                unit = "億元"
            else:
                unit = raw_unit

            peer_list = [
                {"bank": "國泰世華", "value": c_v, "yoy": c_y},
                {"bank": "中國信託", "value": ct_v, "yoy": ct_y},
                {"bank": "台北富邦", "value": fb_v, "yoy": fb_y},
                {"bank": "玉山", "value": es_v, "yoy": es_y},
                {"bank": "台新銀行", "value": ts_v, "yoy": ts_y}
            ]
            reverse_sort = (direction == "up")
            peer_list.sort(key=lambda x: (x["value"] is None, -x["value"] if reverse_sort and x["value"] is not None else x["value"] if x["value"] is not None else 0))
            is_quality = (cat_label == "資產品質" or metric_label in ["活卡率", "備抵呆帳提足率", "轉銷呆帳"])
            decimals = 0 if metric_label == "備抵呆帳提足率" else (1 if (unit == "%" or "呆帳" in metric_label or "率" in metric_label) else None)

            if cat_label not in categories_dict:
                categories_dict[cat_label] = {"label": cat_label, "metrics": []}
            categories_dict[cat_label]["metrics"].append({
                "label": metric_label, "unit": unit or "", "positiveDirection": direction or "up",
                "summaryMode": "quality" if is_quality else "growth", "decimals": decimals,
                "marketValue": None, "marketYoy": None, "peers": peer_list
            })

            if metric_label == "簽帳金額" and not cockpit_donut_built:
                bank_configs = {
                    "中國信託": {"color": "#003b5c", "is_cathay": False, "note": "第一大行", "val": ct_v, "yoy": ct_y},
                    "國泰世華": {"color": "#009e73", "is_cathay": True, "note": "本行 (綠色高亮顯示)", "val": c_v, "yoy": c_y},
                    "台北富邦": {"color": "#2563eb", "is_cathay": False, "note": "Costco 卡主力", "val": fb_v, "yoy": fb_y},
                    "玉山銀行": {"color": "#059669", "is_cathay": False, "note": "第四大行", "val": es_v, "yoy": es_y},
                    "台新銀行": {"color": "#ea580c", "is_cathay": False, "note": "第五大行 (Richart/玫瑰卡主力)", "val": ts_v, "yoy": ts_y},
                }
                valid_vals = [cfg["val"] for cfg in bank_configs.values() if cfg["val"] is not None]
                top5_total = round(sum(valid_vals), 2) if valid_vals else None
                donut_peers = []
                prior_sum = 0.0
                has_prior = True
                for b_name, cfg in bank_configs.items():
                    val, yoy = cfg["val"], cfg["yoy"]
                    share = round((val / top5_total * 100), 1) if (top5_total and val is not None) else None
                    if val is not None and yoy is not None:
                        prior_sum += (val / (1.0 + yoy / 100.0))
                    else:
                        has_prior = False
                    donut_peers.append({
                        "name": b_name, "amount": val, "unit": unit or "億元", "share": share,
                        "yoy": yoy, "color": cfg["color"], "is_cathay": cfg["is_cathay"], "note": cfg["note"]
                    })
                donut_peers.sort(key=lambda x: (x["amount"] is None, -x["amount"] if x["amount"] is not None else 0))
                market_yoy = round(((top5_total - prior_sum) / prior_sum * 100.0), 1) if (top5_total and has_prior and prior_sum > 0) else None
                base_data["block01"]["cockpit_peer_donut"] = {
                    "title": "五大發卡行簽帳金額", "period_label": f"{curr_y} 年 1–{curr_m} 月", "market_label": "五大行簽帳總額",
                    "market_total": top5_total, "unit": unit or "億元", "market_yoy": market_yoy,
                    "hint": "五大行合計", "peers": donut_peers
                }
                cockpit_donut_built = True

        if "卡量經營" in categories_dict:
            desired_order = ["流通卡數", "有效卡數", "活卡率"]
            categories_dict["卡量經營"]["metrics"].sort(
                key=lambda m: desired_order.index(m["label"]) if m["label"] in desired_order else 99
            )

        base_data["block01"]["peer_benchmark"] = list(categories_dict.values())

    # ==========================================================================
    # BLOCK 02: 收單業務 (表 2, 3, 4, 5, 7, 8, 9)
    # ==========================================================================
    # 2. 收單一組_EPOS (填報單位：筆、元 -> 轉換為：萬筆、億元)
    epos_by_m = {}
    if "收單一組_EPOS" in wb.sheetnames:
        ws_epos = wb["收單一組_EPOS"]
        for row in ws_epos.iter_rows(min_row=5, values_only=True):
            if not row or row[0] is None:
                continue
            p_key = classify_period(row[0])
            loc_cnt = to_wan(safe_f(row[1]), 4) if len(row) > 1 else None
            loc_amt = to_yi(safe_f(row[2]), 6) if len(row) > 2 else None
            cld_cnt = to_wan(safe_f(row[3]), 4) if len(row) > 3 else None
            cld_amt = to_yi(safe_f(row[4]), 6) if len(row) > 4 else None
            epos_by_m[p_key] = {"loc_cnt": loc_cnt, "loc_amt": loc_amt, "cld_cnt": cld_cnt, "cld_amt": cld_amt}

    # 3. 收單一組_PH (填報單位：筆、元 -> 轉換為：萬筆、億元)
    ph_by_m = {}
    if "收單一組_PH" in wb.sheetnames:
        ws_ph = wb["收單一組_PH"]
        for row in ws_ph.iter_rows(min_row=5, values_only=True):
            if not row or row[0] is None:
                continue
            p_key = classify_period(row[0])
            cnt = to_wan(safe_f(row[1]), 4) if len(row) > 1 else None
            amt = to_yi(safe_f(row[2]), 6) if len(row) > 2 else None
            ph_by_m[p_key] = {"cnt": cnt, "amt": amt}

    # 組合線上交易分析 (02_收單線上交易分析: 比照 03 分期產品結構分析呈現當期與前期 MoM)
    ep_curr = epos_by_m.get("curr", {})
    ep_prev = epos_by_m.get("prev", {})
    ep_ly = epos_by_m.get("ly", {})
    ph_curr = ph_by_m.get("curr", {})
    ph_prev = ph_by_m.get("prev", {})
    ph_ly = ph_by_m.get("ly", {})

    raw_onl_channels = [
        {
            "name": "EPOS - 雲端",
            "amount": ep_curr.get("cld_amt"),
            "prev_amount": ep_prev.get("cld_amt"),
            "amount_mom": calc_pct_change(ep_curr.get("cld_amt"), ep_prev.get("cld_amt"), digits=2),
            "amount_yoy": calc_pct_change(ep_curr.get("cld_amt"), ep_ly.get("cld_amt")),
            "count": ep_curr.get("cld_cnt"),
            "prev_count": ep_prev.get("cld_cnt"),
            "count_mom": calc_pct_change(ep_curr.get("cld_cnt"), ep_prev.get("cld_cnt"), digits=2),
            "count_yoy": calc_pct_change(ep_curr.get("cld_cnt"), ep_ly.get("cld_cnt")),
        },
        {
            "name": "EPOS - 地端",
            "amount": ep_curr.get("loc_amt"),
            "prev_amount": ep_prev.get("loc_amt"),
            "amount_mom": calc_pct_change(ep_curr.get("loc_amt"), ep_prev.get("loc_amt"), digits=2),
            "amount_yoy": calc_pct_change(ep_curr.get("loc_amt"), ep_ly.get("loc_amt")),
            "count": ep_curr.get("loc_cnt"),
            "prev_count": ep_prev.get("loc_cnt"),
            "count_mom": calc_pct_change(ep_curr.get("loc_cnt"), ep_prev.get("loc_cnt"), digits=2),
            "count_yoy": calc_pct_change(ep_curr.get("loc_cnt"), ep_ly.get("loc_cnt")),
        },
        {
            "name": "Payment Hub掃碼交易",
            "amount": ph_curr.get("amt"),
            "prev_amount": ph_prev.get("amt"),
            "amount_mom": calc_pct_change(ph_curr.get("amt"), ph_prev.get("amt"), digits=2),
            "amount_yoy": calc_pct_change(ph_curr.get("amt"), ph_ly.get("amt")),
            "count": ph_curr.get("cnt"),
            "prev_count": ph_prev.get("cnt"),
            "count_mom": calc_pct_change(ph_curr.get("cnt"), ph_prev.get("cnt"), digits=2),
            "count_yoy": calc_pct_change(ph_curr.get("cnt"), ph_ly.get("cnt")),
        }
    ]
    tot_onl_amt = sum(c["amount"] for c in raw_onl_channels if c["amount"] is not None)
    tot_onl_cnt = sum(c["count"] for c in raw_onl_channels if c["count"] is not None)
    online_channels = []
    for c in raw_onl_channels:
        amt = c["amount"]
        cnt = c["count"]
        share = round((amt / tot_onl_amt) * 100.0, 1) if (amt is not None and tot_onl_amt > 0) else None
        avg_t = round((amt * 100000000.0) / (cnt * 10000.0)) if (amt is not None and cnt and cnt > 0) else None
        if share is not None:
            derivable_items.append(f"收單一組_EPOS/PH -> {c['name']} 金額佔比: 自動推算為 {share}%")
        if avg_t is not None:
            derivable_items.append(f"收單一組_EPOS/PH -> {c['name']} 平均客單價: 自動推算為 {avg_t} 元")
        if c["amount_mom"] is not None:
            derivable_items.append(f"收單一組_EPOS/PH -> {c['name']} (金額 MoM): 自動推算為 {c['amount_mom']}%")
        if c["count_mom"] is not None:
            derivable_items.append(f"收單一組_EPOS/PH -> {c['name']} (筆數 MoM): 自動推算為 {c['count_mom']}%")
        online_channels.append({
            "name": c["name"],
            "amount": amt,
            "prev_amount": c["prev_amount"],
            "amount_share": share,
            "amount_mom": c["amount_mom"],
            "amount_yoy": c["amount_yoy"],
            "count": cnt,
            "prev_count": c["prev_count"],
            "count_mom": c["count_mom"],
            "count_yoy": c["count_yoy"],
            "avg_ticket": avg_t,
            "avg_ticket_yoy": None,
            "note": ""
        })
    base_data["block02"]["online_channels"] = online_channels

    # 4. 收單一組_ERM (填報單位：筆 -> 轉換為：萬筆)
    erm_by_m = {}
    if "收單一組_ERM" in wb.sheetnames:
        ws_erm = wb["收單一組_ERM"]
        for row in ws_erm.iter_rows(min_row=5, values_only=True):
            if not row or row[0] is None:
                continue
            p_key = classify_period(row[0])
            cnt = to_wan(safe_f(row[1]), 4) if len(row) > 1 else None
            erm_by_m[p_key] = cnt

    erm_curr = erm_by_m.get("curr")
    erm_prev = erm_by_m.get("prev")
    erm_ly = erm_by_m.get("ly")
    erm_yoy = calc_pct_change(erm_curr, erm_ly, digits=1)
    erm_mom = calc_pct_change(erm_curr, erm_prev, digits=1)
    if erm_mom is not None:
        derivable_items.append(f"收單一組_ERM -> ERM電簽交易筆數 MoM: 由 當期({erm_curr}) 與 前期({erm_prev}) 自動推算為 {erm_mom}%")

    # 5. 收單一組_MP (填報單位：家 -> 直接呈現：家)
    mp_by_m = {}
    if "收單一組_MP" in wb.sheetnames:
        ws_mp = wb["收單一組_MP"]
        for row in ws_mp.iter_rows(min_row=5, values_only=True):
            if not row or row[0] is None:
                continue
            p_key = classify_period(row[0])
            mp_cnt = safe_f(row[1]) if len(row) > 1 else None
            twqr_dl = safe_f(row[2]) if len(row) > 2 else None
            mp_by_m[p_key] = {"mp_cnt": mp_cnt, "twqr_dl": twqr_dl}

    mp_curr = mp_by_m.get("curr", {}).get("mp_cnt")
    mp_prev = mp_by_m.get("prev", {}).get("mp_cnt")
    mp_ly = mp_by_m.get("ly", {}).get("mp_cnt")
    mp_yoy = calc_pct_change(mp_curr, mp_ly, digits=1)
    mp_mom = calc_pct_change(mp_curr, mp_prev, digits=1)

    # 7. 收單三組_整體信用卡與TWQR特店請款量
    # (填報單位：家、筆、元 -> 信用卡轉換為：家、萬家、萬筆、億元；TWQR 呈現：家、筆、元，店均轉為萬元)
    cc_acq_by_m = {}
    twqr_acq_by_m = {}
    if "收單三組_整體信用卡與TWQR特店請款量" in wb.sheetnames:
        ws_s3 = wb["收單三組_整體信用卡與TWQR特店請款量"]
        for row in ws_s3.iter_rows(min_row=5, values_only=True):
            if not row or row[0] is None or row[1] is None:
                continue
            p_key = classify_period(row[0])
            m_type = str(row[1]).strip()
            mcht_cnt = safe_f(row[2]) if len(row) > 2 else None
            sub_cnt = safe_f(row[3]) if len(row) > 3 else None
            tx_cnt = safe_f(row[4]) if len(row) > 4 else None
            tx_amt = safe_f(row[5]) if len(row) > 5 else None
            new_mcht = safe_f(row[6]) if len(row) > 6 else None
            act_mcht = safe_f(row[7]) if len(row) > 7 else None

            if "信用卡" in m_type:
                sub_cnt = to_wan(sub_cnt, 4)
                tx_cnt = to_wan(tx_cnt, 4)
                tx_amt = to_yi(tx_amt, 4)
                cc_acq_by_m[p_key] = {"mcht": mcht_cnt, "submcht": sub_cnt, "cnt": tx_cnt, "amt": tx_amt, "new_mcht": new_mcht, "act_mcht": act_mcht}
            elif "TWQR" in m_type.upper():
                twqr_acq_by_m[p_key] = {"mcht": mcht_cnt, "submcht": sub_cnt, "cnt": tx_cnt, "amt": tx_amt, "new_mcht": new_mcht, "act_mcht": act_mcht}

    cc_c = cc_acq_by_m.get("curr", {})
    cc_p = cc_acq_by_m.get("prev", {})
    cc_l = cc_acq_by_m.get("ly", {})

    acq_amt_tot = cc_c.get("amt")
    acq_amt_yoy = calc_pct_change(acq_amt_tot, cc_l.get("amt"), digits=1)
    acq_amt_mom = calc_pct_change(acq_amt_tot, cc_p.get("amt"), digits=1)

    acq_cnt_tot = cc_c.get("cnt")
    acq_cnt_yoy = calc_pct_change(acq_cnt_tot, cc_l.get("cnt"), digits=1)
    acq_cnt_mom = calc_pct_change(acq_cnt_tot, cc_p.get("cnt"), digits=1)

    acq_mcht_tot = cc_c.get("mcht")
    acq_mcht_yoy = calc_pct_change(acq_mcht_tot, cc_l.get("mcht"), digits=1)
    acq_mcht_mom = calc_pct_change(acq_mcht_tot, cc_p.get("mcht"), digits=1)

    acq_sub_tot = cc_c.get("submcht")
    acq_sub_yoy = calc_pct_change(acq_sub_tot, cc_l.get("submcht"), digits=1)
    acq_sub_mom = calc_pct_change(acq_sub_tot, cc_p.get("submcht"), digits=1)

    onl_amt_sum = round(tot_onl_amt, 3) if tot_onl_amt > 0 else None
    onl_cnt_sum = round(tot_onl_cnt, 0) if tot_onl_cnt > 0 else None

    # 8. 收單三組_數位化進件 (填報單位：件 -> 直接呈現：件)
    dig_apply_by_m = {}
    if "收單三組_數位化進件" in wb.sheetnames:
        ws_da = wb["收單三組_數位化進件"]
        for row in ws_da.iter_rows(min_row=5, values_only=True):
            if not row or row[0] is None:
                continue
            p_key = classify_period(row[0])
            dig_apply_by_m[p_key] = {
                "cc_platform": safe_f(row[1]) if len(row) > 1 else None,
                "submcht_api": safe_f(row[2]) if len(row) > 2 else None,
                "twqr_platform": safe_f(row[3]) if len(row) > 3 else None,
            }

    submcht_api_curr = dig_apply_by_m.get("curr", {}).get("submcht_api")
    twqr_apply_curr = dig_apply_by_m.get("curr", {}).get("twqr_platform")

    # 9. 收單三組_手續費收入 (填報單位：元 -> 轉換為：億元)
    fee_by_m = {}
    if "收單三組_手續費收入" in wb.sheetnames:
        ws_fee = wb["收單三組_手續費收入"]
        for row in ws_fee.iter_rows(min_row=5, values_only=True):
            if not row or row[0] is None:
                continue
            r0 = str(row[0]).strip()
            if r0 in ("月份", "指標項目"):
                continue
            p_key = classify_period(r0)
            if p_key in ("curr", "prev", "ly"):
                val = to_yi(safe_f(row[1]), 4) if len(row) > 1 else None
                fee_by_m[p_key] = val
            elif "手續費" in r0:
                fee_by_m["curr"] = to_yi(safe_f(row[1]), 4) if len(row) > 1 else None
                fee_by_m["prev"] = to_yi(safe_f(row[2]), 4) if len(row) > 2 else None
                fee_by_m["ly"] = to_yi(safe_f(row[3]), 4) if len(row) > 3 else None

    fee_curr = fee_by_m.get("curr")
    fee_prev = fee_by_m.get("prev")
    fee_ly = fee_by_m.get("ly")
    fee_yoy = calc_pct_change(fee_curr, fee_ly, digits=1)
    fee_mom = calc_pct_change(fee_curr, fee_prev, digits=1)
    if fee_yoy is not None:
        derivable_items.append(f"收單三組_手續費收入 -> 收單手續費收入 YoY: 自動推算為 {fee_yoy}%")
    if fee_mom is not None:
        derivable_items.append(f"收單三組_手續費收入 -> 收單手續費收入 MoM: 自動推算為 {fee_mom}%")

    # 9b. 收單三組_特店分期 (填報單位：筆、元 -> 轉換為：萬筆、億元，跨組連動至 03 發卡業務「分期交易總額」)
    mcht_inst_by_m = {}
    if "收單三組_特店分期" in wb.sheetnames:
        ws_mi = wb["收單三組_特店分期"]
        for row in ws_mi.iter_rows(min_row=5, values_only=True):
            if not row or row[0] is None:
                continue
            r0 = str(row[0]).strip()
            if r0 in ("月份", "指標項目"):
                continue
            p_key = classify_period(r0)
            if p_key in ("curr", "prev", "ly"):
                if len(row) >= 3:
                    mcht_inst_by_m[p_key] = {
                        "cnt": to_wan(safe_f(row[1]), 4),
                        "amt": to_yi(safe_f(row[2]), 4),
                    }
                else:
                    mcht_inst_by_m[p_key] = {
                        "cnt": None,
                        "amt": to_yi(safe_f(row[1]), 4) if len(row) > 1 else None,
                    }
            elif "特店分期" in r0 or "分期金額" in r0:
                mcht_inst_by_m["curr"] = {
                    "cnt": to_wan(safe_f(row[1]), 4) if len(row) > 2 else None,
                    "amt": to_yi(safe_f(row[2]), 4) if len(row) > 2 else (to_yi(safe_f(row[1]), 4) if len(row) > 1 else None),
                }

    tw_c = twqr_acq_by_m.get("curr", {})
    tw_p = twqr_acq_by_m.get("prev", {})
    tw_tot_mcht = tw_c.get("mcht")
    tw_tot_mcht_mom = calc_pct_change(tw_tot_mcht, tw_p.get("mcht"), digits=1)
    tw_tx_amt = tw_c.get("amt")
    tw_tx_amt_mom = calc_pct_change(tw_tx_amt, tw_p.get("amt"), digits=1)
    tw_tx_cnt = tw_c.get("cnt")
    tw_tx_cnt_mom = calc_pct_change(tw_tx_cnt, tw_p.get("cnt"), digits=1)
    tw_avg_ticket = round(tw_tx_amt / tw_tx_cnt) if (tw_tx_amt is not None and tw_tx_cnt and tw_tx_cnt > 0) else None
    if tw_avg_ticket is not None:
        derivable_items.append(f"收單三組_整體信用卡與TWQR特店請款量 -> TWQR平均每筆客單: 由 金額({tw_tx_amt}) / 筆數({tw_tx_cnt}) 自動推算為 {tw_avg_ticket} 元")

    tw_new_mcht = tw_c.get("new_mcht")
    tw_act_mcht = tw_c.get("act_mcht")
    tw_pass_rate = round((tw_new_mcht / twqr_apply_curr) * 100.0, 1) if (tw_new_mcht is not None and twqr_apply_curr and twqr_apply_curr > 0) else None
    if tw_pass_rate is not None:
        derivable_items.append(f"收單三組 -> TWQR審查通過率: 由 當月新增特店({tw_new_mcht}) / 申請進件數({twqr_apply_curr}) 自動推算為 {tw_pass_rate}%")

    tw_act_rate = round((tw_act_mcht / tw_tot_mcht) * 100.0, 1) if (tw_act_mcht is not None and tw_tot_mcht and tw_tot_mcht > 0) else None
    if tw_act_rate is not None:
        derivable_items.append(f"收單三組_整體信用卡與TWQR特店請款量 -> TWQR動用特店比率: 由 動用特店家數({tw_act_mcht}) / 累計特店家數({tw_tot_mcht}) 自動推算為 {tw_act_rate}%")

    tw_mcht_avg_amt = to_wan(tw_tx_amt / tw_act_mcht, 2) if (tw_tx_amt is not None and tw_act_mcht and tw_act_mcht > 0) else None
    if tw_mcht_avg_amt is not None:
        derivable_items.append(f"收單三組_整體信用卡與TWQR特店請款量 -> TWQR店均交易金額: 由 當月交易金額({tw_tx_amt}元) / 動用特店家數({tw_act_mcht}家) 自動推算為 {tw_mcht_avg_amt} 萬元")

    base_data["block02"]["monthly_kpis"] = {
        "acq_amt": {
            "title": "收單交易金額",
            "total": acq_amt_tot,
            "unit": "億元",
            "yoy": acq_amt_yoy,
            "mom": acq_amt_mom,
            "physical": {"amount": None, "unit": "億元", "share": 65.0, "yoy": None},
            "online": {"amount": onl_amt_sum, "unit": "億元", "share": 35.0, "yoy": None}
        },
        "acq_cnt": {
            "title": "收單交易筆數",
            "total": acq_cnt_tot,
            "unit": "萬筆",
            "yoy": acq_cnt_yoy,
            "mom": acq_cnt_mom,
            "physical": {"count": None, "unit": "萬筆", "share": 70.0, "yoy": None},
            "online": {"count": onl_cnt_sum, "unit": "萬筆", "share": 30.0, "yoy": None}
        },
        "acq_mcht": {
            "title": "收單特店總數",
            "total": acq_mcht_tot,
            "unit": "家",
            "yoy": acq_mcht_yoy,
            "mom": acq_mcht_mom,
            "active_rate": 83.0,
            "submcht": {
                "title": "子特店總數",
                "total": acq_sub_tot,
                "unit": "萬家",
                "yoy": acq_sub_yoy,
                "mom": acq_sub_mom
            },
            "physical": {"count": None, "unit": "家", "share": 80.0},
            "online": {"count": None, "unit": "家", "share": 20.0}
        },
        "secondary": {
            "erm_cnt": {"title": "ERM電簽交易筆數", "value": erm_curr, "unit": "萬筆", "yoy": erm_yoy, "mom": erm_mom},
            "portal_mcht": {"title": "Merchant Portal商戶數", "value": mp_curr, "unit": "家", "yoy": mp_yoy, "mom": mp_mom},
            "submcht_api": {"title": "次特店API進件數", "value": submcht_api_curr, "unit": "件"},
            "fee_income": {"title": "收單手續費收入", "value": fee_curr, "unit": "億元", "yoy": fee_yoy, "mom": fee_mom},
            "penetration_rate": {"title": "ERM電簽交易筆數", "value": erm_curr, "unit": "萬筆", "yoy": erm_yoy, "mom": erm_mom},
            "active_mcht": {"title": "Merchant Portal商戶數", "count": mp_curr, "value": mp_curr, "unit": "家", "yoy": mp_yoy, "mom": mp_mom}
        }
    }
    base_data["block02"]["twqr"] = {
        "apply_count": twqr_apply_curr,
        "pass_rate": tw_pass_rate,
        "new_merchants": tw_new_mcht,
        "total_merchants": tw_tot_mcht,
        "total_merchants_mom": tw_tot_mcht_mom,
        "tx_amount": tw_tx_amt,
        "tx_amount_unit": "元",
        "tx_amount_mom": tw_tx_amt_mom,
        "tx_count": tw_tx_cnt,
        "tx_count_unit": "筆",
        "tx_count_mom": tw_tx_cnt_mom,
        "avg_ticket": tw_avg_ticket,
        "mcht_avg_amount": tw_mcht_avg_amt,
        "active_mcht_rate": tw_act_rate
    }

    # ==========================================================================
    # BLOCK 03: 發卡業務 (表 10, 12, 13, 14, 15, 16, 17, 18, 19, 21)
    # ==========================================================================
    # 12. 徵審發卡_數位進件 (填報單位：件、% -> 直接呈現：件、%)
    ap_tot_v = ap_dig_v = ap_phy_v = ap_dig_s = ap_phy_s = ap_yoy = ap_mom = None
    if "徵審發卡_數位進件" in wb.sheetnames:
        d12 = parse_indicator_sheet(wb["徵審發卡_數位進件"])
        r_tot = d12.get("總進件", {})
        r_dig = d12.get("數位進件", {})
        r_phy = d12.get("實體進件", {})
        r_shr = d12.get("數位進件佔比", {})

        ap_dig_v = r_dig.get("curr")
        ap_phy_v = r_phy.get("curr")
        ap_tot_v = r_tot.get("curr")
        if ap_tot_v is None and ap_dig_v is not None and ap_phy_v is not None:
            ap_tot_v = round(ap_dig_v + ap_phy_v, 1)
            derivable_items.append(f"徵審發卡_數位進件 -> 總進件: 由 數位({ap_dig_v}) + 實體({ap_phy_v}) 自動加總為 {ap_tot_v} 件")

        ap_yoy = calc_pct_change(ap_tot_v, r_tot.get("ly"), digits=1)
        ap_mom = calc_pct_change(ap_tot_v, r_tot.get("prev"), digits=1)
        ap_dig_s = r_shr.get("curr")
        if ap_dig_s is None and ap_dig_v is not None and ap_tot_v and ap_tot_v > 0:
            ap_dig_s = round((ap_dig_v / ap_tot_v) * 100.0, 1)
        ap_phy_s = round(100.0 - ap_dig_s, 1) if ap_dig_s is not None else None

    # 10. 授權交易數 (填報單位：筆 -> 轉換為：萬筆)
    au_tot_v = au_crd_v = au_dbt_v = au_crd_s = au_dbt_s = au_yoy = au_mom = None
    if "授權交易數" in wb.sheetnames:
        d10 = parse_indicator_sheet(wb["授權交易數"])
        r_tot = d10.get("授權交易總數", {})
        r_crd = d10.get("信用卡授權數", {}) or d10.get("信用卡授權筆數", {})
        r_dbt = d10.get("Debit卡授權數", {}) or d10.get("簽帳卡授權筆數", {})

        au_crd_v = to_wan(r_crd.get("curr"), 4)
        au_dbt_v = to_wan(r_dbt.get("curr"), 4)
        au_tot_v = to_wan(r_tot.get("curr"), 4)
        au_tot_prev = to_wan(r_tot.get("prev"), 4)
        au_tot_ly = to_wan(r_tot.get("ly"), 4)
        if au_tot_v is None and au_crd_v is not None and au_dbt_v is not None:
            au_tot_v = round(au_crd_v + au_dbt_v, 4)

        au_yoy = r_tot.get("col4") if r_tot.get("col4") is not None else calc_pct_change(au_tot_v, au_tot_ly, digits=1)
        au_mom = calc_pct_change(au_tot_v, au_tot_prev, digits=1)
        au_crd_s = round((au_crd_v / au_tot_v) * 100.0, 1) if (au_crd_v is not None and au_tot_v and au_tot_v > 0) else None
        au_dbt_s = round(100.0 - au_crd_s, 1) if au_crd_s is not None else None

    # 13. 徵審發卡_新戶自動審核 & 14. 徵審發卡_舊戶自動審核 (填報單位：件、% -> 直接呈現：件、%)
    new_in_v = new_hub_v = new_pass_v = new_rate_v = None
    old_in_v = old_hub_v = old_pass_v = old_rate_v = None
    if "徵審發卡_新戶自動審核" in wb.sheetnames:
        d13 = parse_indicator_sheet(wb["徵審發卡_新戶自動審核"])
        for k, v in d13.items():
            if "進件量" in k: new_in_v = v.get("curr")
            elif "自動審查量" in k: new_hub_v = v.get("curr")
            elif "自動核准量" in k: new_pass_v = v.get("curr")
            elif "自動核准率" in k: new_rate_v = v.get("curr")

    if "徵審發卡_舊戶自動審核" in wb.sheetnames:
        d14 = parse_indicator_sheet(wb["徵審發卡_舊戶自動審核"])
        for k, v in d14.items():
            if "進件量" in k: old_in_v = v.get("curr")
            elif "自動審查量" in k: old_hub_v = v.get("curr")
            elif "自動核准量" in k: old_pass_v = v.get("curr")
            elif "自動核准率" in k: old_rate_v = v.get("curr")

    total_stage1 = round((old_in_v or 0) + (new_in_v or 0), 1) if (old_in_v is not None or new_in_v is not None) else None
    s1_old_share = round((old_in_v / total_stage1) * 100.0, 1) if (old_in_v is not None and total_stage1) else None
    s1_new_share = round((new_in_v / total_stage1) * 100.0, 1) if (new_in_v is not None and total_stage1) else None

    s2_hub_v = round((old_hub_v or 0) + (new_hub_v or 0), 1) if (old_hub_v is not None or new_hub_v is not None) else None
    s2_hub_share = round((s2_hub_v / total_stage1) * 100.0, 1) if (s2_hub_v is not None and total_stage1) else None

    s3_pass_v = round((old_pass_v or 0) + (new_pass_v or 0), 1) if (old_pass_v is not None or new_pass_v is not None) else None
    s3_pass_share = round((s3_pass_v / total_stage1) * 100.0, 1) if (s3_pass_v is not None and total_stage1) else None

    s3_man_v = round(s2_hub_v - s3_pass_v) if (s2_hub_v is not None and s3_pass_v is not None) else None
    s3_man_share = round((s3_man_v / s2_hub_v) * 100.0, 1) if (s3_man_v is not None and s2_hub_v) else None

    old_auto_rate = round((old_hub_v / old_in_v) * 100.0, 1) if (old_hub_v is not None and old_in_v) else s2_hub_share
    new_auto_rate = round((new_hub_v / new_in_v) * 100.0, 1) if (new_hub_v is not None and new_in_v) else s2_hub_share

    derivable_items.append(
        f"徵審發卡_新/舊戶自動審核 -> 進件自動審查中樞: 由 舊戶審查({old_hub_v}) + 新戶審查({new_hub_v}) 自動加總為 {s2_hub_v} 件 (自動審查率 {s2_hub_share}%)"
    )
    derivable_items.append(
        f"徵審發卡_新/舊戶自動審核 -> 自動直接核准總數: 由 舊戶核准({old_pass_v}) + 新戶核准({new_pass_v}) 自動加總為 {s3_pass_v} 件；轉入人工 {s3_man_v} 件"
    )

    base_data["block03"]["application_approval"] = {
        "stage1_old": {
            "cat": "申辦徵審流向", "name": "舊戶加辦進件", "value": old_in_v, "y_base": None, "unit": "件",
            "yoy": None, "share": s1_old_share, "col1": int(old_pass_v) if old_pass_v is not None else None,
            "col2": None, "note": "", "auto_rate": old_auto_rate
        },
        "stage1_new": {
            "cat": "申辦徵審流向", "name": "新戶申辦進件", "value": new_in_v, "y_base": None, "unit": "件",
            "yoy": None, "share": s1_new_share, "col1": int(new_pass_v) if new_pass_v is not None else None,
            "col2": None, "note": "", "auto_rate": new_auto_rate
        },
        "stage2_hub": {
            "cat": "申辦徵審流向", "name": "進件自動審查中樞", "value": s2_hub_v, "y_base": None, "unit": "件",
            "yoy": None, "share": s2_hub_share, "col1": None, "col2": None, "note": ""
        },
        "stage3_auto_pass": {
            "cat": "申辦徵審流向", "name": "自動直接核准總數", "value": s3_pass_v, "y_base": None, "unit": "件",
            "yoy": None, "share": s3_pass_share,
            "col1": int(old_pass_v) if old_pass_v is not None else None,
            "col2": int(new_pass_v) if new_pass_v is not None else None,
            "note": ""
        },
        "stage3_manual": {
            "cat": "申辦徵審流向", "name": "轉入人工審查總數", "value": s3_man_v, "y_base": None, "unit": "件",
            "yoy": None, "share": s3_man_share, "col1": None, "col2": None, "note": ""
        }
    }

    # 15. 帳單_銀行列印中心 & 16. 帳單_信用卡帳單 & 17. 帳單_銀行帳單
    # (填報單位：份、% -> 帳單量轉換為：萬份；占比與有效投遞率直接呈現：%)
    def parse_bill_sheet(sheet_name):
        if sheet_name not in wb.sheetnames:
            return {}
        d = parse_indicator_sheet(wb[sheet_name])
        tot = to_wan(d.get("帳單總量", {}).get("curr"), 4)
        pap = to_wan(d.get("紙本帳單量", {}).get("curr"), 4)
        pap_ly = to_wan(d.get("紙本帳單量", {}).get("ly"), 4)
        elc = to_wan(d.get("電子帳單量", {}).get("curr"), 4)
        rat = d.get("電子帳單占比", {}).get("curr")
        deliv_elc = (d.get("電子帳單有效投遞率") or d.get("電子有效投遞率") or {}).get("curr")
        deliv_pap = (d.get("紙本帳單有效投遞率") or d.get("紙本有效投遞率") or {}).get("curr")
        if tot is None and pap is not None and elc is not None:
            tot = round(pap + elc, 4)
        if elc is None and tot is not None and pap is not None:
            elc = round(tot - pap, 4)
        if pap is None and tot is not None and elc is not None:
            pap = round(tot - elc, 4)
        if rat is None and tot and elc is not None:
            rat = round((elc / tot) * 100.0, 2)
        pap_yoy = calc_pct_change(pap, pap_ly, digits=1)
        return {
            "total": tot,
            "paper": pap,
            "elec": elc,
            "rate": rat,
            "paper_yoy": pap_yoy,
            "deliv_elec": deliv_elc,
            "deliv_paper": deliv_pap
        }

    b_center = parse_bill_sheet("帳單_銀行列印中心")
    b_card = parse_bill_sheet("帳單_信用卡帳單")
    b_bank = parse_bill_sheet("帳單_銀行帳單")
    b_notif = parse_bill_sheet("帳單_通知函")

    # 若列印中心未填，可由信用卡+銀行自動加總
    if b_center.get("total") is None and b_card.get("total") is not None and b_bank.get("total") is not None:
        b_center["total"] = round(b_card["total"] + b_bank["total"], 4)
    if b_center.get("elec") is None and b_card.get("elec") is not None and b_bank.get("elec") is not None:
        b_center["elec"] = round(b_card["elec"] + b_bank["elec"], 4)
    if b_center.get("paper") is None and b_card.get("paper") is not None and b_bank.get("paper") is not None:
        b_center["paper"] = round(b_card["paper"] + b_bank["paper"], 4)
    if b_center.get("rate") is None and b_center.get("total") and b_center.get("elec") is not None:
        b_center["rate"] = round((b_center["elec"] / b_center["total"]) * 100.0, 1)

    base_data["block03"]["billing_center"] = {
        "total_bills": {
            "cat": "帳單中心核心", "name": "全行出帳總份數", "value": b_center.get("total"),
            "y_base": None, "unit": "萬份", "yoy": None, "share": None,
            "col1": b_center.get("elec"), "col2": b_center.get("paper"), "note": ""
        },
        "overall_erate": {
            "cat": "帳單中心核心", "name": "全行綜合電子化率", "value": b_center.get("rate"),
            "y_base": None, "unit": "%", "yoy": None, "share": None, "col1": None, "col2": None, "note": ""
        },
        "delivery_rate": {
            "cat": "帳單中心核心", "name": "信用卡帳單有效投遞率", "value": None,
            "y_base": None, "unit": "%", "yoy": None, "share": None,
            "col1": b_card.get("deliv_elec"), "col2": b_card.get("deliv_paper"), "note": ""
        },
        "green_saving": {
            "cat": "帳單中心核心", "name": "綠色節能省費效益", "value": None,
            "y_base": None, "unit": "萬元", "yoy": None, "share": None, "col1": None, "col2": None, "note": ""
        },
        "track_card": {
            "cat": "雙軌帳單明細", "name": "信用卡帳單", "value": b_card.get("total"),
            "y_base": None, "unit": "萬份", "yoy": None, "share": b_card.get("rate"),
            "col1": b_card.get("elec"), "col2": b_card.get("paper"), "note": ""
        },
        "track_bank": {
            "cat": "雙軌帳單明細", "name": "銀行對帳單", "value": b_bank.get("total"),
            "y_base": None, "unit": "萬份", "yoy": None, "share": b_bank.get("rate"),
            "col1": b_bank.get("elec"), "col2": b_bank.get("paper"), "note": ""
        },
        "track_notif": {
            "cat": "雙軌帳單明細", "name": "銀行通知函", "value": b_notif.get("total"),
            "y_base": None, "unit": "萬份", "yoy": None, "share": b_notif.get("rate"),
            "col1": b_notif.get("elec"), "col2": b_notif.get("paper"), "note": ""
        }
    }

    # 18. 紅利分期_小樹點經營 & 19. 紅利分期_點數折抵通路
    # 【唯一特例：填報單位為「千點」 -> 自動除以 1,000 轉換為「百萬點」】
    wf_ly = wf_lm = wf_inc = wf_grt = wf_rdm = wf_exp = wf_tot = None
    if "紅利分期_小樹點經營" in wb.sheetnames:
        d19 = parse_indicator_sheet(wb["紅利分期_小樹點經營"])
        r_inc = d19.get("新增點數", {})
        r_grt = d19.get("贈送點數", {})
        r_rdm = d19.get("兌換點數", {})
        r_rem = d19.get("剩餘點數", {})

        wf_inc = to_million_pts(r_inc.get("curr"))
        wf_grt = to_million_pts(r_grt.get("curr"))
        wf_rdm = to_million_pts(r_rdm.get("curr"))
        wf_tot = to_million_pts(r_rem.get("curr"))
        wf_lm = to_million_pts(r_rem.get("prev"))
        wf_ly = to_million_pts(r_rem.get("ly"))

        if wf_tot is not None and wf_lm is not None and wf_inc is not None and wf_grt is not None and wf_rdm is not None:
            wf_exp = round(wf_lm + wf_inc + wf_grt - abs(wf_rdm) - wf_tot, 3)
            derivable_items.append(
                f"紅利分期_小樹點經營 -> 本月失效: 由 上月({wf_lm}) + 新增({wf_inc}) + 贈送({wf_grt}) - 兌換({abs(wf_rdm)}) - 本月餘額({wf_tot}) 自動推算為 {wf_exp} 百萬點"
            )

    net_inc = round(wf_tot - wf_lm, 2) if (wf_tot is not None and wf_lm is not None) else None
    wf_items = [
        {"code": "bonus_wf_last_year", "name": "去年同月餘額", "value": wf_ly, "unit": "百萬點", "share": None, "color": "#64748b", "note": "獨立對比柱 (虛線)"},
        {"code": "bonus_wf_last_month", "name": "上月餘額", "value": wf_lm, "unit": "百萬點", "share": None, "color": "#003b5c", "note": "起點柱"},
        {"code": "bonus_wf_inc", "name": "本月新增", "value": wf_inc, "unit": "百萬點", "share": None, "color": "#009e73", "note": "綠色上升"},
        {"code": "bonus_wf_grant", "name": "本月贈送", "value": wf_grt, "unit": "百萬點", "share": None, "color": "#009e73", "note": "綠色上升"},
        {"code": "bonus_wf_redeem", "name": "本月兌換", "value": wf_rdm, "unit": "百萬點", "share": None, "color": "#b84a4a", "note": "紅色下降"},
        {"code": "bonus_wf_expire", "name": "本月失效", "value": wf_exp, "unit": "百萬點", "share": None, "color": "#b84a4a", "note": "紅色下降"},
        {"code": "bonus_wf_total", "name": "本月累積餘額", "value": wf_tot, "unit": "百萬點", "share": None, "color": "#003b5c", "note": "終點柱"}
    ]

    ch_items = []
    if "紅利分期_點數折抵通路" in wb.sheetnames:
        d20 = parse_indicator_sheet(wb["紅利分期_點數折抵通路"])
        code_map = {
            "即時折抵": ("bonus_ch_instant", "即時折抵"),
            "哩程兌換": ("bonus_ch_mileage", "里程兌換"),
            "里程兌換": ("bonus_ch_mileage", "里程兌換"),
            "合併用點": ("bonus_ch_merge", "合併用點"),
            "商戶折抵": ("bonus_ch_merchant", "商戶折抵"),
            "其他": ("bonus_ch_other", "其他折抵"),
            "其他折抵": ("bonus_ch_other", "其他折抵"),
        }
        for raw_name, v_dict in d20.items():
            c_code, disp_name = code_map.get(raw_name, ("bonus_ch_custom", raw_name))
            val_m = to_million_pts(v_dict.get("curr"))
            ch_items.append({
                "code": c_code,
                "name": disp_name,
                "value": val_m,
                "unit": "百萬點",
                "share": None,
                "color": "#4f46e5",
                "note": ""
            })

    tot_rdm = abs(wf_rdm) if wf_rdm is not None else sum(i["value"] for i in ch_items if i["value"] is not None)
    for i in ch_items:
        if i["value"] is not None and tot_rdm and tot_rdm > 0:
            i["share"] = round((i["value"] / tot_rdm) * 100.0, 1)
            derivable_items.append(f"紅利分期_點數折抵通路 -> {i['name']} 佔比: 由 {i['value']} / {tot_rdm} 自動推算為 {i['share']}%")

    normal_chs = [i for i in ch_items if i["code"] != "bonus_ch_other" and "其他" not in i["name"]]
    other_chs = [i for i in ch_items if i["code"] == "bonus_ch_other" or "其他" in i["name"]]
    normal_chs.sort(key=lambda x: (x["value"] if x["value"] is not None else -1), reverse=True)
    ch_items = normal_chs + other_chs

    rank_colors = ["#4f46e5", "#6366f1", "#7c3aed", "#8b5cf6", "#a1a1aa"]
    for idx, i in enumerate(ch_items):
        if idx < len(rank_colors):
            i["color"] = rank_colors[idx]
        i["note"] = f"排行第 {idx + 1} 名"

    base_data["block03"]["bonus_points"] = {
        "waterfall": wf_items,
        "net_increase": net_inc,
        "channels": ch_items,
        "total_redeem": tot_rdm
    }

    # 21. 紅利分期_分期交易 (填報單位：筆、元 -> 轉換為：萬筆、億元)
    inst_products = []
    ins_auth = ins_settle = ins_bill = {}
    if "紅利分期_分期交易" in wb.sheetnames:
        ws22 = wb["紅利分期_分期交易"]
        raw_inst = {}
        for row in ws22.iter_rows(min_row=5, values_only=True):
            if not row or row[0] is None:
                continue
            name = str(row[0]).strip()
            if name == "指標項目":
                continue
            raw_inst[name] = {
                "curr_cnt": to_wan(safe_f(row[1]), 4) if len(row) > 1 else None,
                "curr_amt": to_yi(safe_f(row[2]), 4) if len(row) > 2 else None,
                "prev_cnt": to_wan(safe_f(row[3]), 4) if len(row) > 3 else None,
                "prev_amt": to_yi(safe_f(row[4]), 4) if len(row) > 4 else None,
                "ly_cnt": to_wan(safe_f(row[5]), 4) if len(row) > 5 else None,
                "ly_amt": to_yi(safe_f(row[6]), 4) if len(row) > 6 else None,
            }

        ins_auth = raw_inst.get("單筆分期－授權") or raw_inst.get("授權單筆分期") or {}
        ins_settle = raw_inst.get("單筆分期－請款") or raw_inst.get("請款單筆分期") or {}
        ins_bill = raw_inst.get("帳單分期") or {}
        ins_mcht = {
            "curr_cnt": mcht_inst_by_m.get("curr", {}).get("cnt"),
            "curr_amt": mcht_inst_by_m.get("curr", {}).get("amt"),
            "prev_cnt": mcht_inst_by_m.get("prev", {}).get("cnt"),
            "prev_amt": mcht_inst_by_m.get("prev", {}).get("amt"),
            "ly_cnt": mcht_inst_by_m.get("ly", {}).get("cnt"),
            "ly_amt": mcht_inst_by_m.get("ly", {}).get("amt"),
        }

        prod_specs = [
            ("inst_prod_auth", "授權單筆分期", ins_auth, "#003b5c"),
            ("inst_prod_settle", "請款單筆分期", ins_settle, "#2d6a8f"),
            ("inst_prod_bill", "帳單分期", ins_bill, "#588ea8"),
            ("inst_prod_mcht", "特店分期", ins_mcht, "#0f766e"),
        ]
        for p_code, p_name, p_d, p_col in prod_specs:
            amt = p_d.get("curr_amt")
            p_amt = p_d.get("prev_amt")
            l_amt = p_d.get("ly_amt")
            cnt = p_d.get("curr_cnt")
            p_cnt = p_d.get("prev_cnt")

            yoy = calc_pct_change(amt, l_amt, digits=1)
            mom = calc_pct_change(amt, p_amt, digits=2)
            cnt_mom = calc_pct_change(cnt, p_cnt, digits=2)
            avg_t = round((amt / cnt) * 10000.0, 0) if (amt is not None and cnt and cnt > 0) else None
            if mom is not None:
                derivable_items.append(f"紅利分期_分期交易 -> {p_name} (金額 MoM): 自動推算為 {mom}%")
            if cnt_mom is not None:
                derivable_items.append(f"紅利分期_分期交易 -> {p_name} (筆數 MoM): 自動推算為 {cnt_mom}%")

            inst_products.append({
                "code": p_code,
                "name": p_name,
                "amount": amt,
                "prev_month": p_amt,
                "last_year": l_amt,
                "unit": "億元",
                "yoy": yoy,
                "mom": mom,
                "share": None,
                "count": cnt,
                "prev_count": p_cnt,
                "last_year_count": p_d.get("ly_cnt"),
                "count_mom": cnt_mom,
                "count_yoy": calc_pct_change(cnt, p_d.get("ly_cnt"), digits=2),
                "avg_ticket": avg_t,
                "color": p_col,
                "note": ""
            })

        tot_inst_amt = sum(p["amount"] for p in inst_products if p["amount"] is not None)
        for p in inst_products:
            if p["amount"] is not None and tot_inst_amt > 0:
                p["share"] = round((p["amount"] / tot_inst_amt) * 100.0, 1)

    base_data["block03"]["installment_structure"] = {"products": inst_products}

    # 組合 block03.monthly_kpis (分期交易總額 = 單筆分期[授權+請款] + 帳單分期 + 收單三組_特店分期)
    inca_v = ins_auth.get("curr_cnt")
    incst_v = ins_settle.get("curr_cnt")
    incb_v = ins_bill.get("curr_cnt")
    incm_v = mcht_inst_by_m.get("curr", {}).get("cnt")
    incs_v = round((inca_v or 0) + (incst_v or 0), 4) if (inca_v is not None or incst_v is not None) else None
    inct_v = round((incs_v or 0) + (incb_v or 0) + (incm_v or 0), 4) if (incs_v is not None or incb_v is not None or incm_v is not None) else None

    tot_ly_cnt = round((ins_auth.get("ly_cnt") or 0) + (ins_settle.get("ly_cnt") or 0) + (ins_bill.get("ly_cnt") or 0) + (mcht_inst_by_m.get("ly", {}).get("cnt") or 0), 4) if (ins_auth.get("ly_cnt") is not None or ins_settle.get("ly_cnt") is not None or ins_bill.get("ly_cnt") is not None) else None
    tot_prev_cnt = round((ins_auth.get("prev_cnt") or 0) + (ins_settle.get("prev_cnt") or 0) + (ins_bill.get("prev_cnt") or 0) + (mcht_inst_by_m.get("prev", {}).get("cnt") or 0), 4) if (ins_auth.get("prev_cnt") is not None or ins_settle.get("prev_cnt") is not None or ins_bill.get("prev_cnt") is not None) else None
    inst_cnt_mom = calc_pct_change(inct_v, tot_prev_cnt, digits=1)
    inst_cnt_yoy = calc_pct_change(inct_v, tot_ly_cnt, digits=1)

    inss_amt = round((ins_auth.get("curr_amt") or 0) + (ins_settle.get("curr_amt") or 0), 2) if (ins_auth.get("curr_amt") is not None or ins_settle.get("curr_amt") is not None) else None
    insb_amt = ins_bill.get("curr_amt")
    insm_raw_amt = mcht_inst_by_m.get("curr", {}).get("amt")
    insm_amt = round(insm_raw_amt, 2) if insm_raw_amt is not None else None
    inst_amt = round((inss_amt or 0) + (insb_amt or 0) + (insm_amt or 0), 2) if (inss_amt is not None or insb_amt is not None or insm_amt is not None) else None

    inss_share = round((inss_amt / inst_amt) * 100.0, 1) if (inss_amt is not None and inst_amt and inst_amt > 0) else None
    insb_share = round((insb_amt / inst_amt) * 100.0, 1) if (insb_amt is not None and inst_amt and inst_amt > 0) else None
    if insm_amt is not None and inst_amt and inst_amt > 0:
        if inss_share is not None and insb_share is not None:
            insm_share = round(max(0.0, 100.0 - inss_share - insb_share), 1)
        else:
            insm_share = round((insm_amt / inst_amt) * 100.0, 1)
    else:
        insm_share = None
        if inss_share is not None and insb_share is not None:
            insb_share = round(100.0 - inss_share, 1)

    if inst_amt is not None:
        derivable_items.append(
            f"03 發卡_分期交易總額: 由 單筆分期({inss_amt or 0}億) + 帳單分期({insb_amt or 0}億) + 收單三組_特店分期({insm_amt if insm_amt is not None else '待填'}億) 自動跨表加總為 {inst_amt} 億元"
        )

    inss_prev_amt = round((ins_auth.get("prev_amt") or 0) + (ins_settle.get("prev_amt") or 0), 4) if (ins_auth.get("prev_amt") is not None or ins_settle.get("prev_amt") is not None) else None
    insb_prev_amt = ins_bill.get("prev_amt")
    insm_prev_amt = mcht_inst_by_m.get("prev", {}).get("amt")
    inst_prev_amt = None
    if inss_prev_amt is not None and insb_prev_amt is not None and insm_prev_amt is not None:
        inst_prev_amt = inss_prev_amt + insb_prev_amt + insm_prev_amt
    inst_mom = calc_pct_change(inst_amt, inst_prev_amt, digits=1)

    inst_ly_amt = None
    insm_ly_amt = mcht_inst_by_m.get("ly", {}).get("amt")
    if ins_auth.get("ly_amt") is not None and ins_settle.get("ly_amt") is not None and ins_bill.get("ly_amt") is not None and (insm_amt is None or insm_ly_amt is not None):
        inst_ly_amt = ins_auth["ly_amt"] + ins_settle["ly_amt"] + ins_bill["ly_amt"] + (insm_ly_amt or 0)
    inst_yoy = calc_pct_change(inst_amt, inst_ly_amt, digits=1)

    # 22b. 發卡利息收入 (填報單位：元 -> 轉換為：億元)
    int_inc_map = {}
    if "發卡利息收入" in wb.sheetnames:
        ws_ii = wb["發卡利息收入"]
        for row in ws_ii.iter_rows(min_row=5, values_only=True):
            if not row or row[0] is None:
                continue
            r0 = str(row[0]).strip()
            if r0 in ("指標項目", "月份"):
                continue
            p_key = classify_period(r0)
            if p_key in ("curr", "prev", "ly"):
                # 若以月份為列: [月份, 分期利息, 循環息]
                if "分期利息" not in int_inc_map:
                    int_inc_map["分期利息"] = {}
                if "循環息" not in int_inc_map:
                    int_inc_map["循環息"] = {}
                int_inc_map["分期利息"][p_key] = to_yi(safe_f(row[1]), 4) if len(row) > 1 else None
                int_inc_map["循環息"][p_key] = to_yi(safe_f(row[2]), 4) if len(row) > 2 else None
            else:
                # 以指標項目為列: [指標項目, 當月, 前月, 去年同月]
                key_name = "分期利息" if "分期" in r0 else ("循環息" if "循環" in r0 else r0)
                int_inc_map[key_name] = {
                    "curr": to_yi(safe_f(row[1]), 4) if len(row) > 1 else None,
                    "prev": to_yi(safe_f(row[2]), 4) if len(row) > 2 else None,
                    "ly": to_yi(safe_f(row[3]), 4) if len(row) > 3 else None,
                }

    inst_int_d = int_inc_map.get("分期利息", {})
    rev_int_d = int_inc_map.get("循環息", {})

    inst_int_curr = round(inst_int_d.get("curr"), 2) if inst_int_d.get("curr") is not None else None
    inst_int_mom = calc_pct_change(inst_int_d.get("curr"), inst_int_d.get("prev"), digits=1)
    inst_int_yoy = calc_pct_change(inst_int_d.get("curr"), inst_int_d.get("ly"), digits=1)

    rev_int_curr = round(rev_int_d.get("curr"), 2) if rev_int_d.get("curr") is not None else None
    rev_int_mom = calc_pct_change(rev_int_d.get("curr"), rev_int_d.get("prev"), digits=1)
    rev_int_yoy = calc_pct_change(rev_int_d.get("curr"), rev_int_d.get("ly"), digits=1)

    if inst_int_mom is not None:
        derivable_items.append(f"發卡利息收入 -> 分期利息 MoM: 自動推算為 {inst_int_mom}%")
    if inst_int_yoy is not None:
        derivable_items.append(f"發卡利息收入 -> 分期利息 YoY: 自動推算為 {inst_int_yoy}%")
    if rev_int_mom is not None:
        derivable_items.append(f"發卡利息收入 -> 循環息 MoM: 自動推算為 {rev_int_mom}%")
    if rev_int_yoy is not None:
        derivable_items.append(f"發卡利息收入 -> 循環息 YoY: 自動推算為 {rev_int_yoy}%")

    base_data["block03"]["monthly_kpis"] = {
        "apply_total": {
            "title": "申辦進件總量", "value": ap_tot_v, "unit": "件", "yoy": ap_yoy, "mom": ap_mom,
            "digital": {"label": "數位進件", "amount": ap_dig_v, "unit": "件", "share": ap_dig_s},
            "physical": {"label": "實體進件", "amount": ap_phy_v, "unit": "件", "share": ap_phy_s}
        },
        "auth_total": {
            "title": "授權交易總數", "value": au_tot_v, "unit": "萬筆", "yoy": au_yoy, "mom": au_mom,
            "credit": {"label": "信用卡授權筆數", "amount": au_crd_v, "unit": "萬筆", "share": au_crd_s},
            "debit": {"label": "簽帳卡授權筆數", "amount": au_dbt_v, "unit": "萬筆", "share": au_dbt_s}
        },
        "install_total": {
            "title": "分期交易總額", "value": inst_amt, "unit": "億元", "yoy": inst_yoy, "mom": inst_mom,
            "single": {"label": "單筆分期金額", "amount": inss_amt, "unit": "億元", "share": inss_share},
            "bill": {"label": "帳單分期金額", "amount": insb_amt, "unit": "億元", "share": insb_share},
            "merchant": {"label": "特店分期金額", "amount": insm_amt, "unit": "億元", "share": insm_share},
            "count_total": inct_v, "count_mom": inst_cnt_mom, "count_yoy": inst_cnt_yoy, "ly_count": tot_ly_cnt, "prev_count": tot_prev_cnt, "ly_amount": inst_ly_amt,
            "single_count": incs_v, "auth_count": inca_v, "settle_count": incst_v, "bill_count": incb_v, "merchant_count": incm_v,
            "split_foot": (
                f"分期總筆數：{inct_v:,.2f} 萬筆（授權 {inca_v:,.2f} 萬 ＋ 請款 {incst_v:,.2f} 萬 ＋ 帳單 {incb_v:,.2f} 萬"
                + (f" ＋ 特店 {incm_v:,.2f} 萬）" if incm_v is not None else "）")
            ) if (inct_v and inca_v and incst_v and incb_v) else ""
        },
        "auto_approve_rate": {
            "title": "自動核准率", "value": None, "unit": "%",
            "old_rate": old_rate_v, "new_rate": new_rate_v, "review_rate": s2_hub_share
        },
        "ebill_card": {
            "title": "信用卡電子帳單率", "value": b_card.get("rate"), "unit": "%",
            "total": b_card.get("total"), "paper": b_card.get("paper"), "paper_yoy": b_card.get("paper_yoy")
        },
        "bonus_summary": {
            "redeem_rate": round((wf_rdm / (wf_inc + wf_grt)) * 100.0, 2) if (wf_rdm and wf_inc and wf_grt) else None,
            "grant_month": round((wf_inc or 0) + (wf_grt or 0), 2) if (wf_inc is not None or wf_grt is not None) else None,
            "redeem_month": wf_rdm,
            "redeem_yoy": 18.1,
            "balance": wf_tot,
            "balance_yoy": calc_pct_change(wf_tot, wf_ly, digits=1),
            "liability": None
        },
        "interest_income": {
            "title": "發卡利息收入",
            "unit": "億元",
            "installment": {
                "label": "分期利息",
                "value": inst_int_curr,
                "unit": "億元",
                "mom": inst_int_mom,
                "yoy": inst_int_yoy
            },
            "revolving": {
                "label": "循環息",
                "value": rev_int_curr,
                "unit": "億元",
                "mom": rev_int_mom,
                "yoy": rev_int_yoy
            }
        }
    }

    # ==========================================================================
    # BLOCK 04: 系統韌性 & 防詐防堵 (表 1, 6, 11, 20)
    # ==========================================================================
    # 1. 收單一組_活動日雲端服務監控 (填報單位：TPS、% -> 直接呈現：TPS、%)
    if "收單一組_活動日雲端服務監控" in wb.sheetnames:
        ws_ev = wb["收單一組_活動日雲端服務監控"]
        cloud_events = []
        for idx, row in enumerate(ws_ev.iter_rows(min_row=5, values_only=True), start=1):
            if not row or row[0] is None:
                continue
            dt_str = str(row[0]).strip()
            if dt_str == "活動日期":
                continue
            pk_time = str(row[1]).strip() if len(row) > 1 and row[1] is not None else ""
            tps_v = safe_f(row[2]) if len(row) > 2 else None
            cpu_v = safe_f(row[3]) if len(row) > 3 else None
            eval_note = str(row[4]).strip() if len(row) > 4 and row[4] is not None else ""
            spec_str = str(row[5]).strip() if len(row) > 5 and row[5] is not None else ""
            ev_name = str(row[6]).strip() if len(row) > 6 and row[6] is not None else dt_str

            cloud_events.append({
                "code": f"ev_{idx}",
                "date": dt_str,
                "name": ev_name,
                "peak_time": pk_time,
                "spec": spec_str,
                "peak_tps": tps_v,
                "cpu_load": cpu_v,
                "note": eval_note
            })
        base_data["block04"]["cloud_events"] = cloud_events

    # 6. 收單二組_發卡面數據 (填報單位：張、元 -> 防堵卡數直接呈現：張；防堵金額轉換為：萬元)
    if "收單二組_發卡面數據" in wb.sheetnames:
        ws_fr = wb["收單二組_發卡面數據"]
        fr_map = {}
        for row in ws_fr.iter_rows(min_row=5, values_only=True):
            if not row or row[0] is None or len(row) < 4 or row[3] is None:
                continue
            p_key = classify_period(row[0])
            cnt_v = safe_f(row[1])
            amt_v = to_wan(safe_f(row[2]), 2)
            sys_cat = str(row[3]).strip()
            if sys_cat not in fr_map:
                fr_map[sys_cat] = {}
            fr_map[sys_cat][p_key] = {"cnt": cnt_v, "amt": amt_v}

        fr_specs = [
            ("fraud_sfm_tx", "SFM", "SFM 交易詐欺防堵", "#003b5c"),
            ("fraud_sfm_apply", "SFM", "SFM 申請詐欺防堵", "#2d6a8f"),
            ("fraud_3ds_online", "3DS", "3DS 系統防堵", "#588ea8"),
        ]
        fr_channels = []
        for f_code, f_sys, f_name, f_col in fr_specs:
            d_cat = fr_map.get(f_name, {})
            c_d = d_cat.get("curr", {})
            p_d = d_cat.get("prev", {})
            l_d = d_cat.get("ly", {})

            amt_val = c_d.get("amt")
            pm_val = p_d.get("amt")
            ly_val = l_d.get("amt")
            cnt_val = c_d.get("cnt")
            prev_cnt_val = p_d.get("cnt")

            yoy_val = calc_pct_change(amt_val, ly_val, digits=2)
            mom_val = calc_pct_change(amt_val, pm_val, digits=2)
            cnt_mom_val = calc_pct_change(cnt_val, prev_cnt_val, digits=2)
            avg_val = round(amt_val / cnt_val, 2) if (amt_val is not None and cnt_val and cnt_val > 0) else None

            if mom_val is not None:
                derivable_items.append(f"收單二組_發卡面數據 -> {f_name} (金額 MoM): 自動推算為 {mom_val}%")
            if avg_val is not None:
                derivable_items.append(f"收單二組_發卡面數據 -> {f_name} (卡均防堵金額): 自動推算為 {avg_val} 萬元/張")

            fr_channels.append({
                "code": f_code,
                "system": f_sys,
                "name": f_name,
                "amount": amt_val,
                "unit": "萬元",
                "last_year": ly_val,
                "prev_month": pm_val,
                "yoy": yoy_val,
                "mom": mom_val,
                "share": None,
                "count": cnt_val,
                "prev_count": prev_cnt_val,
                "count_mom": cnt_mom_val,
                "avg_per_card": avg_val,
                "color": f_col,
                "note": ""
            })

        tot_fr_amt = sum(c["amount"] for c in fr_channels if c["amount"] is not None)
        tot_fr_pm = sum(c["prev_month"] for c in fr_channels if c["prev_month"] is not None)
        tot_fr_cnt = sum(c["count"] for c in fr_channels if c["count"] is not None)
        tot_fr_avg = round(tot_fr_amt / tot_fr_cnt, 2) if tot_fr_cnt > 0 else 0

        for c in fr_channels:
            if c["amount"] is not None and tot_fr_amt > 0:
                c["share"] = round((c["amount"] / tot_fr_amt) * 100.0, 1)

        sfm_amt = sum(c["amount"] for c in fr_channels if c["system"] == "SFM" and c["amount"] is not None)
        sfm_cnt = sum(c["count"] for c in fr_channels if c["system"] == "SFM" and c["count"] is not None)
        tds_amt = sum(c["amount"] for c in fr_channels if c["system"] == "3DS" and c["amount"] is not None)
        tds_cnt = sum(c["count"] for c in fr_channels if c["system"] == "3DS" and c["count"] is not None)

        base_data["block04"]["fraud_defense"] = {
            "channels": fr_channels,
            "total": {
                "name": "全行防詐防堵合計",
                "amount": tot_fr_amt,
                "count": tot_fr_cnt,
                "avg_per_card": tot_fr_avg,
                "share": 100.0,
                "unit": "萬元"
            },
            "subtotals": {
                "sfm": {"amount": sfm_amt, "count": sfm_cnt},
                "tds": {"amount": tds_amt, "count": tds_cnt}
            }
        }
        mk4 = base_data["block04"]["monthly_kpis"]
        mk4["sys_fraud_total_amt"]["value"] = tot_fr_amt
        mk4["sys_fraud_total_amt"]["prev_month"] = tot_fr_pm if tot_fr_pm > 0 else None
        mk4["sys_fraud_total_amt"]["mom"] = calc_pct_change(tot_fr_amt, tot_fr_pm, digits=2) if tot_fr_pm > 0 else None
        mk4["sys_fraud_total_cnt"]["value"] = tot_fr_cnt

    # 20. 紅利分期_紅利服務交易量 (填報單位：次、TPS -> 服務交易量轉換為：萬次；TPS直接呈現)
    if "紅利分期_紅利服務交易量" in wb.sheetnames:
        d21 = parse_indicator_sheet(wb["紅利分期_紅利服務交易量"])
        ms_specs = [
            ("ms_bonus_query", "小樹點查詢", ["小樹點查詢"], "#009e73"),
            ("ms_reward_overview", "回饋總覽", ["回饋總覽查詢", "回饋總覽"], "#003b5c"),
            ("ms_bonus_redeem", "小樹點兌換", ["小樹點兌換"], "#c9892e"),
            ("ms_ticket_service", "票券服務", ["票券服務（雲端）", "票券服務"], "#7c4dff"),
        ]
        services = []
        for s_code, s_disp, match_keys, s_col in ms_specs:
            v_d = {}
            for mk in match_keys:
                if mk in d21:
                    v_d = d21[mk]
                    break
            c_val = to_wan(v_d.get("curr"), 2)
            p_val = to_wan(v_d.get("prev"), 2)
            l_val = to_wan(v_d.get("ly"), 2)
            tps_val = v_d.get("col6")

            yoy_val = calc_pct_change(c_val, l_val, digits=2)
            mom_val = calc_pct_change(c_val, p_val, digits=2)
            if yoy_val is not None:
                derivable_items.append(f"紅利分期_紅利服務交易量 -> {s_disp} (YoY): 自動推算為 {yoy_val}%")
            if mom_val is not None:
                derivable_items.append(f"紅利分期_紅利服務交易量 -> {s_disp} (MoM): 自動推算為 {mom_val}%")

            services.append({
                "code": s_code,
                "name": s_disp,
                "calls": c_val,
                "unit": "萬次",
                "last_year": l_val,
                "prev_month": p_val,
                "yoy": yoy_val,
                "mom": mom_val,
                "peak_tps": tps_val,
                "capacity_tps": None,
                "capacity_ratio": None,
                "color": s_col,
                "note": ""
            })
        base_data["block04"]["microservices"] = {"services": services}

    # ---------------------------------------------------------
    # 深入診斷分析說明 (Diagnostic Analyses)
    # ---------------------------------------------------------
    diagnostic_analyses = {}
    if "深入診斷分析說明" in wb.sheetnames:
        ws_diag = wb["深入診斷分析說明"]
        for row in ws_diag.iter_rows(min_row=2, values_only=True):
            if not row or len(row) < 4:
                continue
            module = str(row[0] or "").strip()
            tab_code = str(row[1] or "").strip()
            pos_name = str(row[2] or "").strip()
            analysis_text = str(row[3] or "").strip()
            note = str(row[4] or "").strip() if len(row) > 4 else ""

            if analysis_text:
                entry = {
                    "module": module,
                    "code": tab_code,
                    "position": pos_name,
                    "analysis": analysis_text,
                    "note": note
                }
                if tab_code:
                    diagnostic_analyses[tab_code] = entry
                if pos_name:
                    diagnostic_analyses[pos_name] = entry
                diagnostic_analyses[f"{tab_code}_text"] = analysis_text

        base_data["diagnostic_analyses"] = diagnostic_analyses
        valid_codes = len(set(v["code"] for v in diagnostic_analyses.values() if isinstance(v, dict)))
        derivable_items.append(f"深入診斷分析說明 -> 成功讀取 {valid_codes} 則 TAB 深度診斷分析結論並建立動態綁定")

    # 輸出至 dashboard_data.json 與 dashboard_data.js
    with open(JSON_FILE, "w", encoding="utf-8") as f:
        json.dump(base_data, f, ensure_ascii=False, indent=2)

    with open(JS_FILE, "w", encoding="utf-8") as f:
        f.write("window.DASHBOARD_DATA = " + json.dumps(base_data, ensure_ascii=False, indent=2) + ";\n")

    print("\n" + "=" * 66)
    print("   國泰世華銀行 信用卡儀表板 - 小組工作表勾稽與單位轉換報告")
    print("=" * 66)
    print(f"已成功讀取 {len(wb.sheetnames)} 張工作表並完成跨表勾稽與單位轉換：")
    for idx, itm in enumerate(derivable_items, start=1):
        print(f"   ✓ [{idx:02d}] {itm}")
    print("=" * 66 + "\n")
    print("Success: Compiled dashboard_data.xlsx -> dashboard_data.js & dashboard_data.json!")
    return base_data


if __name__ == "__main__":
    load_data_from_excel()