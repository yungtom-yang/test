window.DASHBOARD_DATA = {
  "meta": {
    "title": "國泰世華銀行 信用卡營運整合數據儀表板",
    "year": "2026",
    "month": "08",
    "period_label": "營運月報",
    "brand": "國泰世華"
  },
  "block01": {
    "section_title": "信用卡整體經營概況",
    "section_num": "01",
    "monthly_kpis": {
      "total_amount": {
        "title": "總交易金額",
        "value": 765.0,
        "unit": "億元",
        "yoy": null,
        "mom": null,
        "general": {
          "label": "一般交易",
          "amount": 740.0,
          "unit": "億元",
          "share": 96.73,
          "yoy": 15.1,
          "mom": -4.6
        },
        "installment": {
          "label": "分期交易",
          "amount": 25.0,
          "unit": "億元",
          "share": 3.27,
          "yoy": null,
          "mom": -2.6
        }
      },
      "total_count": {
        "title": "總交易筆數",
        "value": 6576.0,
        "unit": "萬筆",
        "yoy": null,
        "mom": null,
        "general": {
          "label": "一般交易",
          "count": 6554.0,
          "unit": "萬筆",
          "share": 99.67,
          "yoy": null,
          "mom": -4.1
        },
        "installment": {
          "label": "分期交易",
          "count": 22.0,
          "unit": "萬筆",
          "share": 0.33,
          "yoy": null,
          "mom": -2.6
        }
      },
      "active_card": {
        "title": "活卡率",
        "rate": null,
        "unit": "%",
        "yoy_pp": null,
        "mom_pp": null,
        "active_cards": null,
        "active_cards_unit": "張",
        "active_share": null,
        "issued_cards": null,
        "issued_cards_unit": "張",
        "inactive_cards": null,
        "inactive_cards_unit": "張",
        "inactive_share": null
      },
      "credit_business": {
        "revolving": {
          "title": "循環信用餘額",
          "balance": null,
          "unit": "億元",
          "yoy": null,
          "mom": null
        },
        "cash_advance": {
          "title": "預借現金金額",
          "amount": 1.854,
          "unit": "億元",
          "yoy": -5.1,
          "mom": -29.5,
          "count_wan": 0.9
        }
      }
    },
    "cockpit_peer_donut": {
      "title": "五大發卡行簽帳金額",
      "period_label": "2026 年 1–8 月",
      "market_label": "五大行簽帳總額",
      "market_total": 24534.17,
      "unit": "億元",
      "market_yoy": 18.5,
      "hint": "五大行合計",
      "peers": [
        {
          "name": "中國信託",
          "amount": 6457.36,
          "unit": "億元",
          "share": 26.3,
          "yoy": 25.86,
          "color": "#003b5c",
          "is_cathay": false,
          "note": "第一大行"
        },
        {
          "name": "國泰世華",
          "amount": 5726.22,
          "unit": "億元",
          "share": 23.3,
          "yoy": 17.12,
          "color": "#009e73",
          "is_cathay": true,
          "note": "本行 (綠色高亮顯示)"
        },
        {
          "name": "玉山銀行",
          "amount": 4705.48,
          "unit": "億元",
          "share": 19.2,
          "yoy": 18.43,
          "color": "#059669",
          "is_cathay": false,
          "note": "第四大行"
        },
        {
          "name": "台北富邦",
          "amount": 3893.63,
          "unit": "億元",
          "share": 15.9,
          "yoy": 6.38,
          "color": "#2563eb",
          "is_cathay": false,
          "note": "Costco 卡主力"
        },
        {
          "name": "台新銀行",
          "amount": 3751.48,
          "unit": "億元",
          "share": 15.3,
          "yoy": 22.71,
          "color": "#ea580c",
          "is_cathay": false,
          "note": "第五大行 (Richart/玫瑰卡主力)"
        }
      ]
    },
    "peer_benchmark": [
      {
        "label": "消費經營",
        "metrics": [
          {
            "label": "簽帳金額",
            "unit": "億元",
            "positiveDirection": "up",
            "summaryMode": "growth",
            "decimals": null,
            "marketValue": null,
            "marketYoy": null,
            "peers": [
              {
                "bank": "中國信託",
                "value": 6457.36,
                "yoy": 25.86
              },
              {
                "bank": "國泰世華",
                "value": 5726.22,
                "yoy": 17.12
              },
              {
                "bank": "玉山",
                "value": 4705.48,
                "yoy": 18.43
              },
              {
                "bank": "台北富邦",
                "value": 3893.63,
                "yoy": 6.38
              },
              {
                "bank": "台新銀行",
                "value": 3751.48,
                "yoy": 22.71
              }
            ]
          }
        ]
      },
      {
        "label": "卡量經營",
        "metrics": [
          {
            "label": "流通卡數",
            "unit": "張",
            "positiveDirection": "up",
            "summaryMode": "growth",
            "decimals": null,
            "marketValue": null,
            "marketYoy": null,
            "peers": [
              {
                "bank": "中國信託",
                "value": 9787283.0,
                "yoy": 8.88
              },
              {
                "bank": "台北富邦",
                "value": 7564017.0,
                "yoy": 1.65
              },
              {
                "bank": "玉山",
                "value": 7497711.0,
                "yoy": -14.17
              },
              {
                "bank": "國泰世華",
                "value": 7257654.0,
                "yoy": -0.59
              },
              {
                "bank": "台新銀行",
                "value": 6685959.0,
                "yoy": 0.91
              }
            ]
          },
          {
            "label": "有效卡數",
            "unit": "張",
            "positiveDirection": "up",
            "summaryMode": "growth",
            "decimals": null,
            "marketValue": null,
            "marketYoy": null,
            "peers": [
              {
                "bank": "中國信託",
                "value": 6904052.0,
                "yoy": 13.01
              },
              {
                "bank": "台北富邦",
                "value": 5867144.0,
                "yoy": 1.21
              },
              {
                "bank": "國泰世華",
                "value": 5119242.0,
                "yoy": -0.15
              },
              {
                "bank": "玉山",
                "value": 4888279.0,
                "yoy": -9.53
              },
              {
                "bank": "台新銀行",
                "value": 4806088.0,
                "yoy": -1.38
              }
            ]
          },
          {
            "label": "活卡率",
            "unit": "%",
            "positiveDirection": "up",
            "summaryMode": "quality",
            "decimals": 1,
            "marketValue": null,
            "marketYoy": null,
            "peers": [
              {
                "bank": "台北富邦",
                "value": 77.57,
                "yoy": -0.33
              },
              {
                "bank": "台新銀行",
                "value": 71.88,
                "yoy": -1.67
              },
              {
                "bank": "國泰世華",
                "value": 70.54,
                "yoy": 0.31
              },
              {
                "bank": "中國信託",
                "value": 70.54,
                "yoy": 2.58
              },
              {
                "bank": "玉山",
                "value": 65.2,
                "yoy": 3.35
              }
            ]
          }
        ]
      },
      {
        "label": "信用業務",
        "metrics": [
          {
            "label": "循環信用餘額",
            "unit": "億元",
            "positiveDirection": "up",
            "summaryMode": "growth",
            "decimals": null,
            "marketValue": null,
            "marketYoy": null,
            "peers": [
              {
                "bank": "國泰世華",
                "value": 225.28,
                "yoy": 4.79
              },
              {
                "bank": "中國信託",
                "value": 182.65,
                "yoy": 5.61
              },
              {
                "bank": "玉山",
                "value": 174.64,
                "yoy": 4.31
              },
              {
                "bank": "台新銀行",
                "value": 114.87,
                "yoy": 4.65
              },
              {
                "bank": "台北富邦",
                "value": 114.33,
                "yoy": 4.71
              }
            ]
          },
          {
            "label": "未到期分期付款餘額",
            "unit": "億元",
            "positiveDirection": "up",
            "summaryMode": "growth",
            "decimals": null,
            "marketValue": null,
            "marketYoy": null,
            "peers": [
              {
                "bank": "國泰世華",
                "value": 462.0,
                "yoy": 10.2
              },
              {
                "bank": "中國信託",
                "value": 448.0,
                "yoy": 9.1
              },
              {
                "bank": "玉山",
                "value": 311.0,
                "yoy": 7.5
              },
              {
                "bank": "台北富邦",
                "value": 282.0,
                "yoy": 5.9
              },
              {
                "bank": "台新銀行",
                "value": 235.0,
                "yoy": 6.8
              }
            ]
          }
        ]
      }
    ]
  },
  "block02": {
    "section_title": "收單業務",
    "section_num": "02",
    "monthly_kpis": {
      "acq_amt": {
        "title": "收單交易金額",
        "total": 239.4112,
        "unit": "億元",
        "yoy": -7.1,
        "mom": 2.1,
        "physical": {
          "amount": null,
          "unit": "億元",
          "share": 65.0,
          "yoy": null
        },
        "online": {
          "amount": 18.835,
          "unit": "億元",
          "share": 35.0,
          "yoy": null
        }
      },
      "acq_cnt": {
        "title": "收單交易筆數",
        "total": 2991.8,
        "unit": "萬筆",
        "yoy": -2.0,
        "mom": 1.8,
        "physical": {
          "count": null,
          "unit": "萬筆",
          "share": 70.0,
          "yoy": null
        },
        "online": {
          "count": 1667.0,
          "unit": "萬筆",
          "share": 30.0,
          "yoy": null
        }
      },
      "acq_mcht": {
        "title": "收單特店總數",
        "total": 60382.0,
        "unit": "家",
        "yoy": -0.1,
        "mom": -0.7,
        "active_rate": 83.0,
        "submcht": {
          "title": "子特店總數",
          "total": 331.6053,
          "unit": "萬家",
          "yoy": 2.1,
          "mom": 0.7
        },
        "physical": {
          "count": null,
          "unit": "家",
          "share": 80.0
        },
        "online": {
          "count": null,
          "unit": "家",
          "share": 20.0
        }
      },
      "secondary": {
        "erm_cnt": {
          "title": "ERM電簽交易筆數",
          "value": 381.97,
          "unit": "萬筆",
          "yoy": null,
          "mom": 1.8
        },
        "portal_mcht": {
          "title": "Merchant Portal商戶數",
          "value": 361.0,
          "unit": "家",
          "yoy": null,
          "mom": null
        },
        "submcht_api": {
          "title": "次特店API進件數",
          "value": null,
          "unit": "件"
        },
        "fee_income": {
          "title": "收單手續費收入",
          "value": null,
          "unit": "億元",
          "yoy": null,
          "mom": null
        },
        "penetration_rate": {
          "title": "ERM電簽交易筆數",
          "value": 381.97,
          "unit": "萬筆",
          "yoy": null,
          "mom": 1.8
        },
        "active_mcht": {
          "title": "Merchant Portal商戶數",
          "count": 361.0,
          "value": 361.0,
          "unit": "家",
          "yoy": null,
          "mom": null
        }
      }
    },
    "online_channels": [
      {
        "name": "EPOS - 雲端",
        "amount": 6.128,
        "prev_amount": null,
        "amount_share": 32.5,
        "amount_mom": null,
        "amount_yoy": null,
        "count": 663.2232,
        "prev_count": null,
        "count_mom": null,
        "count_yoy": null,
        "avg_ticket": 92,
        "avg_ticket_yoy": null,
        "note": ""
      },
      {
        "name": "EPOS - 地端",
        "amount": 10.715,
        "prev_amount": null,
        "amount_share": 56.9,
        "amount_mom": null,
        "amount_yoy": null,
        "count": 653.2417,
        "prev_count": null,
        "count_mom": null,
        "count_yoy": null,
        "avg_ticket": 164,
        "avg_ticket_yoy": null,
        "note": ""
      },
      {
        "name": "Payment Hub掃碼交易",
        "amount": 1.991722,
        "prev_amount": null,
        "amount_share": 10.6,
        "amount_mom": null,
        "amount_yoy": null,
        "count": 350.1689,
        "prev_count": null,
        "count_mom": null,
        "count_yoy": null,
        "avg_ticket": 57,
        "avg_ticket_yoy": null,
        "note": ""
      }
    ],
    "merchant_concentration": {
      "top10_share": null,
      "top10_yoy": null,
      "top_merchants": [
        {
          "name": "特店 A",
          "sub": "量販巨頭",
          "amount": null,
          "yoy": null,
          "quadrant": "核心成長區"
        },
        {
          "name": "特店 B",
          "sub": "綜合電商",
          "amount": null,
          "yoy": null,
          "quadrant": "核心成長區"
        },
        {
          "name": "特店 C",
          "sub": "百貨生活",
          "amount": null,
          "yoy": null,
          "quadrant": "重點維繫區"
        },
        {
          "name": "特店 D",
          "sub": "連鎖超商",
          "amount": null,
          "yoy": null,
          "quadrant": "重點維繫區"
        },
        {
          "name": "特店 E",
          "sub": "連鎖餐飲",
          "amount": null,
          "yoy": null,
          "quadrant": "潛力開發區"
        }
      ],
      "matrix_reps": {
        "core": "代表：特店 A、特店 B",
        "potential": "代表：特店 E 等",
        "maintain": "代表：特店 C、特店 D",
        "general": "代表：特店 X"
      }
    },
    "industry_structure": [
      {
        "name": "量販超市",
        "label": "🛒 量販超市",
        "merchant_count": null,
        "merchant_share": null,
        "amount": null,
        "amount_share": null,
        "avg_per_merchant": null,
        "color": "#003b5c"
      },
      {
        "name": "綜合電商",
        "label": "🌐 綜合電商",
        "merchant_count": null,
        "merchant_share": null,
        "amount": null,
        "amount_share": null,
        "avg_per_merchant": null,
        "color": "#0284c7"
      },
      {
        "name": "百貨生活",
        "label": "🏬 百貨生活",
        "merchant_count": null,
        "merchant_share": null,
        "amount": null,
        "amount_share": null,
        "avg_per_merchant": null,
        "color": "#10b981"
      },
      {
        "name": "餐飲美食",
        "label": "🍽️ 餐飲美食",
        "merchant_count": null,
        "merchant_share": null,
        "amount": null,
        "amount_share": null,
        "avg_per_merchant": null,
        "color": "#f59e0b"
      },
      {
        "name": "交通旅遊",
        "label": "✈️ 交通旅遊",
        "merchant_count": null,
        "merchant_share": null,
        "amount": null,
        "amount_share": null,
        "avg_per_merchant": null,
        "color": "#8b5cf6"
      },
      {
        "name": "其他各業",
        "label": "📦 其他各業",
        "merchant_count": null,
        "merchant_share": null,
        "amount": null,
        "amount_share": null,
        "avg_per_merchant": null,
        "color": "#94a3b8"
      }
    ],
    "twqr": {
      "apply_count": null,
      "pass_rate": null,
      "new_merchants": null,
      "total_merchants": 256.0,
      "total_merchants_mom": 11.3,
      "tx_amount": 130620.0,
      "tx_amount_unit": "元",
      "tx_amount_mom": 262.9,
      "tx_count": 199.0,
      "tx_count_unit": "筆",
      "tx_count_mom": 38.2,
      "avg_ticket": 656,
      "mcht_avg_amount": null,
      "active_mcht_rate": null
    }
  },
  "block03": {
    "section_title": "發卡業務",
    "section_num": "03",
    "monthly_kpis": {
      "apply_total": {
        "title": "申辦進件總量",
        "value": 55503.0,
        "unit": "件",
        "yoy": -1.6,
        "mom": -13.1,
        "digital": {
          "label": "數位進件",
          "amount": 51735.0,
          "unit": "件",
          "share": 93.2
        },
        "physical": {
          "label": "實體進件",
          "amount": 3768.0,
          "unit": "件",
          "share": 6.8
        }
      },
      "auth_total": {
        "title": "授權交易總數",
        "value": 7866.9788,
        "unit": "萬筆",
        "yoy": 21.4,
        "mom": 2.7,
        "credit": {
          "label": "信用卡授權筆數",
          "amount": 7289.8322,
          "unit": "萬筆",
          "share": 92.7
        },
        "debit": {
          "label": "簽帳卡授權筆數",
          "amount": 577.1466,
          "unit": "萬筆",
          "share": 7.3
        }
      },
      "install_total": {
        "title": "分期交易總額",
        "value": 18.67,
        "unit": "億元",
        "yoy": -15.9,
        "mom": null,
        "single": {
          "label": "單筆分期金額",
          "amount": 10.66,
          "unit": "億元",
          "share": 57.1
        },
        "bill": {
          "label": "帳單分期金額",
          "amount": 8.01,
          "unit": "億元",
          "share": 42.9
        },
        "merchant": {
          "label": "特店分期金額",
          "amount": null,
          "unit": "億元",
          "share": null
        },
        "count_total": 11.9849,
        "count_mom": -16.3,
        "count_yoy": 0.9,
        "ly_count": 11.8815,
        "prev_count": 14.32,
        "ly_amount": 22.208,
        "single_count": 9.0685,
        "auth_count": 5.6657,
        "settle_count": 3.4028,
        "bill_count": 2.9164,
        "merchant_count": null,
        "split_foot": "分期總筆數：11.98 萬筆（授權 5.67 萬 ＋ 請款 3.40 萬 ＋ 帳單 2.92 萬）"
      },
      "auto_approve_rate": {
        "title": "自動核准率",
        "value": null,
        "unit": "%",
        "old_rate": 91.82,
        "new_rate": 77.98,
        "review_rate": 83.5
      },
      "ebill_card": {
        "title": "信用卡電子帳單率",
        "value": 67.93,
        "unit": "%",
        "total": 468.6346,
        "paper": 150.3101,
        "paper_yoy": null
      },
      "bonus_summary": {
        "redeem_rate": 71.17,
        "grant_month": 898.31,
        "redeem_month": 639.34,
        "redeem_yoy": 18.1,
        "balance": 7353.794,
        "balance_yoy": 28.9,
        "liability": null
      },
      "interest_income": {
        "title": "發卡利息收入",
        "unit": "億元",
        "installment": {
          "label": "分期利息",
          "value": null,
          "unit": "億元",
          "mom": null,
          "yoy": null
        },
        "revolving": {
          "label": "循環息",
          "value": null,
          "unit": "億元",
          "mom": null,
          "yoy": null
        }
      }
    },
    "application_approval": {
      "stage1_old": {
        "cat": "申辦徵審流向",
        "name": "舊戶加辦進件",
        "value": 14543.0,
        "y_base": null,
        "unit": "件",
        "yoy": null,
        "share": 28.5,
        "col1": 12946,
        "col2": null,
        "note": "",
        "auto_rate": 96.9
      },
      "stage1_new": {
        "cat": "申辦徵審流向",
        "name": "新戶申辦進件",
        "value": 36397.0,
        "y_base": null,
        "unit": "件",
        "yoy": null,
        "share": 71.5,
        "col1": 22178,
        "col2": null,
        "note": "",
        "auto_rate": 78.1
      },
      "stage2_hub": {
        "cat": "申辦徵審流向",
        "name": "進件自動審查中樞",
        "value": 42540.0,
        "y_base": null,
        "unit": "件",
        "yoy": null,
        "share": 83.5,
        "col1": null,
        "col2": null,
        "note": ""
      },
      "stage3_auto_pass": {
        "cat": "申辦徵審流向",
        "name": "自動直接核准總數",
        "value": 35124.0,
        "y_base": null,
        "unit": "件",
        "yoy": null,
        "share": 69.0,
        "col1": 12946,
        "col2": 22178,
        "note": ""
      },
      "stage3_manual": {
        "cat": "申辦徵審流向",
        "name": "轉入人工審查總數",
        "value": 7416,
        "y_base": null,
        "unit": "件",
        "yoy": null,
        "share": 17.4,
        "col1": null,
        "col2": null,
        "note": ""
      }
    },
    "billing_center": {
      "total_bills": {
        "cat": "帳單中心核心",
        "name": "全行出帳總份數",
        "value": 531.5525,
        "y_base": null,
        "unit": "萬份",
        "yoy": null,
        "share": null,
        "col1": 323.6855,
        "col2": 207.867,
        "note": ""
      },
      "overall_erate": {
        "cat": "帳單中心核心",
        "name": "全行綜合電子化率",
        "value": 60.9,
        "y_base": null,
        "unit": "%",
        "yoy": null,
        "share": null,
        "col1": null,
        "col2": null,
        "note": ""
      },
      "delivery_rate": {
        "cat": "帳單中心核心",
        "name": "信用卡帳單有效投遞率",
        "value": null,
        "y_base": null,
        "unit": "%",
        "yoy": null,
        "share": null,
        "col1": null,
        "col2": null,
        "note": ""
      },
      "green_saving": {
        "cat": "帳單中心核心",
        "name": "綠色節能省費效益",
        "value": null,
        "y_base": null,
        "unit": "萬元",
        "yoy": null,
        "share": null,
        "col1": null,
        "col2": null,
        "note": ""
      },
      "track_card": {
        "cat": "雙軌帳單明細",
        "name": "信用卡帳單",
        "value": 468.6346,
        "y_base": null,
        "unit": "萬份",
        "yoy": null,
        "share": 67.93,
        "col1": 318.3245,
        "col2": 150.3101,
        "note": ""
      },
      "track_bank": {
        "cat": "雙軌帳單明細",
        "name": "銀行對帳單",
        "value": 62.9179,
        "y_base": null,
        "unit": "萬份",
        "yoy": null,
        "share": 8.52,
        "col1": 5.361,
        "col2": 57.5569,
        "note": ""
      },
      "track_notif": {
        "cat": "雙軌帳單明細",
        "name": "銀行通知函",
        "value": 2.37,
        "y_base": null,
        "unit": "萬份",
        "yoy": null,
        "share": 10.03,
        "col1": 0.2378,
        "col2": 2.1322,
        "note": ""
      }
    },
    "bonus_points": {
      "waterfall": [
        {
          "code": "bonus_wf_last_year",
          "name": "去年同月餘額",
          "value": 5705.94,
          "unit": "百萬點",
          "share": null,
          "color": "#64748b",
          "note": "獨立對比柱 (虛線)"
        },
        {
          "code": "bonus_wf_last_month",
          "name": "上月餘額",
          "value": 7194.028,
          "unit": "百萬點",
          "share": null,
          "color": "#003b5c",
          "note": "起點柱"
        },
        {
          "code": "bonus_wf_inc",
          "name": "本月新增",
          "value": 787.541,
          "unit": "百萬點",
          "share": null,
          "color": "#009e73",
          "note": "綠色上升"
        },
        {
          "code": "bonus_wf_grant",
          "name": "本月贈送",
          "value": 110.768,
          "unit": "百萬點",
          "share": null,
          "color": "#009e73",
          "note": "綠色上升"
        },
        {
          "code": "bonus_wf_redeem",
          "name": "本月兌換",
          "value": 639.34,
          "unit": "百萬點",
          "share": null,
          "color": "#b84a4a",
          "note": "紅色下降"
        },
        {
          "code": "bonus_wf_expire",
          "name": "本月失效",
          "value": 99.203,
          "unit": "百萬點",
          "share": null,
          "color": "#b84a4a",
          "note": "紅色下降"
        },
        {
          "code": "bonus_wf_total",
          "name": "本月累積餘額",
          "value": 7353.794,
          "unit": "百萬點",
          "share": null,
          "color": "#003b5c",
          "note": "終點柱"
        }
      ],
      "net_increase": 159.77,
      "channels": [
        {
          "code": "bonus_ch_instant",
          "name": "即時折抵",
          "value": 415.933,
          "unit": "百萬點",
          "share": 65.1,
          "color": "#4f46e5",
          "note": "排行第 1 名"
        },
        {
          "code": "bonus_ch_merge",
          "name": "合併用點",
          "value": 97.916,
          "unit": "百萬點",
          "share": 15.3,
          "color": "#6366f1",
          "note": "排行第 2 名"
        },
        {
          "code": "bonus_ch_mileage",
          "name": "里程兌換",
          "value": 80.204,
          "unit": "百萬點",
          "share": 12.5,
          "color": "#7c3aed",
          "note": "排行第 3 名"
        },
        {
          "code": "bonus_ch_merchant",
          "name": "商戶折抵",
          "value": 12.689,
          "unit": "百萬點",
          "share": 2.0,
          "color": "#8b5cf6",
          "note": "排行第 4 名"
        },
        {
          "code": "bonus_ch_other",
          "name": "其他折抵",
          "value": 32.598,
          "unit": "百萬點",
          "share": 5.1,
          "color": "#a1a1aa",
          "note": "排行第 5 名"
        }
      ],
      "total_redeem": 639.34
    },
    "installment_structure": {
      "products": [
        {
          "code": "inst_prod_auth",
          "name": "授權單筆分期",
          "amount": 6.66,
          "prev_month": null,
          "last_year": 5.528,
          "unit": "億元",
          "yoy": 20.5,
          "mom": null,
          "share": 35.7,
          "count": 5.6657,
          "prev_count": 6.3289,
          "last_year_count": 3.6318,
          "count_mom": -10.48,
          "count_yoy": 56.0,
          "avg_ticket": 11755.0,
          "color": "#003b5c",
          "note": ""
        },
        {
          "code": "inst_prod_settle",
          "name": "請款單筆分期",
          "amount": 4.0,
          "prev_month": null,
          "last_year": 6.776,
          "unit": "億元",
          "yoy": -41.0,
          "mom": null,
          "share": 21.4,
          "count": 3.4028,
          "prev_count": 3.8011,
          "last_year_count": 4.4512,
          "count_mom": -10.48,
          "count_yoy": -23.55,
          "avg_ticket": 11755.0,
          "color": "#2d6a8f",
          "note": ""
        },
        {
          "code": "inst_prod_bill",
          "name": "帳單分期",
          "amount": 8.01,
          "prev_month": 12.26,
          "last_year": 9.904,
          "unit": "億元",
          "yoy": -19.1,
          "mom": -34.67,
          "share": 42.9,
          "count": 2.9164,
          "prev_count": 4.19,
          "last_year_count": 3.7985,
          "count_mom": -30.4,
          "count_yoy": -23.22,
          "avg_ticket": 27465.0,
          "color": "#588ea8",
          "note": ""
        },
        {
          "code": "inst_prod_mcht",
          "name": "特店分期",
          "amount": null,
          "prev_month": null,
          "last_year": null,
          "unit": "億元",
          "yoy": null,
          "mom": null,
          "share": null,
          "count": null,
          "prev_count": null,
          "last_year_count": null,
          "count_mom": null,
          "count_yoy": null,
          "avg_ticket": null,
          "color": "#0f766e",
          "note": ""
        }
      ]
    },
    "collection_asset": {
      "m1_defense": {
        "col_m1_entry": {
          "name": "M1當期進案",
          "value": null,
          "unit": "億元",
          "count": null,
          "note": ""
        },
        "col_cure_rate": {
          "name": "催收回復正常率",
          "value": null,
          "unit": "%",
          "count": null,
          "note": ""
        },
        "col_to_m2": {
          "name": "轉入M2催收流程",
          "value": null,
          "unit": "%",
          "count": null,
          "note": ""
        }
      },
      "aging_buckets": [
        {
          "code": "aging_m1",
          "name": "M1 (1–30天)",
          "amount": null,
          "unit": "億元",
          "share": null,
          "count": null,
          "rec_ratio": null,
          "color": "#003b5c",
          "note": ""
        },
        {
          "code": "aging_m2",
          "name": "M2 (31–60天)",
          "amount": null,
          "unit": "億元",
          "share": null,
          "count": null,
          "rec_ratio": null,
          "color": "#c9892e",
          "note": ""
        },
        {
          "code": "aging_m3",
          "name": "M3+ (61天以上)",
          "amount": null,
          "unit": "億元",
          "share": null,
          "count": null,
          "rec_ratio": null,
          "color": "#b84a4a",
          "note": ""
        }
      ],
      "loss_settlement": {
        "loss_writeoff": {
          "name": "當月轉銷呆帳 (損)",
          "value": null,
          "unit": "億元",
          "note": ""
        },
        "loss_recovery": {
          "name": "當月呆帳回收 (益)",
          "value": null,
          "unit": "億元",
          "note": ""
        },
        "loss_net": {
          "name": "當月淨信用損失",
          "value": null,
          "unit": "億元",
          "note": ""
        }
      }
    }
  },
  "block04": {
    "section_title": "系統韌性",
    "section_num": "04",
    "monthly_kpis": {
      "sys_cardpool_resp": {
        "dimension": "CardPool授權主機",
        "name": "交易響應時間",
        "value": null,
        "unit": "ms",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "可用率 99.999%",
        "sub2": "SLA 100% 達標"
      },
      "sys_cardpool_vol": {
        "dimension": "CardPool授權主機",
        "name": "月授權交易量",
        "value": null,
        "unit": "萬筆",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": 0,
        "sub2": "< 120ms"
      },
      "sys_cardpool_succ": {
        "dimension": "CardPool授權主機",
        "name": "授權成功率",
        "value": null,
        "unit": "%",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "99.999%",
        "sub2": "744 小時"
      },
      "sys_cardlink_vol": {
        "dimension": "Cardlink核心帳務",
        "name": "月帳務處理量",
        "value": null,
        "unit": "億筆",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "100.0%",
        "sub2": "4,850 TPS"
      },
      "sys_cardlink_avail": {
        "dimension": "Cardlink核心帳務",
        "name": "系統可用率",
        "value": null,
        "unit": "%",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "100.0%",
        "sub2": "4,850 TPS"
      },
      "sys_cardlink_tps": {
        "dimension": "Cardlink核心帳務",
        "name": "瞬時處理峰值",
        "value": null,
        "unit": "TPS",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "100.0%",
        "sub2": null
      },
      "sys_cardlink_batch_time": {
        "dimension": "Cardlink核心帳務",
        "name": "批次作業完成時間",
        "value": null,
        "unit": "時間",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "100%",
        "sub2": "40 分鐘"
      },
      "sys_cardlink_batch_limit": {
        "dimension": "Cardlink核心帳務",
        "name": "排程窗口上限時間",
        "value": null,
        "unit": "時間",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "安全裕度足",
        "sub2": "40 分鐘"
      },
      "sys_cardlink_batch_accounts": {
        "dimension": "Cardlink核心帳務",
        "name": "日均處理帳單戶數",
        "value": null,
        "unit": "萬戶",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "100.0%",
        "sub2": "零延宕"
      },
      "sys_fraud_total_amt": {
        "dimension": "全行防詐防堵",
        "name": "全月總防堵金額",
        "value": 9482.0,
        "unit": "萬元",
        "last_year": null,
        "prev_month": 10970.0,
        "yoy": null,
        "mom": -13.56,
        "note": "",
        "sub1": 2684,
        "sub2": null
      },
      "sys_fraud_total_cnt": {
        "dimension": "全行防詐防堵",
        "name": "總阻斷冒用卡數",
        "value": 5858.0,
        "unit": "張",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": 4280,
        "sub2": null
      }
    },
    "cloud_events": [
      {
        "code": "ev_1",
        "date": "2026/06/18 (週四)",
        "name": "蝦皮618 年中慶",
        "peak_time": "00:00–00:10",
        "spec": "28 vCPU",
        "peak_tps": 251.0,
        "cpu_load": 84.1,
        "note": "超出 80% 安全閾值，出現明顯運算壓力"
      },
      {
        "code": "ev_2",
        "date": "2026/07/07 (週二)",
        "name": "蝦皮77 購物節",
        "peak_time": "00:00–00:10",
        "spec": "16 vCPU",
        "peak_tps": 115.0,
        "cpu_load": 60.74,
        "note": "安全範圍內，無明顯壓力"
      },
      {
        "code": "ev_3",
        "date": "2026/07/18 (週六)",
        "name": "蝦皮718 會員日",
        "peak_time": "00:00–00:10",
        "spec": "16 vCPU",
        "peak_tps": 94.0,
        "cpu_load": 48.5,
        "note": "安全範圍內，無明顯壓力"
      },
      {
        "code": "ev_4",
        "date": "2026/07/25 (週六)",
        "name": "蝦皮725 狂購節",
        "peak_time": "00:00–00:10",
        "spec": "16 vCPU",
        "peak_tps": 71.0,
        "cpu_load": 45.44,
        "note": "安全範圍內，無明顯壓力"
      },
      {
        "code": "ev_5",
        "date": "2026/08/08 (週六)",
        "name": "蝦皮88 父親節 / 年中大促",
        "peak_time": "00:00–00:10",
        "spec": "16 vCPU",
        "peak_tps": 178.0,
        "cpu_load": 83.33,
        "note": "超出 80% 安全閾值，出現明顯運算壓力"
      },
      {
        "code": "ev_6",
        "date": "2026/08/18 (週二)",
        "name": "蝦皮818 會員日",
        "peak_time": "00:00–00:10",
        "spec": "16 vCPU",
        "peak_tps": 143.0,
        "cpu_load": 85.86,
        "note": "超出 80% 安全閾值，出現明顯運算壓力"
      },
      {
        "code": "ev_7",
        "date": "2026/08/25 (週二)",
        "name": "蝦皮825 商城狂購節",
        "peak_time": "00:00–00:10",
        "spec": "16 vCPU",
        "peak_tps": 114.0,
        "cpu_load": 59.08,
        "note": "安全範圍內，無明顯壓力"
      },
      {
        "code": "ev_8",
        "date": "2026/09/09 (週三)",
        "name": "蝦皮99 超級購物節",
        "peak_time": "00:00–00:10",
        "spec": "24 vCPU",
        "peak_tps": 238.0,
        "cpu_load": 29.84,
        "note": "安全範圍內，無明顯壓力"
      }
    ],
    "fraud_defense": {
      "channels": [
        {
          "code": "fraud_sfm_tx",
          "system": "SFM",
          "name": "SFM 交易詐欺防堵",
          "amount": 6155.0,
          "unit": "萬元",
          "last_year": null,
          "prev_month": 6027.0,
          "yoy": null,
          "mom": 2.12,
          "share": 64.9,
          "count": 5434.0,
          "prev_count": null,
          "count_mom": null,
          "avg_per_card": 1.13,
          "color": "#003b5c",
          "note": ""
        },
        {
          "code": "fraud_sfm_apply",
          "system": "SFM",
          "name": "SFM 申請詐欺防堵",
          "amount": 3070.0,
          "unit": "萬元",
          "last_year": null,
          "prev_month": 3583.0,
          "yoy": null,
          "mom": -14.32,
          "share": 32.4,
          "count": 195.0,
          "prev_count": null,
          "count_mom": null,
          "avg_per_card": 15.74,
          "color": "#2d6a8f",
          "note": ""
        },
        {
          "code": "fraud_3ds_online",
          "system": "3DS",
          "name": "3DS 系統防堵",
          "amount": 257.0,
          "unit": "萬元",
          "last_year": null,
          "prev_month": 1360.0,
          "yoy": null,
          "mom": -81.1,
          "share": 2.7,
          "count": 229.0,
          "prev_count": null,
          "count_mom": null,
          "avg_per_card": 1.12,
          "color": "#588ea8",
          "note": ""
        }
      ],
      "total": {
        "name": "全行防詐防堵合計",
        "amount": 9482.0,
        "count": 5858.0,
        "avg_per_card": 1.62,
        "share": 100.0,
        "unit": "萬元"
      },
      "subtotals": {
        "sfm": {
          "amount": 9225.0,
          "count": 5629.0
        },
        "tds": {
          "amount": 257.0,
          "count": 229.0
        }
      }
    },
    "microservices": {
      "services": [
        {
          "code": "ms_bonus_query",
          "name": "小樹點查詢",
          "calls": 11516.57,
          "unit": "萬次",
          "last_year": 10577.34,
          "prev_month": 11299.13,
          "yoy": 8.88,
          "mom": 1.92,
          "peak_tps": 670.0,
          "capacity_tps": null,
          "capacity_ratio": null,
          "color": "#009e73",
          "note": ""
        },
        {
          "code": "ms_reward_overview",
          "name": "回饋總覽",
          "calls": 996.37,
          "unit": "萬次",
          "last_year": 958.79,
          "prev_month": 1005.23,
          "yoy": 3.92,
          "mom": -0.88,
          "peak_tps": 92.0,
          "capacity_tps": null,
          "capacity_ratio": null,
          "color": "#003b5c",
          "note": ""
        },
        {
          "code": "ms_bonus_redeem",
          "name": "小樹點兌換",
          "calls": 210.94,
          "unit": "萬次",
          "last_year": 202.6,
          "prev_month": 204.7,
          "yoy": 4.12,
          "mom": 3.05,
          "peak_tps": 34.0,
          "capacity_tps": null,
          "capacity_ratio": null,
          "color": "#c9892e",
          "note": ""
        },
        {
          "code": "ms_ticket_service",
          "name": "票券服務",
          "calls": 23.39,
          "unit": "萬次",
          "last_year": null,
          "prev_month": 22.0,
          "yoy": null,
          "mom": 6.32,
          "peak_tps": 1217.0,
          "capacity_tps": null,
          "capacity_ratio": null,
          "color": "#7c4dff",
          "note": ""
        }
      ]
    }
  },
  "diagnostic_analyses": {
    "peer_benchmark_spend": {
      "module": "01 全行概況",
      "code": "peer_benchmark_spend",
      "position": "同業經營比較-消費經營",
      "analysis": "分析：2026 年前 8 月五大發卡行簽帳總額達 2.45 兆元（年增 18.5%），本行以 5,726 億元穩居市場第二（市占率 23.3%、年增 17.1%），持續鞏固刷卡基本盤；面對中信（市占 26.3%）與台新（年增 22.7%）積極搶攻市占，後續應深化主力 CUBE 卡分群權益切換與高動能場景促刷，拉大對後進者的領先差距。",
      "note": "01全行概況-同業YTD簽帳金額經營比較"
    },
    "同業經營比較-消費經營": {
      "module": "01 全行概況",
      "code": "peer_benchmark_spend",
      "position": "同業經營比較-消費經營",
      "analysis": "分析：2026 年前 8 月五大發卡行簽帳總額達 2.45 兆元（年增 18.5%），本行以 5,726 億元穩居市場第二（市占率 23.3%、年增 17.1%），持續鞏固刷卡基本盤；面對中信（市占 26.3%）與台新（年增 22.7%）積極搶攻市占，後續應深化主力 CUBE 卡分群權益切換與高動能場景促刷，拉大對後進者的領先差距。",
      "note": "01全行概況-同業YTD簽帳金額經營比較"
    },
    "peer_benchmark_spend_text": "分析：2026 年前 8 月五大發卡行簽帳總額達 2.45 兆元（年增 18.5%），本行以 5,726 億元穩居市場第二（市占率 23.3%、年增 17.1%），持續鞏固刷卡基本盤；面對中信（市占 26.3%）與台新（年增 22.7%）積極搶攻市占，後續應深化主力 CUBE 卡分群權益切換與高動能場景促刷，拉大對後進者的領先差距。",
    "peer_benchmark_cards": {
      "module": "01 全行概況",
      "code": "peer_benchmark_cards",
      "position": "同業經營比較-卡量經營",
      "analysis": "分析：本行有效卡數達 511.9 萬張穩居市場前三，活卡率 70.54% 逆勢年增 +0.31pp，優於台新（71.9% 年減 1.67pp）與玉山（65.2%）且與首位中信齊平；在發卡市場進入存量整併期下，本行採取清呆活化策略奏效，流通卡結構精實且持卡客群維持高頻動用體質。",
      "note": "01全行概況-同業流通卡/有效卡/活卡率分析"
    },
    "同業經營比較-卡量經營": {
      "module": "01 全行概況",
      "code": "peer_benchmark_cards",
      "position": "同業經營比較-卡量經營",
      "analysis": "分析：本行有效卡數達 511.9 萬張穩居市場前三，活卡率 70.54% 逆勢年增 +0.31pp，優於台新（71.9% 年減 1.67pp）與玉山（65.2%）且與首位中信齊平；在發卡市場進入存量整併期下，本行採取清呆活化策略奏效，流通卡結構精實且持卡客群維持高頻動用體質。",
      "note": "01全行概況-同業流通卡/有效卡/活卡率分析"
    },
    "peer_benchmark_cards_text": "分析：本行有效卡數達 511.9 萬張穩居市場前三，活卡率 70.54% 逆勢年增 +0.31pp，優於台新（71.9% 年減 1.67pp）與玉山（65.2%）且與首位中信齊平；在發卡市場進入存量整併期下，本行採取清呆活化策略奏效，流通卡結構精實且持卡客群維持高頻動用體質。",
    "peer_benchmark_credit": {
      "module": "01 全行概況",
      "code": "peer_benchmark_credit",
      "position": "同業經營比較-信用業務",
      "analysis": "分析：本行在生息資產端展現強大市場統治力，循環信用餘額 225.3 億元（年增 4.8%）與未到期分期餘額 462.0 億元（年增 10.2%）雙雙拔得市場頭籌；高資產規模伴隨穩健授信風控，持續為全行信用卡業務貢獻優質且穩定的利息收益底盤。",
      "note": "01全行概況-同業循環信用餘額與分期餘額比較"
    },
    "同業經營比較-信用業務": {
      "module": "01 全行概況",
      "code": "peer_benchmark_credit",
      "position": "同業經營比較-信用業務",
      "analysis": "分析：本行在生息資產端展現強大市場統治力，循環信用餘額 225.3 億元（年增 4.8%）與未到期分期餘額 462.0 億元（年增 10.2%）雙雙拔得市場頭籌；高資產規模伴隨穩健授信風控，持續為全行信用卡業務貢獻優質且穩定的利息收益底盤。",
      "note": "01全行概況-同業循環信用餘額與分期餘額比較"
    },
    "peer_benchmark_credit_text": "分析：本行在生息資產端展現強大市場統治力，循環信用餘額 225.3 億元（年增 4.8%）與未到期分期餘額 462.0 億元（年增 10.2%）雙雙拔得市場頭籌；高資產規模伴隨穩健授信風控，持續為全行信用卡業務貢獻優質且穩定的利息收益底盤。",
    "acq_diag_channels": {
      "module": "02 收單業務",
      "code": "acq_diag_channels",
      "position": "收單深入診斷-交易通路分析",
      "analysis": "分析：線上收單金額以「EPOS-地端」為營收主力（佔比 56.9%、平均客單 164 元），承載較高客單價商戶；「EPOS-雲端」與「Payment Hub 掃碼」則展現高頻民生小額特色（合計筆數突破 1,000 萬筆），三軌通路分工明確，全面覆蓋大額支付與高頻微額交易場景。",
      "note": "02收單業務-TAB 0 交易通路分析 (EPOS雲地端+PH掃碼)"
    },
    "收單深入診斷-交易通路分析": {
      "module": "02 收單業務",
      "code": "acq_diag_channels",
      "position": "收單深入診斷-交易通路分析",
      "analysis": "分析：線上收單金額以「EPOS-地端」為營收主力（佔比 56.9%、平均客單 164 元），承載較高客單價商戶；「EPOS-雲端」與「Payment Hub 掃碼」則展現高頻民生小額特色（合計筆數突破 1,000 萬筆），三軌通路分工明確，全面覆蓋大額支付與高頻微額交易場景。",
      "note": "02收單業務-TAB 0 交易通路分析 (EPOS雲地端+PH掃碼)"
    },
    "acq_diag_channels_text": "分析：線上收單金額以「EPOS-地端」為營收主力（佔比 56.9%、平均客單 164 元），承載較高客單價商戶；「EPOS-雲端」與「Payment Hub 掃碼」則展現高頻民生小額特色（合計筆數突破 1,000 萬筆），三軌通路分工明確，全面覆蓋大額支付與高頻微額交易場景。",
    "acq_diag_twqr": {
      "module": "02 收單業務",
      "code": "acq_diag_twqr",
      "position": "收單深入診斷-TWQR業務推展",
      "analysis": "分析：TWQR 業務處於早期場景普及與鋪路階段，累計特店家數已達 256 家（月增 11.3%）；隨核心商戶陸續開通，單月交易金額暴增 262.9% 突破 13 萬元、交易筆數月增 38.2%，平均客單價達 656 元，反映跨機構共通 QR 碼已開始在具實質消費力的微型商家發揮動能。",
      "note": "02收單業務-TWQR業務推展與交易動能專區"
    },
    "收單深入診斷-TWQR業務推展": {
      "module": "02 收單業務",
      "code": "acq_diag_twqr",
      "position": "收單深入診斷-TWQR業務推展",
      "analysis": "分析：TWQR 業務處於早期場景普及與鋪路階段，累計特店家數已達 256 家（月增 11.3%）；隨核心商戶陸續開通，單月交易金額暴增 262.9% 突破 13 萬元、交易筆數月增 38.2%，平均客單價達 656 元，反映跨機構共通 QR 碼已開始在具實質消費力的微型商家發揮動能。",
      "note": "02收單業務-TWQR業務推展與交易動能專區"
    },
    "acq_diag_twqr_text": "分析：TWQR 業務處於早期場景普及與鋪路階段，累計特店家數已達 256 家（月增 11.3%）；隨核心商戶陸續開通，單月交易金額暴增 262.9% 突破 13 萬元、交易筆數月增 38.2%，平均客單價達 656 元，反映跨機構共通 QR 碼已開始在具實質消費力的微型商家發揮動能。",
    "iss_diag_approval": {
      "module": "03 發卡業務",
      "code": "iss_diag_approval",
      "position": "發卡深入診斷-申辦自動徵審分析",
      "analysis": "分析：發卡進件全面無紙化（數位進件佔比 93.2%），自動化徵審中樞達到 83.5% 高自動化審查率；自動直接核准率高達 69.0%（舊戶自動核准率達 96.9%、新戶達 78.1%），大幅壓縮審查時效，轉人工僅 17.4%，展現科技賦能下極致的徵審營運效能。",
      "note": "03發卡業務-TAB 0 申辦自動徵審分析"
    },
    "發卡深入診斷-申辦自動徵審分析": {
      "module": "03 發卡業務",
      "code": "iss_diag_approval",
      "position": "發卡深入診斷-申辦自動徵審分析",
      "analysis": "分析：發卡進件全面無紙化（數位進件佔比 93.2%），自動化徵審中樞達到 83.5% 高自動化審查率；自動直接核准率高達 69.0%（舊戶自動核准率達 96.9%、新戶達 78.1%），大幅壓縮審查時效，轉人工僅 17.4%，展現科技賦能下極致的徵審營運效能。",
      "note": "03發卡業務-TAB 0 申辦自動徵審分析"
    },
    "iss_diag_approval_text": "分析：發卡進件全面無紙化（數位進件佔比 93.2%），自動化徵審中樞達到 83.5% 高自動化審查率；自動直接核准率高達 69.0%（舊戶自動核准率達 96.9%、新戶達 78.1%），大幅壓縮審查時效，轉人工僅 17.4%，展現科技賦能下極致的徵審營運效能。",
    "iss_diag_billing": {
      "module": "03 發卡業務",
      "code": "iss_diag_billing",
      "position": "發卡深入診斷-帳單列印中心",
      "analysis": "分析：全行出帳總量達 531.6 萬份，其中佔量 88% 的信用卡帳單電子化滲透率已提升至 67.93%（達 318.3 萬份），有效抑制實體印製郵寄成本；銀行端帳單與通知函電子化率仍處於個位數至一成初，具備高度綠色數位化轉化潛力。",
      "note": "03發卡業務-TAB 1 帳單列印中心雙軌明細"
    },
    "發卡深入診斷-帳單列印中心": {
      "module": "03 發卡業務",
      "code": "iss_diag_billing",
      "position": "發卡深入診斷-帳單列印中心",
      "analysis": "分析：全行出帳總量達 531.6 萬份，其中佔量 88% 的信用卡帳單電子化滲透率已提升至 67.93%（達 318.3 萬份），有效抑制實體印製郵寄成本；銀行端帳單與通知函電子化率仍處於個位數至一成初，具備高度綠色數位化轉化潛力。",
      "note": "03發卡業務-TAB 1 帳單列印中心雙軌明細"
    },
    "iss_diag_billing_text": "分析：全行出帳總量達 531.6 萬份，其中佔量 88% 的信用卡帳單電子化滲透率已提升至 67.93%（達 318.3 萬份），有效抑制實體印製郵寄成本；銀行端帳單與通知函電子化率仍處於個位數至一成初，具備高度綠色數位化轉化潛力。",
    "iss_diag_bonus": {
      "module": "03 發卡業務",
      "code": "iss_diag_bonus",
      "position": "發卡深入診斷-小樹點經營與折抵通路",
      "analysis": "分析：小樹點流通池維持健康良性擴張（餘額年增 28.9% 達 73.5 億點），且單月兌換率高達 71.2%，活絡度顯著；折抵通路高度聚焦於「即時折抵」（佔 65.1%）與「合併用點」（佔 15.3%），顯示點數深度融入持卡人每日消費折抵，形成高黏著度的數位生態閉環。",
      "note": "03發卡業務-TAB 2 小樹點經營7柱水庫與五大折抵通路"
    },
    "發卡深入診斷-小樹點經營與折抵通路": {
      "module": "03 發卡業務",
      "code": "iss_diag_bonus",
      "position": "發卡深入診斷-小樹點經營與折抵通路",
      "analysis": "分析：小樹點流通池維持健康良性擴張（餘額年增 28.9% 達 73.5 億點），且單月兌換率高達 71.2%，活絡度顯著；折抵通路高度聚焦於「即時折抵」（佔 65.1%）與「合併用點」（佔 15.3%），顯示點數深度融入持卡人每日消費折抵，形成高黏著度的數位生態閉環。",
      "note": "03發卡業務-TAB 2 小樹點經營7柱水庫與五大折抵通路"
    },
    "iss_diag_bonus_text": "分析：小樹點流通池維持健康良性擴張（餘額年增 28.9% 達 73.5 億點），且單月兌換率高達 71.2%，活絡度顯著；折抵通路高度聚焦於「即時折抵」（佔 65.1%）與「合併用點」（佔 15.3%），顯示點數深度融入持卡人每日消費折抵，形成高黏著度的數位生態閉環。",
    "iss_diag_fraud": {
      "module": "03 發卡業務",
      "code": "iss_diag_fraud",
      "position": "發卡深入診斷-SFM與3DS防詐成效",
      "analysis": "分析：全月阻斷冒用卡數達 5,858 張、保全資產 9,482 萬元，以 SFM 交易詐欺為第一道即時攔阻主力（佔 64.9%）；特別是 SFM 申請詐欺每卡平均阻斷高達 15.74 萬元，成功於前端進件源頭精準阻截高額組織型偽冒申辦，有效遏阻重大信用損失。",
      "note": "03發卡業務-TAB 3 SFM 3DS防詐防堵成效分析"
    },
    "發卡深入診斷-SFM與3DS防詐成效": {
      "module": "03 發卡業務",
      "code": "iss_diag_fraud",
      "position": "發卡深入診斷-SFM與3DS防詐成效",
      "analysis": "分析：全月阻斷冒用卡數達 5,858 張、保全資產 9,482 萬元，以 SFM 交易詐欺為第一道即時攔阻主力（佔 64.9%）；特別是 SFM 申請詐欺每卡平均阻斷高達 15.74 萬元，成功於前端進件源頭精準阻截高額組織型偽冒申辦，有效遏阻重大信用損失。",
      "note": "03發卡業務-TAB 3 SFM 3DS防詐防堵成效分析"
    },
    "iss_diag_fraud_text": "分析：全月阻斷冒用卡數達 5,858 張、保全資產 9,482 萬元，以 SFM 交易詐欺為第一道即時攔阻主力（佔 64.9%）；特別是 SFM 申請詐欺每卡平均阻斷高達 15.74 萬元，成功於前端進件源頭精準阻截高額組織型偽冒申辦，有效遏阻重大信用損失。",
    "iss_diag_installment": {
      "module": "03 發卡業務",
      "code": "iss_diag_installment",
      "position": "發卡深入診斷-分期產品結構分析",
      "analysis": "分析：客戶分期行為呈現明確的「單筆消費即時處置」轉移趨勢（單筆筆數佔比升至 75.7%、金額佔比達 57.1%），整期帳單分期逐期收縮；其中「授權單筆」在筆數（佔單筆 62.5%）與金額（年增 +20.5%）皆為絕對核心，為當前分期業務最強勁的成長驅動力。",
      "note": "03發卡業務-TAB 4 分期產品結構分析 (客戶偏好 vs 營收結構)"
    },
    "發卡深入診斷-分期產品結構分析": {
      "module": "03 發卡業務",
      "code": "iss_diag_installment",
      "position": "發卡深入診斷-分期產品結構分析",
      "analysis": "分析：客戶分期行為呈現明確的「單筆消費即時處置」轉移趨勢（單筆筆數佔比升至 75.7%、金額佔比達 57.1%），整期帳單分期逐期收縮；其中「授權單筆」在筆數（佔單筆 62.5%）與金額（年增 +20.5%）皆為絕對核心，為當前分期業務最強勁的成長驅動力。",
      "note": "03發卡業務-TAB 4 分期產品結構分析 (客戶偏好 vs 營收結構)"
    },
    "iss_diag_installment_text": "分析：客戶分期行為呈現明確的「單筆消費即時處置」轉移趨勢（單筆筆數佔比升至 75.7%、金額佔比達 57.1%），整期帳單分期逐期收縮；其中「授權單筆」在筆數（佔單筆 62.5%）與金額（年增 +20.5%）皆為絕對核心，為當前分期業務最強勁的成長驅動力。",
    "res_diag_cloud_events": {
      "module": "04 系統韌性",
      "code": "res_diag_cloud_events",
      "position": "系統韌性深入診斷-活動日EPOS雲端監控",
      "analysis": "分析：監控 618 至 99 等大型電商促銷，8 月份 88 節與 818 會員日因瞬間峰值湧入，CPU 負載一度突破 80% 運算預警線；經 99 大促彈性擴容至 24 vCPU 後，峰值 TPS 達 238 筆但 CPU 負載大幅降至 29.8%，展現雲端架構動態伸縮彈性與高可用承載力。",
      "note": "04系統韌性-TAB 0 活動日EPOS雲端服務監控數據"
    },
    "系統韌性深入診斷-活動日EPOS雲端監控": {
      "module": "04 系統韌性",
      "code": "res_diag_cloud_events",
      "position": "系統韌性深入診斷-活動日EPOS雲端監控",
      "analysis": "分析：監控 618 至 99 等大型電商促銷，8 月份 88 節與 818 會員日因瞬間峰值湧入，CPU 負載一度突破 80% 運算預警線；經 99 大促彈性擴容至 24 vCPU 後，峰值 TPS 達 238 筆但 CPU 負載大幅降至 29.8%，展現雲端架構動態伸縮彈性與高可用承載力。",
      "note": "04系統韌性-TAB 0 活動日EPOS雲端服務監控數據"
    },
    "res_diag_cloud_events_text": "分析：監控 618 至 99 等大型電商促銷，8 月份 88 節與 818 會員日因瞬間峰值湧入，CPU 負載一度突破 80% 運算預警線；經 99 大促彈性擴容至 24 vCPU 後，峰值 TPS 達 238 筆但 CPU 負載大幅降至 29.8%，展現雲端架構動態伸縮彈性與高可用承載力。",
    "res_diag_bonus_microservices": {
      "module": "04 系統韌性",
      "code": "res_diag_bonus_microservices",
      "position": "系統韌性深入診斷-紅利平台服務量能監控",
      "analysis": "分析：紅利平台四大微服務架構運作平穩，「小樹點查詢」單月調用量突破 1.15 億次（年增 8.9%），為高頻基石服務；「票券服務」於搶券搶點期間瞬時迸發達 1,217 TPS，微服務架構有效隔離高併發流量，確保核心紅利查詢與折抵服務 100% 零中斷。",
      "note": "04系統韌性-TAB 1 紅利平台四大微服務量能矩陣"
    },
    "系統韌性深入診斷-紅利平台服務量能監控": {
      "module": "04 系統韌性",
      "code": "res_diag_bonus_microservices",
      "position": "系統韌性深入診斷-紅利平台服務量能監控",
      "analysis": "分析：紅利平台四大微服務架構運作平穩，「小樹點查詢」單月調用量突破 1.15 億次（年增 8.9%），為高頻基石服務；「票券服務」於搶券搶點期間瞬時迸發達 1,217 TPS，微服務架構有效隔離高併發流量，確保核心紅利查詢與折抵服務 100% 零中斷。",
      "note": "04系統韌性-TAB 1 紅利平台四大微服務量能矩陣"
    },
    "res_diag_bonus_microservices_text": "分析：紅利平台四大微服務架構運作平穩，「小樹點查詢」單月調用量突破 1.15 億次（年增 8.9%），為高頻基石服務；「票券服務」於搶券搶點期間瞬時迸發達 1,217 TPS，微服務架構有效隔離高併發流量，確保核心紅利查詢與折抵服務 100% 零中斷。"
  }
};
