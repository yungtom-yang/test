# 00_交接文件 (Project Handover Documentation)

本資料夾為本專案跨電腦開發與接續維護之專用入口。

## 檔案說明
- **[`PROJECT_HANDOVER_CONTEXT.md`](./PROJECT_HANDOVER_CONTEXT.md)**：專案全景交接總綱（含五大維護鐵律、歷史決策演進、00戰情總覽三本柱架構、02收單業務改裝盤點、14張工作表規格、一鍵喚醒 Prompt）。

## 快速使用方式
當在新電腦執行 Antigravity AI 時，請直接複製 `PROJECT_HANDOVER_CONTEXT.md` 第七節（§七）的「一鍵喚醒 Prompt」發送給 AI 即可無縫接續！

