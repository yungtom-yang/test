@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 正在開啟 國泰世華銀行 信用卡暨支付維運全景儀表板...
start "" "%~dp001_儀表板執行環境\credit_card_full_dashboard.html"
