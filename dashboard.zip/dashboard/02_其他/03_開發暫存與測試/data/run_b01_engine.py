# -*- coding: utf-8 -*-
"""
Block 01 數據計算與盤點引擎 (run_b01_engine.py)
功能：
  1. 盤點檢查 (audit): 檢查特定月份是否所有指標皆已填報，有無遺漏。
  2. 計算與產出 (calc): 自動計算 YoY、MoM、佔比、總計，輸出前端儀表板所需的標準結構。
"""

import csv
import os
import sys
import json

if sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REGISTRY_FILE = os.path.join(SCRIPT_DIR, 'dim_metric_registry_b01.csv')
DATA_FILE = os.path.join(SCRIPT_DIR, 'fact_monthly_data_b01.csv')

def load_registry():
    registry = {}
    with open(REGISTRY_FILE, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            registry[row['metric_id']] = row
    return registry

def load_data():
    # month -> { metric_id -> { 'val': float, 'hint': str, 'user': str } }
    data = {}
    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = row['data_month'].strip()
            mid = row['metric_id'].strip()
            val = float(row['metric_value'].strip())
            hint = row.get('hint_note', '').strip()
            user = row.get('updated_by', '').strip()
            if m not in data:
                data[m] = {}
            data[m][mid] = {'val': val, 'hint': hint, 'user': user}
    return data

def audit_month(target_month='2026-08'):
    registry = load_registry()
    data = load_data()
    
    print(f"\n=======================================================")
    print(f"🔍 數據健康體檢與盤點報告：【{target_month}】")
    print(f"=======================================================")
    
    month_data = data.get(target_month, {})
    missing = []
    ready = []
    
    for mid, meta in registry.items():
        if mid in month_data:
            ready.append((mid, meta, month_data[mid]))
        else:
            missing.append((mid, meta))
            
    print(f"📊 應填報指標總數：{len(registry)} 項")
    print(f"✅ 已填報完成：{len(ready)} 項")
    print(f"❌ 缺失未填報：{len(missing)} 項")
    print("-------------------------------------------------------")
    
    if missing:
        print("⚠️ 以下指標尚未填報，請聯繫負責單位補件：")
        for mid, meta in missing:
            print(f"  • [{mid}] {meta['metric_name']} - {meta['dimension']} (負責窗口: {meta['responsible_dept']})")
    else:
        print("🎉 恭喜！本月所有指標 100% 齊全，可以一鍵生成儀表板數據！")
        
    return len(missing) == 0

def calc_growth(cur, prev):
    if prev is None or prev == 0:
        return 0.0
    return round(((cur - prev) / prev) * 100, 1)

def calc_diff(cur, prev):
    if prev is None:
        return 0.0
    return round(cur - prev, 1)

def get_val(data, m, mid):
    return data.get(m, {}).get(mid, {}).get('val', None)

def process_block01(target_month='2026-08'):
    data = load_data()
    # Determine prior month & prior year
    year, month = map(int, target_month.split('-'))
    prior_year_month = f"{year - 1:04d}-{month:02d}"
    
    if month == 1:
        prior_month = f"{year - 1:04d}-12"
    else:
        prior_month = f"{year:04d}-{month - 1:02d}"
        
    print(f"\n⚙️ 正在計算 {target_month} 數據（對比前期: {prior_month}，去年同期: {prior_year_month}）...\n")
    
    # 1. 總交易金額
    gen_amt = get_val(data, target_month, 'B01_TXN_AMT_GEN')
    inst_amt = get_val(data, target_month, 'B01_TXN_AMT_INST')
    tot_amt = gen_amt + inst_amt if gen_amt and inst_amt else 0
    
    # Prior year & month for amt
    py_tot_amt = (get_val(data, prior_year_month, 'B01_TXN_AMT_GEN') or 0) + (get_val(data, prior_year_month, 'B01_TXN_AMT_INST') or 0)
    pm_tot_amt = (get_val(data, prior_month, 'B01_TXN_AMT_GEN') or 0) + (get_val(data, prior_month, 'B01_TXN_AMT_INST') or 0)
    
    amt_yoy = calc_growth(tot_amt, py_tot_amt)
    amt_mom = calc_growth(tot_amt, pm_tot_amt)
    gen_share = round((gen_amt / tot_amt) * 100, 1) if tot_amt else 0
    inst_share = round((inst_amt / tot_amt) * 100, 1) if tot_amt else 0
    
    # 2. 總交易筆數
    gen_cnt = get_val(data, target_month, 'B01_TXN_CNT_GEN')
    inst_cnt = get_val(data, target_month, 'B01_TXN_CNT_INST')
    tot_cnt = gen_cnt + inst_cnt if gen_cnt and inst_cnt else 0
    
    py_tot_cnt = (get_val(data, prior_year_month, 'B01_TXN_CNT_GEN') or 0) + (get_val(data, prior_year_month, 'B01_TXN_CNT_INST') or 0)
    pm_tot_cnt = (get_val(data, prior_month, 'B01_TXN_CNT_GEN') or 0) + (get_val(data, prior_month, 'B01_TXN_CNT_INST') or 0)
    
    cnt_yoy = calc_growth(tot_cnt, py_tot_cnt)
    cnt_mom = calc_growth(tot_cnt, pm_tot_cnt)
    gen_cnt_share = round((gen_cnt / tot_cnt) * 100, 1) if tot_cnt else 0
    inst_cnt_share = round((inst_cnt / tot_cnt) * 100, 1) if tot_cnt else 0
    
    # 3. 活卡經營
    act_cards = get_val(data, target_month, 'B01_ACTIVE_CARDS') or 0
    iss_cards = get_val(data, target_month, 'B01_ISSUED_CARDS') or 0
    active_rate = round((act_cards / iss_cards) * 100, 1) if iss_cards else 0
    
    py_act_cards = get_val(data, prior_year_month, 'B01_ACTIVE_CARDS') or 0
    py_iss_cards = get_val(data, prior_year_month, 'B01_ISSUED_CARDS') or 0
    py_rate = round((py_act_cards / py_iss_cards) * 100, 1) if py_iss_cards else 0
    rate_yoy_diff = calc_diff(active_rate, py_rate)
    
    pm_act_cards = get_val(data, prior_month, 'B01_ACTIVE_CARDS') or 0
    pm_iss_cards = get_val(data, prior_month, 'B01_ISSUED_CARDS') or 0
    pm_rate = round((pm_act_cards / pm_iss_cards) * 100, 1) if pm_iss_cards else 0
    rate_mom_diff = calc_diff(active_rate, pm_rate)
    
    # 4. 信用業務
    revolving = get_val(data, target_month, 'B01_REVOLVING_BAL') or 0
    revolving_yoy = calc_growth(revolving, get_val(data, prior_year_month, 'B01_REVOLVING_BAL'))
    revolving_mom = calc_growth(revolving, get_val(data, prior_month, 'B01_REVOLVING_BAL'))
    
    cash_adv = get_val(data, target_month, 'B01_CASH_ADV_AMT') or 0
    cash_adv_yoy = calc_growth(cash_adv, get_val(data, prior_year_month, 'B01_CASH_ADV_AMT'))
    cash_adv_mom = calc_growth(cash_adv, get_val(data, prior_month, 'B01_CASH_ADV_AMT'))
    cash_adv_cnt = get_val(data, target_month, 'B01_CASH_ADV_CNT') or 0
    
    # 5. 同業簽帳 YTD
    peers = [
        ('中國信託', get_val(data, target_month, 'B01_PEER_AMT_CTBC') or 0, get_val(data, prior_year_month, 'B01_PEER_AMT_CTBC')),
        ('國泰世華', get_val(data, target_month, 'B01_PEER_AMT_CATHAY') or 0, get_val(data, prior_year_month, 'B01_PEER_AMT_CATHAY')),
        ('台北富邦', get_val(data, target_month, 'B01_PEER_AMT_FUBON') or 0, get_val(data, prior_year_month, 'B01_PEER_AMT_FUBON')),
        ('玉山銀行', get_val(data, target_month, 'B01_PEER_AMT_ESUN') or 0, get_val(data, prior_year_month, 'B01_PEER_AMT_ESUN')),
        ('其他同業', get_val(data, target_month, 'B01_PEER_AMT_OTHERS') or 0, get_val(data, prior_year_month, 'B01_PEER_AMT_OTHERS'))
    ]
    market_total = sum(p[1] for p in peers)
    market_py_total = sum(p[2] for p in peers if p[2] is not None)
    market_yoy = calc_growth(market_total, market_py_total)
    
    peer_results = []
    for name, cur, py in peers:
        share = round((cur / market_total) * 100, 1) if market_total else 0
        yoy = calc_growth(cur, py)
        peer_results.append({
            'bank': name,
            'amount': cur,
            'share': f"{share}%",
            'yoy': f"{'+' if yoy > 0 else ''}{yoy}%"
        })
        
    dashboard_payload = {
        'period': target_month,
        'cards': {
            'total_amount': {
                'title': '總交易金額',
                'value': f"{tot_amt:,.1f}",
                'unit': '億元',
                'yoy': f"{'+' if amt_yoy > 0 else ''}{amt_yoy}%",
                'mom': f"{'+' if amt_mom > 0 else ''}{amt_mom}%",
                'general': {'amount': f"{gen_amt:,.1f}", 'share': f"{gen_share}%"},
                'installment': {'amount': f"{inst_amt:,.1f}", 'share': f"{inst_share}%"}
            },
            'total_count': {
                'title': '總交易筆數',
                'value': f"{int(tot_cnt):,}",
                'unit': '萬筆',
                'yoy': f"{'+' if cnt_yoy > 0 else ''}{cnt_yoy}%",
                'mom': f"{'+' if cnt_mom > 0 else ''}{cnt_mom}%",
                'general': {'count': f"{int(gen_cnt):,}", 'share': f"{gen_cnt_share}%"},
                'installment': {'count': f"{int(inst_cnt):,}", 'share': f"{inst_cnt_share}%"}
            },
            'active_rate': {
                'title': '活卡率',
                'value': f"{active_rate:.1f}%",
                'yoy_diff': f"{'+' if rate_yoy_diff > 0 else ''}{rate_yoy_diff}pp",
                'mom_diff': f"{'+' if rate_mom_diff > 0 else ''}{rate_mom_diff}pp",
                'active_cards': f"{act_cards:,.0f} 萬卡",
                'issued_cards': f"{iss_cards:,.0f} 萬卡"
            },
            'credit_stack': {
                'revolving': {
                    'title': '循環信用餘額',
                    'value': f"{revolving:,.1f}",
                    'unit': '億元',
                    'yoy': f"{'+' if revolving_yoy > 0 else ''}{revolving_yoy}%"
                },
                'cash_advance': {
                    'title': '預借現金金額',
                    'value': f"{cash_adv:,.1f}",
                    'unit': '億元',
                    'yoy': f"{'+' if cash_adv_yoy > 0 else ''}{cash_adv_yoy}%",
                    'note': f"({cash_adv_cnt}萬筆)"
                }
            }
        },
        'peer_benchmark': {
            'title': '四大發卡行簽帳金額與市佔',
            'period_label': '2026 年 1–8 月',
            'market_total': f"{market_total:,.0f} 億元",
            'market_yoy': f"{'+' if market_yoy > 0 else ''}{market_yoy}%",
            'peers': peer_results
        }
    }
    
    print("✅ 儀表板計算結果（即時產出）：")
    print(json.dumps(dashboard_payload, ensure_ascii=False, indent=2))
    
    # Save to JSON
    out_json = os.path.join(SCRIPT_DIR, f"dashboard_b01_{target_month.replace('-', '')}.json")
    with open(out_json, 'w', encoding='utf-8') as f:
        json.dump(dashboard_payload, f, ensure_ascii=False, indent=2)
    print(f"\n💾 已自動匯出前端 JSON 檔至: {out_json}")
    return dashboard_payload

if __name__ == '__main__':
    target = sys.argv[1] if len(sys.argv) > 1 else '2026-08'
    is_ok = audit_month(target)
    if is_ok:
        process_block01(target)
    else:
        print(f"\n⚠️ 因 {target} 資料尚未填報完整，暫停計算與匯出。請補齊上述欄位後再試！")
