# -*- coding: utf-8 -*-
"""
sync_excel.py
Reads dashboard_data.xlsx and compiles it into:
  - dashboard_data.js (for browser direct loading)
  - dashboard_data.json (for standard JSON storage)
"""
import openpyxl
import json
import os

EXCEL_FILE = "dashboard_data.xlsx"

def load_data_from_excel():
    if not os.path.exists(EXCEL_FILE):
        raise FileNotFoundError(f"找不到 Excel 檔案：{EXCEL_FILE}")

    wb = openpyxl.load_workbook(EXCEL_FILE, data_only=True)
    
    # 1. 讀取現有 dashboard_data.json 作為基礎（保留未在 Excel 的其他區塊結構）
    base_data = {
        "meta": {
            "title": "國泰世華銀行 信用卡營運整合數據儀表板",
            "year": "2026",
            "month": "08",
            "period_label": "營運月報",
            "brand": "國泰世華"
        },
        "block01": {
            "section_title": "信用卡整體經營概況",
            "section_num": "01",
            "monthly_kpis": {},
            "cockpit_peer_donut": {},
            "peer_benchmark": []
        }
    }
    if os.path.exists("dashboard_data.json"):
        try:
            with open("dashboard_data.json", "r", encoding="utf-8") as f:
                base_data = json.load(f)
        except Exception:
            pass

    # ========================================================
    # SHEET 1: 01_全行月度指標
    # ========================================================
    if "01_全行月度指標" in wb.sheetnames:
        ws1 = wb["01_全行月度指標"]
        metrics = {}
        for row in ws1.iter_rows(min_row=5, values_only=True):
            if not row or not row[1]:
                continue
            cat, code, name, val, unit, yoy, mom, share, note = row[:9]
            metrics[code] = {
                "name": name,
                "value": float(val) if val is not None else None,
                "unit": unit or "",
                "yoy": float(yoy) if yoy is not None else 0.0,
                "mom": float(mom) if mom is not None else 0.0,
                "share": float(share) if share is not None else None
            }

        # 組合 total_amount
        gen_amt = metrics.get("amt_general", {})
        inst_amt = metrics.get("amt_installment", {})
        tot_amt = metrics.get("amt_total", {})
        
        amt_val = tot_amt.get("value")
        if amt_val is None and gen_amt.get("value") is not None and inst_amt.get("value") is not None:
            amt_val = round(gen_amt["value"] + inst_amt["value"], 1)

        gen_share = gen_amt.get("share")
        if gen_share is None and amt_val and gen_amt.get("value") is not None:
            gen_share = round((gen_amt["value"] / amt_val) * 100, 1)

        inst_share = inst_amt.get("share")
        if inst_share is None and amt_val and inst_amt.get("value") is not None:
            inst_share = round((inst_amt["value"] / amt_val) * 100, 1)

        total_amount = {
            "title": tot_amt.get("name", "總交易金額"),
            "value": amt_val if amt_val is not None else 1286.4,
            "unit": tot_amt.get("unit", "億元"),
            "yoy": tot_amt.get("yoy", 12.8),
            "mom": tot_amt.get("mom", 2.1),
            "general": {
                "label": "一般交易",
                "amount": gen_amt.get("value", 1086.4),
                "unit": gen_amt.get("unit", "億"),
                "share": gen_share if gen_share is not None else 84.4,
                "yoy": gen_amt.get("yoy", 10.5),
                "mom": gen_amt.get("mom", 1.4)
            },
            "installment": {
                "label": "分期交易",
                "amount": inst_amt.get("value", 200.0),
                "unit": inst_amt.get("unit", "億"),
                "share": inst_share if inst_share is not None else 15.6,
                "yoy": inst_amt.get("yoy", 27.3),
                "mom": inst_amt.get("mom", 8.7)
            }
        }

        # 組合 total_count
        gen_cnt = metrics.get("cnt_general", {})
        inst_cnt = metrics.get("cnt_installment", {})
        tot_cnt = metrics.get("cnt_total", {})

        cnt_val = tot_cnt.get("value")
        if cnt_val is None and gen_cnt.get("value") is not None and inst_cnt.get("value") is not None:
            cnt_val = int(gen_cnt["value"] + inst_cnt["value"])

        gen_cnt_share = gen_cnt.get("share")
        if gen_cnt_share is None and cnt_val and gen_cnt.get("value") is not None:
            gen_cnt_share = round((gen_cnt["value"] / cnt_val) * 100, 1)

        inst_cnt_share = inst_cnt.get("share")
        if inst_cnt_share is None and cnt_val and inst_cnt.get("value") is not None:
            inst_cnt_share = round((inst_cnt["value"] / cnt_val) * 100, 1)

        total_count = {
            "title": tot_cnt.get("name", "總交易筆數"),
            "value": int(cnt_val) if cnt_val is not None else 8425,
            "unit": tot_cnt.get("unit", "萬筆"),
            "yoy": tot_cnt.get("yoy", 15.2),
            "mom": tot_cnt.get("mom", 1.7),
            "general": {
                "label": "一般交易",
                "count": int(gen_cnt.get("value", 7750)),
                "unit": gen_cnt.get("unit", "萬筆"),
                "share": gen_cnt_share if gen_cnt_share is not None else 92.0,
                "yoy": gen_cnt.get("yoy", 14.1),
                "mom": gen_cnt.get("mom", 1.2)
            },
            "installment": {
                "label": "分期交易",
                "count": int(inst_cnt.get("value", 675)),
                "unit": inst_cnt.get("unit", "萬筆"),
                "share": inst_cnt_share if inst_cnt_share is not None else 8.0,
                "yoy": inst_cnt.get("yoy", 29.8),
                "mom": inst_cnt.get("mom", 7.9)
            }
        }

        # 組合 active_card
        card_act = metrics.get("card_active", {})
        card_iss = metrics.get("card_issued", {})
        act_val = card_act.get("value", 741)
        iss_val = card_iss.get("value", 858)
        act_rate = card_act.get("share")
        if act_rate is None and act_val and iss_val:
            act_rate = round((act_val / iss_val) * 100, 1)
        
        inact_val = round(iss_val - act_val, 1) if (iss_val and act_val) else 117
        inact_share = round(100 - act_rate, 1) if act_rate else 13.6

        active_card = {
            "title": "活卡率",
            "rate": act_rate if act_rate is not None else 86.4,
            "unit": "%",
            "yoy_pp": card_act.get("yoy", 1.8),
            "mom_pp": card_act.get("mom", 0.3),
            "active_cards": act_val,
            "active_cards_unit": card_act.get("unit", "萬卡"),
            "active_share": act_rate if act_rate is not None else 86.4,
            "issued_cards": iss_val,
            "issued_cards_unit": card_iss.get("unit", "萬卡"),
            "inactive_cards": inact_val,
            "inactive_cards_unit": "萬卡",
            "inactive_share": inact_share
        }

        # 組合 credit_business
        rev = metrics.get("rev_balance", {})
        cash = metrics.get("cash_amount", {})
        cash_cnt = metrics.get("cash_count", {})

        credit_business = {
            "revolving": {
                "title": rev.get("name", "循環信用餘額"),
                "balance": rev.get("value", 325.7),
                "unit": rev.get("unit", "億元"),
                "yoy": rev.get("yoy", 6.7),
                "mom": rev.get("mom", 0.9)
            },
            "cash_advance": {
                "title": cash.get("name", "預借現金金額"),
                "amount": cash.get("value", 18.6),
                "unit": cash.get("unit", "億元"),
                "yoy": cash.get("yoy", -3.4),
                "mom": cash.get("mom", -0.8),
                "count_wan": cash_cnt.get("value", 42.8)
            }
        }

        base_data["block01"]["monthly_kpis"] = {
            "total_amount": total_amount,
            "total_count": total_count,
            "active_card": active_card,
            "credit_business": credit_business
        }

    # ========================================================
    # SHEET 2: 01_四大行簽帳市占
    # ========================================================
    if "01_四大行簽帳市占" in wb.sheetnames:
        ws2 = wb["01_四大行簽帳市占"]
        peers = []
        market_total = 0
        for row in ws2.iter_rows(min_row=5, values_only=True):
            if not row or not row[0]:
                continue
            bank, amt, share, yoy, color, is_cathay, note = row[:7]
            amt = float(amt) if amt is not None else 0
            market_total += amt
            peers.append({
                "name": str(bank),
                "amount": amt,
                "unit": "億",
                "share": float(share) if share is not None else None,
                "yoy": float(yoy) if yoy is not None else 0.0,
                "color": str(color) if color else "#003b5c",
                "is_cathay": str(is_cathay).strip() in ["是", "True", "true", "1"]
            })

        # 計算市佔率若為空
        for p in peers:
            if p["share"] is None and market_total > 0:
                p["share"] = round((p["amount"] / market_total) * 100, 1)

        top4_share = round(sum(p["share"] for p in peers[:4]), 1) if len(peers) >= 4 else None

        base_data["block01"]["cockpit_peer_donut"] = {
            "title": "四大發卡行簽帳金額與市佔",
            "period_label": "2026 年 1–8 月",
            "market_total": market_total,
            "unit": "億元",
            "market_yoy": 14.3,
            "top4_share": top4_share if top4_share is not None else 66.7,
            "peers": peers
        }

    # ========================================================
    # SHEET 3: 01_同業對標明細
    # ========================================================
    if "01_同業對標明細" in wb.sheetnames:
        ws3 = wb["01_同業對標明細"]
        # Group by 業務主題
        categories_dict = {}
        for row in ws3.iter_rows(min_row=5, values_only=True):
            if not row or not row[0] or not row[1]:
                continue
            cat_label, metric_label, unit, direction, mkt_val, mkt_yoy = row[:6]
            cathay_val, cathay_yoy = row[6], row[7]
            ctbc_val, ctbc_yoy = row[8], row[9]
            fubon_val, fubon_yoy = row[10], row[11]
            esun_val, esun_yoy = row[12], row[13]
            taishin_val, taishin_yoy = row[14], row[15]

            peer_list = [
                {"bank": "國泰世華", "value": cathay_val, "yoy": cathay_yoy},
                {"bank": "中國信託", "value": ctbc_val, "yoy": ctbc_yoy},
                {"bank": "台北富邦", "value": fubon_val, "yoy": fubon_yoy},
                {"bank": "玉山銀行" if "玉山" in str(cat_label) or "玉山" in str(metric_label) else "玉山", "value": esun_val, "yoy": esun_yoy},
                {"bank": "台新銀行", "value": taishin_val, "yoy": taishin_yoy}
            ]
            # 排序：依 value 大小（若 direction == 'up' 則大到小，若 down 則小到大）
            reverse_sort = (direction == "up")
            peer_list.sort(key=lambda x: x["value"] if x["value"] is not None else -999999, reverse=reverse_sort)

            metric_item = {
                "label": metric_label,
                "unit": unit or "",
                "positiveDirection": direction or "up",
                "marketValue": mkt_val,
                "marketYoy": mkt_yoy,
                "peers": peer_list
            }

            if cat_label not in categories_dict:
                categories_dict[cat_label] = {
                    "label": cat_label,
                    "metrics": []
                }
            categories_dict[cat_label]["metrics"].append(metric_item)

        base_data["block01"]["peer_benchmark"] = list(categories_dict.values())

    # 輸出至 dashboard_data.json 與 dashboard_data.js
    with open("dashboard_data.json", "w", encoding="utf-8") as f:
        json.dump(base_data, f, ensure_ascii=False, indent=2)

    with open("dashboard_data.js", "w", encoding="utf-8") as f:
        f.write("window.DASHBOARD_DATA = " + json.dumps(base_data, ensure_ascii=False, indent=2) + ";\n")

    print("Success: Compiled dashboard_data.xlsx -> dashboard_data.js & dashboard_data.json!")
    return base_data

if __name__ == "__main__":
    load_data_from_excel()
