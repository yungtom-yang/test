window.DASHBOARD_DATA = {
  "meta": {
    "title": "國泰世華銀行 信用卡營運整合數據儀表板",
    "year": "2026",
    "month": "08",
    "period_label": "營運月報",
    "brand": "國泰世華"
  },
  "block01": {
    "section_title": "信用卡整體經營概況",
    "section_num": "01",
    "monthly_kpis": {
      "total_amount": {
        "title": "總交易金額",
        "value": 1286.4,
        "unit": "億元",
        "yoy": 12.8,
        "mom": 2.1,
        "general": {
          "label": "一般交易",
          "amount": 1086.4,
          "unit": "億元",
          "share": 84.4,
          "yoy": 10.5,
          "mom": 1.4
        },
        "installment": {
          "label": "分期交易",
          "amount": 200.0,
          "unit": "億元",
          "share": 15.6,
          "yoy": 27.3,
          "mom": 8.7
        }
      },
      "total_count": {
        "title": "總交易筆數",
        "value": 8425,
        "unit": "萬筆",
        "yoy": 15.2,
        "mom": 1.7,
        "general": {
          "label": "一般交易",
          "count": 7750,
          "unit": "萬筆",
          "share": 92.0,
          "yoy": 14.1,
          "mom": 1.2
        },
        "installment": {
          "label": "分期交易",
          "count": 675,
          "unit": "萬筆",
          "share": 8.0,
          "yoy": 29.8,
          "mom": 7.9
        }
      },
      "active_card": {
        "title": "活卡率",
        "rate": 86.4,
        "unit": "%",
        "yoy_pp": 1.8,
        "mom_pp": 0.3,
        "active_cards": 741.0,
        "active_cards_unit": "萬卡",
        "active_share": 86.4,
        "issued_cards": 858.0,
        "issued_cards_unit": "萬卡",
        "inactive_cards": 117.0,
        "inactive_cards_unit": "萬卡",
        "inactive_share": 13.6
      },
      "credit_business": {
        "revolving": {
          "title": "循環信用餘額",
          "balance": 325.7,
          "unit": "億元",
          "yoy": 6.7,
          "mom": 0.9
        },
        "cash_advance": {
          "title": "預借現金金額",
          "amount": 18.6,
          "unit": "億元",
          "yoy": -3.4,
          "mom": -0.8,
          "count_wan": 42.8
        }
      }
    },
    "cockpit_peer_donut": {
      "title": "四大發卡行簽帳金額與市佔",
      "period_label": "2026 年 1–8 月",
      "market_total": 30720.0,
      "unit": "億元",
      "market_yoy": 14.3,
      "top4_share": 66.7,
      "peers": [
        {
          "name": "中國信託",
          "amount": 5980.0,
          "unit": "億",
          "share": 19.5,
          "yoy": 11.2,
          "color": "#003b5c",
          "is_cathay": false
        },
        {
          "name": "國泰世華",
          "amount": 5726.0,
          "unit": "億",
          "share": 18.6,
          "yoy": 12.8,
          "color": "#009e73",
          "is_cathay": true
        },
        {
          "name": "台北富邦",
          "amount": 4450.0,
          "unit": "億",
          "share": 14.5,
          "yoy": 18.4,
          "color": "#2563eb",
          "is_cathay": false
        },
        {
          "name": "玉山銀行",
          "amount": 4320.0,
          "unit": "億",
          "share": 14.1,
          "yoy": 9.6,
          "color": "#059669",
          "is_cathay": false
        },
        {
          "name": "其他同業",
          "amount": 10244.0,
          "unit": "億",
          "share": 33.3,
          "yoy": 17.4,
          "color": "#cbd5e1",
          "is_cathay": false
        }
      ]
    },
    "peer_benchmark": [
      {
        "label": "消費經營",
        "metrics": [
          {
            "label": "簽帳金額",
            "unit": "億元",
            "positiveDirection": "up",
            "marketValue": 30740,
            "marketYoy": 14.3,
            "peers": [
              {
                "bank": "中國信託",
                "value": 6457,
                "yoy": 25.9
              },
              {
                "bank": "國泰世華",
                "value": 5726,
                "yoy": 17.1
              },
              {
                "bank": "玉山",
                "value": 4705,
                "yoy": 18.4
              },
              {
                "bank": "台北富邦",
                "value": 3894,
                "yoy": 6.4
              },
              {
                "bank": "台新銀行",
                "value": 3480,
                "yoy": 11.8
              }
            ]
          }
        ]
      },
      {
        "label": "卡量經營",
        "metrics": [
          {
            "label": "有效卡數",
            "unit": "萬卡",
            "positiveDirection": "up",
            "marketValue": 4528,
            "marketYoy": 4.8,
            "peers": [
              {
                "bank": "中國信託",
                "value": 812,
                "yoy": 5.2
              },
              {
                "bank": "國泰世華",
                "value": 741,
                "yoy": 1.8
              },
              {
                "bank": "玉山",
                "value": 624,
                "yoy": 3.1
              },
              {
                "bank": "台北富邦",
                "value": 598,
                "yoy": 8.4
              },
              {
                "bank": "台新銀行",
                "value": 482,
                "yoy": 4
              }
            ]
          },
          {
            "label": "流通卡數",
            "unit": "萬卡",
            "positiveDirection": "up",
            "marketValue": 5892,
            "marketYoy": 3.9,
            "peers": [
              {
                "bank": "中國信託",
                "value": 980,
                "yoy": 4.5
              },
              {
                "bank": "國泰世華",
                "value": 858,
                "yoy": 2.1
              },
              {
                "bank": "台北富邦",
                "value": 762,
                "yoy": 9.1
              },
              {
                "bank": "玉山",
                "value": 745,
                "yoy": 2.8
              },
              {
                "bank": "台新銀行",
                "value": 620,
                "yoy": 3.5
              }
            ]
          },
          {
            "label": "活卡率",
            "unit": "%",
            "positiveDirection": "up",
            "marketValue": 76.8,
            "marketYoy": 0.6,
            "peers": [
              {
                "bank": "國泰世華",
                "value": 86.4,
                "yoy": -0.3
              },
              {
                "bank": "玉山",
                "value": 83.8,
                "yoy": 0.2
              },
              {
                "bank": "中國信託",
                "value": 82.9,
                "yoy": 0.5
              },
              {
                "bank": "台北富邦",
                "value": 78.5,
                "yoy": -0.5
              },
              {
                "bank": "台新銀行",
                "value": 77.7,
                "yoy": 0.4
              }
            ]
          },
          {
            "label": "發卡量",
            "unit": "萬卡",
            "positiveDirection": "up",
            "marketValue": 382,
            "marketYoy": 12.5,
            "peers": [
              {
                "bank": "中國信託",
                "value": 85,
                "yoy": 20.1
              },
              {
                "bank": "台北富邦",
                "value": 72,
                "yoy": 8.6
              },
              {
                "bank": "國泰世華",
                "value": 68,
                "yoy": 15.3
              },
              {
                "bank": "玉山",
                "value": 54,
                "yoy": 4.2
              },
              {
                "bank": "台新銀行",
                "value": 46,
                "yoy": 6.8
              }
            ]
          },
          {
            "label": "停卡量",
            "unit": "萬卡",
            "positiveDirection": "down",
            "marketValue": 215,
            "marketYoy": -3.2,
            "peers": [
              {
                "bank": "台新銀行",
                "value": 28,
                "yoy": -2.1
              },
              {
                "bank": "玉山",
                "value": 31,
                "yoy": -4.5
              },
              {
                "bank": "國泰世華",
                "value": 34,
                "yoy": -5.1
              },
              {
                "bank": "台北富邦",
                "value": 39,
                "yoy": -1.8
              },
              {
                "bank": "中國信託",
                "value": 48,
                "yoy": 2.3
              }
            ]
          },
          {
            "label": "淨發卡量",
            "unit": "萬卡",
            "positiveDirection": "up",
            "marketValue": 167,
            "marketYoy": 41.5,
            "peers": [
              {
                "bank": "中國信託",
                "value": 37,
                "yoy": 54.2
              },
              {
                "bank": "國泰世華",
                "value": 34,
                "yoy": 47.8
              },
              {
                "bank": "台北富邦",
                "value": 33,
                "yoy": 23.5
              },
              {
                "bank": "玉山",
                "value": 23,
                "yoy": 19.8
              },
              {
                "bank": "台新銀行",
                "value": 18,
                "yoy": 24.5
              }
            ]
          }
        ]
      },
      {
        "label": "信用業務",
        "metrics": [
          {
            "label": "循環信用餘額",
            "unit": "億元",
            "positiveDirection": "up",
            "marketValue": 1120,
            "marketYoy": 5.4,
            "peers": [
              {
                "bank": "中國信託",
                "value": 340.2,
                "yoy": 7.8
              },
              {
                "bank": "國泰世華",
                "value": 325.7,
                "yoy": 6.7
              },
              {
                "bank": "台北富邦",
                "value": 168.4,
                "yoy": 4.2
              },
              {
                "bank": "玉山",
                "value": 145.6,
                "yoy": 3.8
              },
              {
                "bank": "台新銀行",
                "value": 110.5,
                "yoy": 2.9
              }
            ]
          },
          {
            "label": "預借現金金額",
            "unit": "億元",
            "positiveDirection": "up",
            "marketValue": 125,
            "marketYoy": -1.2,
            "peers": [
              {
                "bank": "中國信託",
                "value": 28.5,
                "yoy": 1.2
              },
              {
                "bank": "國泰世華",
                "value": 18.6,
                "yoy": -3.4
              },
              {
                "bank": "玉山",
                "value": 16.8,
                "yoy": -0.5
              },
              {
                "bank": "台北富邦",
                "value": 14.2,
                "yoy": -2.1
              },
              {
                "bank": "台新銀行",
                "value": 12.4,
                "yoy": -1.8
              }
            ]
          }
        ]
      },
      {
        "label": "收單業務",
        "metrics": [
          {
            "label": "特店簽帳金額",
            "unit": "億元",
            "positiveDirection": "up",
            "marketValue": 18500,
            "marketYoy": 16.2,
            "peers": [
              {
                "bank": "中國信託",
                "value": 4200,
                "yoy": 21
              },
              {
                "bank": "國泰世華",
                "value": 3850,
                "yoy": 18.4
              },
              {
                "bank": "台北富邦",
                "value": 2950,
                "yoy": 14.5
              },
              {
                "bank": "玉山",
                "value": 2800,
                "yoy": 12.3
              },
              {
                "bank": "台新銀行",
                "value": 2100,
                "yoy": 10.8
              }
            ]
          },
          {
            "label": "特店家數",
            "unit": "萬家",
            "positiveDirection": "up",
            "marketValue": 54.2,
            "marketYoy": 6.5,
            "peers": [
              {
                "bank": "中國信託",
                "value": 14.2,
                "yoy": 9.1
              },
              {
                "bank": "國泰世華",
                "value": 12.5,
                "yoy": 7.8
              },
              {
                "bank": "台北富邦",
                "value": 8.4,
                "yoy": 4.2
              },
              {
                "bank": "玉山",
                "value": 8.1,
                "yoy": 5
              },
              {
                "bank": "台新銀行",
                "value": 6.2,
                "yoy": 3.8
              }
            ]
          }
        ]
      },
      {
        "label": "收益品質",
        "metrics": [
          {
            "label": "簽帳手續費收入",
            "unit": "億元",
            "positiveDirection": "up",
            "marketValue": 1320,
            "marketYoy": 13.5,
            "peers": [
              {
                "bank": "國泰世華",
                "value": 287,
                "yoy": 12
              },
              {
                "bank": "中國信託",
                "value": 276,
                "yoy": 8
              },
              {
                "bank": "玉山",
                "value": 252,
                "yoy": 4
              },
              {
                "bank": "台新銀行",
                "value": 245,
                "yoy": 5
              },
              {
                "bank": "台北富邦",
                "value": 238,
                "yoy": 6
              }
            ]
          },
          {
            "label": "轉銷呆帳",
            "unit": "億元",
            "positiveDirection": "down",
            "marketValue": 6.8,
            "marketYoy": -0.3,
            "peers": [
              {
                "bank": "國泰世華",
                "value": 1.1,
                "yoy": -0.2
              },
              {
                "bank": "台北富邦",
                "value": 1.2,
                "yoy": 0.1
              },
              {
                "bank": "玉山",
                "value": 1.3,
                "yoy": 0.2
              },
              {
                "bank": "台新銀行",
                "value": 1.3,
                "yoy": -0.1
              },
              {
                "bank": "中國信託",
                "value": 1.4,
                "yoy": 0.1
              }
            ]
          }
        ]
      }
    ]
  }
};
