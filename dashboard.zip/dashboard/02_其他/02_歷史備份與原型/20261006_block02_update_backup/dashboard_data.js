window.DASHBOARD_DATA = {
  "meta": {
    "title": "國泰世華銀行 信用卡營運整合數據儀表板",
    "year": "2026",
    "month": "08",
    "period_label": "營運月報",
    "brand": "國泰世華"
  },
  "block01": {
    "section_title": "信用卡整體經營概況",
    "section_num": "01",
    "monthly_kpis": {
      "total_amount": {
        "title": "總交易金額",
        "value": 765.0,
        "unit": "億元",
        "yoy": null,
        "mom": null,
        "general": {
          "label": "一般交易",
          "amount": 740.0,
          "unit": "億元",
          "share": 96.73,
          "yoy": 15.1,
          "mom": -4.6
        },
        "installment": {
          "label": "分期交易",
          "amount": 25.0,
          "unit": "億元",
          "share": 3.27,
          "yoy": null,
          "mom": -2.6
        }
      },
      "total_count": {
        "title": "總交易筆數",
        "value": 6576.0,
        "unit": "萬筆",
        "yoy": null,
        "mom": null,
        "general": {
          "label": "一般交易",
          "count": 6554.0,
          "unit": "萬筆",
          "share": 99.67,
          "yoy": null,
          "mom": -4.1
        },
        "installment": {
          "label": "分期交易",
          "count": 22.0,
          "unit": "萬筆",
          "share": 0.33,
          "yoy": null,
          "mom": -2.6
        }
      },
      "active_card": {
        "title": "活卡率",
        "rate": null,
        "unit": "%",
        "yoy_pp": null,
        "mom_pp": null,
        "active_cards": null,
        "active_cards_unit": "張",
        "active_share": null,
        "issued_cards": null,
        "issued_cards_unit": "張",
        "inactive_cards": null,
        "inactive_cards_unit": "張",
        "inactive_share": null
      },
      "credit_business": {
        "revolving": {
          "title": "循環信用餘額",
          "balance": null,
          "unit": "億元",
          "yoy": null,
          "mom": null
        },
        "cash_advance": {
          "title": "預借現金金額",
          "amount": 1.854,
          "unit": "億元",
          "yoy": -5.1,
          "mom": -29.5,
          "count_wan": 0.9
        }
      }
    },
    "cockpit_peer_donut": {
      "title": "五大發卡行簽帳金額",
      "period_label": "2026 年 1–8 月",
      "market_label": "五大行簽帳總額",
      "market_total": 24534.17,
      "unit": "億元",
      "market_yoy": 18.5,
      "hint": "五大行合計",
      "peers": [
        {
          "name": "中國信託",
          "amount": 6457.36,
          "unit": "億元",
          "share": 26.3,
          "yoy": 25.86,
          "color": "#003b5c",
          "is_cathay": false,
          "note": "第一大行"
        },
        {
          "name": "國泰世華",
          "amount": 5726.22,
          "unit": "億元",
          "share": 23.3,
          "yoy": 17.12,
          "color": "#009e73",
          "is_cathay": true,
          "note": "本行 (綠色高亮顯示)"
        },
        {
          "name": "玉山銀行",
          "amount": 4705.48,
          "unit": "億元",
          "share": 19.2,
          "yoy": 18.43,
          "color": "#059669",
          "is_cathay": false,
          "note": "第四大行"
        },
        {
          "name": "台北富邦",
          "amount": 3893.63,
          "unit": "億元",
          "share": 15.9,
          "yoy": 6.38,
          "color": "#2563eb",
          "is_cathay": false,
          "note": "Costco 卡主力"
        },
        {
          "name": "台新銀行",
          "amount": 3751.48,
          "unit": "億元",
          "share": 15.3,
          "yoy": 22.71,
          "color": "#ea580c",
          "is_cathay": false,
          "note": "第五大行 (Richart/玫瑰卡主力)"
        }
      ]
    },
    "peer_benchmark": [
      {
        "label": "消費經營",
        "metrics": [
          {
            "label": "簽帳金額",
            "unit": "億元",
            "positiveDirection": "up",
            "summaryMode": "growth",
            "decimals": null,
            "marketValue": null,
            "marketYoy": null,
            "peers": [
              {
                "bank": "中國信託",
                "value": 6457.36,
                "yoy": 25.86
              },
              {
                "bank": "國泰世華",
                "value": 5726.22,
                "yoy": 17.12
              },
              {
                "bank": "玉山",
                "value": 4705.48,
                "yoy": 18.43
              },
              {
                "bank": "台北富邦",
                "value": 3893.63,
                "yoy": 6.38
              },
              {
                "bank": "台新銀行",
                "value": 3751.48,
                "yoy": 22.71
              }
            ]
          }
        ]
      },
      {
        "label": "卡量經營",
        "metrics": [
          {
            "label": "有效卡數",
            "unit": "張",
            "positiveDirection": "up",
            "summaryMode": "growth",
            "decimals": null,
            "marketValue": null,
            "marketYoy": null,
            "peers": [
              {
                "bank": "中國信託",
                "value": 6904052.0,
                "yoy": 13.01
              },
              {
                "bank": "台北富邦",
                "value": 5867144.0,
                "yoy": 1.21
              },
              {
                "bank": "國泰世華",
                "value": 5119242.0,
                "yoy": -0.15
              },
              {
                "bank": "玉山",
                "value": 4888279.0,
                "yoy": -9.53
              },
              {
                "bank": "台新銀行",
                "value": 4806088.0,
                "yoy": -1.38
              }
            ]
          },
          {
            "label": "流通卡數",
            "unit": "張",
            "positiveDirection": "up",
            "summaryMode": "growth",
            "decimals": null,
            "marketValue": null,
            "marketYoy": null,
            "peers": [
              {
                "bank": "中國信託",
                "value": 9787283.0,
                "yoy": 8.88
              },
              {
                "bank": "台北富邦",
                "value": 7564017.0,
                "yoy": 1.65
              },
              {
                "bank": "玉山",
                "value": 7497711.0,
                "yoy": -14.17
              },
              {
                "bank": "國泰世華",
                "value": 7257654.0,
                "yoy": -0.59
              },
              {
                "bank": "台新銀行",
                "value": 6685959.0,
                "yoy": 0.91
              }
            ]
          },
          {
            "label": "活卡率",
            "unit": "%",
            "positiveDirection": "up",
            "summaryMode": "quality",
            "decimals": 1,
            "marketValue": null,
            "marketYoy": null,
            "peers": [
              {
                "bank": "台北富邦",
                "value": 77.57,
                "yoy": -0.33
              },
              {
                "bank": "台新銀行",
                "value": 71.88,
                "yoy": -1.67
              },
              {
                "bank": "國泰世華",
                "value": 70.54,
                "yoy": 0.31
              },
              {
                "bank": "中國信託",
                "value": 70.54,
                "yoy": 2.58
              },
              {
                "bank": "玉山",
                "value": 65.2,
                "yoy": 3.35
              }
            ]
          }
        ]
      },
      {
        "label": "信用業務",
        "metrics": [
          {
            "label": "循環信用餘額",
            "unit": "億元",
            "positiveDirection": "up",
            "summaryMode": "growth",
            "decimals": null,
            "marketValue": null,
            "marketYoy": null,
            "peers": [
              {
                "bank": "國泰世華",
                "value": 225.28,
                "yoy": 4.79
              },
              {
                "bank": "中國信託",
                "value": 182.65,
                "yoy": 5.61
              },
              {
                "bank": "玉山",
                "value": 174.64,
                "yoy": 4.31
              },
              {
                "bank": "台新銀行",
                "value": 114.87,
                "yoy": 4.65
              },
              {
                "bank": "台北富邦",
                "value": 114.33,
                "yoy": 4.71
              }
            ]
          },
          {
            "label": "預借現金金額",
            "unit": "億元",
            "positiveDirection": "up",
            "summaryMode": "growth",
            "decimals": null,
            "marketValue": null,
            "marketYoy": null,
            "peers": [
              {
                "bank": "中國信託",
                "value": 35.72,
                "yoy": -0.36
              },
              {
                "bank": "玉山",
                "value": 16.75,
                "yoy": 0.19
              },
              {
                "bank": "國泰世華",
                "value": 14.74,
                "yoy": 4.07
              },
              {
                "bank": "台新銀行",
                "value": 8.5,
                "yoy": 4.25
              },
              {
                "bank": "台北富邦",
                "value": 6.85,
                "yoy": -5.96
              }
            ]
          }
        ]
      },
      {
        "label": "資產品質",
        "metrics": [
          {
            "label": "備抵呆帳提足率",
            "unit": "%",
            "positiveDirection": "up",
            "summaryMode": "quality",
            "decimals": 0,
            "marketValue": null,
            "marketYoy": null,
            "peers": [
              {
                "bank": "台北富邦",
                "value": 1622.13,
                "yoy": 194.09
              },
              {
                "bank": "國泰世華",
                "value": 969.16,
                "yoy": -7.6
              },
              {
                "bank": "台新銀行",
                "value": 902.42,
                "yoy": 237.82
              },
              {
                "bank": "玉山",
                "value": 518.04,
                "yoy": 274.04
              },
              {
                "bank": "中國信託",
                "value": 288.76,
                "yoy": -10.73
              }
            ]
          },
          {
            "label": "轉銷呆帳",
            "unit": "億元",
            "positiveDirection": "down",
            "summaryMode": "quality",
            "decimals": 1,
            "marketValue": null,
            "marketYoy": null,
            "peers": [
              {
                "bank": "台新銀行",
                "value": 2.78,
                "yoy": -19.38
              },
              {
                "bank": "玉山",
                "value": 5.66,
                "yoy": 31.53
              },
              {
                "bank": "台北富邦",
                "value": 5.7,
                "yoy": -17.3
              },
              {
                "bank": "中國信託",
                "value": 6.03,
                "yoy": -5.71
              },
              {
                "bank": "國泰世華",
                "value": 6.3,
                "yoy": -16.09
              }
            ]
          }
        ]
      }
    ]
  },
  "block02": {
    "section_title": "收單業務",
    "section_num": "02",
    "monthly_kpis": {
      "acq_amt": {
        "title": "收單交易金額",
        "total": 239.4112,
        "unit": "億元",
        "yoy": -7.1,
        "mom": 2.1,
        "physical": {
          "amount": null,
          "unit": "億元",
          "share": 65.0,
          "yoy": null
        },
        "online": {
          "amount": 18.835,
          "unit": "億元",
          "share": 35.0,
          "yoy": null
        }
      },
      "acq_cnt": {
        "title": "收單交易筆數",
        "total": 2991.8,
        "unit": "萬筆",
        "yoy": -2.0,
        "mom": 1.8,
        "physical": {
          "count": null,
          "unit": "萬筆",
          "share": 70.0,
          "yoy": null
        },
        "online": {
          "count": 1667.0,
          "unit": "萬筆",
          "share": 30.0,
          "yoy": null
        }
      },
      "acq_mcht": {
        "title": "收單特店總數",
        "total": 60382.0,
        "unit": "家",
        "yoy": -0.1,
        "mom": 0.7,
        "active_rate": 83.0,
        "physical": {
          "count": null,
          "unit": "家",
          "share": 80.0
        },
        "online": {
          "count": null,
          "unit": "家",
          "share": 20.0
        }
      },
      "secondary": {
        "penetration_rate": {
          "title": "自行收單滲透率",
          "value": null,
          "unit": "%",
          "yoy": null,
          "mom": 0.3
        },
        "active_mcht": {
          "title": "活躍自行特店數",
          "count": null,
          "unit": "家",
          "yoy": null,
          "active_rate": 83.0
        },
        "submcht_api": {
          "title": "次特店API進件數",
          "value": null,
          "unit": "件"
        },
        "fee_income": {
          "title": "收單手續費收入",
          "value": null,
          "unit": "億元",
          "yoy": null
        }
      }
    },
    "twqr": {
      "apply_count": null,
      "pass_rate": null,
      "new_merchants": null,
      "total_merchants": 256.0,
      "total_merchants_mom": 11.3,
      "tx_amount": 130620.0,
      "tx_amount_unit": "元",
      "tx_amount_mom": 262.9,
      "tx_count": 199.0,
      "tx_count_unit": "筆",
      "tx_count_mom": 38.2,
      "avg_ticket": 656,
      "mcht_avg_amount": null,
      "active_mcht_rate": null
    },
    "online_channels": [
      {
        "name": "EPOS - 雲端",
        "amount": 6.128,
        "amount_share": 32.5,
        "amount_yoy": null,
        "count": 663.2232,
        "count_yoy": null,
        "avg_ticket": 92,
        "avg_ticket_yoy": null,
        "note": ""
      },
      {
        "name": "EPOS - 地端",
        "amount": 10.715,
        "amount_share": 56.9,
        "amount_yoy": null,
        "count": 653.2417,
        "count_yoy": null,
        "avg_ticket": 164,
        "avg_ticket_yoy": null,
        "note": ""
      },
      {
        "name": "Payment Hub掃碼交易",
        "amount": 1.991722,
        "amount_share": 10.6,
        "amount_yoy": null,
        "count": 350.1689,
        "count_yoy": null,
        "avg_ticket": 57,
        "avg_ticket_yoy": null,
        "note": ""
      }
    ],
    "merchant_concentration": {
      "top10_share": null,
      "top10_yoy": null,
      "top_merchants": [
        {
          "name": "特店 A",
          "sub": "量販巨頭",
          "amount": null,
          "yoy": null,
          "quadrant": "核心成長區"
        },
        {
          "name": "特店 B",
          "sub": "綜合電商",
          "amount": null,
          "yoy": null,
          "quadrant": "核心成長區"
        },
        {
          "name": "特店 C",
          "sub": "百貨生活",
          "amount": null,
          "yoy": null,
          "quadrant": "重點維繫區"
        },
        {
          "name": "特店 D",
          "sub": "連鎖超商",
          "amount": null,
          "yoy": null,
          "quadrant": "重點維繫區"
        },
        {
          "name": "特店 E",
          "sub": "連鎖餐飲",
          "amount": null,
          "yoy": null,
          "quadrant": "潛力開發區"
        }
      ],
      "matrix_reps": {
        "core": "代表：特店 A、特店 B",
        "potential": "代表：特店 E 等",
        "maintain": "代表：特店 C、特店 D",
        "general": "代表：特店 X"
      }
    },
    "industry_structure": [
      {
        "name": "量販超市",
        "label": "🛒 量販超市",
        "merchant_count": null,
        "merchant_share": null,
        "amount": null,
        "amount_share": null,
        "avg_per_merchant": null,
        "color": "#003b5c"
      },
      {
        "name": "綜合電商",
        "label": "🌐 綜合電商",
        "merchant_count": null,
        "merchant_share": null,
        "amount": null,
        "amount_share": null,
        "avg_per_merchant": null,
        "color": "#0284c7"
      },
      {
        "name": "百貨生活",
        "label": "🏬 百貨生活",
        "merchant_count": null,
        "merchant_share": null,
        "amount": null,
        "amount_share": null,
        "avg_per_merchant": null,
        "color": "#10b981"
      },
      {
        "name": "餐飲美食",
        "label": "🍽️ 餐飲美食",
        "merchant_count": null,
        "merchant_share": null,
        "amount": null,
        "amount_share": null,
        "avg_per_merchant": null,
        "color": "#f59e0b"
      },
      {
        "name": "交通旅遊",
        "label": "✈️ 交通旅遊",
        "merchant_count": null,
        "merchant_share": null,
        "amount": null,
        "amount_share": null,
        "avg_per_merchant": null,
        "color": "#8b5cf6"
      },
      {
        "name": "其他各業",
        "label": "📦 其他各業",
        "merchant_count": null,
        "merchant_share": null,
        "amount": null,
        "amount_share": null,
        "avg_per_merchant": null,
        "color": "#94a3b8"
      }
    ]
  },
  "block03": {
    "section_title": "發卡業務",
    "section_num": "03",
    "monthly_kpis": {
      "apply_total": {
        "title": "申辦進件總量",
        "value": 55503.0,
        "unit": "件",
        "yoy": -1.6,
        "mom": -13.1,
        "digital": {
          "label": "數位進件",
          "amount": 51735.0,
          "unit": "件",
          "share": 93.2
        },
        "physical": {
          "label": "實體進件",
          "amount": 3768.0,
          "unit": "件",
          "share": 6.8
        }
      },
      "auth_total": {
        "title": "授權交易總數",
        "value": 7866.9788,
        "unit": "萬筆",
        "yoy": 21.4,
        "mom": 2.7,
        "credit": {
          "label": "信用卡授權筆數",
          "amount": 7289.8322,
          "unit": "萬筆",
          "share": 92.7
        },
        "debit": {
          "label": "簽帳卡授權筆數",
          "amount": 577.1466,
          "unit": "萬筆",
          "share": 7.3
        }
      },
      "install_total": {
        "title": "分期交易總額",
        "value": 22.07,
        "unit": "億元",
        "yoy": null,
        "mom": null,
        "single": {
          "label": "單筆分期金額",
          "amount": 14.07,
          "unit": "億元",
          "share": 63.8
        },
        "bill": {
          "label": "帳單分期金額",
          "amount": 8.0,
          "unit": "億元",
          "share": 36.2
        },
        "count_total": 11.98,
        "single_count": 9.0685,
        "bill_count": 2.9164,
        "split_foot": "分期總筆數：11.98 萬筆（單筆 9.07 萬筆 ＋ 帳單 2.92 萬筆）"
      },
      "auto_approve_rate": {
        "title": "綜合自動核准率",
        "value": null,
        "unit": "%",
        "old_rate": 91.82,
        "new_rate": 77.98,
        "review_rate": null
      },
      "ebill_card": {
        "title": "信用卡電子帳單率",
        "value": 67.93,
        "unit": "%",
        "total": 468.6346,
        "paper": 150.3101,
        "paper_yoy": 153.3
      },
      "bonus_summary": {
        "redeem_rate": 71.17,
        "grant_month": 898.3,
        "redeem_month": 639.3,
        "redeem_yoy": 18.1,
        "balance": 7353.79,
        "balance_yoy": 28.9,
        "liability": null
      }
    },
    "application_approval": {
      "stage1_old": {
        "cat": "申辦徵審流向",
        "name": "舊戶加辦進件",
        "value": 14543.0,
        "y_base": null,
        "unit": "件",
        "yoy": null,
        "share": 28.5,
        "col1": null,
        "col2": null,
        "note": ""
      },
      "stage1_new": {
        "cat": "申辦徵審流向",
        "name": "新戶申辦進件",
        "value": 36397.0,
        "y_base": null,
        "unit": "件",
        "yoy": null,
        "share": 71.5,
        "col1": null,
        "col2": null,
        "note": ""
      },
      "stage2_hub": {
        "cat": "申辦徵審流向",
        "name": "進件自動審查中樞",
        "value": 42540.0,
        "y_base": null,
        "unit": "件",
        "yoy": null,
        "share": 83.5,
        "col1": null,
        "col2": null,
        "note": ""
      },
      "stage3_auto_pass": {
        "cat": "申辦徵審流向",
        "name": "自動直接核准總數",
        "value": 35124.0,
        "y_base": null,
        "unit": "件",
        "yoy": null,
        "share": 69.0,
        "col1": null,
        "col2": null,
        "note": ""
      },
      "stage3_manual": {
        "cat": "申辦徵審流向",
        "name": "轉入人工審查總數",
        "value": null,
        "y_base": null,
        "unit": "件",
        "yoy": null,
        "share": null,
        "col1": null,
        "col2": null,
        "note": ""
      }
    },
    "billing_center": {
      "total_bills": {
        "cat": "帳單中心核心",
        "name": "全行出帳總份數",
        "value": 531.5525,
        "y_base": null,
        "unit": "萬份",
        "yoy": null,
        "share": null,
        "col1": 323.6855,
        "col2": 207.867,
        "note": ""
      },
      "overall_erate": {
        "cat": "帳單中心核心",
        "name": "全行綜合電子化率",
        "value": 60.9,
        "y_base": null,
        "unit": "%",
        "yoy": null,
        "share": null,
        "col1": null,
        "col2": null,
        "note": ""
      },
      "delivery_rate": {
        "cat": "帳單中心核心",
        "name": "有效投遞率",
        "value": null,
        "y_base": null,
        "unit": "%",
        "yoy": null,
        "share": null,
        "col1": null,
        "col2": null,
        "note": ""
      },
      "green_saving": {
        "cat": "帳單中心核心",
        "name": "綠色節能省費效益",
        "value": null,
        "y_base": null,
        "unit": "萬元",
        "yoy": null,
        "share": null,
        "col1": null,
        "col2": null,
        "note": ""
      },
      "track_card": {
        "cat": "雙軌帳單明細",
        "name": "信用卡帳單",
        "value": 468.6346,
        "y_base": null,
        "unit": "萬份",
        "yoy": null,
        "share": 67.93,
        "col1": 318.3245,
        "col2": 150.3101,
        "note": ""
      },
      "track_bank": {
        "cat": "雙軌帳單明細",
        "name": "銀行對帳單",
        "value": 62.9179,
        "y_base": null,
        "unit": "萬份",
        "yoy": null,
        "share": 8.52,
        "col1": 5.361,
        "col2": 57.5569,
        "note": ""
      }
    },
    "bonus_points": {
      "waterfall": [
        {
          "code": "bonus_wf_last_year",
          "name": "去年同月餘額",
          "value": 5705.94,
          "unit": "百萬點",
          "share": null,
          "color": "#64748b",
          "note": "獨立對比柱 (虛線)"
        },
        {
          "code": "bonus_wf_last_month",
          "name": "上月餘額",
          "value": 7194.028,
          "unit": "百萬點",
          "share": null,
          "color": "#003b5c",
          "note": "起點柱"
        },
        {
          "code": "bonus_wf_inc",
          "name": "本月新增",
          "value": 787.541,
          "unit": "百萬點",
          "share": null,
          "color": "#009e73",
          "note": "綠色上升 (+2.4)"
        },
        {
          "code": "bonus_wf_grant",
          "name": "本月贈送",
          "value": 110.768,
          "unit": "百萬點",
          "share": null,
          "color": "#0284c7",
          "note": "藍色上升 (+1.6)"
        },
        {
          "code": "bonus_wf_redeem",
          "name": "本月兌換",
          "value": 639.34,
          "unit": "百萬點",
          "share": null,
          "color": "#b84a4a",
          "note": "紅色下降 (-3.2)"
        },
        {
          "code": "bonus_wf_expire",
          "name": "本月失效",
          "value": null,
          "unit": "百萬點",
          "share": null,
          "color": "#b84a4a",
          "note": "負向下降 (-0.2)"
        },
        {
          "code": "bonus_wf_total",
          "name": "本月累積餘額",
          "value": 7353.794,
          "unit": "百萬點",
          "share": null,
          "color": "#7c4dff",
          "note": "終點柱 (17.9 + 2.4 + 1.6 - 3.2 - 0.2 = 18.5)"
        }
      ],
      "net_increase": 1537.6,
      "channels": [
        {
          "code": "bonus_ch_instant",
          "name": "即時折抵",
          "value": 415.933,
          "unit": "百萬點",
          "share": 65.1,
          "color": "#009e73",
          "note": "排行第 1 名"
        },
        {
          "code": "bonus_ch_merchant",
          "name": "商戶折抵",
          "value": 80.204,
          "unit": "百萬點",
          "share": 12.5,
          "color": "#003b5c",
          "note": "排行第 2 名"
        },
        {
          "code": "bonus_ch_mileage",
          "name": "里程兌換",
          "value": 97.916,
          "unit": "百萬點",
          "share": 15.3,
          "color": "#7c4dff",
          "note": "排行第 3 名"
        },
        {
          "code": "bonus_ch_merge",
          "name": "合併用點",
          "value": 12.689,
          "unit": "百萬點",
          "share": 2.0,
          "color": "#c9892e",
          "note": "排行第 4 名"
        },
        {
          "code": "bonus_ch_other",
          "name": "其他折抵",
          "value": 32.598,
          "unit": "百萬點",
          "share": 5.1,
          "color": "#94a3b8",
          "note": "排行第 5 名"
        }
      ],
      "total_redeem": 639.34
    },
    "installment_structure": {
      "products": [
        {
          "code": "inst_prod_auth",
          "name": "授權單筆分期",
          "amount": 6.66,
          "unit": "億元",
          "yoy": 20.5,
          "share": 35.7,
          "count": null,
          "avg_ticket": null,
          "color": "#003b5c",
          "note": "授權單筆分期，筆數 285 萬筆，客單 ,596"
        },
        {
          "code": "inst_prod_settle",
          "name": "請款單筆分期",
          "amount": 4.0,
          "unit": "億元",
          "yoy": -41.0,
          "share": 21.4,
          "count": null,
          "avg_ticket": null,
          "color": "#2d6a8f",
          "note": "請款單筆分期，筆數 220 萬筆，客單 ,545"
        },
        {
          "code": "inst_prod_bill",
          "name": "帳單分期",
          "amount": 8.01,
          "unit": "億元",
          "yoy": -19.1,
          "share": 42.9,
          "count": null,
          "avg_ticket": null,
          "color": "#588ea8",
          "note": "帳單分期，筆數 170 萬筆，客單 ,176"
        }
      ]
    },
    "collection_asset": {
      "m1_defense": {
        "col_m1_entry": {
          "name": "M1當期進案",
          "value": null,
          "unit": "億元",
          "count": null,
          "note": "當期進案 28,500 戶 (8.2 億元)"
        },
        "col_cure_rate": {
          "name": "催收回復正常率",
          "value": null,
          "unit": "%",
          "count": null,
          "note": "回復正常 24,400 戶 (8.2 億元)"
        },
        "col_to_m2": {
          "name": "轉入M2催收流程",
          "value": null,
          "unit": "%",
          "count": null,
          "note": "轉入 M2 催收 4,100 戶"
        }
      },
      "aging_buckets": [
        {
          "code": "aging_m1",
          "name": "M1 (1–30天)",
          "amount": null,
          "unit": "億元",
          "share": null,
          "count": null,
          "rec_ratio": null,
          "color": "#003b5c",
          "note": "0.52% 應收，進度條 52%"
        },
        {
          "code": "aging_m2",
          "name": "M2 (31–60天)",
          "amount": null,
          "unit": "億元",
          "share": null,
          "count": null,
          "rec_ratio": null,
          "color": "#c9892e",
          "note": "0.16% 應收，進度條 16%"
        },
        {
          "code": "aging_m3",
          "name": "M3+ (61天以上)",
          "amount": null,
          "unit": "億元",
          "share": null,
          "count": null,
          "rec_ratio": null,
          "color": "#b84a4a",
          "note": "0.18% 應收，進度條 18%"
        }
      ],
      "loss_settlement": {
        "loss_writeoff": {
          "name": "當月轉銷呆帳 (損)",
          "value": null,
          "unit": "億元",
          "note": "轉銷呆帳 (損)"
        },
        "loss_recovery": {
          "name": "當月呆帳回收 (益)",
          "value": null,
          "unit": "億元",
          "note": "呆帳回收 (益)"
        },
        "loss_net": {
          "name": "當月淨信用損失",
          "value": null,
          "unit": "億元",
          "note": "淨信用損失 = 轉銷 + 回收 = -1.45 + 0.35 = -1.10"
        }
      }
    }
  },
  "block04": {
    "section_title": "系統韌性",
    "section_num": "04",
    "monthly_kpis": {
      "sys_cardpool_resp": {
        "dimension": "CardPool授權主機",
        "name": "交易響應時間",
        "value": null,
        "unit": "ms",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "可用率 99.999%",
        "sub2": "SLA 100% 達標"
      },
      "sys_cardpool_vol": {
        "dimension": "CardPool授權主機",
        "name": "月授權交易量",
        "value": null,
        "unit": "萬筆",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": 0,
        "sub2": "< 120ms"
      },
      "sys_cardpool_succ": {
        "dimension": "CardPool授權主機",
        "name": "授權成功率",
        "value": null,
        "unit": "%",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "99.999%",
        "sub2": "744 小時"
      },
      "sys_cardlink_vol": {
        "dimension": "Cardlink核心帳務",
        "name": "月帳務處理量",
        "value": null,
        "unit": "億筆",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "100.0%",
        "sub2": "4,850 TPS"
      },
      "sys_cardlink_avail": {
        "dimension": "Cardlink核心帳務",
        "name": "系統可用率",
        "value": null,
        "unit": "%",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "100.0%",
        "sub2": "4,850 TPS"
      },
      "sys_cardlink_tps": {
        "dimension": "Cardlink核心帳務",
        "name": "瞬時處理峰值",
        "value": null,
        "unit": "TPS",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "100.0%",
        "sub2": null
      },
      "sys_cardlink_batch_time": {
        "dimension": "Cardlink核心帳務",
        "name": "批次作業完成時間",
        "value": null,
        "unit": "時間",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "100%",
        "sub2": "40 分鐘"
      },
      "sys_cardlink_batch_limit": {
        "dimension": "Cardlink核心帳務",
        "name": "排程窗口上限時間",
        "value": null,
        "unit": "時間",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "安全裕度足",
        "sub2": "40 分鐘"
      },
      "sys_cardlink_batch_accounts": {
        "dimension": "Cardlink核心帳務",
        "name": "日均處理帳單戶數",
        "value": null,
        "unit": "萬戶",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": "100.0%",
        "sub2": "零延宕"
      },
      "sys_fraud_total_amt": {
        "dimension": "全行防詐防堵",
        "name": "全月總防堵金額",
        "value": 9482.0,
        "unit": "萬元",
        "last_year": null,
        "prev_month": 10970.0,
        "yoy": null,
        "mom": -13.56,
        "note": "",
        "sub1": 2684,
        "sub2": null
      },
      "sys_fraud_total_cnt": {
        "dimension": "全行防詐防堵",
        "name": "總阻斷冒用卡數",
        "value": 5858.0,
        "unit": "張",
        "last_year": null,
        "prev_month": null,
        "yoy": null,
        "mom": null,
        "note": "",
        "sub1": 4280,
        "sub2": null
      }
    },
    "cloud_events": [
      {
        "code": "ev_618",
        "date": "2026/06/18",
        "name": "年中大促 618",
        "peak_time": "00:00–01:00",
        "spec": "32 vCPU / 128GB",
        "instances": "36 實例",
        "peak_tps": 3850.0,
        "cpu_load": 54.0,
        "latency": "< 80ms",
        "note": "平穩運行，延遲 < 80ms"
      },
      {
        "code": "ev_0808",
        "date": "2026/08/08",
        "name": "父親節檔期",
        "peak_time": "12:30–13:30",
        "spec": "32 vCPU / 128GB",
        "instances": "24 實例",
        "peak_tps": 2420.0,
        "cpu_load": 38.0,
        "latency": "< 75ms",
        "note": "平穩運行，處於常態健康區"
      },
      {
        "code": "ev_anniv",
        "date": "2026/10/24",
        "name": "百貨週年慶首週末",
        "peak_time": "14:30–16:30",
        "spec": "48 vCPU / 192GB",
        "instances": "48 實例",
        "peak_tps": 4180.0,
        "cpu_load": 62.0,
        "latency": "< 85ms",
        "note": "平穩運行，實體與掃碼無延滯"
      },
      {
        "code": "ev_1111",
        "date": "2026/11/11",
        "name": "雙11電商零點狂歡",
        "peak_time": "00:00–00:30",
        "spec": "64 vCPU / 256GB",
        "instances": "72 實例",
        "peak_tps": 5420.0,
        "cpu_load": 68.0,
        "latency": "< 90ms",
        "note": "年度最高峰順暢通過，零中斷"
      },
      {
        "code": "ev_1212",
        "date": "2026/12/12",
        "name": "雙12年終購物節",
        "peak_time": "20:00–22:00",
        "spec": "48 vCPU / 192GB",
        "instances": "48 實例",
        "peak_tps": 3960.0,
        "cpu_load": 58.0,
        "latency": "< 82ms",
        "note": "平穩運行，延遲 < 82ms"
      }
    ],
    "fraud_defense": {
      "channels": [
        {
          "code": "fraud_sfm_tx",
          "system": "SFM",
          "name": "SFM 交易詐欺防堵",
          "amount": 6155.0,
          "unit": "萬元",
          "last_year": null,
          "prev_month": 6027.0,
          "yoy": null,
          "share": 64.9,
          "count": 5434.0,
          "avg_per_card": 1.13,
          "color": "#003b5c",
          "note": ""
        },
        {
          "code": "fraud_sfm_apply",
          "system": "SFM",
          "name": "SFM 申請詐欺防堵",
          "amount": 3070.0,
          "unit": "萬元",
          "last_year": null,
          "prev_month": 3583.0,
          "yoy": null,
          "share": 32.4,
          "count": 195.0,
          "avg_per_card": 15.74,
          "color": "#2d6a8f",
          "note": ""
        },
        {
          "code": "fraud_3ds_online",
          "system": "3DS",
          "name": "3DS 系統防堵",
          "amount": 257.0,
          "unit": "萬元",
          "last_year": null,
          "prev_month": 1360.0,
          "yoy": null,
          "share": 2.7,
          "count": 229.0,
          "avg_per_card": 1.12,
          "color": "#588ea8",
          "note": ""
        }
      ],
      "total": {
        "name": "全行防詐防堵合計",
        "amount": 9482.0,
        "count": 5858.0,
        "avg_per_card": 1.62,
        "share": 100.0,
        "unit": "萬元"
      },
      "subtotals": {
        "sfm": {
          "amount": 9225.0,
          "count": 5629.0
        },
        "tds": {
          "amount": 257.0,
          "count": 229.0
        }
      }
    },
    "microservices": {
      "services": [
        {
          "code": "ms_bonus_query",
          "name": "小樹點查詢",
          "calls": 11516.57,
          "unit": "萬次",
          "last_year": 10577.34,
          "prev_month": 11299.13,
          "yoy": 8.88,
          "mom": 1.92,
          "peak_tps": 670.0,
          "capacity_tps": null,
          "capacity_ratio": null,
          "color": "#009e73",
          "note": "小樹點查詢服務；峰值 1,850 TPS / 2,500 容量 (74%)"
        },
        {
          "code": "ms_reward_overview",
          "name": "回饋總覽",
          "calls": 996.37,
          "unit": "萬次",
          "last_year": 958.79,
          "prev_month": 1005.23,
          "yoy": 3.92,
          "mom": -0.88,
          "peak_tps": 92.0,
          "capacity_tps": null,
          "capacity_ratio": null,
          "color": "#003b5c",
          "note": "回饋總覽查詢服務；峰值 1,320 TPS / 2,000 容量 (66%)"
        },
        {
          "code": "ms_bonus_redeem",
          "name": "小樹點兌換",
          "calls": 210.94,
          "unit": "萬次",
          "last_year": 202.6,
          "prev_month": 204.7,
          "yoy": 4.12,
          "mom": 3.05,
          "peak_tps": 34.0,
          "capacity_tps": null,
          "capacity_ratio": null,
          "color": "#c9892e",
          "note": "小樹點兌換服務；峰值 620 TPS / 1,200 容量 (51.6%)"
        },
        {
          "code": "ms_ticket_service",
          "name": "票券服務",
          "calls": 23.39,
          "unit": "萬次",
          "last_year": null,
          "prev_month": 22.0,
          "yoy": null,
          "mom": 6.32,
          "peak_tps": 1217.0,
          "capacity_tps": null,
          "capacity_ratio": null,
          "color": "#7c4dff",
          "note": "票券服務（雲端）；峰值 380 TPS / 800 容量 (47.5%)"
        }
      ]
    }
  }
};
