import json
import re

with open('01_儀表板執行環境/dashboard_app.js', 'r', encoding='utf-8') as f:
    text = f.read()

b02_match = re.search(r'function renderBlock02FromData\(.*?\)\s*\{(.*?)\n  function renderBlock03FromData', text, re.DOTALL)
if b02_match:
    b02_code = b02_match.group(1)
    b02_ids = set(re.findall(r'getElementById\(["\']([^"\']+)["\']\)', b02_code))
    print(f'Block02 getElementByIds count: {len(b02_ids)}')
    print('b02 IDs:', sorted([x for x in b02_ids if x.startswith('b02-')]))

b03_match = re.search(r'function renderBlock03FromData\(.*?\)\s*\{(.*?)\n  function renderBlock04FromData', text, re.DOTALL)
if b03_match:
    b03_code = b03_match.group(1)
    b03_ids = set(re.findall(r'getElementById\(["\']([^"\']+)["\']\)', b03_code))
    print(f'\nBlock03 getElementByIds count: {len(b03_ids)}')
    print('b03 IDs:', sorted([x for x in b03_ids if x.startswith('b03-') or x.startswith('b04-')]))

data = json.load(open('01_儀表板執行環境/dashboard_data.json', encoding='utf-8'))
print('\n=== BLOCK 02 DATA KEYS ===')
print(list(data['block02'].keys()))
for k, v in data['block02'].items():
    if isinstance(v, dict):
        print(f'  {k}: {list(v.keys())}')
    elif isinstance(v, list):
        print(f'  {k}: list of {len(v)} items')

print('\n=== BLOCK 03 DATA KEYS ===')
print(list(data['block03'].keys()))
for k, v in data['block03'].items():
    if isinstance(v, dict):
        print(f'  {k}: {list(v.keys())}')
    elif isinstance(v, list):
        print(f'  {k}: list of {len(v)} items')
