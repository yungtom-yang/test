# -*- coding: utf-8 -*-
import urllib.request
import json
import asyncio
import websockets
import os
import subprocess
import time
import sys

sys.stdout.reconfigure(encoding='utf-8')

port = 9398
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)
html_abs = os.path.join(project_root, '01_儀表板執行環境', 'credit_card_full_dashboard.html')
html_uri = 'file:///' + html_abs.replace('\\', '/')

cmd = [
    r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
    '--headless=new',
    f'--remote-debugging-port={port}',
    '--window-size=1600,1200',
    '--no-sandbox',
    '--disable-gpu',
    html_uri
]
proc = subprocess.Popen(cmd)
time.sleep(2)

try:
    tabs = json.loads(urllib.request.urlopen(f'http://localhost:{port}/json').read().decode())
    page_tab = [t for t in tabs if t.get('type') == 'page'][0]
    
    async def run():
        async with websockets.connect(page_tab['webSocketDebuggerUrl']) as ws:
            console_msgs = []
            
            async def send_cmd(cmd_id, method, params=None):
                payload = {'id': cmd_id, 'method': method}
                if params:
                    payload['params'] = params
                await ws.send(json.dumps(payload))
                while True:
                    msg = json.loads(await ws.recv())
                    if 'method' in msg and 'Console' in msg['method']:
                        console_msgs.append(msg)
                    if msg.get('id') == cmd_id:
                        return msg

            await send_cmd(1, 'Console.enable')
            await send_cmd(2, 'Runtime.enable')

            # Test switching all 5 main sections
            for i, sec in enumerate(['section-cockpit', 'section-overview', 'section-acquiring', 'section-issuing', 'section-resilience']):
                await send_cmd(10 + i, 'Runtime.evaluate', {'expression': f'switchMainSection("{sec}")'})
                await asyncio.sleep(0.1)

            # Test all Issuing tabs 0 to 4
            for tab_idx in range(5):
                await send_cmd(30 + tab_idx, 'Runtime.evaluate', {'expression': f'switchIssTab({tab_idx})'})
                await asyncio.sleep(0.1)

            errors = [m for m in console_msgs if m.get('params', {}).get('message', {}).get('level') == 'error']
            print('Total console messages captured:', len(console_msgs))
            print('Console errors across all 5 sections & all tabs:', len(errors))
            if len(errors) == 0:
                print('100% CLEAN! ZERO REGRESSIONS!')

    asyncio.run(run())
finally:
    proc.kill()
