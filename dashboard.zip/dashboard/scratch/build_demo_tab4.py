# -*- coding: utf-8 -*-
import os
import re

demo_path = r"01_儀表板執行環境\demo.html"

with open(demo_path, "r", encoding="utf-8") as f:
    html = f.read()

# 1. Custom Scoped CSS for Tab 4 (Inside demo.html head or before iss-tab-4)
tab4_css = """
<style id="demo-tab4-css">
  #b03-inst-svg-wrapper {
    display: none !important;
  }
  .inst-analysis-container {
    display: flex;
    flex-direction: column;
    gap: 14px;
    padding: 4px 0;
  }
  .inst-headline-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
  }
  .inst-kpi-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 14px 18px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    box-shadow: 0 1px 2px rgba(0,0,0,0.03);
  }
  .inst-kpi-title {
    font-size: 13px;
    font-weight: 800;
    color: #475569;
    margin-bottom: 4px;
  }
  .inst-kpi-val-row {
    display: flex;
    align-items: baseline;
    gap: 5px;
  }
  .inst-kpi-num {
    font-size: 28px;
    font-weight: 900;
    color: #003b5c;
    line-height: 1.1;
    letter-spacing: -0.5px;
  }
  .inst-kpi-unit {
    font-size: 13px;
    font-weight: 800;
    color: #64748b;
  }
  .inst-kpi-sub {
    margin-top: 6px;
    font-size: 12px;
    font-weight: 800;
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .inst-sep {
    color: #cbd5e1;
    font-weight: normal;
  }
  .inst-dual-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
  }
  .inst-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 16px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    box-shadow: 0 1px 2px rgba(0,0,0,0.03);
  }
  .inst-card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .inst-card-title {
    font-size: 15px;
    font-weight: 900;
    color: #003b5c;
    margin: 0;
  }
  .inst-toggle-group {
    display: flex;
    align-items: center;
    gap: 4px;
    background: #f1f5f9;
    border-radius: 6px;
    padding: 3px;
    border: 1px solid #e2e8f0;
  }
  .inst-toggle-btn {
    border: none;
    background: transparent;
    padding: 4px 10px;
    font-size: 12px;
    font-weight: 800;
    color: #64748b;
    border-radius: 4px;
    cursor: pointer;
    transition: all 0.15s ease;
  }
  .inst-toggle-btn.active {
    background: #ffffff;
    color: #003b5c;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  }
  .inst-mix-chart-body, .inst-wf-chart-body {
    display: flex;
    flex-direction: column;
    gap: 10px;
    min-height: 180px;
  }
  .inst-mix-row {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }
  .inst-mix-meta {
    display: flex;
    justify-content: space-between;
    font-size: 12px;
    font-weight: 800;
    color: #475569;
  }
  .inst-mix-bar-track {
    display: flex;
    height: 26px;
    background: #e2e8f0;
    border-radius: 5px;
    overflow: hidden;
  }
  .inst-mix-seg {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #ffffff;
    font-size: 11.5px;
    font-weight: 800;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    padding: 0 4px;
    transition: width 0.3s ease;
  }
  .inst-layer-summary {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    padding: 10px 14px;
    font-size: 12px;
    color: #334155;
    line-height: 1.5;
  }
  .inst-wf-row {
    display: grid;
    grid-template-columns: 80px 1fr 110px;
    align-items: center;
    gap: 10px;
    font-size: 12px;
    font-weight: 800;
  }
  .inst-wf-name {
    color: #475569;
    white-space: nowrap;
  }
  .inst-wf-track {
    position: relative;
    height: 20px;
    background: #f1f5f9;
    border-radius: 4px;
    overflow: hidden;
  }
  .inst-wf-fill {
    height: 100%;
    border-radius: 4px;
    transition: width 0.3s ease;
  }
  .inst-wf-val {
    text-align: right;
    font-variant-numeric: tabular-nums;
  }
  .inst-wf-summary {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    padding: 10px 14px;
    font-size: 12px;
    color: #334155;
    line-height: 1.5;
  }
  .inst-legend {
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 11.5px;
    font-weight: 800;
    color: #64748b;
    margin-top: 4px;
  }
  .inst-legend-item {
    display: inline-flex;
    align-items: center;
    gap: 5px;
  }
  .inst-legend-dot {
    width: 9px;
    height: 9px;
    border-radius: 2px;
    display: inline-block;
  }
</style>
"""

# 2. Tab 4 HTML
tab4_html = """<!-- 3B Tab 4: 分期產品結構分析 (規模 ➔ 結構 ➔ 貢獻) -->
<div class="tab-content" id="iss-tab-4">
  <!-- 隱藏保留原始 DOM ID 確保既有 JS 存取安全 -->
  <div class="acq-channel-dual-grid" id="b03-inst-svg-wrapper" style="display: none !important;"></div>

  <!-- 新版結構化分析容器 -->
  <div class="inst-analysis-container" id="demo-tab4-content">
    <!-- 第一層：整體分期規模動能 -->
    <div class="inst-headline-grid">
      <div class="inst-kpi-card">
        <div class="inst-kpi-title">分期總金額</div>
        <div class="inst-kpi-val-row">
          <span class="inst-kpi-num" id="demo-inst-tot-amt">18.67</span>
          <span class="inst-kpi-unit">億元</span>
        </div>
        <div class="inst-kpi-sub" id="demo-inst-tot-amt-sub">
          <span class="number-down" id="demo-inst-tot-amt-yoy">YoY -15.9%</span>
        </div>
      </div>
      <div class="inst-kpi-card">
        <div class="inst-kpi-title">分期總筆數</div>
        <div class="inst-kpi-val-row">
          <span class="inst-kpi-num" id="demo-inst-tot-cnt">11.98</span>
          <span class="inst-kpi-unit">萬筆</span>
        </div>
        <div class="inst-kpi-sub" id="demo-inst-tot-cnt-sub">
          <span class="number-down" id="demo-inst-tot-cnt-mom">MoM -16.3%</span>
          <span class="inst-sep">｜</span>
          <span class="number-up" id="demo-inst-tot-cnt-yoy">YoY +0.9%</span>
        </div>
      </div>
      <div class="inst-kpi-card">
        <div class="inst-kpi-title">分期平均客單價</div>
        <div class="inst-kpi-val-row">
          <span class="inst-kpi-num" id="demo-inst-avg-ticket">$15,578</span>
          <span class="inst-kpi-unit">元</span>
        </div>
        <div class="inst-kpi-sub" id="demo-inst-avg-ticket-sub">
          <span class="number-down" id="demo-inst-avg-ticket-yoy">YoY -16.7%</span>
        </div>
      </div>
    </div>

    <!-- 第二、三層並列雙欄 Grid -->
    <div class="inst-dual-grid">
      <!-- 左欄：產品結構轉移分析 -->
      <div class="chart-box inst-card">
        <div class="inst-card-header">
          <div>
            <h3 class="inst-card-title">分期產品結構演變</h3>
          </div>
          <div class="inst-toggle-group">
            <button class="inst-toggle-btn active" id="btn-mix-cnt" onclick="switchInstMix('cnt')" type="button">筆數結構（行為偏好）</button>
            <button class="inst-toggle-btn" id="btn-mix-amt" onclick="switchInstMix('amt')" type="button">金額結構（營收體量）</button>
          </div>
        </div>

        <div class="inst-legend">
          <span class="inst-legend-item"><i class="inst-legend-dot" style="background:#003b5c;"></i> 授權單筆</span>
          <span class="inst-legend-item"><i class="inst-legend-dot" style="background:#2d6a8f;"></i> 請款單筆</span>
          <span class="inst-legend-item"><i class="inst-legend-dot" style="background:#588ea8;"></i> 帳單分期</span>
        </div>
        
        <!-- 三期結構長條圖 -->
        <div class="inst-mix-chart-body" id="inst-mix-chart"></div>

        <!-- 兩層式結構解讀卡 -->
        <div class="inst-layer-summary" id="inst-mix-summary"></div>
      </div>

      <!-- 右欄：成長變動貢獻分解 (Waterfall) -->
      <div class="chart-box inst-card">
        <div class="inst-card-header">
          <div>
            <h3 class="inst-card-title">成長變動貢獻分解</h3>
          </div>
          <div class="inst-toggle-group">
            <button class="inst-toggle-btn active" id="btn-wf-cnt" onclick="switchInstWf('cnt_mom')" type="button">筆數 MoM 貢獻</button>
            <button class="inst-toggle-btn" id="btn-wf-amt" onclick="switchInstWf('amt_yoy')" type="button">金額 YoY 貢獻</button>
          </div>
        </div>

        <!-- 瀑布圖本體 -->
        <div class="inst-wf-chart-body" id="inst-wf-chart"></div>

        <!-- 貢獻度結論摘要 -->
        <div class="inst-wf-summary" id="inst-wf-summary"></div>
      </div>
    </div>
  </div>
</div>"""

# 3. Dedicated Script for Tab 4 Dynamic Rendering & Interactivity
tab4_js = """
<script id="demo-tab4-logic">
  // Current active states
  window.instMixMode = 'cnt'; // 'cnt' or 'amt'
  window.instWfMode = 'cnt_mom'; // 'cnt_mom' or 'amt_yoy'

  function switchInstMix(mode) {
    window.instMixMode = mode;
    document.getElementById('btn-mix-cnt').classList.toggle('active', mode === 'cnt');
    document.getElementById('btn-mix-amt').classList.toggle('active', mode === 'amt');
    renderInstMixChart();
  }

  function switchInstWf(mode) {
    window.instWfMode = mode;
    document.getElementById('btn-wf-cnt').classList.toggle('active', mode === 'cnt_mom');
    document.getElementById('btn-wf-amt').classList.toggle('active', mode === 'amt_yoy');
    renderInstWfChart();
  }

  function renderDemoTab4() {
    const data = window.DASHBOARD_DATA;
    if (!data || !data.block03) return;
    const b3 = data.block03;
    const kpi = b3.monthly_kpis?.install_total || {};
    const prods = b3.installment_structure?.products || [];

    const pAuth = prods.find(p => p.code === 'inst_prod_auth') || {};
    const pSettle = prods.find(p => p.code === 'inst_prod_settle') || {};
    const pBill = prods.find(p => p.code === 'inst_prod_bill') || {};

    // 1. Headline Metrics
    const totAmtEl = document.getElementById('demo-inst-tot-amt');
    if (totAmtEl && kpi.value) totAmtEl.textContent = Number(kpi.value).toFixed(2);
    const totAmtYoyEl = document.getElementById('demo-inst-tot-amt-yoy');
    if (totAmtYoyEl && kpi.yoy !== null) {
      totAmtYoyEl.textContent = `YoY ${kpi.yoy > 0 ? '+' : ''}${kpi.yoy}%`;
      totAmtYoyEl.className = kpi.yoy >= 0 ? 'number-up' : 'number-down';
    }

    const totCntEl = document.getElementById('demo-inst-tot-cnt');
    if (totCntEl && kpi.count_total) totCntEl.textContent = Number(kpi.count_total).toFixed(2);
    const totCntMomEl = document.getElementById('demo-inst-tot-cnt-mom');
    if (totCntMomEl && kpi.count_mom !== null) {
      totCntMomEl.textContent = `MoM ${kpi.count_mom > 0 ? '+' : ''}${kpi.count_mom}%`;
      totCntMomEl.className = kpi.count_mom >= 0 ? 'number-up' : 'number-down';
    }
    const totCntYoyEl = document.getElementById('demo-inst-tot-cnt-yoy');
    if (totCntYoyEl && kpi.count_yoy !== null) {
      totCntYoyEl.textContent = `YoY ${kpi.count_yoy > 0 ? '+' : ''}${kpi.count_yoy}%`;
      totCntYoyEl.className = kpi.count_yoy >= 0 ? 'number-up' : 'number-down';
    }

    // Average ticket
    const totAmtRaw = (kpi.value || 0) * 100000000;
    const totCntRaw = (kpi.count_total || 0) * 10000;
    const avgTicket = totCntRaw > 0 ? Math.round(totAmtRaw / totCntRaw) : 0;
    const lyAmtRaw = (kpi.ly_amount || 0) * 100000000;
    const lyCntRaw = (kpi.ly_count || 0) * 10000;
    const lyAvgTicket = lyCntRaw > 0 ? Math.round(lyAmtRaw / lyCntRaw) : 0;
    const ticketYoy = lyAvgTicket > 0 ? (((avgTicket - lyAvgTicket) / lyAvgTicket) * 100).toFixed(1) : null;

    const avgTktEl = document.getElementById('demo-inst-avg-ticket');
    if (avgTktEl) avgTktEl.textContent = '$' + avgTicket.toLocaleString();
    const avgTktYoyEl = document.getElementById('demo-inst-avg-ticket-yoy');
    if (avgTktYoyEl && ticketYoy !== null) {
      avgTktYoyEl.textContent = `YoY ${ticketYoy > 0 ? '+' : ''}${ticketYoy}%`;
      avgTktYoyEl.className = ticketYoy >= 0 ? 'number-up' : 'number-down';
    }

    renderInstMixChart();
    renderInstWfChart();
  }

  function renderInstMixChart() {
    const data = window.DASHBOARD_DATA;
    if (!data || !data.block03) return;
    const prods = data.block03.installment_structure?.products || [];
    const pAuth = prods.find(p => p.code === 'inst_prod_auth') || {};
    const pSettle = prods.find(p => p.code === 'inst_prod_settle') || {};
    const pBill = prods.find(p => p.code === 'inst_prod_bill') || {};

    const chartEl = document.getElementById('inst-mix-chart');
    const summaryEl = document.getElementById('inst-mix-summary');
    if (!chartEl || !summaryEl) return;

    if (window.instMixMode === 'cnt') {
      // 筆數結構（三期完整齊備）
      const periods = [
        {
          label: '去年同期 (2025/08)',
          auth: pAuth.last_year_count || 3.6318,
          settle: pSettle.last_year_count || 4.4512,
          bill: pBill.last_year_count || 3.7985,
        },
        {
          label: '前期 (2026/07)',
          auth: pAuth.prev_count || 6.3289,
          settle: pSettle.prev_count || 3.8011,
          bill: pBill.prev_count || 4.1900,
        },
        {
          label: '本期 (2026/08)',
          auth: pAuth.count || 5.6657,
          settle: pSettle.count || 3.4028,
          bill: pBill.count || 2.9164,
        }
      ];

      chartEl.innerHTML = periods.map(p => {
        const total = p.auth + p.settle + p.bill;
        const pAuthPct = ((p.auth / total) * 100).toFixed(1);
        const pSettlePct = ((p.settle / total) * 100).toFixed(1);
        const pBillPct = ((p.bill / total) * 100).toFixed(1);
        const pSinglePct = (((p.auth + p.settle) / total) * 100).toFixed(1);

        return `
          <div class="inst-mix-row">
            <div class="inst-mix-meta">
              <span>${p.label}</span>
              <span>總筆數 ${total.toFixed(2)} 萬筆（單筆 ${pSinglePct}% ｜ 帳單 ${pBillPct}%）</span>
            </div>
            <div class="inst-mix-bar-track">
              <div class="inst-mix-seg" style="width:${pAuthPct}%; background:#003b5c;" title="授權單筆：${p.auth.toFixed(2)} 萬筆 (${pAuthPct}%)">
                授權 ${pAuthPct}%
              </div>
              <div class="inst-mix-seg" style="width:${pSettlePct}%; background:#2d6a8f;" title="請款單筆：${p.settle.toFixed(2)} 萬筆 (${pSettlePct}%)">
                請款 ${pSettlePct}%
              </div>
              <div class="inst-mix-seg" style="width:${pBillPct}%; background:#588ea8;" title="帳單分期：${p.bill.toFixed(2)} 萬筆 (${pBillPct}%)">
                帳單 ${pBillPct}%
              </div>
            </div>
          </div>
        `;
      }).join('');

      // 兩層式結論卡
      summaryEl.innerHTML = `
        <div style="font-weight:900; color:#003b5c; margin-bottom:4px;">兩層結構分析結論（客戶行為）：</div>
        <div>• <b>第一層（單筆 vs 帳單）</b>：單筆分期佔比自去年 <b>68.0%</b> 攀升至本期 <b>75.7%</b> (+7.7pp)；整份帳單分期萎縮至 <b>24.3%</b> (-7.7pp)，客戶明顯由事後整筆帳單轉移向單筆消費即時處置。</div>
        <div style="margin-top:2px;">• <b>第二層（授權 vs 請款）</b>：單筆分期內部以「授權單筆」佔大宗（佔單筆之 <b>62.5%</b>），顯示客戶偏好在交易授權成立當下即約定分期。</div>
      `;
    } else {
      // 金額結構（去年同期 vs 本期）
      const periods = [
        {
          label: '去年同期 (2025/08)',
          auth: pAuth.last_year || 5.528,
          settle: pSettle.last_year || 6.776,
          bill: pBill.last_year || 9.904,
        },
        {
          label: '本期 (2026/08)',
          auth: pAuth.amount || 6.66,
          settle: pSettle.amount || 4.00,
          bill: pBill.amount || 8.01,
        }
      ];

      chartEl.innerHTML = periods.map(p => {
        const total = p.auth + p.settle + p.bill;
        const pAuthPct = ((p.auth / total) * 100).toFixed(1);
        const pSettlePct = ((p.settle / total) * 100).toFixed(1);
        const pBillPct = ((p.bill / total) * 100).toFixed(1);
        const pSinglePct = (((p.auth + p.settle) / total) * 100).toFixed(1);

        return `
          <div class="inst-mix-row">
            <div class="inst-mix-meta">
              <span>${p.label}</span>
              <span>總金額 ${total.toFixed(2)} 億元（單筆 ${pSinglePct}% ｜ 帳單 ${pBillPct}%）</span>
            </div>
            <div class="inst-mix-bar-track">
              <div class="inst-mix-seg" style="width:${pAuthPct}%; background:#003b5c;" title="授權單筆：${p.auth.toFixed(2)} 億元 (${pAuthPct}%)">
                授權 ${pAuthPct}%
              </div>
              <div class="inst-mix-seg" style="width:${pSettlePct}%; background:#2d6a8f;" title="請款單筆：${p.settle.toFixed(2)} 億元 (${pSettlePct}%)">
                請款 ${pSettlePct}%
              </div>
              <div class="inst-mix-seg" style="width:${pBillPct}%; background:#588ea8;" title="帳單分期：${p.bill.toFixed(2)} 億元 (${pBillPct}%)">
                帳單 ${pBillPct}%
              </div>
            </div>
          </div>
        `;
      }).join('');

      summaryEl.innerHTML = `
        <div style="font-weight:900; color:#003b5c; margin-bottom:4px;">兩層結構分析結論（營收體量）：</div>
        <div>• <b>第一層（單筆 vs 帳單）</b>：單筆分期總額 <b>10.66 億元</b> (佔 <b>57.1%</b>)，超越帳單分期 <b>8.01 億元</b> (佔 <b>42.9%</b>)。</div>
        <div style="margin-top:2px;">• <b>第二層（授權 vs 請款）</b>：授權分期金額較去年逆勢成長 <b>+20.5%</b> (5.53億 ➔ 6.66億)，請款單筆與帳單分期則呈現雙位數衰退。</div>
      `;
    }
  }

  function renderInstWfChart() {
    const data = window.DASHBOARD_DATA;
    if (!data || !data.block03) return;
    const prods = data.block03.installment_structure?.products || [];
    const pAuth = prods.find(p => p.code === 'inst_prod_auth') || {};
    const pSettle = prods.find(p => p.code === 'inst_prod_settle') || {};
    const pBill = prods.find(p => p.code === 'inst_prod_bill') || {};

    const chartEl = document.getElementById('inst-wf-chart');
    const summaryEl = document.getElementById('inst-wf-summary');
    if (!chartEl || !summaryEl) return;

    if (window.instWfMode === 'cnt_mom') {
      // 筆數 MoM 瀑布分解
      const baseVal = 14.32; // 前月 14.32 萬筆
      const finalVal = 11.9849; // 本月 11.98 萬筆
      const deltaTotal = finalVal - baseVal; // -2.3351 萬筆 (-16.31%)

      // 各自變動量
      const dBills = 2.9164 - 4.1900; // -1.2736
      const dAuth = 5.6657 - 6.3289;   // -0.6632
      const dSettle = 3.4028 - 3.8011; // -0.3983

      const cBills = ((dBills / baseVal) * 100).toFixed(2); // -8.89%
      const cAuth = ((dAuth / baseVal) * 100).toFixed(2);   // -4.63%
      const cSettle = ((dSettle / baseVal) * 100).toFixed(2);// -2.78%

      const maxAbs = Math.max(Math.abs(dBills), Math.abs(dAuth), Math.abs(dSettle), 0.1);

      chartEl.innerHTML = `
        <div class="inst-wf-row" style="border-bottom:1px solid #e2e8f0; padding-bottom:6px;">
          <span class="inst-wf-name" style="color:#003b5c; font-weight:900;">前期基準</span>
          <div class="inst-wf-track"><div class="inst-wf-fill" style="width:100%; background:#94a3b8;"></div></div>
          <span class="inst-wf-val" style="color:#003b5c; font-weight:900;">14.32 萬筆</span>
        </div>
        <div class="inst-wf-row">
          <span class="inst-wf-name">帳單分期</span>
          <div class="inst-wf-track">
            <div class="inst-wf-fill" style="width:${(Math.abs(dBills) / maxAbs) * 85}%; background:#d9383a;"></div>
          </div>
          <span class="inst-wf-val number-down">${dBills.toFixed(2)}萬 (${cBills}pp)</span>
        </div>
        <div class="inst-wf-row">
          <span class="inst-wf-name">授權單筆</span>
          <div class="inst-wf-track">
            <div class="inst-wf-fill" style="width:${(Math.abs(dAuth) / maxAbs) * 85}%; background:#d9383a;"></div>
          </div>
          <span class="inst-wf-val number-down">${dAuth.toFixed(2)}萬 (${cAuth}pp)</span>
        </div>
        <div class="inst-wf-row">
          <span class="inst-wf-name">請款單筆</span>
          <div class="inst-wf-track">
            <div class="inst-wf-fill" style="width:${(Math.abs(dSettle) / maxAbs) * 85}%; background:#d9383a;"></div>
          </div>
          <span class="inst-wf-val number-down">${dSettle.toFixed(2)}萬 (${cSettle}pp)</span>
        </div>
        <div class="inst-wf-row" style="border-top:1px solid #e2e8f0; padding-top:6px;">
          <span class="inst-wf-name" style="color:#003b5c; font-weight:900;">本期總計</span>
          <div class="inst-wf-track"><div class="inst-wf-fill" style="width:83.7%; background:#003b5c;"></div></div>
          <span class="inst-wf-val" style="color:#003b5c; font-weight:900;">11.98 萬筆 (-16.3%)</span>
        </div>
      `;

      summaryEl.innerHTML = `
        <div style="font-weight:900; color:#003b5c; margin-bottom:4px;">變動歸因診斷（筆數 MoM）：</div>
        <div>整體筆數 MoM 減少 <b>2.34 萬筆 (-16.3%)</b>，其中高達 <b>54.5%</b> 的衰退來自於 <b>帳單分期</b>（貢獻度 -8.89pp），顯示本月客戶並非整體不辦分期，而是大幅減少了整期帳單分期的申請。</div>
      `;
    } else {
      // 金額 YoY 瀑布分解
      const baseVal = 22.208; // 去年 22.21 億元
      const finalVal = 18.67;  // 本期 18.67 億元
      const dTotal = finalVal - baseVal; // -3.538 億元 (-15.93%)

      const dAuth = 6.660 - 5.528;   // +1.132 億元
      const dSettle = 4.000 - 6.776; // -2.776 億元
      const dBill = 8.010 - 9.904;   // -1.894 億元

      const cAuth = ((dAuth / baseVal) * 100).toFixed(2);   // +5.10%
      const cSettle = ((dSettle / baseVal) * 100).toFixed(2);// -12.50%
      const cBill = ((dBill / baseVal) * 100).toFixed(2);   // -8.53%

      const maxAbs = Math.max(Math.abs(dAuth), Math.abs(dSettle), Math.abs(dBill), 0.1);

      chartEl.innerHTML = `
        <div class="inst-wf-row" style="border-bottom:1px solid #e2e8f0; padding-bottom:6px;">
          <span class="inst-wf-name" style="color:#003b5c; font-weight:900;">去年基準</span>
          <div class="inst-wf-track"><div class="inst-wf-fill" style="width:100%; background:#94a3b8;"></div></div>
          <span class="inst-wf-val" style="color:#003b5c; font-weight:900;">22.21 億元</span>
        </div>
        <div class="inst-wf-row">
          <span class="inst-wf-name">授權單筆</span>
          <div class="inst-wf-track">
            <div class="inst-wf-fill" style="width:${(Math.abs(dAuth) / maxAbs) * 85}%; background:#009e73;"></div>
          </div>
          <span class="inst-wf-val number-up">+${dAuth.toFixed(2)}億 (+${cAuth}pp)</span>
        </div>
        <div class="inst-wf-row">
          <span class="inst-wf-name">請款單筆</span>
          <div class="inst-wf-track">
            <div class="inst-wf-fill" style="width:${(Math.abs(dSettle) / maxAbs) * 85}%; background:#d9383a;"></div>
          </div>
          <span class="inst-wf-val number-down">${dSettle.toFixed(2)}億 (${cSettle}pp)</span>
        </div>
        <div class="inst-wf-row">
          <span class="inst-wf-name">帳單分期</span>
          <div class="inst-wf-track">
            <div class="inst-wf-fill" style="width:${(Math.abs(dBill) / maxAbs) * 85}%; background:#d9383a;"></div>
          </div>
          <span class="inst-wf-val number-down">${dBill.toFixed(2)}億 (${cBill}pp)</span>
        </div>
        <div class="inst-wf-row" style="border-top:1px solid #e2e8f0; padding-top:6px;">
          <span class="inst-wf-name" style="color:#003b5c; font-weight:900;">本期總計</span>
          <div class="inst-wf-track"><div class="inst-wf-fill" style="width:84.1%; background:#003b5c;"></div></div>
          <span class="inst-wf-val" style="color:#003b5c; font-weight:900;">18.67 億元 (-15.9%)</span>
        </div>
      `;

      summaryEl.innerHTML = `
        <div style="font-weight:900; color:#003b5c; margin-bottom:4px;">變動歸因診斷（金額 YoY）：</div>
        <div>整體分期金額較去年減少 <b>3.54 億元 (-15.9%)</b>。拆解貢獻度後可明確識別：<b>授權單筆是唯一逆勢成長 (+1.13億 / +5.1pp) 的正向主力</b>；整體跌幅主要來自 <b>請款單筆 (-2.78億 / -12.5pp)</b> 與 <b>帳單分期 (-1.89億 / -8.5pp)</b>。</div>
      `;
    }
  }

  // Hook into DOMContentLoaded after dashboard_app.js has executed
  window.addEventListener('DOMContentLoaded', () => {
    setTimeout(renderDemoTab4, 100);
  });
</script>
"""

# Replace in demo.html
# 1. Inject CSS into <head>
if '</head>' in html and 'demo-tab4-css' not in html:
    html = html.replace('</head>', tab4_css + '\n</head>')

# 2. Replace Tab 4 content
old_tab4 = '<div class="tab-content" id="iss-tab-4">\n<div class="acq-channel-dual-grid" id="b03-inst-svg-wrapper">\n</div>\n</div>'
if old_tab4 in html:
    html = html.replace(old_tab4, tab4_html)
    print("Tab 4 HTML replaced via exact match!")
else:
    # Try regex match
    pattern = re.compile(r'<div class="tab-content" id="iss-tab-4">.*?</div>\s*</div>', re.DOTALL)
    if pattern.search(html):
        html = pattern.sub(tab4_html, html)
        print("Tab 4 HTML replaced via regex match!")
    else:
        print("ERROR: Tab 4 target not found!")

# 3. Inject JS before </body>
if '</body>' in html and 'demo-tab4-logic' not in html:
    html = html.replace('</body>', tab4_js + '\n</body>')

with open(demo_path, 'w', encoding='utf-8') as f:
    f.write(html)

print("demo.html updated with new Tab 4 successfully!")
