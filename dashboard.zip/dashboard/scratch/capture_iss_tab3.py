# -*- coding: utf-8 -*-
import os
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

opts = Options()
opts.add_argument('--headless')
opts.add_argument('--window-size=1600,1200')
opts.add_argument('--disable-gpu')

driver = webdriver.Chrome(options=opts)
html_path = os.path.abspath('01_儀表板執行環境/credit_card_full_dashboard.html')
driver.get(f'file:///{html_path.replace(os.sep, "/")}')
time.sleep(2)

driver.execute_script("switchMainSection('section-issuing'); switchIssTab(3);")
time.sleep(1)

out_dir = r"C:\Users\詠棠\.gemini\antigravity\brain\481f5639-3c51-435d-a7c2-e9b2ea99ea3d"
driver.save_screenshot(os.path.join(out_dir, "current_iss_tab3_full.png"))
elem = driver.find_element(By.ID, "iss-tab-3")
elem.screenshot(os.path.join(out_dir, "current_iss_tab3_cards.png"))
driver.quit()
print("SUCCESS capturing iss tab 3")
