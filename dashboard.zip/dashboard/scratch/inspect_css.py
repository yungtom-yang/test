import re

with open('01_儀表板執行環境/dashboard.css', 'r', encoding='utf-8') as f:
    css = f.read()

classes = re.findall(r'(\.[a-zA-Z0-9_-]*(?:memo|note|tooltip|hint|info)[a-zA-Z0-9_-]*)', css, re.IGNORECASE)
print('CSS classes related to note/memo/tooltip/hint/info:')
for c in sorted(set(classes)):
    print(' ', c)

with open('01_儀表板執行環境/credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Check tooltips or titles
titles = re.findall(r'title="([^"]+)"', html)
print(f'\nCount of title attributes in HTML: {len(titles)}')
print('Sample title attributes:')
for t in titles[:10]:
    print(' ', t)
