# -*- coding: utf-8 -*-
import sys
import os

demo_file = r"01_儀表板執行環境\demo.html"

with open(demo_file, "r", encoding="utf-8") as f:
    html = f.read()

# 1. Replace the block from c00-card-cnt down to cell-iss-1c
# First, let's find the separator in c00-card-cnt
target_auth_block = """<!-- 同格分隔線 -->
<div style="border-top: 1px dashed #cbd5e1; margin: 8px 0 6px;"></div>
<!-- 授權交易總數 -->
<div class="c-kpi-header-row">
<span class="c-kpi-title">授權交易總數</span>
<div class="c-kpi-growth" id="c00-iss-auth-growth">-</div>
</div>
<div class="c-kpi-val-row">
<div class="c-kpi-main-val" id="c00-iss-auth-val">-</div>
<div class="c-daily-stat"><span class="d-lbl">日均</span><span class="d-val">253.8 萬筆</span></div>
</div>
<div class="c-ratio-bar-wrap">
<div class="c-ratio-bar-track">
<div class="c-ratio-seg seg-credit" id="c00-iss-auth-seg-crd" style="width: 0%;" title="信用卡: -"></div>
<div class="c-ratio-seg seg-debit" id="c00-iss-auth-seg-dbt" style="width: 0%;" title="簽帳卡: -"></div>
</div>
</div>
<div class="c-ratio-data-row">
<div class="c-ratio-col">
<span class="r-label"><span class="r-dot dot-credit"></span>信用卡 <span class="r-pct r-pct-credit" id="c00-iss-auth-crd-pct">(-%)</span></span>
<strong class="r-val" id="c00-iss-auth-crd-val">-</strong>
</div>
<div class="c-ratio-col align-right">
<span class="r-label"><span class="r-dot dot-debit"></span>簽帳卡 <span class="r-pct r-pct-debit" id="c00-iss-auth-dbt-pct">(-%)</span></span>
<strong class="r-val" id="c00-iss-auth-dbt-val">-</strong>
</div>
</div>"""

# Replace target_auth_block with nothing inside c00-card-cnt
if target_auth_block in html:
    html = html.replace(target_auth_block, "")
    print("Successfully removed visible auth block from c00-card-cnt")
else:
    print("Warning: target_auth_block not found exactly, trying relaxed search")

# 2. Add hidden preservation container for c00-iss-auth-* DOM IDs into c-kpi-mini-grid
target_mini_grid = """<div class="c-kpi-mini-grid" style="display: none;">
<div class="c-mini-kpi">
<span class="c-kpi-title">預借現金金額</span>"""

replacement_mini_grid = """<div class="c-kpi-mini-grid" style="display: none;">
<!-- 隱藏保留 DOM ID 確保 JS 數據注入 100% 正常 (授權交易總數 8 個 ID 完整保留) -->
<div id="c00-iss-auth-growth"></div>
<div id="c00-iss-auth-val"></div>
<div id="c00-iss-auth-seg-crd"></div>
<div id="c00-iss-auth-seg-dbt"></div>
<div id="c00-iss-auth-crd-pct"></div>
<div id="c00-iss-auth-crd-val"></div>
<div id="c00-iss-auth-dbt-pct"></div>
<div id="c00-iss-auth-dbt-val"></div>
<div class="c-mini-kpi">
<span class="c-kpi-title">預借現金金額</span>"""

if target_mini_grid in html:
    html = html.replace(target_mini_grid, replacement_mini_grid)
    print("Successfully injected hidden preservation container for c00-iss-auth-*")
else:
    print("Warning: target_mini_grid not found")

# 3. Replace cell-iss-1c block with the two-variant demo container
old_cell_1c_start = '<div class="cockpit-subbox c-tier2-card cell-iss-1c"'
old_cell_1c_end = '<div class="cockpit-col-2">'

idx_1c = html.find(old_cell_1c_start)
idx_col2 = html.find(old_cell_1c_end)

if idx_1c != -1 and idx_col2 != -1:
    old_cell_1c_html = html[idx_1c:idx_col2]
    
    new_cell_1c_html = """<div class="cockpit-subbox c-tier2-card cell-iss-1c" style="cursor: default;">
<div class="cockpit-box-title" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
  <div style="display: flex; align-items: center; gap: 8px;">
    <span id="c00-peer-box-title">五大發卡行簽帳金額</span>
    <span class="cockpit-tag-pill">2026 年 1–8 月</span>
  </div>
  <!-- 方案切換器 (Demo 環境專屬) -->
  <div class="demo-variant-toggle" style="display: inline-flex; background: #e2e8f0; border-radius: 6px; padding: 2px; gap: 2px;">
    <button type="button" id="btn-variant-bar" class="demo-v-btn active" onclick="switchPeerVariant('bar')">方案 1：水平長條排名</button>
    <button type="button" id="btn-variant-donut" class="demo-v-btn" onclick="switchPeerVariant('donut')">方案 2：升級版大環圖</button>
  </div>
</div>

<!-- ==============================================
     方案 1: 水平長條競爭排名圖 (Horizontal Ranking Bars)
     ============================================== -->
<div id="peer-view-bar" class="peer-variant-view" style="display: flex; flex-direction: column; justify-content: space-between; height: 100%; flex: 1;">
  <!-- 頂部五大行簽帳總額精簡摘要列 -->
  <div class="bar-summary-strip">
    <div class="b-sum-left">
      <span class="b-sum-lbl">五大行簽帳總額</span>
      <strong class="b-sum-val" id="bar-sum-val">24,534.2 <em>億元</em></strong>
    </div>
    <div class="b-sum-right">
      <span class="b-sum-yoy number-positive" id="bar-sum-yoy">YoY +18.5%</span>
      <span class="b-sum-hint">五大行合計</span>
    </div>
  </div>

  <!-- 水平長條表格標頭 -->
  <div class="bar-table-header">
    <span class="b-col-rank">排名</span>
    <span class="b-col-name">發卡銀行</span>
    <span class="b-col-track">簽帳規模與市場佔比</span>
    <span class="b-col-yoy">YoY</span>
  </div>

  <!-- 5 家發卡行長條列 (動態/高保真預渲染) -->
  <div class="bar-rows-list" id="bar-rows-list">
    <!-- Row 1: 中國信託 -->
    <div class="bar-row-item">
      <div class="b-rank-badge rank-1">1</div>
      <div class="b-bank-name"><span class="peer-color-dot" style="background:#003b5c;"></span>中國信託</div>
      <div class="b-track-container">
        <div class="b-track-bar-bg">
          <div class="b-track-bar-fill" style="width: 100%; background: #003b5c;"></div>
        </div>
        <div class="b-track-meta">
          <span class="b-track-val">6,457.4 億元</span>
          <span class="b-track-share">26.3%</span>
        </div>
      </div>
      <div class="b-yoy-val number-positive">YoY +25.9%</div>
    </div>

    <!-- Row 2: 國泰世華 (本行高亮) -->
    <div class="bar-row-item highlight">
      <div class="b-rank-badge rank-2">2</div>
      <div class="b-bank-name cathay"><span class="peer-color-dot" style="background:#009e73;"></span>國泰世華</div>
      <div class="b-track-container">
        <div class="b-track-bar-bg">
          <div class="b-track-bar-fill" style="width: 88.7%; background: #009e73;"></div>
        </div>
        <div class="b-track-meta">
          <span class="b-track-val" style="color: #009e73; font-weight:900;">5,726.2 億元</span>
          <span class="b-track-share" style="color: #009e73; font-weight:900;">23.3%</span>
        </div>
      </div>
      <div class="b-yoy-val number-positive">YoY +17.1%</div>
    </div>

    <!-- Row 3: 玉山銀行 -->
    <div class="bar-row-item">
      <div class="b-rank-badge rank-3">3</div>
      <div class="b-bank-name"><span class="peer-color-dot" style="background:#059669;"></span>玉山銀行</div>
      <div class="b-track-container">
        <div class="b-track-bar-bg">
          <div class="b-track-bar-fill" style="width: 72.9%; background: #059669;"></div>
        </div>
        <div class="b-track-meta">
          <span class="b-track-val">4,705.5 億元</span>
          <span class="b-track-share">19.2%</span>
        </div>
      </div>
      <div class="b-yoy-val number-positive">YoY +18.4%</div>
    </div>

    <!-- Row 4: 台北富邦 -->
    <div class="bar-row-item">
      <div class="b-rank-badge">4</div>
      <div class="b-bank-name"><span class="peer-color-dot" style="background:#2563eb;"></span>台北富邦</div>
      <div class="b-track-container">
        <div class="b-track-bar-bg">
          <div class="b-track-bar-fill" style="width: 60.3%; background: #2563eb;"></div>
        </div>
        <div class="b-track-meta">
          <span class="b-track-val">3,893.6 億元</span>
          <span class="b-track-share">15.9%</span>
        </div>
      </div>
      <div class="b-yoy-val number-positive">YoY +6.4%</div>
    </div>

    <!-- Row 5: 台新銀行 -->
    <div class="bar-row-item">
      <div class="b-rank-badge">5</div>
      <div class="b-bank-name"><span class="peer-color-dot" style="background:#ea580c;"></span>台新銀行</div>
      <div class="b-track-container">
        <div class="b-track-bar-bg">
          <div class="b-track-bar-fill" style="width: 58.1%; background: #ea580c;"></div>
        </div>
        <div class="b-track-meta">
          <span class="b-track-val">3,751.5 億元</span>
          <span class="b-track-share">15.3%</span>
        </div>
      </div>
      <div class="b-yoy-val number-positive">YoY +22.7%</div>
    </div>
  </div>
</div>

<!-- ==============================================
     方案 2: 升級版大環圖 (Expanded Donut & Benchmark)
     ============================================== -->
<div id="peer-view-donut" class="peer-variant-view" style="display: none; flex-direction: column; justify-content: space-between; height: 100%; flex: 1;">
  <div class="cockpit-market-vertical-wrap expanded" style="display: flex; flex-direction: column; gap: 8px; flex: 1; justify-content: space-between;">
    <div class="cockpit-donut-hero-row expanded" style="display: flex; align-items: center; justify-content: center; gap: 20px; padding: 6px 0;">
      <div class="cockpit-donut-chart-wrap expanded" id="c00-donut-wrap" style="position: relative; width: 130px; height: 130px; display: flex; align-items: center; justify-content: center;">
        <svg height="130" style="display:block;" viewbox="0 0 140 140" width="130">
          <circle cx="70" cy="70" fill="none" r="56" stroke="#e2e8f0" stroke-width="20"></circle>
          <circle cx="70" cy="70" fill="#ffffff" r="44"></circle>
        </svg>
      </div>
      <div class="cockpit-donut-summary-side expanded" style="text-align: left; display: flex; flex-direction: column; justify-content: center;">
        <div class="c-market-stat-label" id="c00-market-label" style="font-size: 13px; font-weight: 800; color: #64748b;">五大行簽帳總額</div>
        <div class="c-market-stat-val" id="c00-market-val" style="font-size: 24px; font-weight: 900; color: #003b5c; line-height: 1.2;">24,534.2 <em>億元</em></div>
        <div class="c-market-stat-sub" id="c00-market-sub" style="margin-top: 3px;">
          <span class="number-positive" id="c00-market-yoy" style="font-size: 13.5px; font-weight: 900;">YoY +18.5%</span>
        </div>
      </div>
    </div>
    <div class="cockpit-peer-table-box expanded" style="flex: 1; display: flex; flex-direction: column; justify-content: space-between;">
      <div class="cockpit-peer-header" style="font-size: 12px; padding: 3px 6px; color: #64748b; font-weight: 800; border-bottom: 1px solid #e2e8f0;">
        <span class="p-name">發卡銀行</span>
        <span class="p-val">簽帳金額</span>
        <span class="p-share">佔比</span>
        <span class="p-yoy">YoY</span>
      </div>
      <div class="cockpit-peer-list expanded" id="c00-peer-list" style="display: flex; flex-direction: column; justify-content: space-between; flex: 1; gap: 3px;">
        <div class="cockpit-peer-row">
          <span class="p-name"><span class="peer-color-dot" style="background:#003b5c;"></span>中國信託</span>
          <span class="p-val">6,457.4 億元</span>
          <span class="p-share"><b>26.3%</b></span>
          <span class="p-yoy number-positive">+25.9%</span>
        </div>
        <div class="cockpit-peer-row highlight">
          <span class="p-name"><span class="peer-color-dot" style="background:#009e73;"></span>國泰世華</span>
          <span class="p-val">5,726.2 億元</span>
          <span class="p-share"><b>23.3%</b></span>
          <span class="p-yoy number-positive">+17.1%</span>
        </div>
        <div class="cockpit-peer-row">
          <span class="p-name"><span class="peer-color-dot" style="background:#059669;"></span>玉山銀行</span>
          <span class="p-val">4,705.5 億元</span>
          <span class="p-share"><b>19.2%</b></span>
          <span class="p-yoy number-positive">+18.4%</span>
        </div>
        <div class="cockpit-peer-row">
          <span class="p-name"><span class="peer-color-dot" style="background:#2563eb;"></span>台北富邦</span>
          <span class="p-val">3,893.6 億元</span>
          <span class="p-share"><b>15.9%</b></span>
          <span class="p-yoy number-positive">+6.4%</span>
        </div>
        <div class="cockpit-peer-row">
          <span class="p-name"><span class="peer-color-dot" style="background:#ea580c;"></span>台新銀行</span>
          <span class="p-val">3,751.5 億元</span>
          <span class="p-share"><b>15.3%</b></span>
          <span class="p-yoy number-positive">+22.7%</span>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>
"""
    html = html[:idx_1c] + new_cell_1c_html + html[idx_col2:]
    print("Successfully replaced cell-iss-1c with two-variant container")
else:
    print(f"Error finding cell-iss-1c: idx_1c={idx_1c}, idx_col2={idx_col2}")

# 4. Inject styles and switch script right before </head> or </body>
custom_css_js = """
<style id="demo-peer-variants-style">
  /* Demo 專用：五大發卡行彈性高度擴增與完美對齊 */
  .cell-iss-1a {
    flex: 0 0 auto !important;
  }
  .cell-iss-1c {
    flex: 1 1 auto !important;
    display: flex !important;
    flex-direction: column !important;
    justify-content: space-between !important;
    min-height: 0 !important;
    padding: 12px 14px !important;
  }
  
  /* 切換按鈕 */
  .demo-v-btn {
    border: none;
    background: transparent;
    color: #475569;
    font-size: 11px;
    font-weight: 800;
    padding: 3px 8px;
    border-radius: 4px;
    cursor: pointer;
    transition: all 0.15s ease;
  }
  .demo-v-btn.active {
    background: #009e73;
    color: #ffffff;
    box-shadow: 0 1px 2px rgba(0,0,0,0.12);
  }

  /* 方案 1: 水平長條排名樣式 */
  .bar-summary-strip {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    padding: 7px 10px;
    margin-bottom: 6px;
  }
  .b-sum-left { display: flex; align-items: baseline; gap: 8px; }
  .b-sum-lbl { font-size: 12px; font-weight: 800; color: #475569; }
  .b-sum-val { font-size: 18px; font-weight: 900; color: #003b5c; }
  .b-sum-val em { font-size: 11.5px; font-weight: 700; color: #64748b; font-style: normal; margin-left: 2px; }
  .b-sum-right { display: flex; align-items: center; gap: 6px; }
  .b-sum-yoy { font-size: 12.5px; font-weight: 900; }
  .b-sum-hint { font-size: 10.5px; color: #94a3b8; font-weight: 700; }

  .bar-table-header {
    display: grid;
    grid-template-columns: 24px 70px 1fr 76px;
    align-items: center;
    gap: 8px;
    padding: 3px 6px;
    font-size: 11px;
    font-weight: 800;
    color: #64748b;
    border-bottom: 1px solid #e2e8f0;
  }
  .b-col-rank { text-align: center; }
  .b-col-name { text-align: left; }
  .b-col-track { text-align: left; padding-left: 2px; }
  .b-col-yoy { text-align: right; }

  .bar-rows-list {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    flex: 1;
    gap: 5px;
    margin-top: 4px;
  }
  .bar-row-item {
    display: grid;
    grid-template-columns: 24px 70px 1fr 76px;
    align-items: center;
    gap: 8px;
    padding: 5px 6px;
    border-radius: 6px;
    background: #ffffff;
    border: 1px solid #f1f5f9;
    box-shadow: 0 1px 2px rgba(0,0,0,0.02);
  }
  .bar-row-item.highlight {
    background: #f0fdf4 !important;
    border: 1.5px solid #86efac !important;
  }
  .b-rank-badge {
    width: 20px;
    height: 20px;
    line-height: 20px;
    text-align: center;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 900;
    background: #f1f5f9;
    color: #64748b;
  }
  .b-rank-badge.rank-1 { background: #fef3c7; color: #b45309; }
  .b-rank-badge.rank-2 { background: #dcfce7; color: #15803d; }
  .b-rank-badge.rank-3 { background: #e0f2fe; color: #0369a1; }
  .b-bank-name {
    font-size: 12.5px;
    font-weight: 800;
    color: #1e293b;
    white-space: nowrap;
    display: flex;
    align-items: center;
    gap: 4px;
  }
  .b-bank-name.cathay {
    color: #009e73;
    font-weight: 900;
  }
  .b-track-container {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }
  .b-track-bar-bg {
    height: 10px;
    background: #f1f5f9;
    border-radius: 5px;
    overflow: hidden;
  }
  .b-track-bar-fill {
    height: 100%;
    border-radius: 5px;
    transition: width 0.3s ease;
  }
  .b-track-meta {
    display: flex;
    justify-content: space-between;
    font-size: 11px;
    font-variant-numeric: tabular-nums;
    line-height: 1.15;
  }
  .b-track-val { font-weight: 800; color: #334155; }
  .b-track-share { font-weight: 800; color: #64748b; }
  .b-yoy-val {
    font-size: 12px;
    font-weight: 800;
    text-align: right;
    white-space: nowrap;
  }

  /* 方案 2: 升級版大環圖樣式 */
  .cockpit-donut-chart-wrap.expanded svg {
    width: 128px !important;
    height: 128px !important;
  }
  .cockpit-peer-list.expanded .cockpit-peer-row {
    padding: 5px 8px !important;
    font-size: 13px !important;
  }
</style>

<script id="demo-peer-variants-script">
  function switchPeerVariant(variant) {
    const viewBar = document.getElementById("peer-view-bar");
    const viewDonut = document.getElementById("peer-view-donut");
    const btnBar = document.getElementById("btn-variant-bar");
    const btnDonut = document.getElementById("btn-variant-donut");

    if (variant === 'bar') {
      if (viewBar) viewBar.style.display = "flex";
      if (viewDonut) viewDonut.style.display = "none";
      if (btnBar) btnBar.classList.add("active");
      if (btnDonut) btnDonut.classList.remove("active");
    } else {
      if (viewBar) viewBar.style.display = "none";
      if (viewDonut) viewDonut.style.display = "flex";
      if (btnBar) btnBar.classList.remove("active");
      if (btnDonut) btnDonut.classList.add("active");
      
      // 確保 Donut 切片在放大尺寸下渲染完美
      renderExpandedDonut();
    }
  }

  function renderExpandedDonut() {
    const donutWrap = document.getElementById("c00-donut-wrap");
    if (!donutWrap) return;
    const donutData = (window.dashboardData && window.dashboardData.b01 && window.dashboardData.b01.cockpit_peer_donut) || {};
    if (!donutData.peers) return;

    let cumulativeAngle = 0;
    const radiusOuter = 62;
    const radiusInner = 42;
    const cx = 70, cy = 70;

    const paths = donutData.peers.filter(p => p.share && p.share > 0).map(p => {
      const sliceAngle = (p.share / 100) * 360;
      const startAngle = cumulativeAngle;
      const endAngle = cumulativeAngle + sliceAngle;
      cumulativeAngle = endAngle;

      const startRad = (startAngle - 90) * Math.PI / 180;
      const endRad = (endAngle - 90) * Math.PI / 180;

      const x1 = (cx + radiusOuter * Math.cos(startRad)).toFixed(2);
      const y1 = (cy + radiusOuter * Math.sin(startRad)).toFixed(2);
      const x2 = (cx + radiusOuter * Math.cos(endRad)).toFixed(2);
      const y2 = (cy + radiusOuter * Math.sin(endRad)).toFixed(2);

      const x3 = (cx + radiusInner * Math.cos(endRad)).toFixed(2);
      const y3 = (cy + radiusInner * Math.sin(endRad)).toFixed(2);
      const x4 = (cx + radiusInner * Math.cos(startRad)).toFixed(2);
      const y4 = (cy + radiusInner * Math.sin(startRad)).toFixed(2);

      const largeArc = sliceAngle > 180 ? 1 : 0;
      const pathData = `M ${x1} ${y1} A ${radiusOuter} ${radiusOuter} 0 ${largeArc} 1 ${x2} ${y2} L ${x3} ${y3} A ${radiusInner} ${radiusInner} 0 ${largeArc} 0 ${x4} ${y4} Z`;

      return `<path class="cockpit-donut-slice" d="${pathData}" fill="${p.color}" stroke="#ffffff" stroke-width="2"><title>${p.name}: ${p.share}% (${p.amount} 億元)</title></path>`;
    }).join("\\n");

    donutWrap.innerHTML = `
      <svg viewBox="0 0 140 140" width="130" height="130" style="display:block;">
        <circle cx="70" cy="70" r="${radiusOuter}" fill="none" stroke="#e2e8f0" stroke-width="2" />
        ${paths}
        <circle cx="70" cy="70" r="${radiusInner}" fill="#ffffff" />
      </svg>
    `;
  }

  // 頁面初次載入時監聽數據綁定
  window.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
      // 確保數據綁定完成
      renderExpandedDonut();
    }, 300);
  });
</script>
"""

# Inject before </body>
html = html.replace("</body>", custom_css_js + "\n</body>")

with open(demo_file, "w", encoding="utf-8") as f:
    f.write(html)

print("demo.html updated successfully!")
