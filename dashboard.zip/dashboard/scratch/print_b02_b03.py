import sys
import json
sys.stdout.reconfigure(encoding='utf-8')

data = json.load(open('01_儀表板執行環境/dashboard_data.json', encoding='utf-8'))

print("========================================")
print("BLOCK 02 (收單業務) DATA DETAILS")
print("========================================")
b2 = data['block02']
for k, v in b2.items():
    print(f"\n--- {k} ---")
    print(json.dumps(v, ensure_ascii=False, indent=2)[:800])

print("\n========================================")
print("BLOCK 03 (發卡業務) DATA DETAILS")
print("========================================")
b3 = data['block03']
for k, v in b3.items():
    print(f"\n--- {k} ---")
    print(json.dumps(v, ensure_ascii=False, indent=2)[:800])
