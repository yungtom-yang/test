# -*- coding: utf-8 -*-
import os
import sys
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

artifact_dir = r"C:\Users\詠棠\.gemini\antigravity\brain\481f5639-3c51-435d-a7c2-e9b2ea99ea3d"
demo_path = os.path.abspath("01_儀表板執行環境/credit_card_full_dashboard.html")

opts = Options()
opts.add_argument("--headless")
opts.add_argument("--window-size=1600,1200")
opts.add_argument("--disable-gpu")
opts.set_capability('goog:loggingPrefs', {'browser': 'ALL'})

driver = webdriver.Chrome(options=opts)

try:
    print(f"Loading {demo_path}...")
    driver.get(f"file:///{demo_path.replace(os.sep, '/')}")
    time.sleep(2)

    # 1. Check Console Logs
    logs = driver.get_log('browser')
    errors = [log for log in logs if log['level'] in ['SEVERE', 'ERROR']]
    print(f"Browser console logs count: {len(logs)}, errors: {len(errors)}")
    for err in errors:
        print("  Console Error:", err)

    # 2. Switch to Section 02 Acquiring and Tab 0 (交易通路分析)
    print("Switching to Section 02 Acquiring and AcqTab 0...")
    driver.execute_script("switchMainSection('section-acquiring'); switchAcqTab(0);")
    time.sleep(1)

    # 3. Verify Dual Charts
    wrapper = driver.find_element(By.ID, "b02-online-svg-wrapper")
    cards = wrapper.find_elements(By.CLASS_NAME, "acq-channel-card")
    print(f"Found {len(cards)} channel cards in wrapper (Expected: 2)")

    assert len(cards) == 2, f"Expected 2 cards, got {len(cards)}"

    left_card = cards[0]
    right_card = cards[1]

    left_title = left_card.find_element(By.TAG_NAME, "h3").text
    right_title = right_card.find_element(By.TAG_NAME, "h3").text
    print(f"Left Card Title: {left_title}")
    print(f"Right Card Title: {right_title}")

    # Check DOM IDs & values
    expected_amts = {
        "b02-onl-c2-amt": "10.72",
        "b02-onl-c1-amt": "6.13",
        "b02-onl-c3-amt": "1.99"
    }
    expected_cnts = {
        "b02-onl-c2-cnt": "653.24",
        "b02-onl-c1-cnt": "663.22",
        "b02-onl-c3-cnt": "350.17"
    }

    print("\n=== VERIFYING AMOUNT VALUES ===")
    for eid, exp in expected_amts.items():
        el = driver.find_element(By.ID, eid)
        val = el.text.strip()
        print(f"  {eid}: {val} (Expected starts with: {exp}) -> {'PASS' if exp in val else 'FAIL'}")
        assert exp in val, f"{eid} mismatch: got {val}, expected {exp}"

    print("\n=== VERIFYING COUNT VALUES ===")
    for eid, exp in expected_cnts.items():
        el = driver.find_element(By.ID, eid)
        val = el.text.strip()
        print(f"  {eid}: {val} (Expected starts with: {exp}) -> {'PASS' if exp in val else 'FAIL'}")
        assert exp in val, f"{eid} mismatch: got {val}, expected {exp}"

    # 4. Capture Screenshots
    os.makedirs(artifact_dir, exist_ok=True)
    screenshot_full = os.path.join(artifact_dir, "prod_acq_tab0_full.png")
    screenshot_cards = os.path.join(artifact_dir, "prod_acq_tab0_cards.png")

    tab_elem = driver.find_element(By.ID, "acq-tab-0")
    driver.execute_script("arguments[0].scrollIntoView({behavior: 'instant', block: 'center'});", tab_elem)
    time.sleep(0.5)

    driver.save_screenshot(screenshot_full)
    print(f"\nSaved full screenshot: {screenshot_full}")

    tab_elem.screenshot(screenshot_cards)
    print(f"Saved cards screenshot: {screenshot_cards}")

    print(f"\nOverall Result: {'SUCCESS' if len(errors) == 0 else 'FAILURE'}")

finally:
    driver.quit()
