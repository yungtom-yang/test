# -*- coding: utf-8 -*-
from html.parser import HTMLParser
import sys

class TagChecker(HTMLParser):
    def __init__(self):
        super().__init__()
        self.stack = []
        self.void_tags = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr', 'path', 'line', 'rect', 'circle', 'stop', 'defs', 'lineargradient'}
        self.errors = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() not in self.void_tags:
            self.stack.append((tag.lower(), self.getpos()))

    def handle_endtag(self, tag):
        if tag.lower() in self.void_tags:
            return
        if not self.stack:
            self.errors.append(f'Unexpected end tag </{tag}> at line {self.getpos()[0]}')
            return
        last_tag, pos = self.stack.pop()
        if last_tag != tag.lower():
            self.errors.append(f'Mismatched tag: expected </{last_tag}> (opened at {pos}), but got </{tag}> at line {self.getpos()[0]}')

def check_file(filename):
    with open(filename, encoding='utf-8') as f:
        html = f.read()

    parser = TagChecker()
    parser.feed(html)
    print(f'Checking {filename}:')
    print(f'  Errors found: {len(parser.errors)}')
    for err in parser.errors[:10]:
        print(f'    {err}')
    if parser.stack:
        print(f'  Unclosed tags ({len(parser.stack)}):')
        for tag, pos in parser.stack[-5:]:
            print(f'    <{tag}> opened at line {pos[0]}')

if __name__ == '__main__':
    check_file('dashboard/01_儀表板執行環境/credit_card_full_dashboard.html')
    check_file('dashboard/01_儀表板執行環境/demo.html')
