# -*- coding: utf-8 -*-
import sys
import os
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

artifact_dir = r"C:\Users\詠棠\.gemini\antigravity\brain\7f466f8c-d4e5-407e-b8a3-effee7d7cd33"
os.makedirs(artifact_dir, exist_ok=True)

opts = Options()
opts.add_argument("--headless")
opts.add_argument("--window-size=1680,1050")
opts.add_argument("--disable-gpu")
opts.set_capability('goog:loggingPrefs', {'browser': 'ALL'})

driver = webdriver.Chrome(options=opts)

demo_path = os.path.abspath("01_儀表板執行環境/demo.html").replace("\\", "/")
print(f"Loading {demo_path}...")
driver.get(f"file:///{demo_path}")
time.sleep(1.5)

# 1. Console Logs Check
logs = driver.get_log('browser')
errors = [log for log in logs if log['level'] in ['SEVERE', 'ERROR']]
print(f"Console errors count: {len(errors)}")
for err in errors:
    print("  Error:", err['message'])

# 2. Check heights for Variant 1 (Bar)
col1 = driver.find_element(By.CSS_SELECTOR, '.cockpit-col-1')
col2 = driver.find_element(By.CSS_SELECTOR, '.cockpit-col-2')
col3 = driver.find_element(By.CSS_SELECTOR, '.cockpit-col-3')
c1a = driver.find_element(By.CSS_SELECTOR, '.cell-iss-1a')
c1c = driver.find_element(By.CSS_SELECTOR, '.cell-iss-1c')

print("\n--- VARIANT 1 (BAR) HEIGHTS ---")
print(f"Col 1: {col1.size['height']}px (c1a: {c1a.size['height']}px, c1c: {c1c.size['height']}px)")
print(f"Col 2: {col2.size['height']}px")
print(f"Col 3: {col3.size['height']}px")

# Save Variant 1 Full Cockpit & Col 1 Close-up
cockpit_elem = driver.find_element(By.ID, 'section-cockpit')
cockpit_img1 = os.path.join(artifact_dir, "variant1_horizontal_bars_cockpit.png")
cockpit_elem.screenshot(cockpit_img1)
print(f"Saved: {cockpit_img1}")

col1_img1 = os.path.join(artifact_dir, "variant1_col1_detail.png")
col1.screenshot(col1_img1)
print(f"Saved: {col1_img1}")

# 3. Switch to Variant 2 (Donut)
driver.execute_script("switchPeerVariant('donut');")
time.sleep(1.0)

# Check heights for Variant 2
print("\n--- VARIANT 2 (DONUT) HEIGHTS ---")
print(f"Col 1: {col1.size['height']}px (c1a: {c1a.size['height']}px, c1c: {c1c.size['height']}px)")
print(f"Col 2: {col2.size['height']}px")
print(f"Col 3: {col3.size['height']}px")

# Save Variant 2 Full Cockpit & Col 1 Close-up
cockpit_img2 = os.path.join(artifact_dir, "variant2_expanded_donut_cockpit.png")
cockpit_elem.screenshot(cockpit_img2)
print(f"Saved: {cockpit_img2}")

col1_img2 = os.path.join(artifact_dir, "variant2_col1_detail.png")
col1.screenshot(col1_img2)
print(f"Saved: {col1_img2}")

driver.quit()
print("\nVerification and capture complete!")
