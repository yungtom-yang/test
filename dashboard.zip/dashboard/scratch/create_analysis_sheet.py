# -*- coding: utf-8 -*-
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)
excel_path = os.path.join(project_root, '01_儀表板執行環境', 'dashboard_data.xlsx')

wb = openpyxl.load_workbook(excel_path)
sheet_name = '深入診斷分析說明'

if sheet_name in wb.sheetnames:
    del wb[sheet_name]

ws = wb.create_sheet(title=sheet_name)

# Define Headers
headers = ['業務模組', 'TAB代碼', '位置', '分析說明文字', '備註說明']
ws.append(headers)

# Define Data Rows
rows = [
    [
        '01 全行概況',
        'peer_benchmark_spend',
        '同業經營比較-消費經營',
        '分析：2026 年前 8 月五大發卡行簽帳總額達 2.45 兆元（年增 18.5%），本行以 5,726 億元穩居市場第二（市占率 23.3%、年增 17.1%），持續鞏固刷卡基本盤；面對中信（市占 26.3%）與台新（年增 22.7%）積極搶攻市占，後續應深化主力 CUBE 卡分群權益切換與高動能場景促刷，拉大對後進者的領先差距。',
        '01全行概況-同業YTD簽帳金額經營比較'
    ],
    [
        '01 全行概況',
        'peer_benchmark_cards',
        '同業經營比較-卡量經營',
        '分析：本行有效卡數達 511.9 萬張穩居市場前三，活卡率 70.54% 逆勢年增 +0.31pp，優於台新（71.9% 年減 1.67pp）與玉山（65.2%）且與首位中信齊平；在發卡市場進入存量整併期下，本行採取清呆活化策略奏效，流通卡結構精實且持卡客群維持高頻動用體質。',
        '01全行概況-同業流通卡/有效卡/活卡率分析'
    ],
    [
        '01 全行概況',
        'peer_benchmark_credit',
        '同業經營比較-信用業務',
        '分析：本行在生息資產端展現強大市場統治力，循環信用餘額 225.3 億元（年增 4.8%）與未到期分期餘額 462.0 億元（年增 10.2%）雙雙拔得市場頭籌；高資產規模伴隨穩健授信風控，持續為全行信用卡業務貢獻優質且穩定的利息收益底盤。',
        '01全行概況-同業循環信用餘額與分期餘額比較'
    ],
    [
        '02 收單業務',
        'acq_diag_channels',
        '收單深入診斷-交易通路分析',
        '分析：線上收單金額以「EPOS-地端」為營收主力（佔比 56.9%、平均客單 164 元），承載較高客單價商戶；「EPOS-雲端」與「Payment Hub 掃碼」則展現高頻民生小額特色（合計筆數突破 1,000 萬筆），三軌通路分工明確，全面覆蓋大額支付與高頻微額交易場景。',
        '02收單業務-TAB 0 交易通路分析 (EPOS雲地端+PH掃碼)'
    ],
    [
        '02 收單業務',
        'acq_diag_twqr',
        '收單深入診斷-TWQR業務推展',
        '分析：TWQR 業務處於早期場景普及與鋪路階段，累計特店家數已達 256 家（月增 11.3%）；隨核心商戶陸續開通，單月交易金額暴增 262.9% 突破 13 萬元、交易筆數月增 38.2%，平均客單價達 656 元，反映跨機構共通 QR 碼已開始在具實質消費力的微型商家發揮動能。',
        '02收單業務-TWQR業務推展與交易動能專區'
    ],
    [
        '03 發卡業務',
        'iss_diag_approval',
        '發卡深入診斷-申辦自動徵審分析',
        '分析：發卡進件全面無紙化（數位進件佔比 93.2%），自動化徵審中樞達到 83.5% 高自動化審查率；自動直接核准率高達 69.0%（舊戶自動核准率達 96.9%、新戶達 78.1%），大幅壓縮審查時效，轉人工僅 17.4%，展現科技賦能下極致的徵審營運效能。',
        '03發卡業務-TAB 0 申辦自動徵審分析'
    ],
    [
        '03 發卡業務',
        'iss_diag_billing',
        '發卡深入診斷-帳單列印中心',
        '分析：全行出帳總量達 531.6 萬份，其中佔量 88% 的信用卡帳單電子化滲透率已提升至 67.93%（達 318.3 萬份），有效抑制實體印製郵寄成本；銀行端帳單與通知函電子化率仍處於個位數至一成初，具備高度綠色數位化轉化潛力。',
        '03發卡業務-TAB 1 帳單列印中心雙軌明細'
    ],
    [
        '03 發卡業務',
        'iss_diag_bonus',
        '發卡深入診斷-小樹點經營與折抵通路',
        '分析：小樹點流通池維持健康良性擴張（餘額年增 28.9% 達 73.5 億點），且單月兌換率高達 71.2%，活絡度顯著；折抵通路高度聚焦於「即時折抵」（佔 65.1%）與「合併用點」（佔 15.3%），顯示點數深度融入持卡人每日消費折抵，形成高黏著度的數位生態閉環。',
        '03發卡業務-TAB 2 小樹點經營7柱水庫與五大折抵通路'
    ],
    [
        '03 發卡業務',
        'iss_diag_fraud',
        '發卡深入診斷-SFM與3DS防詐成效',
        '分析：全月阻斷冒用卡數達 5,858 張、保全資產 9,482 萬元，以 SFM 交易詐欺為第一道即時攔阻主力（佔 64.9%）；特別是 SFM 申請詐欺每卡平均阻斷高達 15.74 萬元，成功於前端進件源頭精準阻截高額組織型偽冒申辦，有效遏阻重大信用損失。',
        '03發卡業務-TAB 3 SFM 3DS防詐防堵成效分析'
    ],
    [
        '03 發卡業務',
        'iss_diag_installment',
        '發卡深入診斷-分期產品結構分析',
        '分析：客戶分期行為呈現明確的「單筆消費即時處置」轉移趨勢（單筆筆數佔比升至 75.7%、金額佔比達 57.1%），整期帳單分期逐期收縮；其中「授權單筆」在筆數（佔單筆 62.5%）與金額（年增 +20.5%）皆為絕對核心，為當前分期業務最強勁的成長驅動力。',
        '03發卡業務-TAB 4 分期產品結構分析 (客戶偏好 vs 營收結構)'
    ],
    [
        '04 系統韌性',
        'res_diag_cloud_events',
        '系統韌性深入診斷-活動日EPOS雲端監控',
        '分析：監控 618 至 99 等大型電商促銷，8 月份 88 節與 818 會員日因瞬間峰值湧入，CPU 負載一度突破 80% 運算預警線；經 99 大促彈性擴容至 24 vCPU 後，峰值 TPS 達 238 筆但 CPU 負載大幅降至 29.8%，展現雲端架構動態伸縮彈性與高可用承載力。',
        '04系統韌性-TAB 0 活動日EPOS雲端服務監控數據'
    ],
    [
        '04 系統韌性',
        'res_diag_bonus_microservices',
        '系統韌性深入診斷-紅利平台服務量能監控',
        '分析：紅利平台四大微服務架構運作平穩，「小樹點查詢」單月調用量突破 1.15 億次（年增 8.9%），為高頻基石服務；「票券服務」於搶券搶點期間瞬時迸發達 1,217 TPS，微服務架構有效隔離高併發流量，確保核心紅利查詢與折抵服務 100% 零中斷。',
        '04系統韌性-TAB 1 紅利平台四大微服務量能矩陣'
    ]
]

for r in rows:
    ws.append(r)

# Styling
header_fill = PatternFill(start_color='003B5C', end_color='003B5C', fill_type='solid')
header_font = Font(name='微軟正黑體', size=11, bold=True, color='FFFFFF')
data_font = Font(name='微軟正黑體', size=10, color='1E293B')
thin_border = Border(
    left=Side(style='thin', color='E2E8F0'),
    right=Side(style='thin', color='E2E8F0'),
    top=Side(style='thin', color='E2E8F0'),
    bottom=Side(style='thin', color='E2E8F0')
)

# Apply header styling
for col_idx in range(1, len(headers) + 1):
    cell = ws.cell(row=1, column=col_idx)
    cell.fill = header_fill
    cell.font = header_font
    cell.alignment = Alignment(horizontal='center', vertical='center')
    cell.border = thin_border
ws.row_dimensions[1].height = 26

# Apply data styling
for row_idx in range(2, len(rows) + 2):
    ws.row_dimensions[row_idx].height = 58
    for col_idx in range(1, len(headers) + 1):
        cell = ws.cell(row=row_idx, column=col_idx)
        cell.font = data_font
        cell.border = thin_border
        if col_idx in (1, 2, 3):
            cell.alignment = Alignment(horizontal='center', vertical='center')
        elif col_idx == 4:
            cell.alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
        else:
            cell.alignment = Alignment(horizontal='left', vertical='center')

# Column Widths
col_widths = {
    'A': 16,
    'B': 30,
    'C': 34,
    'D': 92,
    'E': 38
}
for col_letter, width in col_widths.items():
    ws.column_dimensions[col_letter].width = width

wb.save(excel_path)
print(f"Successfully created worksheet '{sheet_name}' in {excel_path} with {len(rows)} analysis entries!")
