const http = require('http');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const PORT = 9222;
const edgePath = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';

async function main() {
  console.log('Starting Edge headless...');
  const edge = spawn(edgePath, [
    `--remote-debugging-port=${PORT}`,
    '--headless=new',
    '--disable-gpu',
    '--no-first-run',
    '--no-default-browser-check',
    '--user-data-dir=' + path.resolve(__dirname, 'edge_user_data')
  ]);

  // Wait for port to open
  let wsUrl = null;
  for (let i = 0; i < 30; i++) {
    await new Promise(r => setTimeout(r, 300));
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/version`);
      const data = await res.json();
      wsUrl = data.webSocketDebuggerUrl;
      if (wsUrl) break;
    } catch (e) {}
  }

  if (!wsUrl) {
    console.error('Failed to get WebSocket debugger URL');
    edge.kill();
    process.exit(1);
  }

  console.log('Connected to CDP at:', wsUrl);

  const ws = new WebSocket(wsUrl);
  let id = 1;
  const callbacks = new Map();

  ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    if (callbacks.has(msg.id)) {
      const cb = callbacks.get(msg.id);
      callbacks.delete(msg.id);
      cb(msg);
    }
  };

  const send = (method, params = {}) => new Promise((resolve) => {
    const reqId = id++;
    callbacks.set(reqId, resolve);
    ws.send(JSON.stringify({ id: reqId, method, params }));
  });

  await new Promise(r => ws.onopen = r);

  // Create new target / page
  const newTarget = await send('Target.createTarget', { url: 'about:blank' });
  const targetId = newTarget.result.targetId;
  const attachRes = await send('Target.attachToTarget', { targetId, flatten: true });
  const sessionId = attachRes.result.sessionId;

  const sendSession = (method, params = {}) => new Promise((resolve) => {
    const reqId = id++;
    callbacks.set(reqId, resolve);
    ws.send(JSON.stringify({ id: reqId, method, params, sessionId }));
  });

  await sendSession('Page.enable');
  await sendSession('Runtime.enable');
  await sendSession('DOM.enable');

  async function testHtmlFile(fileName, screenPrefix) {
    console.log(`\n=============================================`);
    console.log(`Testing file: ${fileName}`);
    console.log(`=============================================`);

    const filePath = 'file:///' + path.resolve(__dirname, '../01_儀表板執行環境', fileName).replace(/\\/g, '/');
    await sendSession('Page.navigate', { url: filePath });

    // Wait 1.5s for data & render
    await new Promise(r => setTimeout(r, 1500));

    // Switch to section 01 and category 卡量經營
    const resSetup = await sendSession('Runtime.evaluate', {
      expression: `
        (() => {
          switchMainSection('section-overview');
          // Find index of 卡量經營 in peerCategories
          const catIdx = peerCategories.findIndex(c => c.label === "卡量經營");
          selectCategory(catIdx);
          
          const catBtns = Array.from(document.querySelectorAll('#ytd-category-tabs button')).map(b => ({
            text: b.textContent.trim(),
            active: b.classList.contains('active')
          }));
          
          const subtabBtns = Array.from(document.querySelectorAll('#ytd-metric-selector button')).map(b => ({
            text: b.textContent.trim(),
            active: b.classList.contains('active')
          }));

          const chartTitle = document.getElementById('peer-chart-title')?.textContent.trim();
          const chartUnit = document.getElementById('peer-chart-unit')?.textContent.trim();
          const firstBank = document.querySelector('#peer-chart-rows .peer-row .peer-name')?.textContent.trim().replace(/\\s+/g, ' ');

          return { catBtns, subtabBtns, chartTitle, chartUnit, firstBank };
        })()
      `,
      returnByValue: true
    });

    console.log('Setup Result:', JSON.stringify(resSetup.result.value, null, 2));

    // Screenshot initial 卡量經營 (流通卡數 active)
    const ss1 = await sendSession('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync(path.resolve(__dirname, `${screenPrefix}_01_card_mgmt_tab0.png`), Buffer.from(ss1.result.data, 'base64'));

    // Click subtab 1: 有效卡數
    const resSub1 = await sendSession('Runtime.evaluate', {
      expression: `
        (() => {
          selectMetric(1);
          return {
            activeSubtab: document.querySelector('#ytd-metric-selector button.active')?.textContent.trim(),
            chartTitle: document.getElementById('peer-chart-title')?.textContent.trim(),
            chartUnit: document.getElementById('peer-chart-unit')?.textContent.trim(),
            firstBank: document.querySelector('#peer-chart-rows .peer-row .peer-name')?.textContent.trim().replace(/\\s+/g, ' ')
          };
        })()
      `,
      returnByValue: true
    });
    console.log('Subtab 1 Result (有效卡數):', JSON.stringify(resSub1.result.value, null, 2));

    const ss2 = await sendSession('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync(path.resolve(__dirname, `${screenPrefix}_02_card_mgmt_tab1.png`), Buffer.from(ss2.result.data, 'base64'));

    // Click subtab 2: 活卡率
    const resSub2 = await sendSession('Runtime.evaluate', {
      expression: `
        (() => {
          selectMetric(2);
          return {
            activeSubtab: document.querySelector('#ytd-metric-selector button.active')?.textContent.trim(),
            chartTitle: document.getElementById('peer-chart-title')?.textContent.trim(),
            chartUnit: document.getElementById('peer-chart-unit')?.textContent.trim(),
            firstBank: document.querySelector('#peer-chart-rows .peer-row .peer-name')?.textContent.trim().replace(/\\s+/g, ' ')
          };
        })()
      `,
      returnByValue: true
    });
    console.log('Subtab 2 Result (活卡率):', JSON.stringify(resSub2.result.value, null, 2));

    const ss3 = await sendSession('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync(path.resolve(__dirname, `${screenPrefix}_03_card_mgmt_tab2.png`), Buffer.from(ss3.result.data, 'base64'));
  }

  await testHtmlFile('demo.html', 'demo');
  await testHtmlFile('credit_card_full_dashboard.html', 'prod');

  edge.kill();
  process.exit(0);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
