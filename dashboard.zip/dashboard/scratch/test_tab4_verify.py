# -*- coding: utf-8 -*-
import urllib.request
import json
import asyncio
import websockets
import os
import subprocess
import time
import sys

sys.stdout.reconfigure(encoding='utf-8')

port = 9388
html_abs = os.path.abspath('01_儀表板執行環境/demo.html')
html_uri = 'file:///' + html_abs.replace('\\', '/')

cmd = [
    r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
    '--headless=new',
    f'--remote-debugging-port={port}',
    '--window-size=1600,1200',
    '--no-sandbox',
    '--disable-gpu',
    html_uri
]
proc = subprocess.Popen(cmd)
time.sleep(2)

try:
    tabs = json.loads(urllib.request.urlopen(f'http://localhost:{port}/json').read().decode())
    page_tab = [t for t in tabs if t.get('type') == 'page'][0]
    
    async def run():
        async with websockets.connect(page_tab['webSocketDebuggerUrl']) as ws:
            errors = []
            await ws.send(json.dumps({'id': 1, 'method': 'Console.enable'}))
            await ws.recv()
            await ws.send(json.dumps({'id': 2, 'method': 'Runtime.enable'}))
            await ws.recv()

            async def send_cmd(cmd_id, method, params=None):
                payload = {'id': cmd_id, 'method': method}
                if params:
                    payload['params'] = params
                await ws.send(json.dumps(payload))
                while True:
                    msg = json.loads(await ws.recv())
                    if msg.get('id') == cmd_id:
                        return msg

            # Switch section and tab
            await send_cmd(10, 'Runtime.evaluate', {'expression': 'switchMainSection("section-issuing"); switchIssTab(4);'})
            await asyncio.sleep(0.5)

            # Check DOM state
            cnt_res = await send_cmd(20, 'Runtime.evaluate', {'expression': 'document.getElementById("inst-mix-cnt-chart") ? document.getElementById("inst-mix-cnt-chart").innerHTML : "NOT_FOUND"'})
            cnt_val = cnt_res.get('result', {}).get('result', {}).get('value', '')
            print('CNT innerHTML length:', len(cnt_val))
            
            amt_res = await send_cmd(21, 'Runtime.evaluate', {'expression': 'document.getElementById("inst-mix-amt-chart") ? document.getElementById("inst-mix-amt-chart").innerHTML : "NOT_FOUND"'})
            amt_val = amt_res.get('result', {}).get('result', {}).get('value', '')
            print('AMT innerHTML length:', len(amt_val))

            cnt_rows = await send_cmd(22, 'Runtime.evaluate', {'expression': 'JSON.stringify([...document.querySelectorAll("#inst-mix-cnt-chart .inst-mix-row")].map(r => ({ cls: r.className, label: r.querySelector(".inst-mix-meta span").textContent })))'})
            print('CNT rows:', cnt_rows.get('result', {}).get('result', {}).get('value'))

            amt_rows = await send_cmd(23, 'Runtime.evaluate', {'expression': 'JSON.stringify([...document.querySelectorAll("#inst-mix-amt-chart .inst-mix-row")].map(r => ({ cls: r.className, label: r.querySelector(".inst-mix-meta span").textContent })))'})
            print('AMT rows:', amt_rows.get('result', {}).get('result', {}).get('value'))

    asyncio.run(run())
finally:
    proc.kill()
