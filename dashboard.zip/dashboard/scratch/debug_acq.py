# -*- coding: utf-8 -*-
import urllib.request
import json
import asyncio
import websockets
import os
import subprocess
import time
import sys

sys.stdout.reconfigure(encoding='utf-8')

port = 9399
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)
html_abs = os.path.join(project_root, '01_儀表板執行環境', 'credit_card_full_dashboard.html')
html_uri = 'file:///' + html_abs.replace('\\', '/')

cmd = [
    r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
    '--headless=new',
    f'--remote-debugging-port={port}',
    '--window-size=1600,1200',
    '--no-sandbox',
    '--disable-gpu',
    html_uri
]
proc = subprocess.Popen(cmd)
time.sleep(2)

try:
    tabs = json.loads(urllib.request.urlopen(f'http://localhost:{port}/json').read().decode())
    page_tab = [t for t in tabs if t.get('type') == 'page'][0]

    async def run():
        async with websockets.connect(page_tab['webSocketDebuggerUrl']) as ws:
            async def send_cmd(cmd_id, method, params=None):
                payload = {'id': cmd_id, 'method': method}
                if params:
                    payload['params'] = params
                await ws.send(json.dumps(payload))
                while True:
                    msg = json.loads(await ws.recv())
                    if msg.get('id') == cmd_id:
                        return msg

            r_err = await send_cmd(1, 'Runtime.evaluate', {
                'expression': '(() => { try { renderBlock01FromData(window.DASHBOARD_DATA); } catch(e) { return "B1: " + e.message; } try { renderBlock02FromData(window.DASHBOARD_DATA); } catch(e) { return "B2: " + e.message; } try { renderBlock03FromData(window.DASHBOARD_DATA); } catch(e) { return "B3: " + e.message; } try { renderBlock04FromData(window.DASHBOARD_DATA); } catch(e) { return "B4: " + e.message; } return "ALL_OK"; })()'
            })
            print('Init check:', r_err.get('result', {}).get('result', {}).get('value'))

    asyncio.run(run())
finally:
    proc.kill()
