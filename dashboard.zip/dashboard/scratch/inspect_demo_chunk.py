# -*- coding: utf-8 -*-
import sys
import os

with open('01_儀表板執行環境/demo.html', 'r', encoding='utf-8') as f:
    content = f.read()

p1 = content.find('id="c00-card-cnt"')
p2 = content.find('class="cockpit-subbox c-tier2-card cell-iss-1c"')
p3 = content.find('class="cockpit-col-2"')

print(f"p1 (c00-card-cnt): {p1}")
print(f"p2 (cell-iss-1c): {p2}")
print(f"p3 (cockpit-col-2): {p3}")

print("\n--- CONTENT BETWEEN p1 and p2 ---")
print(content[p1:p2])

print("\n--- CONTENT BETWEEN p2 and p3 ---")
print(content[p2:p3])
