import os
import sys
import time

sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

CHROMEDRIVER_PATH = r"C:\Users\詠棠\.cache\selenium\chromedriver\win64\155.0.8059.84\chromedriver.exe"
WORKSPACE_DIR = r"C:\Users\詠棠\.gemini\antigravity\scratch\dashboard\01_儀表板執行環境"
SCRATCH_DIR = r"C:\Users\詠棠\.gemini\antigravity\scratch\dashboard\scratch"

def verify_file(driver, filename, prefix):
    print(f"\n========================================================")
    print(f" Verifying: {filename}")
    print(f"========================================================")
    file_url = "file:///" + os.path.join(WORKSPACE_DIR, filename).replace("\\", "/")
    driver.get(file_url)
    time.sleep(1.5)

    # Check for console logs / JS errors
    logs = driver.get_log('browser')
    errors = [l for l in logs if l['level'] == 'SEVERE']
    if errors:
        print(f"⚠️ Found {len(errors)} browser errors:")
        for e in errors:
            print("  ", e['message'])
    else:
        print("✓ Zero browser errors.")

    # 1. Switch to Section 01
    driver.execute_script("switchMainSection('section-overview');")
    time.sleep(0.5)

    # 2. Click category tab "卡量經營"
    driver.execute_script("""
        const catIdx = peerCategories.findIndex(c => c.label === "卡量經營");
        selectCategory(catIdx);
    """)
    time.sleep(0.5)

    # 3. Inspect category tabs
    cat_buttons = driver.find_elements(By.CSS_SELECTOR, "#ytd-category-tabs button")
    cat_texts = [b.text.strip() for b in cat_buttons]
    active_cat = [b.text.strip() for b in cat_buttons if "active" in b.get_attribute("class")]
    print(f"✓ Category Tabs: {cat_texts}")
    print(f"✓ Active Category: {active_cat}")
    assert "卡量經營" in active_cat, "卡量經營 should be active"

    # 4. Inspect subtab buttons under 卡量經營
    subtab_buttons = driver.find_elements(By.CSS_SELECTOR, "#ytd-metric-selector button")
    subtab_texts = [b.text.strip() for b in subtab_buttons]
    print(f"✓ Subtab Buttons: {subtab_texts}")
    expected_order = ["流通卡數", "有效卡數", "活卡率"]
    assert subtab_texts == expected_order, f"Subtabs order mismatch! Expected: {expected_order}, got: {subtab_texts}"

    # Verify default active subtab is 流通卡數 (index 0)
    assert "active" in subtab_buttons[0].get_attribute("class"), "Subtab 0 (流通卡數) must be active initially"
    title_0 = driver.find_element(By.ID, "peer-chart-title").text.strip()
    unit_0 = driver.find_element(By.ID, "peer-chart-unit").text.strip()
    print(f"✓ Subtab 0 [流通卡數] Active -> Chart Title: '{title_0}', Unit: '{unit_0}'")
    assert "流通卡數" in title_0, f"Title should contain '流通卡數', got {title_0}"

    # Take screenshot of subtab 0
    el_panel = driver.find_element(By.ID, "overview-peer-benchmark")
    ss_path_0 = os.path.join(SCRATCH_DIR, f"{prefix}_subtab0_流通卡數.png")
    el_panel.screenshot(ss_path_0)
    print(f"✓ Saved screenshot: {ss_path_0}")

    # 5. Click Subtab 1: 有效卡數
    subtab_buttons[1].click()
    time.sleep(0.4)
    subtab_buttons = driver.find_elements(By.CSS_SELECTOR, "#ytd-metric-selector button")
    assert "active" in subtab_buttons[1].get_attribute("class"), "Subtab 1 (有效卡數) must be active"
    title_1 = driver.find_element(By.ID, "peer-chart-title").text.strip()
    unit_1 = driver.find_element(By.ID, "peer-chart-unit").text.strip()
    print(f"✓ Subtab 1 [有效卡數] Active -> Chart Title: '{title_1}', Unit: '{unit_1}'")
    assert "有效卡數" in title_1, f"Title should contain '有效卡數', got {title_1}"

    ss_path_1 = os.path.join(SCRATCH_DIR, f"{prefix}_subtab1_有效卡數.png")
    el_panel.screenshot(ss_path_1)
    print(f"✓ Saved screenshot: {ss_path_1}")

    # 6. Click Subtab 2: 活卡率
    subtab_buttons[2].click()
    time.sleep(0.4)
    subtab_buttons = driver.find_elements(By.CSS_SELECTOR, "#ytd-metric-selector button")
    assert "active" in subtab_buttons[2].get_attribute("class"), "Subtab 2 (活卡率) must be active"
    title_2 = driver.find_element(By.ID, "peer-chart-title").text.strip()
    unit_2 = driver.find_element(By.ID, "peer-chart-unit").text.strip()
    print(f"✓ Subtab 2 [活卡率] Active -> Chart Title: '{title_2}', Unit: '{unit_2}'")
    assert "活卡率" in title_2, f"Title should contain '活卡率', got {title_2}"

    ss_path_2 = os.path.join(SCRATCH_DIR, f"{prefix}_subtab2_活卡率.png")
    el_panel.screenshot(ss_path_2)
    print(f"✓ Saved screenshot: {ss_path_2}")

    print(f"✓ SUCCESS: {filename} verified all 3 subtabs with exact requested order: 流通卡數、有效卡數、活卡率!\n")

def main():
    opts = Options()
    opts.add_argument("--headless=new")
    opts.add_argument("--window-size=1920,1080")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--no-sandbox")
    opts.set_capability('goog:loggingPrefs', {'browser': 'ALL'})

    service = Service(CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=opts)

    try:
        verify_file(driver, "demo.html", "demo")
        verify_file(driver, "credit_card_full_dashboard.html", "prod")
    finally:
        driver.quit()

if __name__ == "__main__":
    main()
