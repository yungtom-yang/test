# -*- coding: utf-8 -*-
import urllib.request
import json
import asyncio
import websockets
import os
import subprocess
import time
import sys

sys.stdout.reconfigure(encoding='utf-8')

port = 9392
html_abs = os.path.abspath('01_儀表板執行環境/demo.html')
html_uri = 'file:///' + html_abs.replace('\\', '/')

cmd = [
    r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
    '--headless=new',
    f'--remote-debugging-port={port}',
    '--window-size=1600,1200',
    '--no-sandbox',
    '--disable-gpu',
    html_uri
]
proc = subprocess.Popen(cmd)
time.sleep(2)

try:
    tabs = json.loads(urllib.request.urlopen(f'http://localhost:{port}/json').read().decode())
    page_tab = [t for t in tabs if t.get('type') == 'page'][0]
    
    async def run():
        async with websockets.connect(page_tab['webSocketDebuggerUrl']) as ws:
            console_msgs = []
            
            async def send_cmd(cmd_id, method, params=None):
                payload = {'id': cmd_id, 'method': method}
                if params:
                    payload['params'] = params
                await ws.send(json.dumps(payload))
                while True:
                    msg = json.loads(await ws.recv())
                    if 'method' in msg and 'Console' in msg['method']:
                        console_msgs.append(msg)
                    if msg.get('id') == cmd_id:
                        return msg

            await send_cmd(1, 'Console.enable')
            await send_cmd(2, 'Runtime.enable')

            # Test all section switches 00 to 04
            sections = ['section-cockpit', 'section-overview', 'section-acquiring', 'section-issuing', 'section-resilience']
            for i, sec in enumerate(sections):
                await send_cmd(10 + i, 'Runtime.evaluate', {'expression': f'switchMainSection("{sec}")'})
                await asyncio.sleep(0.1)

            # Switch back to issuing and tab 4
            await send_cmd(20, 'Runtime.evaluate', {'expression': 'switchMainSection("section-issuing"); switchIssTab(4);'})
            await asyncio.sleep(0.5)

            errors = [m for m in console_msgs if m.get('params', {}).get('message', {}).get('level') == 'error']
            print('Captured console messages:', len(console_msgs))
            print('Console errors count:', len(errors))
            if errors:
                for e in errors:
                    print('ERROR:', e)
            else:
                print('ZERO ERRORS VERIFIED! ALL SECTIONS CLEAN!')

    asyncio.run(run())
finally:
    proc.kill()
