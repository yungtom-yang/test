# -*- coding: utf-8 -*-
import urllib.request
import json
import asyncio
import websockets
import os
import subprocess
import time
import sys

sys.stdout.reconfigure(encoding='utf-8')

port = 9396
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)
html_abs = os.path.join(project_root, '01_儀表板執行環境', 'credit_card_full_dashboard.html')
html_uri = 'file:///' + html_abs.replace('\\', '/')

cmd = [
    r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
    '--headless=new',
    f'--remote-debugging-port={port}',
    '--window-size=1600,1200',
    '--no-sandbox',
    '--disable-gpu',
    html_uri
]
proc = subprocess.Popen(cmd)
time.sleep(2)

try:
    tabs = json.loads(urllib.request.urlopen(f'http://localhost:{port}/json').read().decode())
    page_tab = [t for t in tabs if t.get('type') == 'page'][0]
    
    async def run():
        async with websockets.connect(page_tab['webSocketDebuggerUrl']) as ws:
            console_msgs = []
            
            async def send_cmd(cmd_id, method, params=None):
                payload = {'id': cmd_id, 'method': method}
                if params:
                    payload['params'] = params
                await ws.send(json.dumps(payload))
                while True:
                    msg = json.loads(await ws.recv())
                    if 'method' in msg and 'Console' in msg['method']:
                        console_msgs.append(msg)
                    if msg.get('id') == cmd_id:
                        return msg

            await send_cmd(1, 'Console.enable')
            await send_cmd(2, 'Runtime.enable')

            # Test tab switching
            await send_cmd(20, 'Runtime.evaluate', {'expression': 'switchMainSection("section-issuing"); switchIssTab(4);'})
            await asyncio.sleep(0.5)

            # Check rendered chart content
            expr = """
            JSON.stringify({
                cntRows: document.querySelectorAll("#inst-mix-cnt-chart .inst-mix-row").length,
                amtRows: document.querySelectorAll("#inst-mix-amt-chart .inst-mix-row").length,
                cntTitle: document.querySelectorAll("#iss-tab-4 .inst-card-title")[0]?.textContent,
                amtTitle: document.querySelectorAll("#iss-tab-4 .inst-card-title")[1]?.textContent,
                cntSummary: document.getElementById("inst-mix-cnt-summary")?.innerText,
                amtSummary: document.getElementById("inst-mix-amt-summary")?.innerText,
                legacyWrapperStyle: document.getElementById("b03-inst-svg-wrapper")?.getAttribute("style")
            })
            """
            res = await send_cmd(30, 'Runtime.evaluate', {'expression': expr})
            val = json.loads(res.get('result', {}).get('result', {}).get('value', '{}'))
            print('Production Render Verification Result:')
            print('Count Chart Rows:', val.get('cntRows'))
            print('Amount Chart Rows:', val.get('amtRows'))
            print('Count Card Title:', val.get('cntTitle'))
            print('Amount Card Title:', val.get('amtTitle'))
            print('Count Summary:', val.get('cntSummary'))
            print('Amount Summary:', val.get('amtSummary'))
            print('Legacy Wrapper Style:', val.get('legacyWrapperStyle'))

            errors = [m for m in console_msgs if m.get('params', {}).get('message', {}).get('level') == 'error']
            print('Console errors count:', len(errors))

    asyncio.run(run())
finally:
    proc.kill()
