# -*- coding: utf-8 -*-
import urllib.request
import json
import asyncio
import websockets
import os
import subprocess
import time
import sys
import base64

sys.stdout.reconfigure(encoding='utf-8')

port = 9397
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)
html_abs = os.path.join(project_root, '01_儀表板執行環境', 'demo.html')
html_uri = 'file:///' + html_abs.replace('\\', '/')

cmd = [
    r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
    '--headless=new',
    f'--remote-debugging-port={port}',
    '--window-size=1600,1200',
    '--no-sandbox',
    '--disable-gpu',
    html_uri
]
proc = subprocess.Popen(cmd)
time.sleep(2)

try:
    tabs = json.loads(urllib.request.urlopen(f'http://localhost:{port}/json').read().decode())
    page_tab = [t for t in tabs if t.get('type') == 'page'][0]

    async def run():
        async with websockets.connect(page_tab['webSocketDebuggerUrl']) as ws:
            async def send_cmd(cmd_id, method, params=None):
                payload = {'id': cmd_id, 'method': method}
                if params:
                    payload['params'] = params
                await ws.send(json.dumps(payload))
                while True:
                    msg = json.loads(await ws.recv())
                    if msg.get('id') == cmd_id:
                        return msg

            await send_cmd(1, 'Console.enable')
            await send_cmd(2, 'Runtime.enable')

            await send_cmd(10, 'Runtime.evaluate', {'expression': 'switchMainSection("section-overview")'})
            await asyncio.sleep(0.2)
            await send_cmd(11, 'Runtime.evaluate', {'expression': 'selectCategory(1)'})
            await asyncio.sleep(0.2)
            # Select 活卡率 (index 2)
            await send_cmd(12, 'Runtime.evaluate', {'expression': 'selectMetric(2)'})
            await asyncio.sleep(0.2)
            await send_cmd(13, 'Runtime.evaluate', {'expression': 'document.getElementById("overview-peer-benchmark").scrollIntoView()'})
            await asyncio.sleep(0.2)
            await send_cmd(14, 'Runtime.evaluate', {'expression': 'switchPeerLayout(1)'})
            await asyncio.sleep(0.3)

            snap = await send_cmd(20, 'Page.captureScreenshot', {'format': 'png'})
            img_data = snap.get('result', {}).get('data')
            if img_data:
                out_path = os.path.join(script_dir, 'demo_peer_active_rate_v1.png')
                with open(out_path, 'wb') as f:
                    f.write(base64.b64decode(img_data))
                print(f"Captured: {out_path}")

    asyncio.run(run())
finally:
    proc.kill()
