# -*- coding: utf-8 -*-
import os

official_file = r"01_儀表板執行環境\credit_card_full_dashboard.html"

with open(official_file, "r", encoding="utf-8") as f:
    html = f.read()

# 1. Remove visible auth block from c00-card-cnt
target_auth_block = """<!-- 同格分隔線 -->
<div style="border-top: 1px dashed #cbd5e1; margin: 8px 0 6px;"></div>
<!-- 授權交易總數 -->
<div class="c-kpi-header-row">
<span class="c-kpi-title">授權交易總數</span>
<div class="c-kpi-growth" id="c00-iss-auth-growth">-</div>
</div>
<div class="c-kpi-val-row">
<div class="c-kpi-main-val" id="c00-iss-auth-val">-</div>
<div class="c-daily-stat"><span class="d-lbl">日均</span><span class="d-val">253.8 萬筆</span></div>
</div>
<div class="c-ratio-bar-wrap">
<div class="c-ratio-bar-track">
<div class="c-ratio-seg seg-credit" id="c00-iss-auth-seg-crd" style="width: 0%;" title="信用卡: -"></div>
<div class="c-ratio-seg seg-debit" id="c00-iss-auth-seg-dbt" style="width: 0%;" title="簽帳卡: -"></div>
</div>
</div>
<div class="c-ratio-data-row">
<div class="c-ratio-col">
<span class="r-label"><span class="r-dot dot-credit"></span>信用卡 <span class="r-pct r-pct-credit" id="c00-iss-auth-crd-pct">(-%)</span></span>
<strong class="r-val" id="c00-iss-auth-crd-val">-</strong>
</div>
<div class="c-ratio-col align-right">
<span class="r-label"><span class="r-dot dot-debit"></span>簽帳卡 <span class="r-pct r-pct-debit" id="c00-iss-auth-dbt-pct">(-%)</span></span>
<strong class="r-val" id="c00-iss-auth-dbt-val">-</strong>
</div>
</div>"""

if target_auth_block in html:
    html = html.replace(target_auth_block, "")
    print("Found and removed visible auth block in credit_card_full_dashboard.html")
else:
    print("Error: target_auth_block not found in credit_card_full_dashboard.html")

# 2. Add hidden preservation container for c00-iss-auth-* DOM IDs into c-kpi-mini-grid
target_mini_grid = """<div class="c-kpi-mini-grid" style="display: none;">
<div class="c-mini-kpi">
<span class="c-kpi-title">預借現金金額</span>"""

replacement_mini_grid = """<div class="c-kpi-mini-grid" style="display: none;">
<!-- 隱藏保留 DOM ID 確保 JS 數據注入 100% 正常 (授權交易總數 8 個 ID 完整保留) -->
<div id="c00-iss-auth-growth"></div>
<div id="c00-iss-auth-val"></div>
<div id="c00-iss-auth-seg-crd"></div>
<div id="c00-iss-auth-seg-dbt"></div>
<div id="c00-iss-auth-crd-pct"></div>
<div id="c00-iss-auth-crd-val"></div>
<div id="c00-iss-auth-dbt-pct"></div>
<div id="c00-iss-auth-dbt-val"></div>
<div class="c-mini-kpi">
<span class="c-kpi-title">預借現金金額</span>"""

if target_mini_grid in html:
    html = html.replace(target_mini_grid, replacement_mini_grid)
    print("Found and injected hidden preservation container into credit_card_full_dashboard.html")
else:
    print("Error: target_mini_grid not found")

# 3. Replace cell-iss-1c with Variant 1 Horizontal Bars
old_cell_1c_start = '<div class="cockpit-subbox c-tier2-card cell-iss-1c"'
old_cell_1c_end = '<div class="cockpit-col-2">'

idx_1c = html.find(old_cell_1c_start)
idx_col2 = html.find(old_cell_1c_end)

if idx_1c != -1 and idx_col2 != -1:
    new_cell_1c_html = """<div class="cockpit-subbox c-tier2-card cell-iss-1c" onclick="drillToPeerBenchmark()" style="cursor: pointer;" title="點擊前往 01 全行概況 ➔ 同業經營比較">
<div class="cockpit-box-title" style="margin-bottom: 4px;">
<span id="c00-peer-box-title">五大發卡行簽帳金額</span>
<span class="cockpit-tag-pill">2026 年 1–8 月</span>
</div>
<div class="cockpit-market-vertical-wrap" style="display: flex; flex-direction: column; justify-content: space-between; height: 100%; flex: 1;">
<!-- 頂部五大行簽帳總額摘要列 -->
<div class="bar-summary-strip">
<div class="b-sum-left">
<span class="b-sum-lbl" id="c00-market-label">五大行簽帳總額</span>
<strong class="b-sum-val" id="c00-market-val">- <em>億元</em></strong>
</div>
<div class="b-sum-right" id="c00-market-sub">
<span class="b-sum-yoy number-neutral" id="c00-market-yoy">-</span>
<span class="b-sum-hint" id="c00-top4-hint">五大行合計</span>
</div>
</div>

<!-- 水平長條表格標頭 -->
<div class="bar-table-header">
<span class="b-col-rank">排名</span>
<span class="b-col-name">發卡銀行</span>
<span class="b-col-track">簽帳規模與市場佔比</span>
<span class="b-col-yoy">YoY</span>
</div>

<!-- 5 家發卡行水平長條列表 (由 dashboard_app.js 動態注入) -->
<div class="bar-rows-list" id="c00-peer-list">
</div>

<!-- 保留隱藏的 c00-donut-wrap 節點確保 JS 數據注入不報錯 -->
<div id="c00-donut-wrap" style="display: none;"></div>
</div>
</div>
</div>
"""
    html = html[:idx_1c] + new_cell_1c_html + html[idx_col2:]
    print("Found and replaced cell-iss-1c successfully")
else:
    print("Error finding cell-iss-1c")

with open(official_file, "w", encoding="utf-8") as f:
    f.write(html)

print("credit_card_full_dashboard.html updated successfully!")
