# -*- coding: utf-8 -*-
import urllib.request
import json
import asyncio
import websockets
import os
import subprocess
import time
import sys

sys.stdout.reconfigure(encoding='utf-8')

def test_file(html_filename, port):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    html_abs = os.path.join(project_root, '01_儀表板執行環境', html_filename)
    html_uri = 'file:///' + html_abs.replace('\\', '/')

    print(f"\n==================================================")
    print(f"Testing {html_filename} on port {port}...")
    print(f"==================================================")

    cmd = [
        r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
        '--headless=new',
        f'--remote-debugging-port={port}',
        '--window-size=1600,1200',
        '--no-sandbox',
        '--disable-gpu',
        html_uri
    ]
    proc = subprocess.Popen(cmd)
    time.sleep(2)

    try:
        tabs = json.loads(urllib.request.urlopen(f'http://localhost:{port}/json').read().decode())
        page_tab = [t for t in tabs if t.get('type') == 'page'][0]

        async def run():
            async with websockets.connect(page_tab['webSocketDebuggerUrl']) as ws:
                console_msgs = []

                async def send_cmd(cmd_id, method, params=None):
                    payload = {'id': cmd_id, 'method': method}
                    if params:
                        payload['params'] = params
                    await ws.send(json.dumps(payload))
                    while True:
                        msg = json.loads(await ws.recv())
                        if 'method' in msg and 'Console' in msg['method']:
                            console_msgs.append(msg)
                        if msg.get('id') == cmd_id:
                            return msg

                await send_cmd(1, 'Console.enable')
                await send_cmd(2, 'Runtime.enable')

                # Verify all static TAB analyses
                analysis_ids = [
                    'analysis-peer-benchmark',
                    'analysis-acq-channels',
                    'analysis-acq-twqr',
                    'analysis-iss-approval',
                    'analysis-iss-billing',
                    'analysis-iss-bonus',
                    'analysis-iss-fraud',
                    'analysis-sys-cloud',
                    'analysis-sys-microservices'
                ]

                print("\n[Step 1] Verifying analysis box contents:")
                for idx, elem_id in enumerate(analysis_ids, start=10):
                    res = await send_cmd(idx, 'Runtime.evaluate', {
                        'expression': f'(() => {{ const el = document.getElementById("{elem_id}"); return el ? el.innerText.trim() : null; }})()'
                    })
                    text = res.get('result', {}).get('result', {}).get('value')
                    if text and text.startswith('分析：'):
                        print(f"  ✓ [{elem_id}] -> {text[:45]}...")
                    else:
                        print(f"  ✗ [{elem_id}] FAILED! Value: {text}")
                        raise Exception(f"Missing or invalid analysis text in {elem_id}")

                print("\n[Step 2] Testing dynamic peer benchmark category switching:")
                categories = [
                    (0, "消費經營", "五大發卡行簽帳總額"),
                    (1, "卡量經營", "有效卡數"),
                    (2, "信用業務", "生息資產端")
                ]
                for cat_idx, cat_name, keyword in categories:
                    await send_cmd(50 + cat_idx, 'Runtime.evaluate', {'expression': f'selectCategory({cat_idx})'})
                    await asyncio.sleep(0.1)
                    res = await send_cmd(60 + cat_idx, 'Runtime.evaluate', {
                        'expression': 'document.getElementById("analysis-peer-benchmark").innerText.trim()'
                    })
                    val = res.get('result', {}).get('result', {}).get('value')
                    if keyword in val:
                        print(f"  ✓ Category {cat_idx} ({cat_name}) switched correctly! Contains '{keyword}'")
                    else:
                        print(f"  ✗ Category {cat_idx} ({cat_name}) FAILED! Text: {val}")
                        raise Exception(f"Peer benchmark category switch failed for {cat_name}")

                # Test switching tabs
                print("\n[Step 3] Switching sections and tabs to verify zero console errors:")
                for i, sec in enumerate(['section-cockpit', 'section-overview', 'section-acquiring', 'section-issuing', 'section-resilience']):
                    await send_cmd(100 + i, 'Runtime.evaluate', {'expression': f'switchMainSection("{sec}")'})
                    await asyncio.sleep(0.05)

                for tab_idx in range(5):
                    await send_cmd(200 + tab_idx, 'Runtime.evaluate', {'expression': f'switchIssTab({tab_idx})'})
                    await asyncio.sleep(0.05)

                for tab_idx in range(2):
                    await send_cmd(300 + tab_idx, 'Runtime.evaluate', {'expression': f'switchSysTab({tab_idx})'})
                    await asyncio.sleep(0.05)

                errors = [m for m in console_msgs if m.get('params', {}).get('message', {}).get('level') == 'error']
                print(f"  Total console messages: {len(console_msgs)}")
                print(f"  Console errors: {len(errors)}")
                if len(errors) == 0:
                    print(f"  ✓ {html_filename} passed all verifications with ZERO errors!")

        asyncio.run(run())
    finally:
        proc.kill()

if __name__ == '__main__':
    test_file('credit_card_full_dashboard.html', 9391)
    test_file('demo.html', 9392)
