# -*- coding: utf-8 -*-
import os
import sys
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

artifact_dir = r"C:\Users\詠棠\.gemini\antigravity\brain\481f5639-3c51-435d-a7c2-e9b2ea99ea3d"
demo_path = os.path.abspath("01_儀表板執行環境/credit_card_full_dashboard.html")

opts = Options()
opts.add_argument("--headless")
opts.add_argument("--window-size=1600,1200")
opts.add_argument("--disable-gpu")
opts.set_capability('goog:loggingPrefs', {'browser': 'ALL'})

driver = webdriver.Chrome(options=opts)

try:
    print(f"Loading {demo_path}...")
    driver.get(f"file:///{demo_path.replace(os.sep, '/')}")
    time.sleep(2)

    # 1. Check Console Logs
    logs = driver.get_log('browser')
    errors = [log for log in logs if log['level'] in ['SEVERE', 'ERROR']]
    print(f"Browser console logs count: {len(logs)}, errors: {len(errors)}")
    for err in errors:
        print("  Console Error:", err)

    # 2. Switch to Section 04 and Tab 1 (紅利平台交易量能監控)
    print("Switching to Section 04 Resilience and SysTab 1...")
    driver.execute_script("switchMainSection('section-resilience'); switchSysTab(1);")
    time.sleep(1)

    # 3. Verify Elements and Data Reconciliations
    services_expected = [
        ("c1", "小樹點查詢", "11,516.57萬次", "YoY +8.88%", "MoM +1.92%", "峰值TPS: 670"),
        ("c2", "回饋總覽", "996.37萬次", "YoY +3.92%", "MoM -0.88%", "峰值TPS: 92"),
        ("c3", "小樹點兌換", "210.94萬次", "YoY +4.12%", "MoM +3.05%", "峰值TPS: 34"),
        ("c4", "票券服務", "23.39萬次", "YoY -", "MoM +6.32%", "峰值TPS: 1,217"),
    ]

    all_matched = True
    print("\n=== VERIFYING RECONCILED DATA IN CARDS ===")
    for cid, name, exp_val, exp_yoy, exp_mom, exp_tps in services_expected:
        val_el = driver.find_element(By.ID, f"b04-ms-{cid}-val")
        yoy_el = driver.find_element(By.ID, f"b04-ms-{cid}-yoy")
        mom_el = driver.find_element(By.ID, f"b04-ms-{cid}-mom")
        tps_el = driver.find_element(By.ID, f"b04-ms-{cid}-tps")

        val_txt = " ".join(val_el.text.split())
        yoy_txt = " ".join(yoy_el.text.split())
        mom_txt = " ".join(mom_el.text.split())
        tps_txt = " ".join(tps_el.text.split())

        print(f"[{name}]")
        print(f"  Value: {val_txt} (Expected: {exp_val}) -> {'PASS' if val_txt == exp_val else 'FAIL'}")
        print(f"  YoY:   {yoy_txt} (Expected: {exp_yoy}) -> {'PASS' if yoy_txt == exp_yoy else 'FAIL'}")
        print(f"  MoM:   {mom_txt} (Expected: {exp_mom}) -> {'PASS' if mom_txt == exp_mom else 'FAIL'}")
        print(f"  TPS:   {tps_txt} (Expected: {exp_tps}) -> {'PASS' if tps_txt == exp_tps else 'FAIL'}")

        if val_txt != exp_val or yoy_txt != exp_yoy or mom_txt != exp_mom or tps_txt != exp_tps:
            all_matched = False

    # 4. Verify Dual Charts are ABSENT
    dual_charts = driver.find_elements(By.CLASS_NAME, "dual-chart-shell")
    print(f"\nDual chart shell count: {len(dual_charts)} (Expected: 0) -> {'PASS' if len(dual_charts) == 0 else 'FAIL'}")
    if len(dual_charts) > 0:
        all_matched = False

    # 5. Capture Screenshots
    os.makedirs(artifact_dir, exist_ok=True)
    screenshot_full = os.path.join(artifact_dir, "prod_resilience_tab1_full.png")
    screenshot_tab = os.path.join(artifact_dir, "prod_resilience_tab1_cards.png")

    driver.save_screenshot(screenshot_full)
    print(f"Saved full screenshot: {screenshot_full}")

    sys_tab_1 = driver.find_element(By.ID, "sys-tab-1")
    sys_tab_1.screenshot(screenshot_tab)
    print(f"Saved tab screenshot: {screenshot_tab}")

    print(f"\nOverall Result: {'SUCCESS' if all_matched and len(errors) == 0 else 'FAILURE'}")

finally:
    driver.quit()
