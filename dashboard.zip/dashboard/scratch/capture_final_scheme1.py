# -*- coding: utf-8 -*-
import urllib.request
import json
import asyncio
import websockets
import os
import subprocess
import time
import sys
import base64

sys.stdout.reconfigure(encoding='utf-8')

def capture(html_filename, port, prefix):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    html_abs = os.path.join(project_root, '01_儀表板執行環境', html_filename)
    html_uri = 'file:///' + html_abs.replace('\\', '/')

    cmd = [
        r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
        '--headless=new',
        f'--remote-debugging-port={port}',
        '--window-size=1600,1200',
        '--no-sandbox',
        '--disable-gpu',
        html_uri
    ]
    proc = subprocess.Popen(cmd)
    time.sleep(2)

    try:
        tabs = json.loads(urllib.request.urlopen(f'http://localhost:{port}/json').read().decode())
        page_tab = [t for t in tabs if t.get('type') == 'page'][0]

        async def run():
            async with websockets.connect(page_tab['webSocketDebuggerUrl']) as ws:
                async def send_cmd(cmd_id, method, params=None):
                    payload = {'id': cmd_id, 'method': method}
                    if params:
                        payload['params'] = params
                    await ws.send(json.dumps(payload))
                    while True:
                        msg = json.loads(await ws.recv())
                        if msg.get('id') == cmd_id:
                            return msg

                await send_cmd(1, 'Console.enable')
                await send_cmd(2, 'Runtime.enable')

                await send_cmd(10, 'Runtime.evaluate', {'expression': 'switchMainSection("section-overview")'})
                await asyncio.sleep(0.2)
                await send_cmd(11, 'Runtime.evaluate', {'expression': 'selectCategory(1)'})
                await asyncio.sleep(0.2)
                await send_cmd(12, 'Runtime.evaluate', {'expression': 'document.getElementById("overview-peer-benchmark").scrollIntoView()'})
                await asyncio.sleep(0.3)

                # Capture 流通卡數 (Growth Mode)
                snap1 = await send_cmd(20, 'Page.captureScreenshot', {'format': 'png'})
                img_data1 = snap1.get('result', {}).get('data')
                if img_data1:
                    p1 = os.path.join(script_dir, f'{prefix}_cards_circ.png')
                    with open(p1, 'wb') as f:
                        f.write(base64.b64decode(img_data1))
                    print(f"Captured: {p1}")

                # Switch to 活卡率 (Quality Mode)
                await send_cmd(30, 'Runtime.evaluate', {'expression': 'selectMetric(2)'})
                await asyncio.sleep(0.3)
                snap2 = await send_cmd(31, 'Page.captureScreenshot', {'format': 'png'})
                img_data2 = snap2.get('result', {}).get('data')
                if img_data2:
                    p2 = os.path.join(script_dir, f'{prefix}_cards_active.png')
                    with open(p2, 'wb') as f:
                        f.write(base64.b64decode(img_data2))
                    print(f"Captured: {p2}")

        asyncio.run(run())
    finally:
        proc.kill()

if __name__ == '__main__':
    capture('credit_card_full_dashboard.html', 9385, 'prod')
    capture('demo.html', 9386, 'demo')
