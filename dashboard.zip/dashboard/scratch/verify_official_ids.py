import re
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('01_儀表板執行環境/credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    text = f.read()

c00_ids = re.findall(r'id="(c00-[^"]+)"', text)
print(f'Total c00-* IDs found: {len(c00_ids)}')

critical_ids = [
    'c00-cashadv-val', 'c00-cashadv-growth', 'c00-cashadv-hint',
    'c00-revolving-val', 'c00-revolving-growth',
    'c00-peer-box-title', 'c00-donut-wrap', 'c00-peer-list',
    'c00-wf-bar2-val', 'c00-wf-inc-val', 'c00-wf-dec-val', 'c00-wf-bar7-val',
    'c00-fr-amt-val', 'c00-fr-cnt-val',
    'c00-acq-amt-val', 'c00-acq-cnt-val', 'c00-acq-mcht-val',
    'c00-twqr-apply-cnt', 'c00-twqr-new-mcht', 'c00-twqr-total-mcht'
]

missing = [cid for cid in critical_ids if cid not in text]
if missing:
    print('MISSING CRITICAL IDS:', missing)
else:
    print('ALL CRITICAL IDS PRESENT AND VERIFIED!')

all_ids = re.findall(r'id="([^"]+)"', text)
print(f'Total HTML IDs across full dashboard: {len(all_ids)}')
