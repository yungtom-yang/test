import urllib.request
import json
import asyncio
import websockets
import os
import subprocess
import time
import base64

port = 9295
html_abs = os.path.abspath('01_儀表板執行環境/credit_card_full_dashboard.html')
artifact_dir = r'C:\Users\詠棠\.gemini\antigravity\brain\a5b67522-ed07-496c-a109-ff9a49d15ce4'
os.makedirs(artifact_dir, exist_ok=True)
screenshot_path = os.path.join(artifact_dir, 'billing_center_3charts.png')

cmd = [
    r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
    '--headless=new',
    f'--remote-debugging-port={port}',
    '--window-size=1600,1100',
    '--no-sandbox',
    '--disable-gpu',
    html_abs
]
proc = subprocess.Popen(cmd)
time.sleep(2)

try:
    tabs = json.loads(urllib.request.urlopen(f'http://localhost:{port}/json').read().decode())
    page_tab = [t for t in tabs if t.get('type') == 'page'][0]
    
    async def run():
        async with websockets.connect(page_tab['webSocketDebuggerUrl']) as ws:
            # Switch to Section Issuing (03 發卡業務)
            await ws.send(json.dumps({'id': 1, 'method': 'Runtime.evaluate', 'params': {'expression': 'switchMainSection("section-issuing")'}}))
            await ws.recv()
            await asyncio.sleep(0.5)

            # Switch to Tab 1 (帳單列印中心)
            await ws.send(json.dumps({'id': 2, 'method': 'Runtime.evaluate', 'params': {'expression': 'switchIssTab(1)'}}))
            await ws.recv()
            await asyncio.sleep(0.5)
            
            # Scroll to section 03 tab 1
            await ws.send(json.dumps({'id': 3, 'method': 'Runtime.evaluate', 'params': {'expression': 'document.getElementById("iss-tab-1").scrollIntoView()'}}))
            await ws.recv()
            await asyncio.sleep(0.5)
            
            # Capture screenshot
            await ws.send(json.dumps({'id': 4, 'method': 'Page.captureScreenshot', 'params': {'format': 'png'}}))
            while True:
                msg = json.loads(await ws.recv())
                if msg.get('id') == 4:
                    img_data = base64.b64decode(msg['result']['data'])
                    with open(screenshot_path, 'wb') as f:
                        f.write(img_data)
                    print('Screenshot saved:', screenshot_path, 'size:', len(img_data))
                    break

    asyncio.run(run())
finally:
    proc.kill()
