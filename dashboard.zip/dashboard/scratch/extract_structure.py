import sys
import re
sys.stdout.reconfigure(encoding='utf-8')

with open('01_儀表板執行環境/credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Extract section 02
sec02 = re.search(r'<!-- =+\s*SECTION 02:.*?-->\s*(<section.*?</section>)', html, re.DOTALL)
if sec02:
    print("=== SECTION 02 FOUND ===")
    cards02 = re.findall(r'<div class="monthly-kpi-title">([^<]+)</div>', sec02.group(1))
    print("Section 02 monthly KPI titles:", cards02)
    panels02 = re.findall(r'<h[34][^>]*>([^<]+)</h[34]>', sec02.group(1))
    print("Section 02 panel/section headings:", panels02)

# Extract section 03
sec03 = re.search(r'<!-- =+\s*SECTION 03:.*?-->\s*(<section.*?</section>)', html, re.DOTALL)
if sec03:
    print("\n=== SECTION 03 FOUND ===")
    cards03 = re.findall(r'<div class="monthly-kpi-title">([^<]+)</div>', sec03.group(1))
    print("Section 03 monthly KPI titles:", cards03)
    panels03 = re.findall(r'<h[34][^>]*>([^<]+)</h[34]>', sec03.group(1))
    print("Section 03 panel/section headings:", panels03)
    tabs03 = re.findall(r'<button[^>]*switchIssTab\(\d+\)[^>]*>([^<]+)</button>', sec03.group(1))
    print("Section 03 diagnosis tabs:", tabs03)
