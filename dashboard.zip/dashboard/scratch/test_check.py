import re

with open('01_儀表板執行環境/credit_card_full_dashboard.html', encoding='utf-8') as f:
    html = f.read()

with open('01_儀表板執行環境/dashboard_app.js', encoding='utf-8') as f:
    js = f.read()

notif_ids = [
    'b03-bill-notif-tot',
    'b03-bill-notif-erate',
    'b03-bill-notif-seg-elec',
    'b03-bill-notif-seg-papr',
    'b03-bill-notif-lbl-elec',
    'b03-bill-notif-lbl-papr'
]

print("=== Checking notif IDs ===")
for nid in notif_ids:
    has_html = f'id="{nid}"' in html
    has_js = nid in js
    print(f"{nid:25} in HTML: {has_html!s:5} | in JS: {has_js}")

print("\n=== Checking all getElementById in dashboard_app.js ===")
ids_in_js = re.findall(r'document\.getElementById\("([^"]+)"\)', js)
ids_in_js += re.findall(r"document\.getElementById\('([^']+)'\)", js)
missing = [i for i in ids_in_js if f'id="{i}"' not in html]
print(f"Total getElementById in JS: {len(ids_in_js)}")
print(f"Missing in HTML count: {len(missing)}")
if missing:
    print("Missing IDs:", missing)
else:
    print("All IDs in JS exist in HTML!")
