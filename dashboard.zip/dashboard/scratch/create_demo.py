# -*- coding: utf-8 -*-
with open('01_儀表板執行環境/credit_card_full_dashboard.html', 'r', encoding='utf-8') as f:
    content = f.read()

new_tab_content = """<!-- 4B Tab 1: 紅利核心交易量能監控 -->
<div class="tab-content" id="sys-tab-1">
<!-- 4 Microservice Overview Cards -->
<div class="monthly-kpi-layout-4">
<article class="monthly-kpi monthly-secondary">
<div class="monthly-kpi-title" id="b04-ms-c1-title">小樹點查詢服務</div>
<div class="monthly-kpi-value" id="b04-ms-c1-val">-<em>萬次</em></div>
<div class="monthly-growth" id="b04-ms-c1-growth">
<span class="number-neutral" id="b04-ms-c1-yoy"><b>YoY</b>-</span>
<span class="number-neutral" id="b04-ms-c1-mom"><b>MoM</b>-</span>
</div>
<div class="monthly-tps" id="b04-ms-c1-tps">峰值TPS: -</div>
</article>
<article class="monthly-kpi monthly-secondary">
<div class="monthly-kpi-title" id="b04-ms-c2-title">回饋總覽查詢服務</div>
<div class="monthly-kpi-value" id="b04-ms-c2-val">-<em>萬次</em></div>
<div class="monthly-growth" id="b04-ms-c2-growth">
<span class="number-neutral" id="b04-ms-c2-yoy"><b>YoY</b>-</span>
<span class="number-neutral" id="b04-ms-c2-mom"><b>MoM</b>-</span>
</div>
<div class="monthly-tps" id="b04-ms-c2-tps">峰值TPS: -</div>
</article>
<article class="monthly-kpi monthly-secondary">
<div class="monthly-kpi-title" id="b04-ms-c3-title">小樹點兌換服務</div>
<div class="monthly-kpi-value" id="b04-ms-c3-val">-<em>萬次</em></div>
<div class="monthly-growth" id="b04-ms-c3-growth">
<span class="number-neutral" id="b04-ms-c3-yoy"><b>YoY</b>-</span>
<span class="number-neutral" id="b04-ms-c3-mom"><b>MoM</b>-</span>
</div>
<div class="monthly-tps" id="b04-ms-c3-tps">峰值TPS: -</div>
</article>
<article class="monthly-kpi monthly-secondary">
<div class="monthly-kpi-title" id="b04-ms-c4-title">票券服務（雲端）</div>
<div class="monthly-kpi-value" id="b04-ms-c4-val">-<em>萬次</em></div>
<div class="monthly-growth" id="b04-ms-c4-growth">
<span class="number-neutral" id="b04-ms-c4-yoy"><b>YoY</b>-</span>
<span class="number-neutral" id="b04-ms-c4-mom"><b>MoM</b>-</span>
</div>
<div class="monthly-tps" id="b04-ms-c4-tps">峰值TPS: -</div>
</article>
</div>
</div>"""

start_marker = '<!-- 4B Tab 1: 紅利核心交易量能監控 (方案一：左右雙圖雙軌制) -->'
# The sys-tab-1 closes with </div>, then </article> closes the main card
# Let's inspect where sys-tab-1 ends
p_start = content.find(start_marker)
# Find the next </article>
p_end = content.find('</article>\n</div>\n</section>', p_start)

if p_start != -1 and p_end != -1:
    old_section = content[p_start:p_end]
    print(f"Found section from {p_start} to {p_end}")
    demo_content = content[:p_start] + new_tab_content + "\n" + content[p_end:]
    with open('01_儀表板執行環境/demo.html', 'w', encoding='utf-8') as f_out:
        f_out.write(demo_content)
    print("demo.html created successfully!")
else:
    print(f"Error: markers not found! p_start={p_start}, p_end={p_end}")
