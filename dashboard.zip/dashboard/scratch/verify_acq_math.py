import sys, json, math
sys.stdout.reconfigure(encoding='utf-8')

with open('01_儀表板執行環境/dashboard_data.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

b2 = data['block02']
kpi = b2['monthly_kpis']
twqr = b2['twqr']
online = b2['online_channels']

print("="*80)
print("收單數據跨模組勾稽與數學邏輯深入檢驗")
print("="*80)

# 1. 收單交易金額
amt_tot = kpi['acq_amt']['total']
amt_yoy = kpi['acq_amt']['yoy']
amt_mom = kpi['acq_amt']['mom']

epos_amt = sum(c['amount'] for c in online if 'EPOS' in c['name'])
ph_amt = sum(c['amount'] for c in online if 'Payment Hub' in c['name'])
online_amt = epos_amt + ph_amt
cps_amt = amt_tot - online_amt

cps_share = (cps_amt / amt_tot) * 100
epos_share = (epos_amt / amt_tot) * 100
ph_share = (ph_amt / amt_tot) * 100

print(f"\n1. 收單交易金額:")
print(f"   總金額: {amt_tot} 億元 (YoY: {amt_yoy}%, MoM: {amt_mom}%)")
print(f"   CPS其他通路: {cps_amt:.6f} 億元 -> 顯示 220.58 億 ({cps_share:.1f}%)")
print(f"   EPOS通路:    {epos_amt:.6f} 億元 -> 顯示 16.84 億 ({epos_share:.1f}%)")
print(f"   PH通路:      {ph_amt:.6f} 億元 -> 顯示 1.99 億 ({ph_share:.1f}%)")
print(f"   驗證和: {cps_amt + epos_amt + ph_amt:.4f} vs 總額 {amt_tot:.4f} => 差值: {abs((cps_amt + epos_amt + ph_amt) - amt_tot):.8f}")
assert abs((cps_amt + epos_amt + ph_amt) - amt_tot) < 1e-6, "金額相加不平衡"

# 2. 收單交易筆數
cnt_tot = kpi['acq_cnt']['total']
cnt_yoy = kpi['acq_cnt']['yoy']
cnt_mom = kpi['acq_cnt']['mom']

epos_cnt = sum(c['count'] for c in online if 'EPOS' in c['name'])
ph_cnt = sum(c['count'] for c in online if 'Payment Hub' in c['name'])
online_cnt = epos_cnt + ph_cnt
cps_cnt = cnt_tot - online_cnt

cps_cnt_share = (cps_cnt / cnt_tot) * 100
epos_cnt_share = (epos_cnt / cnt_tot) * 100
ph_cnt_share = (ph_cnt / cnt_tot) * 100

print(f"\n2. 收單交易筆數:")
print(f"   總筆數: {cnt_tot} 萬筆 (YoY: {cnt_yoy}%, MoM: {cnt_mom}%)")
print(f"   CPS其他通路: {cps_cnt:.4f} 萬筆 -> 顯示 1,325.17 萬筆 ({cps_cnt_share:.1f}%)")
print(f"   EPOS通路:    {epos_cnt:.4f} 萬筆 -> 顯示 1,316.46 萬筆 ({epos_cnt_share:.1f}%)")
print(f"   PH通路:      {ph_cnt:.4f} 萬筆 -> 顯示 350.17 萬筆 ({ph_cnt_share:.1f}%)")
print(f"   驗證和: {cps_cnt + epos_cnt + ph_cnt:.4f} vs 總筆數 {cnt_tot:.4f} => 差值: {abs((cps_cnt + epos_cnt + ph_cnt) - cnt_tot):.8f}")
assert abs((cps_cnt + epos_cnt + ph_cnt) - cnt_tot) < 1e-6, "筆數相加不平衡"

# 3. 線上交易型態明細
print(f"\n3. 線上交易渠道各子項客單價推算:")
for c in online:
    amt_yuan = c['amount'] * 100000000
    cnt_bi = c['count'] * 10000
    calc_ticket = round(amt_yuan / cnt_bi)
    print(f"   {c['name']:<20}: 金額 {c['amount']:.4f} 億, 筆數 {c['count']:.4f} 萬筆, 計算客單: {calc_ticket} 元 vs 填寫客單: {c['avg_ticket']} 元 => 差值: {abs(calc_ticket - c['avg_ticket'])}")
    assert abs(calc_ticket - c['avg_ticket']) <= 1, f"客單價計算不符: {c['name']}"

# 4. TWQR 指標
print(f"\n4. TWQR 業務指標推算:")
tw_amt = twqr['tx_amount']
tw_cnt = twqr['tx_count']
calc_tw_ticket = round(tw_amt / tw_cnt)
print(f"   TWQR 交易金額: {tw_amt} 元 (MoM: {twqr['tx_amount_mom']}%)")
print(f"   TWQR 交易筆數: {tw_cnt} 筆 (MoM: {twqr['tx_count_mom']}%)")
print(f"   TWQR 累計特店: {twqr['total_merchants']} 家 (MoM: {twqr['total_merchants_mom']}%)")
print(f"   TWQR 計算客單: {calc_tw_ticket} 元 vs 填寫客單: {twqr['avg_ticket']} 元 => 差值: {abs(calc_tw_ticket - twqr['avg_ticket'])}")
assert calc_tw_ticket == twqr['avg_ticket'], "TWQR客單價不符"

print("\n>>> 所有數學公式與跨項勾稽 100% 驗證通過！<<<")
