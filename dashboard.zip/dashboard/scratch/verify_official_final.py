# -*- coding: utf-8 -*-
import sys
import os
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

artifact_dir = r"C:\Users\詠棠\.gemini\antigravity\brain\7f466f8c-d4e5-407e-b8a3-effee7d7cd33"
os.makedirs(artifact_dir, exist_ok=True)

opts = Options()
opts.add_argument("--headless")
opts.add_argument("--window-size=1680,1050")
opts.add_argument("--disable-gpu")
opts.set_capability('goog:loggingPrefs', {'browser': 'ALL'})

driver = webdriver.Chrome(options=opts)

dash_path = os.path.abspath("01_儀表板執行環境/credit_card_full_dashboard.html").replace("\\", "/")
print(f"Loading {dash_path}...")
driver.get(f"file:///{dash_path}")
time.sleep(1.5)

# 1. Console Logs Check
logs = driver.get_log('browser')
errors = [log for log in logs if log['level'] in ['SEVERE', 'ERROR']]
print(f"Console errors count: {len(errors)}")
for err in errors:
    print("  Error:", err['message'])

# 2. Check heights
col1 = driver.find_element(By.CSS_SELECTOR, '.cockpit-col-1')
col2 = driver.find_element(By.CSS_SELECTOR, '.cockpit-col-2')
col3 = driver.find_element(By.CSS_SELECTOR, '.cockpit-col-3')
c1a = driver.find_element(By.CSS_SELECTOR, '.cell-iss-1a')
c1c = driver.find_element(By.CSS_SELECTOR, '.cell-iss-1c')

print("\n--- OFFICIAL FINAL HEIGHTS ---")
print(f"Col 1: {col1.size['height']}px (c1a: {c1a.size['height']}px, c1c: {c1c.size['height']}px)")
print(f"Col 2: {col2.size['height']}px")
print(f"Col 3: {col3.size['height']}px")

is_aligned = (col1.size['height'] == col2.size['height'] == col3.size['height'])
print(f"Columns 100% Aligned: {is_aligned}")

# 3. Check specific key elements and text content
bar_items = driver.find_elements(By.CSS_SELECTOR, '.bar-row-item')
print(f"Rendered peer bar items count: {len(bar_items)}")
for item in bar_items:
    rank = item.find_element(By.CSS_SELECTOR, '.b-rank-badge').text
    name = item.find_element(By.CSS_SELECTOR, '.b-bank-name').text
    val = item.find_element(By.CSS_SELECTOR, '.b-track-val').text
    share = item.find_element(By.CSS_SELECTOR, '.b-track-share').text
    yoy = item.find_element(By.CSS_SELECTOR, '.b-yoy-val').text
    print(f"  Rank {rank} | {name}: {val} ({share}) | {yoy}")

# 4. Check DOM IDs preservation
auth_val = driver.find_element(By.ID, 'c00-iss-auth-val')
print(f"c00-iss-auth-val preserved? {auth_val is not None}, display: {auth_val.is_displayed()}")

mkt_val = driver.find_element(By.ID, 'c00-market-val')
print(f"c00-market-val: {mkt_val.text}")

mkt_yoy = driver.find_element(By.ID, 'c00-market-yoy')
print(f"c00-market-yoy: {mkt_yoy.text}")

# 5. Screenshots
cockpit_elem = driver.find_element(By.ID, 'section-cockpit')
official_cockpit_img = os.path.join(artifact_dir, "official_variant1_cockpit.png")
cockpit_elem.screenshot(official_cockpit_img)
print(f"Saved: {official_cockpit_img}")

official_col1_img = os.path.join(artifact_dir, "official_variant1_col1_detail.png")
col1.screenshot(official_col1_img)
print(f"Saved: {official_col1_img}")

driver.quit()
print("\nFinal verification complete!")
