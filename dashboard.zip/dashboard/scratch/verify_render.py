import urllib.request
import json
import asyncio
import websockets
import os
import subprocess
import time

port = 9267
html_abs = os.path.abspath('01_儀表板執行環境/credit_card_full_dashboard.html')
cmd = [
    r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
    '--headless=new',
    f'--remote-debugging-port={port}',
    '--no-sandbox',
    '--disable-gpu',
    html_abs
]
proc = subprocess.Popen(cmd)
time.sleep(2)

try:
    tabs = json.loads(urllib.request.urlopen(f'http://localhost:{port}/json').read().decode())
    page_tab = [t for t in tabs if t.get('type') == 'page'][0]
    
    async def run():
        async with websockets.connect(page_tab['webSocketDebuggerUrl']) as ws:
            async def eval_js(msg_id, code):
                await ws.send(json.dumps({'id': msg_id, 'method': 'Runtime.evaluate', 'params': {'expression': code, 'returnByValue': True}}))
                while True:
                    msg = json.loads(await ws.recv())
                    if msg.get('id') == msg_id:
                        res = msg.get('result', {}).get('result', {})
                        if 'value' in res:
                            return res['value']
                        return res

            print('1. Page Title:', await eval_js(1, 'document.title'))
            
            # Switch tab
            await eval_js(2, 'switchIssTab(1)')
            
            print('2. 信用卡帳單總量:', await eval_js(3, 'document.getElementById("b03-bill-card-tot")?.innerText'))
            print('   - 電子:', await eval_js(4, 'document.getElementById("b03-bill-card-lbl-elec")?.innerText'))
            print('   - 紙本:', await eval_js(5, 'document.getElementById("b03-bill-card-lbl-papr")?.innerText'))
            
            print('3. 銀行帳單總量:', await eval_js(6, 'document.getElementById("b03-bill-bank-tot")?.innerText'))
            print('   - 電子:', await eval_js(7, 'document.getElementById("b03-bill-bank-lbl-elec")?.innerText'))
            print('   - 紙本:', await eval_js(8, 'document.getElementById("b03-bill-bank-lbl-papr")?.innerText'))
            
            print('4. 銀行通知函總量:', await eval_js(9, 'document.getElementById("b03-bill-notif-tot")?.innerText'))
            print('   - 電子:', await eval_js(10, 'document.getElementById("b03-bill-notif-lbl-elec")?.innerText'))
            print('   - 紙本:', await eval_js(11, 'document.getElementById("b03-bill-notif-lbl-papr")?.innerText'))
            print('   - 電子進度條寬度:', await eval_js(12, 'document.getElementById("b03-bill-notif-seg-elec")?.style.width'))
            print('   - 紙本進度條寬度:', await eval_js(13, 'document.getElementById("b03-bill-notif-seg-papr")?.style.width'))

    asyncio.run(run())
finally:
    proc.kill()
