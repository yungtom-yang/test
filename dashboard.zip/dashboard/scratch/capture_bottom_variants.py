# -*- coding: utf-8 -*-
import urllib.request
import json
import asyncio
import websockets
import os
import subprocess
import time
import sys
import base64

sys.stdout.reconfigure(encoding='utf-8')

port = 9395
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)
html_abs = os.path.join(project_root, '01_儀表板執行環境', 'demo.html')
html_uri = 'file:///' + html_abs.replace('\\', '/')

cmd = [
    r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
    '--headless=new',
    f'--remote-debugging-port={port}',
    '--window-size=1600,1200',
    '--no-sandbox',
    '--disable-gpu',
    html_uri
]
proc = subprocess.Popen(cmd)
time.sleep(2)

try:
    tabs = json.loads(urllib.request.urlopen(f'http://localhost:{port}/json').read().decode())
    page_tab = [t for t in tabs if t.get('type') == 'page'][0]

    async def run():
        async with websockets.connect(page_tab['webSocketDebuggerUrl']) as ws:
            async def send_cmd(cmd_id, method, params=None):
                payload = {'id': cmd_id, 'method': method}
                if params:
                    payload['params'] = params
                await ws.send(json.dumps(payload))
                while True:
                    msg = json.loads(await ws.recv())
                    if msg.get('id') == cmd_id:
                        return msg

            await send_cmd(1, 'Console.enable')
            await send_cmd(2, 'Runtime.enable')

            # Switch to section-overview
            await send_cmd(10, 'Runtime.evaluate', {'expression': 'switchMainSection("section-overview")'})
            await asyncio.sleep(0.3)
            # Switch to 卡量經營 (category 1)
            await send_cmd(11, 'Runtime.evaluate', {'expression': 'selectCategory(1)'})
            await asyncio.sleep(0.3)

            # Scroll peer benchmark into view
            await send_cmd(12, 'Runtime.evaluate', {'expression': 'document.getElementById("overview-peer-benchmark").scrollIntoView()'})
            await asyncio.sleep(0.3)

            # Test each layout variant and take screenshot of the panel
            for v, name in [(1, 'variant1_left_kpi'), (2, 'variant2_capsule'), (3, 'variant3_right_kpi'), (0, 'variant0_original')]:
                await send_cmd(20 + v, 'Runtime.evaluate', {'expression': f'switchPeerLayout({v})'})
                await asyncio.sleep(0.3)

                # Capture full screenshot
                snap = await send_cmd(50 + v, 'Page.captureScreenshot', {'format': 'png'})
                img_data = snap.get('result', {}).get('data')
                if img_data:
                    out_path = os.path.join(script_dir, f'demo_peer_{name}.png')
                    with open(out_path, 'wb') as f:
                        f.write(base64.b64decode(img_data))
                    print(f"Captured: {out_path}")

    asyncio.run(run())
finally:
    proc.kill()
