# -*- coding: utf-8 -*-
import urllib.request
import json
import asyncio
import websockets
import os
import subprocess
import time
import base64

port = 9345
html_abs = os.path.abspath('01_儀表板執行環境/demo.html')
artifact_dir = r'C:\Users\詠棠\.gemini\antigravity\brain\cfb8a245-3587-417d-8b97-ee2276e6387e'
os.makedirs(artifact_dir, exist_ok=True)

cmd = [
    r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
    '--headless=new',
    f'--remote-debugging-port={port}',
    '--window-size=1600,1200',
    '--no-sandbox',
    '--disable-gpu',
    f'file:///{html_abs.replace(os.sep, "/")}'
]
proc = subprocess.Popen(cmd)
time.sleep(2)

try:
    tabs = json.loads(urllib.request.urlopen(f'http://localhost:{port}/json').read().decode())
    page_tab = [t for t in tabs if t.get('type') == 'page'][0]
    
    async def run():
        async with websockets.connect(page_tab['webSocketDebuggerUrl']) as ws:
            # 1. Enable console and log
            await ws.send(json.dumps({'id': 1, 'method': 'Console.enable'}))
            await ws.recv()
            await ws.send(json.dumps({'id': 2, 'method': 'Runtime.enable'}))
            await ws.recv()

            # 2. Switch to Section Issuing (03 發卡業務)
            await ws.send(json.dumps({'id': 10, 'method': 'Runtime.evaluate', 'params': {'expression': 'switchMainSection("section-issuing")'}}))
            await ws.recv()
            await asyncio.sleep(0.5)

            # 3. Switch to Tab 4 (分期產品結構分析)
            await ws.send(json.dumps({'id': 11, 'method': 'Runtime.evaluate', 'params': {'expression': 'switchIssTab(4)'}}))
            await ws.recv()
            await asyncio.sleep(0.5)
            
            # 4. Scroll to iss-tab-4
            await ws.send(json.dumps({'id': 12, 'method': 'Runtime.evaluate', 'params': {'expression': 'document.getElementById("iss-tab-4").scrollIntoView()'}}))
            await ws.recv()
            await asyncio.sleep(0.5)
            
            # Check console errors
            await ws.send(json.dumps({'id': 13, 'method': 'Runtime.evaluate', 'params': {
                'expression': 'JSON.stringify({totAmt: document.getElementById("demo-inst-tot-amt")?.textContent, totCnt: document.getElementById("demo-inst-tot-cnt")?.textContent, avgTicket: document.getElementById("demo-inst-avg-ticket")?.textContent})'
            }}))
            res = json.loads(await ws.recv())
            print("Extracted values:", res.get('result', {}).get('result', {}).get('value'))

            # 5. Capture screenshot of default view (筆數結構 + 筆數 MoM 貢獻)
            await ws.send(json.dumps({'id': 20, 'method': 'Page.captureScreenshot', 'params': {'format': 'png'}}))
            while True:
                msg = json.loads(await ws.recv())
                if msg.get('id') == 20:
                    img_data = base64.b64decode(msg['result']['data'])
                    p1 = os.path.join(artifact_dir, 'tab4_demo_cnt_view.png')
                    with open(p1, 'wb') as f:
                        f.write(img_data)
                    print('Screenshot saved (Count View):', p1)
                    break

            # 6. Toggle to 金額結構 + 金額 YoY 貢獻
            await ws.send(json.dumps({'id': 30, 'method': 'Runtime.evaluate', 'params': {'expression': 'switchInstMix("amt"); switchInstWf("amt_yoy");'}}))
            await ws.recv()
            await asyncio.sleep(0.5)

            # 7. Capture screenshot of amount view
            await ws.send(json.dumps({'id': 31, 'method': 'Page.captureScreenshot', 'params': {'format': 'png'}}))
            while True:
                msg = json.loads(await ws.recv())
                if msg.get('id') == 31:
                    img_data = base64.b64decode(msg['result']['data'])
                    p2 = os.path.join(artifact_dir, 'tab4_demo_amt_view.png')
                    with open(p2, 'wb') as f:
                        f.write(img_data)
                    print('Screenshot saved (Amount View):', p2)
                    break

    asyncio.run(run())
finally:
    proc.kill()
