# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')
from bs4 import BeautifulSoup

import os
script_dir = os.path.dirname(os.path.abspath(__file__))
html_path = os.path.join(os.path.dirname(script_dir), '01_儀表板執行環境', 'credit_card_full_dashboard.html')

with open(html_path, 'r', encoding='utf-8') as f:
    soup = BeautifulSoup(f.read(), 'html.parser')

for sec in soup.find_all('section'):
    sec_id = sec.get('id', '')
    h2 = sec.find('h2')
    h2_text = h2.text.strip() if h2 else ''
    print(f'*** Section: id={sec_id}, title={h2_text} ***')
    for nav in sec.find_all(class_=lambda c: c and any(k in c.lower() for k in ['tab', 'nav', 'btn', 'pills', 'header'])):
        btns = nav.find_all('button')
        if btns and len(btns) > 1:
            btn_texts = [b.get_text(strip=True) for b in btns]
            print(f'   Buttons in {nav.get("class")}: {btn_texts}')
    for tc in sec.find_all(class_=lambda c: c and 'tab-content' in c):
        print(f'   Tab-content: id={tc.get("id")}')
    # also find article or chart-box titles
    for art in sec.find_all(class_=lambda c: c and any(k in c.lower() for k in ['chart-box', 'diagnostic', 'secondary'])):
        h3 = art.find(['h3', 'h4', 'span'])
        print(f'   Diagnostic box ({art.get("class")}): id={art.get("id")} header={h3.get_text(strip=True) if h3 else ""}')
