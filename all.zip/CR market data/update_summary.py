import os
import sys
import glob
import re
import shutil
import zipfile
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Ensure UTF-8 output in Windows console
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

DATA_DIR_NAME = 'data'

BANKS_CONFIG = [
    {'key': '中信', 'full_name': '中國信託商業銀行', 'sheet_name': '中國信託'},
    {'key': '國泰', 'full_name': '國泰世華商業銀行', 'sheet_name': '國泰世華'},
    {'key': '玉山', 'full_name': '玉山商業銀行', 'sheet_name': '玉山銀行'},
    {'key': '富邦', 'full_name': '台北富邦商業銀行', 'sheet_name': '台北富邦'},
    {'key': '台新', 'full_name': '台新國際商業銀行', 'sheet_name': '台新銀行'}
]

HEADERS = [
    '資料年月',
    '金融機構名稱',
    '流通卡數',
    '有效卡數',
    '活卡率(%)',
    '當月發卡數',
    '當月停卡數',
    '循環信用餘額',
    '未到期分期付款餘額',
    '當月簽帳金額',
    '當月預借現金金額',
    '逾期三個月以上帳款比率(%)',
    '逾期六個月以上帳款比率(%)',
    '備抵呆帳提足率(%)',
    '當月轉銷呆帳金額',
    '當年度轉銷呆帳金額累計'
]

def auto_extract_zips(work_dir):
    """自動偵測並解壓縮資料夾內的 .zip 檔，提取 .xlsx 到當前資料夾"""
    zip_files = glob.glob(os.path.join(work_dir, '*.zip'))
    if not zip_files:
        return

    print(f"偵測到 {len(zip_files)} 個 .zip 壓縮檔，正在解壓...")
    for zf_path in zip_files:
        zf_name = os.path.basename(zf_path)
        m = re.match(r'^(\d{5})', zf_name)
        period_code = m.group(1) if m else None

        with zipfile.ZipFile(zf_path, 'r') as z:
            for entry in z.namelist():
                if entry.lower().endswith('.xlsx') and not entry.startswith('__MACOSX'):
                    # 若 zip 內檔名不規範，以月份代碼重新標準化命名
                    if period_code and not entry.startswith(period_code):
                        target_filename = f"{period_code}_信用卡重要資訊揭露.xlsx"
                    else:
                        target_filename = os.path.basename(entry)
                    
                    target_path = os.path.join(work_dir, target_filename)
                    with open(target_path, 'wb') as f_out:
                        f_out.write(z.read(entry))
                    print(f"  [+] 已從 {zf_name} 提取: {target_filename}")


def get_monthly_files(work_dir, data_dir):
    """
    取得所有單月資料檔（同時支援 data/ 歷史歸檔資料夾與根目錄新檔）
    若同月份同時存在於根目錄與 data/，優先以根目錄檔案為主
    """
    monthly_map = {}

    # 1. 搜尋 data/ 資料夾中已歸檔的資料
    if os.path.exists(data_dir):
        for f in glob.glob(os.path.join(data_dir, '*.xlsx')):
            basename = os.path.basename(f)
            if basename.startswith('~$') or '五大發卡行' in basename:
                continue
            m = re.search(r'(\d{5})', basename)
            if m:
                monthly_map[m.group(1)] = (f, basename)

    # 2. 搜尋根目錄的新增單月檔（若有相同月份會覆蓋舊檔）
    for f in glob.glob(os.path.join(work_dir, '*.xlsx')):
        basename = os.path.basename(f)
        if basename.startswith('~$') or '五大發卡行' in basename or basename.startswith('_'):
            continue
        m = re.search(r'(\d{5})', basename)
        if m:
            monthly_map[m.group(1)] = (f, basename)

    monthly_files = [(code, path, basename) for code, (path, basename) in monthly_map.items()]
    monthly_files.sort(key=lambda x: x[0])
    return monthly_files


def move_raw_files_to_data(work_dir, data_dir):
    """分析完成後，將根目錄下的原始單月 .xlsx 移入 data 資料夾歸檔"""
    os.makedirs(data_dir, exist_ok=True)
    candidates = glob.glob(os.path.join(work_dir, '*.xlsx'))
    moved_count = 0

    for f in candidates:
        basename = os.path.basename(f)
        if basename.startswith('~$') or '五大發卡行' in basename or basename.startswith('_'):
            continue
        
        # 僅移動符合 5 位月份代碼的原始單月檔
        if re.search(r'(\d{5})', basename):
            dst_path = os.path.join(data_dir, basename)
            # 若目的地已存在同名檔案，先移除以便替換
            if os.path.exists(dst_path):
                try:
                    os.remove(dst_path)
                except Exception:
                    pass
            try:
                shutil.move(f, dst_path)
                print(f"  [>] 已歸檔至 data/ 資料夾：{basename}")
                moved_count += 1
            except Exception as e:
                print(f"  [!] 移動檔案至 data/ 失敗 {basename}: {e}")

    # 若根目錄有已解壓的 .zip，也一併移動歸檔至 data/
    for zf in glob.glob(os.path.join(work_dir, '*.zip')):
        z_name = os.path.basename(zf)
        dst_z = os.path.join(data_dir, z_name)
        if os.path.exists(dst_z):
            try:
                os.remove(dst_z)
            except Exception:
                pass
        try:
            shutil.move(zf, dst_z)
            print(f"  [>] 已將壓縮檔移至 data/ 資料夾：{z_name}")
        except Exception:
            pass

    return moved_count


def build_summary(work_dir):
    data_dir = os.path.join(work_dir, DATA_DIR_NAME)
    os.makedirs(data_dir, exist_ok=True)

    # 1. 偵測並解壓縮 zip（若有）
    auto_extract_zips(work_dir)

    # 2. 獲取所有月份清單（含根目錄新增檔與 data/ 已歸檔資料）
    monthly_files = get_monthly_files(work_dir, data_dir)

    if not monthly_files:
        print("未找到任何單月份的信用卡重要資訊 .xlsx 檔案！")
        return

    min_period = monthly_files[0][0]
    max_period = monthly_files[-1][0]
    total_months = len(monthly_files)

    print(f"找到 {total_months} 個月份資料（區間：{min_period} ～ {max_period}）")

    # 3. 建立新活頁簿
    wb_out = openpyxl.Workbook()
    wb_out.remove(wb_out.active) # 移除預設空白 sheet

    # 建立「總表」
    ws_all = wb_out.create_sheet(title='總表')

    # 建立各銀行工作表
    bank_sheets = {}
    for b in BANKS_CONFIG:
        ws_b = wb_out.create_sheet(title=b['sheet_name'])
        bank_sheets[b['full_name']] = ws_b

    # 樣式定義
    font_header = Font(name='微軟正黑體', size=11, bold=True, color='FFFFFF')
    fill_header = PatternFill(start_color='1F4E79', end_color='1F4E79', fill_type='solid')

    font_bank_header = Font(name='微軟正黑體', size=11, bold=True, color='FFFFFF')
    fill_bank_header = PatternFill(start_color='2E5B82', end_color='2E5B82', fill_type='solid')

    font_data = Font(name='微軟正黑體', size=10)
    fill_alt = PatternFill(start_color='F7F9FC', end_color='F7F9FC', fill_type='solid')

    thin_border = Side(border_style='thin', color='D9D9D9')
    border_cell = Border(left=thin_border, right=thin_border, top=thin_border, bottom=thin_border)

    align_center = Alignment(horizontal='center', vertical='center')
    align_right = Alignment(horizontal='right', vertical='center')
    align_header = Alignment(horizontal='center', vertical='center', wrap_text=True)

    # 寫入表頭 (總表)
    ws_all.append(HEADERS)
    ws_all.row_dimensions[1].height = 28
    for col_idx in range(1, len(HEADERS) + 1):
        c = ws_all.cell(row=1, column=col_idx)
        c.font = font_header
        c.fill = fill_header
        c.alignment = align_header
        c.border = border_cell

    # 寫入表頭 (各銀行)
    for ws_b in bank_sheets.values():
        ws_b.append(HEADERS)
        ws_b.row_dimensions[1].height = 28
        for col_idx in range(1, len(HEADERS) + 1):
            c = ws_b.cell(row=1, column=col_idx)
            c.font = font_bank_header
            c.fill = fill_bank_header
            c.alignment = align_header
            c.border = border_cell

    def apply_row_style(ws, row_idx, is_alt=False):
        ws.row_dimensions[row_idx].height = 20
        for col_idx in range(1, len(HEADERS) + 1):
            c = ws.cell(row=row_idx, column=col_idx)
            c.font = font_data
            c.border = border_cell
            if is_alt:
                c.fill = fill_alt
            
            if col_idx in (1, 2):
                c.alignment = align_center
            elif col_idx in (5, 12, 13, 14): # 活卡率(%) 與 風險比率(%)
                c.alignment = align_right
                c.number_format = '0.00'
            else: # 金額與卡數
                c.alignment = align_right
                c.number_format = '#,##0'

    total_row_idx = 1
    bank_row_indices = {b['full_name']: 1 for b in BANKS_CONFIG}

    # 4. 分析並萃取數據
    for period_code, f_path, basename in monthly_files:
        period_label = f"{period_code[:3]}/{period_code[3:]}"
        
        try:
            wb_src = openpyxl.load_workbook(f_path, data_only=True)
            ws_src = wb_src.active
        except Exception as e:
            print(f"  [!] 讀取檔案失敗 {basename}: {e}")
            continue

        row_by_bank = {}
        for r in range(4, ws_src.max_row + 1):
            name = ws_src.cell(r, 1).value
            if name:
                clean_name = str(name).strip()
                for b in BANKS_CONFIG:
                    if b['full_name'] in clean_name:
                        row_vals = [ws_src.cell(r, c).value for c in range(1, 15)]
                        row_by_bank[b['full_name']] = row_vals
                        break

        for b in BANKS_CONFIG:
            vals = row_by_bank.get(b['full_name'])
            if vals:
                # 計算活卡率 (%) = 有效卡數 / 流通卡數 * 100
                circ_cards = int(vals[1] or 0)
                act_cards = int(vals[2] or 0)
                active_rate = round(act_cards / circ_cards * 100, 2) if circ_cards > 0 else 0.0
                
                # 組成完整行：[年月] + [銀行名, 流通, 有效, 活卡率] + [其餘指標]
                row_with_rate = [vals[0], circ_cards, act_cards, active_rate] + vals[3:]
                row_data = [period_label] + row_with_rate
                
                # 寫入總表
                total_row_idx += 1
                ws_all.append(row_data)
                apply_row_style(ws_all, total_row_idx, is_alt=(total_row_idx % 2 == 0))
                
                # 寫入對應銀行 Sheet
                ws_b = bank_sheets[b['full_name']]
                bank_row_indices[b['full_name']] += 1
                b_idx = bank_row_indices[b['full_name']]
                ws_b.append(row_data)
                apply_row_style(ws_b, b_idx, is_alt=(b_idx % 2 == 0))

    # 自動調整欄寬與設定凍結窗格
    all_worksheets = [ws_all] + list(bank_sheets.values())
    for ws in all_worksheets:
        ws.views.sheetView[0].showGridLines = True
        ws.freeze_panes = 'C2' # 凍結標題與前兩欄
            
        for col in ws.columns:
            col_letter = get_column_letter(col[0].column)
            max_len = 0
            for cell in col:
                val_str = str(cell.value or '')
                w = sum(2 if ord(ch) > 127 else 1 for ch in val_str)
                if w > max_len:
                    max_len = w
            ws.column_dimensions[col_letter].width = max(max_len + 3, 12)

    # 5. 目標新檔名與暫存存檔
    new_summary_name = f"五大發卡行信用卡重要資訊彙整_{min_period}-{max_period}.xlsx"
    new_summary_path = os.path.join(work_dir, new_summary_name)
    temp_save_path = os.path.join(work_dir, "_summary_temp.xlsx")

    try:
        wb_out.save(temp_save_path)
    except PermissionError:
        print("\n[錯誤] 暫存檔寫入失敗，請確認資料夾權限！")
        return

    # 若新檔已存在（例如重複執行同月份更新），嘗試替換
    if os.path.exists(new_summary_path):
        try:
            os.remove(new_summary_path)
        except PermissionError:
            print(f"\n[錯誤] 無法覆寫檔案「{new_summary_name}」！")
            print("  原因：此檔案目前正被 Excel 或其他軟體開啟中。")
            print("  解決方式：請先關閉該 Excel 視窗，再重新執行更新程式！")
            if os.path.exists(temp_save_path):
                os.remove(temp_save_path)
            return

    os.rename(temp_save_path, new_summary_path)

    # 6. 分析儲存完成後，將原始單月 xlsx 移動至 data/ 資料夾歸檔
    print("\n正在將分析完成的原始月份檔案移至 data/ 資料夾...")
    moved_count = move_raw_files_to_data(work_dir, data_dir)
    print(f"  -> 共歸檔 {moved_count} 個原始檔案至 data/")

    # 7. 清理舊版彙整表
    old_summary_files = glob.glob(os.path.join(work_dir, '五大發卡行信用卡重要資訊彙整_*.xlsx'))
    for old_file in old_summary_files:
        if os.path.abspath(old_file) != os.path.abspath(new_summary_path):
            try:
                os.remove(old_file)
                print(f"  [-] 已自動清除舊版彙整檔: {os.path.basename(old_file)}")
            except PermissionError:
                print(f"  [提示] 舊版彙整檔 {os.path.basename(old_file)} 正由 Excel 開啟中，請在關閉 Excel 後手動刪除。")
            except Exception as e:
                print(f"  [!] 無法移除舊檔: {e}")

    print("\n" + "=" * 52)
    print("  信用卡重要資訊彙整表 - 更新成功！")
    print(f"  最新彙整表檔案: {new_summary_name}")
    print(f"  時間區間涵蓋: {min_period} ～ {max_period}（共 {total_months} 個月份）")
    print(f"  總表數據資料筆數: {total_row_idx - 1} 筆 (包含 5 家銀行)")
    print(f"  原始資料歸檔目錄: {DATA_DIR_NAME}/")
    print("=" * 52)


if __name__ == '__main__':
    script_dir = os.path.dirname(os.path.abspath(__file__))
    build_summary(script_dir)
