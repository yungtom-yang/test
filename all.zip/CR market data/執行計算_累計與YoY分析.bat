@echo off
chcp 65001 >nul
title 信用卡重要資訊 - 累計與 YoY 分析工具
echo ====================================================
echo        五大發卡行信用卡 累計數據與 YoY 分析工具
echo ====================================================
echo.

python "%~dp0calculate_yoy.py"

echo.
pause
