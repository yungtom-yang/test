@echo off
chcp 65001 >nul
title 信用卡重要資訊彙整更新程式
echo ====================================================
echo        五大發卡行信用卡重要資訊 - 自動更新工具
echo ====================================================
echo.
echo 正在檢查新資料並更新彙整表，請稍候...
echo.

python "%~dp0update_summary.py"

echo.
pause
