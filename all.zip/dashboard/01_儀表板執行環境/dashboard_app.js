  // ========================================================
  // 方案一：PPT 戰情室大屏等比例縮放引擎 (Scale-to-Fit Engine)
  // ========================================================
  let isPptScaleActive = true;

  function resizeCockpitCanvas() {
    const canvas = document.getElementById('cockpitCanvas');
    const stage = document.getElementById('cockpitStage');
    const indicator = document.getElementById('cockpit-scale-indicator');
    const badge = document.getElementById('subnavScaleBadge');
    if (!canvas || !stage) return;

    if (!isPptScaleActive) {
      canvas.style.transform = 'none';
      canvas.style.width = '100%';
      stage.style.height = 'auto';
      if (indicator) indicator.textContent = 'PPT 縮放: 關閉 (100%)';
      if (badge) badge.classList.add('is-off');
      return;
    }

    if (badge) badge.classList.remove('is-off');
    canvas.style.width = '1780px';

    // 計算當前視窗可用空間
    const stageRect = stage.getBoundingClientRect();
    const availableWidth = window.innerWidth - 32; // 預留兩側呼吸間隔
    const topOffset = stageRect.top > 0 ? stageRect.top : 110;
    const availableHeight = window.innerHeight - topOffset - 16; // 預留底部空間

    const targetW = 1780;
    const targetH = Math.max(canvas.scrollHeight || 860, 860);

    // 等比例縮放因子 (Fit Both Width & Height)
    const scaleX = availableWidth / targetW;
    const scaleY = Math.max(availableHeight, 460) / targetH;
    const scale = Math.min(scaleX, scaleY);

    canvas.style.transform = `scale(${scale})`;
    // 同步更新舞台高度，避免縮放後下方產生不自然的大片空白
    stage.style.height = `${targetH * scale}px`;

    if (indicator) {
      indicator.textContent = `🖥️ PPT 縮放: ${(scale * 100).toFixed(0)}%`;
    }
  }

  function togglePptScale() {
    isPptScaleActive = !isPptScaleActive;
    resizeCockpitCanvas();
  }

  // Main Section Exclusive Switcher (00, 01, 02, 03, 04)
  function switchMainSection(targetSectionId) {
    const sections = document.querySelectorAll('.main-section');
    sections.forEach(sec => sec.classList.remove('active'));

    const target = document.getElementById(targetSectionId);
    if (target) {
      target.classList.add('active');
    }

    const btns = document.querySelectorAll('.nav-tab-btn');
    btns.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.target === targetSectionId);
    });

    // 方案 A：僅在 00 總覽戰情大屏顯示縮放按鈕，切至 01~04 深入分析頁時自動隱藏
    const scaleBadge = document.getElementById('subnavScaleBadge');
    if (scaleBadge) {
      scaleBadge.style.display = (targetSectionId === 'section-cockpit') ? 'flex' : 'none';
    }

    if (targetSectionId === 'section-cockpit') {
      setTimeout(resizeCockpitCanvas, 40);
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // Peer comparison data
  const peerCategories = [
    {
      label: "消費經營",
      metrics: [
        {
          label: "簽帳金額",
          unit: "億元",
          positiveDirection: "up",
          marketValue: 30740,
          marketYoy: 14.3,
          peers: [
            { bank: "中國信託", value: 6457, yoy: 25.9 },
            { bank: "國泰世華", value: 5726, yoy: 17.1 },
            { bank: "玉山", value: 4705, yoy: 18.4 },
            { bank: "台北富邦", value: 3894, yoy: 6.4 },
            { bank: "台新銀行", value: 3480, yoy: 11.8 }
          ]
        }
      ]
    },
    {
      label: "卡量經營",
      metrics: [
        {
          label: "流通卡數",
          unit: "張",
          positiveDirection: "up",
          marketValue: 5440,
          marketYoy: 3.1,
          peers: [
            { bank: "中國信託", value: 912, yoy: 4.2 },
            { bank: "國泰世華", value: 858, yoy: 3.5 },
            { bank: "玉山", value: 726, yoy: 3.3 },
            { bank: "台北富邦", value: 685, yoy: 2.9 },
            { bank: "台新銀行", value: 654, yoy: 3.1 }
          ]
        },
        {
          label: "有效卡數",
          unit: "張",
          positiveDirection: "up",
          marketValue: 4528,
          marketYoy: 4.8,
          peers: [
            { bank: "中國信託", value: 786, yoy: 6.2 },
            { bank: "國泰世華", value: 741, yoy: 5.7 },
            { bank: "玉山", value: 612, yoy: 3.8 },
            { bank: "台北富邦", value: 548, yoy: 4.5 },
            { bank: "台新銀行", value: 468, yoy: 4.2 }
          ]
        },
        {
          label: "活卡率",
          unit: "%",
          decimals: 1,
          positiveDirection: "up",
          marketAverage: 82.3,
          summaryMode: "quality",
          peers: [
            { bank: "國泰世華", value: 86.4, yoy: 1.8 },
            { bank: "中國信託", value: 86.2, yoy: 1.6 },
            { bank: "玉山", value: 84.3, yoy: 0.4 },
            { bank: "台北富邦", value: 80.0, yoy: 1.2 },
            { bank: "台新銀行", value: 71.6, yoy: 0.8 }
          ]
        }
      ]
    },
    {
      label: "信用業務",
      metrics: [
        {
          label: "循環信用餘額",
          unit: "億元",
          positiveDirection: "up",
          marketValue: 1120,
          marketYoy: 5.4,
          peers: [
            { bank: "中國信託", value: 340.2, yoy: 7.8 },
            { bank: "國泰世華", value: 325.7, yoy: 6.7 },
            { bank: "台北富邦", value: 168.4, yoy: 4.2 },
            { bank: "玉山", value: 145.6, yoy: 3.8 },
            { bank: "台新銀行", value: 110.5, yoy: 2.9 }
          ]
        },
        {
          label: "未到期分期付款餘額",
          unit: "億元",
          positiveDirection: "up",
          marketValue: 1940,
          marketYoy: 8.3,
          peers: [
            { bank: "國泰世華", value: 462.0, yoy: 10.2 },
            { bank: "中國信託", value: 448.0, yoy: 9.1 },
            { bank: "玉山", value: 311.0, yoy: 7.5 },
            { bank: "台北富邦", value: 282.0, yoy: 5.9 },
            { bank: "台新銀行", value: 235.0, yoy: 6.8 }
          ]
        }
      ]
    }
  ];

  let currentCatIdx = 0;
  let currentMetricIdx = 0;

  function semanticClass(direction, change) {
    return (direction === "up" ? change >= 0 : change <= 0) ? "number-positive" : "number-negative";
  }

  function formatChange(value, suffix = "%") {
    return `${value > 0 ? "+" : ""}${Number(value).toFixed(1)}${suffix}`;
  }

  function renderYtd() {
    const catTabsContainer = document.getElementById("ytd-category-tabs");
    const metricContainer = document.getElementById("ytd-metric-selector");
    const peerRowsContainer = document.getElementById("peer-chart-rows");
    const insightsContainer = document.getElementById("peer-insights");
    const chartTitle = document.getElementById("peer-chart-title");
    const chartUnit = document.getElementById("peer-chart-unit");

    if (!catTabsContainer) return;

    // Render Category Tabs
    catTabsContainer.innerHTML = peerCategories.map((cat, idx) => `
      <button type="button" class="${idx === currentCatIdx ? 'active' : ''}" onclick="selectCategory(${idx})">
        ${cat.label}
      </button>
    `).join("");

    const category = peerCategories[currentCatIdx];
    const metrics = category.metrics;

    // Render Metric Selector if more than 1
    if (metrics.length > 1) {
      metricContainer.style.display = "flex";
      metricContainer.innerHTML = metrics.map((m, idx) => `
        <button type="button" class="${idx === currentMetricIdx ? 'active' : ''}" onclick="selectMetric(${idx})">
          ${m.label}
        </button>
      `).join("");
    } else {
      metricContainer.style.display = "none";
    }

    const metric = metrics[currentMetricIdx];
    chartTitle.textContent = `${metric.label}｜2026 年 1–8 月`;
    chartUnit.textContent = `單位：${metric.unit}`;

    const cathay = metric.peers.find(p => p.bank === "國泰世華") || metric.peers[0];
    const validPeers = metric.peers.filter(p => p.value !== null && p.value !== undefined && !isNaN(Number(p.value)));
    const maxVal = validPeers.length > 0 ? Math.max(...validPeers.map(p => Number(p.value))) : 1;
    const sortedPeers = [...metric.peers].sort((a, b) => {
      const aVal = (a.value !== null && a.value !== undefined && !isNaN(Number(a.value))) ? Number(a.value) : -999999;
      const bVal = (b.value !== null && b.value !== undefined && !isNaN(Number(b.value))) ? Number(b.value) : -999999;
      return bVal - aVal;
    });
    const isQuality = metric.summaryMode === "quality";

    // Render Peer Rows
    peerRowsContainer.innerHTML = sortedPeers.map(peer => {
      const isCathay = peer.bank === "國泰世華";
      const hasVal = peer.value !== null && peer.value !== undefined && !isNaN(Number(peer.value));
      const barWidth = hasVal && maxVal > 0 ? ((Number(peer.value) / maxVal) * 100).toFixed(1) : 0;
      const hasYoy = peer.yoy !== null && peer.yoy !== undefined && !isNaN(Number(peer.yoy));
      const semCls = hasYoy ? semanticClass(metric.positiveDirection, peer.yoy) : "number-neutral";
      const formattedYoy = hasYoy ? formatChange(peer.yoy, isQuality ? "pp" : "%") : "-";
      let displayVal = "-";
      if (hasVal) {
        displayVal = metric.unit === "%"
          ? (typeof metric.decimals === "number" ? Number(peer.value).toFixed(metric.decimals) : peer.value) + "%"
          : Number(peer.value).toLocaleString();
      }

      return `
        <div class="peer-row ${isCathay ? 'is-cathay' : ''}">
          <div class="peer-name">
            ${peer.bank}
            ${isCathay ? '<small>本行</small>' : ''}
          </div>
          <div class="peer-bar-track">
            <i style="width: ${barWidth}%;">
              <span>${displayVal}</span>
            </i>
          </div>
          <b class="${semCls}">${formattedYoy}</b>
        </div>
      `;
    }).join("");

    // Render Insights
    let insights = [];
    if (validPeers.length === 0 || !cathay || cathay.value === null || cathay.value === undefined) {
      insights = [
        { label: "本行值", value: "-" },
        { label: isQuality ? "五家平均" : "五家發卡行 YoY", value: "-" },
        { label: isQuality ? "與五家差距" : "Growth Gap", value: "-" },
        { label: isQuality ? "YoY 變化" : "在五大行中的佔比", value: "-" }
      ];
    } else if (isQuality) {
      const dec = typeof metric.decimals === "number" ? metric.decimals : 2;
      const cathayVal = Number(cathay.value).toFixed(dec);
      const fiveAvgVal = (validPeers.reduce((s, p) => s + Number(p.value), 0) / validPeers.length);
      const fiveAvg = fiveAvgVal.toFixed(dec);
      const diffNum = Number(cathay.value) - fiveAvgVal;
      const diffFormatted = (diffNum > 0 ? "+" : "") + diffNum.toFixed(dec);
      const diffUnit = metric.unit === "%" ? "pp" : metric.unit;
      insights = [
        { label: "本行值", value: `${cathayVal}${metric.unit}` },
        { label: "五家平均", value: `${fiveAvg}${metric.unit}` },
        { label: "與五家差距", value: `${diffFormatted}${diffUnit}` },
        { label: "YoY 變化", value: cathay.yoy !== null && cathay.yoy !== undefined ? formatChange(cathay.yoy, "pp") : "-" }
      ];
    } else {
      const fiveTotal = validPeers.reduce((s, p) => s + Number(p.value), 0);
      const peersWithYoy = validPeers.filter(p => p.yoy !== null && p.yoy !== undefined && !isNaN(Number(p.yoy)));
      let fiveBanksYoy = 0;
      let hasFiveYoy = false;
      if (peersWithYoy.length > 0) {
        const fivePrevTotal = peersWithYoy.reduce((s, p) => s + (Number(p.value) / (1 + Number(p.yoy) / 100)), 0);
        if (fivePrevTotal > 0) {
          const validSubTotal = peersWithYoy.reduce((s, p) => s + Number(p.value), 0);
          fiveBanksYoy = ((validSubTotal - fivePrevTotal) / fivePrevTotal) * 100;
          hasFiveYoy = true;
        }
      }
      const gap = hasFiveYoy && cathay.yoy !== null && cathay.yoy !== undefined ? (Number(cathay.yoy) - fiveBanksYoy).toFixed(1) : "-";
      const fiveShare = fiveTotal > 0 ? ((Number(cathay.value) / fiveTotal) * 100).toFixed(1) : "-";
      insights = [
        { label: "本行 YoY", value: cathay.yoy !== null && cathay.yoy !== undefined ? formatChange(cathay.yoy) : "-" },
        { label: "五家發卡行 YoY", value: hasFiveYoy ? formatChange(fiveBanksYoy) : "-" },
        { label: "Growth Gap", value: gap !== "-" ? formatChange(gap, "pp") : "-" },
        { label: "在五大行中的佔比", value: fiveShare !== "-" ? `${fiveShare}%` : "-" }
      ];
    }

    insightsContainer.innerHTML = insights.map(item => `
      <div>
        <span>${item.label}</span>
        <strong>${item.value}</strong>
      </div>
    `).join("");
  }

  function selectCategory(idx) {
    currentCatIdx = idx;
    currentMetricIdx = 0;
    renderYtd();
  }

  function selectMetric(idx) {
    currentMetricIdx = idx;
    renderYtd();
  }

  // Tab switching for Acquiring (2B)
  function switchAcqTab(tabIdx) {
    const btns = document.querySelectorAll("#acq-diag-tabs button");
    btns.forEach((btn, i) => {
      btn.classList.toggle("active", i === tabIdx);
    });
    for (let i = 0; i < 3; i++) {
      const content = document.getElementById(`acq-tab-${i}`);
      if (content) content.classList.toggle("active", i === tabIdx);
    }
  }

  // Tab switching for Issuing (3B: 5 Tabs)
  function switchIssTab(tabIdx) {
    const btns = document.querySelectorAll("#iss-diag-tabs button");
    btns.forEach((btn, i) => {
      btn.classList.toggle("active", i === tabIdx);
    });
    for (let i = 0; i < 5; i++) {
      const content = document.getElementById(`iss-tab-${i}`);
      if (content) content.classList.toggle("active", i === tabIdx);
    }
  }

  // Tab switching for System Resilience (4B)
  function switchSysTab(tabIdx) {
    const btns = document.querySelectorAll("#sys-diag-tabs button");
    btns.forEach((btn, i) => {
      btn.classList.toggle("active", i === tabIdx);
    });
    for (let i = 0; i < 2; i++) {
      const content = document.getElementById(`sys-tab-${i}`);
      if (content) content.classList.toggle("active", i === tabIdx);
    }
  }

  // Universal drilldown function from 00 Cockpit to 01~04 sections
  function drillToSection(sectionId, targetElemId, callback) {
    switchMainSection(sectionId);
    if (typeof callback === 'function') {
      callback();
    }
    setTimeout(() => {
      if (targetElemId) {
        const targetElem = document.getElementById(targetElemId);
        if (targetElem) {
          targetElem.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }, 60);
  }

  // Drilldown functions: Column 1 (01 全行概況)
  function drillToOverviewKpi() {
    drillToSection('section-overview', 'overview-kpis');
  }
  function drillToPeerBenchmark() {
    drillToSection('section-overview', 'overview-peer-benchmark');
  }

  // Drilldown functions: Column 2 (02 收單業務)
  function drillToAcqKpi() {
    drillToSection('section-acquiring', 'acq-kpis');
  }
  function drillToAcqTwqr() {
    drillToSection('section-acquiring', 'acq-twqr-panel');
  }

  // Drilldown functions: Column 3 (03 發卡業務)
  function drillToIssuingKpi() {
    drillToSection('section-issuing', 'iss-kpis');
  }
  function drillToIssuingApp() {
    drillToSection('section-issuing', 'iss-diag-tabs', () => switchIssTab(0));
  }
  function drillToIssuingAuth() {
    drillToSection('section-issuing', 'iss-kpis');
  }
  function drillToIssuingBilling() {
    drillToSection('section-issuing', 'iss-diag-tabs', () => switchIssTab(1));
  }
  function drillToIssuingBonus() {
    drillToSection('section-issuing', 'iss-diag-tabs', () => switchIssTab(2));
  }

  // Drilldown functions: Column 4 (04 系統韌性)
  function drillToResilienceCardpool() {
    drillToSection('section-resilience', 'sys-cardpool-kpi');
  }
  function drillToResilienceCardlink() {
    drillToSection('section-resilience', 'sys-cardlink-kpi');
  }
  function drillToResilienceFraud() {
    drillToSection('section-issuing', 'iss-diag-tabs', () => switchIssTab(3));
  }
  function drillToResilienceBonusMs() {
    drillToSection('section-resilience', 'sys-diag-tabs', () => switchSysTab(1));
  }

  // Initialize on load
  
  // ========================================================
  // 動態數據渲染引擎：Block 01 全維度數據綁定 (Single Source of Truth)
  // 自動具備：基礎數值自動推導計算、份額百分比推導、動態字串組裝
  // ========================================================
  function renderBlock01FromData(data) {
    if (!data || !data.block01) return;
    const b1 = data.block01;
    const kpi = b1.monthly_kpis || {};

    const isValidNum = (v) => v !== null && v !== undefined && v !== '' && v !== '-' && !isNaN(Number(v));
    const fmtNum = (v, maxDigits = 2) => {
      if (!isValidNum(v)) return '-';
      return Number(v).toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: maxDigits
      });
    };
    const fmtSign = (v, sfx="%") => {
      if (!isValidNum(v)) return '-';
      const n = Number(v);
      const formatted = n.toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
      });
      return `${n > 0 ? "+" : ""}${formatted}${sfx}`;
    };
    const semCls = (v) => {
      if (!isValidNum(v)) return "number-neutral";
      return Number(v) >= 0 ? "number-positive" : "number-negative";
    };

    // 1. 總交易金額
    const amt = kpi.total_amount || {};
    const amtValHtml = isValidNum(amt.value)
      ? `${fmtNum(amt.value)} <em>${amt.unit || '億元'}</em>`
      : `-`;
    const amtGrowthHtml = `
      <span class="${semCls(amt.yoy)}"><b>YoY</b>${fmtSign(amt.yoy)}</span>
      <span class="${semCls(amt.mom)}"><b>MoM</b>${fmtSign(amt.mom)}</span>
    `;
    
    // c00 Card 1 (00 戰情室)
    const c00AmtVal = document.getElementById("c00-amt-val");
    if (c00AmtVal) {
      c00AmtVal.innerHTML = amtValHtml;
      const dVal = c00AmtVal.parentElement?.querySelector(".c-daily-stat .d-val");
      if (dVal && isValidNum(amt.value)) {
        dVal.textContent = `${(Number(amt.value) / 31).toFixed(1)} ${amt.unit || '億元'}`;
      }
    }
    const c00AmtGrowth = document.getElementById("c00-amt-growth");
    if (c00AmtGrowth) {
      c00AmtGrowth.innerHTML = `<span class="${semCls(amt.yoy)}">YoY ${fmtSign(amt.yoy)}</span> <span class="${semCls(amt.mom)}">MoM ${fmtSign(amt.mom)}</span>`;
    }
    const c00AmtSegGen = document.getElementById("c00-amt-seg-gen");
    if (c00AmtSegGen) {
      if (isValidNum(amt.general?.share)) {
        c00AmtSegGen.style.width = `${amt.general.share}%`;
        c00AmtSegGen.title = `一般交易: ${fmtNum(amt.general.share)}% (${fmtNum(amt.general.amount)} 億)`;
      } else {
        c00AmtSegGen.style.width = `0%`;
        c00AmtSegGen.title = `一般交易: -`;
      }
    }
    const c00AmtSegInst = document.getElementById("c00-amt-seg-inst");
    if (c00AmtSegInst) {
      if (isValidNum(amt.installment?.share)) {
        c00AmtSegInst.style.width = `${amt.installment.share}%`;
        c00AmtSegInst.title = `分期交易: ${fmtNum(amt.installment.share)}% (${fmtNum(amt.installment.amount)} 億)`;
      } else {
        c00AmtSegInst.style.width = `0%`;
        c00AmtSegInst.title = `分期交易: -`;
      }
    }
    const c00AmtGenPct = document.getElementById("c00-amt-gen-pct");
    if (c00AmtGenPct) c00AmtGenPct.textContent = isValidNum(amt.general?.share) ? `(${fmtNum(amt.general.share)}%)` : `(-%)`;
    const c00AmtGenVal = document.getElementById("c00-amt-gen-val");
    if (c00AmtGenVal) c00AmtGenVal.innerHTML = isValidNum(amt.general?.amount) ? `${fmtNum(amt.general.amount)}<em>${amt.general.unit || '億'}</em>` : `-`;
    const c00AmtInstPct = document.getElementById("c00-amt-inst-pct");
    if (c00AmtInstPct) c00AmtInstPct.textContent = isValidNum(amt.installment?.share) ? `(${fmtNum(amt.installment.share)}%)` : `(-%)`;
    const c00AmtInstVal = document.getElementById("c00-amt-inst-val");
    if (c00AmtInstVal) c00AmtInstVal.innerHTML = isValidNum(amt.installment?.amount) ? `${fmtNum(amt.installment.amount)}<em>${amt.installment.unit || '億'}</em>` : `-`;

    // b01 Card 1 (01 全行概況)
    const b01AmtVal = document.getElementById("b01-amt-val");
    if (b01AmtVal) b01AmtVal.innerHTML = amtValHtml;
    const b01AmtGrowth = document.getElementById("b01-amt-growth");
    if (b01AmtGrowth) b01AmtGrowth.innerHTML = amtGrowthHtml;
    const b01AmtSegGen = document.getElementById("b01-amt-seg-gen");
    if (b01AmtSegGen) {
      if (isValidNum(amt.general?.share)) {
        b01AmtSegGen.style.width = `${amt.general.share}%`;
        b01AmtSegGen.title = `一般交易: ${fmtNum(amt.general.share)}% (${fmtNum(amt.general.amount)} 億)`;
      } else {
        b01AmtSegGen.style.width = `0%`;
        b01AmtSegGen.title = `一般交易: -`;
      }
    }
    const b01AmtSegInst = document.getElementById("b01-amt-seg-inst");
    if (b01AmtSegInst) {
      if (isValidNum(amt.installment?.share)) {
        b01AmtSegInst.style.width = `${amt.installment.share}%`;
        b01AmtSegInst.title = `分期交易: ${fmtNum(amt.installment.share)}% (${fmtNum(amt.installment.amount)} 億)`;
      } else {
        b01AmtSegInst.style.width = `0%`;
        b01AmtSegInst.title = `分期交易: -`;
      }
    }
    const b01AmtGenPct = document.getElementById("b01-amt-gen-pct");
    if (b01AmtGenPct) b01AmtGenPct.textContent = isValidNum(amt.general?.share) ? `(${fmtNum(amt.general.share)}%)` : `(-%)`;
    const b01AmtGenVal = document.getElementById("b01-amt-gen-val");
    if (b01AmtGenVal) b01AmtGenVal.innerHTML = isValidNum(amt.general?.amount) ? `${fmtNum(amt.general.amount)}<em>${amt.general.unit || '億'}</em>` : `-`;
    const b01AmtInstPct = document.getElementById("b01-amt-inst-pct");
    if (b01AmtInstPct) b01AmtInstPct.textContent = isValidNum(amt.installment?.share) ? `(${fmtNum(amt.installment.share)}%)` : `(-%)`;
    const b01AmtInstVal = document.getElementById("b01-amt-inst-val");
    if (b01AmtInstVal) b01AmtInstVal.innerHTML = isValidNum(amt.installment?.amount) ? `${fmtNum(amt.installment.amount)}<em>${amt.installment.unit || '億'}</em>` : `-`;

    // 2. 總交易筆數
    const cnt = kpi.total_count || {};
    const cntValHtml = isValidNum(cnt.value)
      ? `${fmtNum(cnt.value)} <em>${cnt.unit || '萬筆'}</em>`
      : `-`;
    const cntGrowthHtml = `
      <span class="${semCls(cnt.yoy)}"><b>YoY</b>${fmtSign(cnt.yoy)}</span>
      <span class="${semCls(cnt.mom)}"><b>MoM</b>${fmtSign(cnt.mom)}</span>
    `;
    
    // c00 Card 2
    const c00CntVal = document.getElementById("c00-cnt-val");
    if (c00CntVal) {
      c00CntVal.innerHTML = cntValHtml;
      const dVal = c00CntVal.parentElement?.querySelector(".c-daily-stat .d-val");
      if (dVal && isValidNum(cnt.value)) {
        dVal.textContent = `${(Number(cnt.value) / 31).toFixed(1)} ${cnt.unit || '萬筆'}`;
      }
    }
    const c00CntGrowth = document.getElementById("c00-cnt-growth");
    if (c00CntGrowth) {
      c00CntGrowth.innerHTML = `<span class="${semCls(cnt.yoy)}">YoY ${fmtSign(cnt.yoy)}</span> <span class="${semCls(cnt.mom)}">MoM ${fmtSign(cnt.mom)}</span>`;
    }
    const c00CntSegGen = document.getElementById("c00-cnt-seg-gen");
    if (c00CntSegGen) {
      if (isValidNum(cnt.general?.share)) {
        c00CntSegGen.style.width = `${cnt.general.share}%`;
        c00CntSegGen.title = `一般交易: ${fmtNum(cnt.general.share)}% (${fmtNum(cnt.general.count)} 萬筆)`;
      } else {
        c00CntSegGen.style.width = `0%`;
        c00CntSegGen.title = `一般交易: -`;
      }
    }
    const c00CntSegInst = document.getElementById("c00-cnt-seg-inst");
    if (c00CntSegInst) {
      if (isValidNum(cnt.installment?.share)) {
        c00CntSegInst.style.width = `${cnt.installment.share}%`;
        c00CntSegInst.title = `分期交易: ${fmtNum(cnt.installment.share)}% (${fmtNum(cnt.installment.count)} 萬筆)`;
      } else {
        c00CntSegInst.style.width = `0%`;
        c00CntSegInst.title = `分期交易: -`;
      }
    }
    const c00CntGenPct = document.getElementById("c00-cnt-gen-pct");
    if (c00CntGenPct) c00CntGenPct.textContent = isValidNum(cnt.general?.share) ? `(${fmtNum(cnt.general.share)}%)` : `(-%)`;
    const c00CntGenVal = document.getElementById("c00-cnt-gen-val");
    if (c00CntGenVal) c00CntGenVal.innerHTML = isValidNum(cnt.general?.count) ? `${fmtNum(cnt.general.count)}<em>${cnt.general.unit || '萬筆'}</em>` : `-`;
    const c00CntInstPct = document.getElementById("c00-cnt-inst-pct");
    if (c00CntInstPct) c00CntInstPct.textContent = isValidNum(cnt.installment?.share) ? `(${fmtNum(cnt.installment.share)}%)` : `(-%)`;
    const c00CntInstVal = document.getElementById("c00-cnt-inst-val");
    if (c00CntInstVal) c00CntInstVal.innerHTML = isValidNum(cnt.installment?.count) ? `${fmtNum(cnt.installment.count)}<em>${cnt.installment.unit || '萬筆'}</em>` : `-`;

    // b01 Card 2
    const b01CntVal = document.getElementById("b01-cnt-val");
    if (b01CntVal) b01CntVal.innerHTML = cntValHtml;
    const b01CntGrowth = document.getElementById("b01-cnt-growth");
    if (b01CntGrowth) b01CntGrowth.innerHTML = cntGrowthHtml;
    const b01CntSegGen = document.getElementById("b01-cnt-seg-gen");
    if (b01CntSegGen) {
      if (isValidNum(cnt.general?.share)) {
        b01CntSegGen.style.width = `${cnt.general.share}%`;
        b01CntSegGen.title = `一般交易: ${fmtNum(cnt.general.share)}% (${fmtNum(cnt.general.count)} 萬筆)`;
      } else {
        b01CntSegGen.style.width = `0%`;
        b01CntSegGen.title = `一般交易: -`;
      }
    }
    const b01CntSegInst = document.getElementById("b01-cnt-seg-inst");
    if (b01CntSegInst) {
      if (isValidNum(cnt.installment?.share)) {
        b01CntSegInst.style.width = `${cnt.installment.share}%`;
        b01CntSegInst.title = `分期交易: ${fmtNum(cnt.installment.share)}% (${fmtNum(cnt.installment.count)} 萬筆)`;
      } else {
        b01CntSegInst.style.width = `0%`;
        b01CntSegInst.title = `分期交易: -`;
      }
    }
    const b01CntGenPct = document.getElementById("b01-cnt-gen-pct");
    if (b01CntGenPct) b01CntGenPct.textContent = isValidNum(cnt.general?.share) ? `(${fmtNum(cnt.general.share)}%)` : `(-%)`;
    const b01CntGenVal = document.getElementById("b01-cnt-gen-val");
    if (b01CntGenVal) b01CntGenVal.innerHTML = isValidNum(cnt.general?.count) ? `${fmtNum(cnt.general.count)}<em>${cnt.general.unit || '萬筆'}</em>` : `-`;
    const b01CntInstPct = document.getElementById("b01-cnt-inst-pct");
    if (b01CntInstPct) b01CntInstPct.textContent = isValidNum(cnt.installment?.share) ? `(${fmtNum(cnt.installment.share)}%)` : `(-%)`;
    const b01CntInstVal = document.getElementById("b01-cnt-inst-val");
    if (b01CntInstVal) b01CntInstVal.innerHTML = isValidNum(cnt.installment?.count) ? `${fmtNum(cnt.installment.count)}<em>${cnt.installment.unit || '萬筆'}</em>` : `-`;

    // 3. 活卡率
    const act = kpi.active_card || {};
    const b01ActVal = document.getElementById("b01-active-val");
    if (b01ActVal) b01ActVal.innerHTML = isValidNum(act.rate) ? `${fmtNum(act.rate)}<em>${act.unit || '%'}</em>` : `-`;
    const b01ActGrowth = document.getElementById("b01-active-growth");
    if (b01ActGrowth) {
      b01ActGrowth.innerHTML = `
        <span class="${semCls(act.yoy_pp)}"><b>YoY</b>${fmtSign(act.yoy_pp, "pp")}</span>
        <span class="${semCls(act.mom_pp)}"><b>MoM</b>${fmtSign(act.mom_pp, "pp")}</span>
      `;
    }
    const b01ActSegGen = document.getElementById("b01-active-seg-gen");
    if (b01ActSegGen) {
      if (isValidNum(act.active_share)) {
        b01ActSegGen.style.width = `${act.active_share}%`;
        b01ActSegGen.title = `有效卡數: ${fmtNum(act.active_share)}% (${fmtNum(act.active_cards)} ${act.active_cards_unit || '張'})`;
      } else {
        b01ActSegGen.style.width = `0%`;
        b01ActSegGen.title = `有效卡數: -`;
      }
    }
    const b01ActSegInact = document.getElementById("b01-active-seg-inact");
    if (b01ActSegInact) {
      if (isValidNum(act.inactive_share)) {
        b01ActSegInact.style.width = `${act.inactive_share}%`;
        b01ActSegInact.title = `未動用卡: ${fmtNum(act.inactive_share)}% (${fmtNum(act.inactive_cards)} ${act.inactive_cards_unit || '張'})`;
      } else {
        b01ActSegInact.style.width = `0%`;
        b01ActSegInact.title = `未動用卡: -`;
      }
    }
    const b01ActGenPct = document.getElementById("b01-active-gen-pct");
    if (b01ActGenPct) b01ActGenPct.textContent = isValidNum(act.active_share) ? `(${fmtNum(act.active_share)}%)` : `(-%)`;
    const b01ActActVal = document.getElementById("b01-active-act-val");
    if (b01ActActVal) b01ActActVal.innerHTML = isValidNum(act.active_cards) ? `${fmtNum(act.active_cards)}<em>${act.active_cards_unit || '張'}</em>` : `-`;
    const b01ActIssVal = document.getElementById("b01-active-iss-val");
    if (b01ActIssVal) b01ActIssVal.innerHTML = isValidNum(act.issued_cards) ? `${fmtNum(act.issued_cards)}<em>${act.issued_cards_unit || '張'}</em>` : `-`;

    // 4. 信用業務 (00 迷你卡 & 01 Card 4)
    const cred = kpi.credit_business || {};
    const rev = cred.revolving || {};
    const cash = cred.cash_advance || {};

    const revValHtml = isValidNum(rev.balance) ? `${fmtNum(rev.balance)} <em>${rev.unit || '億元'}</em>` : `-`;
    const revGrowthHtml = `
      <span class="${semCls(rev.yoy)}"><b>YoY</b>${fmtSign(rev.yoy)}</span>
      <span class="${semCls(rev.mom)}"><b>MoM</b>${fmtSign(rev.mom)}</span>
    `;
    const c00RevVal = document.getElementById("c00-revolving-val");
    if (c00RevVal) c00RevVal.innerHTML = revValHtml;
    const c00RevGrowth = document.getElementById("c00-revolving-growth");
    if (c00RevGrowth) {
      c00RevGrowth.innerHTML = `<span class="${semCls(rev.yoy)}">YoY ${fmtSign(rev.yoy)}</span>`;
    }
    const b01RevVal = document.getElementById("b01-revolving-val");
    if (b01RevVal) b01RevVal.innerHTML = revValHtml;
    const b01RevGrowth = document.getElementById("b01-revolving-growth");
    if (b01RevGrowth) b01RevGrowth.innerHTML = revGrowthHtml;

    const cashValHtml = isValidNum(cash.amount) ? `${fmtNum(cash.amount)} <em>${cash.unit || '億元'}</em>` : `-`;
    const cashGrowthHtml = `
      <span class="${semCls(cash.yoy)}"><b>YoY</b>${fmtSign(cash.yoy)}</span>
      <span class="${semCls(cash.mom)}"><b>MoM</b>${fmtSign(cash.mom)}</span>
    `;
    const cashCountHint = isValidNum(cash.count_wan) ? `(${fmtNum(cash.count_wan)}萬筆)` : (cash.count_hint || "");
    const c00CashVal = document.getElementById("c00-cashadv-val");
    if (c00CashVal) c00CashVal.innerHTML = cashValHtml;
    const c00CashGrowth = document.getElementById("c00-cashadv-growth");
    if (c00CashGrowth) {
      c00CashGrowth.innerHTML = `<span class="${semCls(cash.yoy)}">YoY ${fmtSign(cash.yoy)}</span> ${cashCountHint ? `<span class="c-hint">${cashCountHint}</span>` : ''}`;
    }
    const b01CashVal = document.getElementById("b01-cashadv-val");
    if (b01CashVal) b01CashVal.innerHTML = cashValHtml;
    const b01CashGrowth = document.getElementById("b01-cashadv-growth");
    if (b01CashGrowth) b01CashGrowth.innerHTML = cashGrowthHtml;

    // 5. 戰情室同業圓餅圖 (00 戰情室)
    const donut = b1.cockpit_peer_donut || {};
    const c00BoxTitle = document.getElementById("c00-peer-box-title");
    if (c00BoxTitle && donut.title) c00BoxTitle.textContent = donut.title;
    const c00MktLabel = document.getElementById("c00-market-label");
    if (c00MktLabel && donut.market_label) c00MktLabel.textContent = donut.market_label;
    const c00MktVal = document.getElementById("c00-market-val");
    if (c00MktVal) c00MktVal.innerHTML = isValidNum(donut.market_total) ? `${fmtNum(donut.market_total)} <em>${donut.unit || '億元'}</em>` : `-`;
    const c00MktYoy = document.getElementById("c00-market-yoy");
    if (c00MktYoy) c00MktYoy.textContent = isValidNum(donut.market_yoy) ? `YoY ${fmtSign(donut.market_yoy)}` : `YoY -`;
    const c00Top4Hint = document.getElementById("c00-top4-hint");
    if (c00Top4Hint) c00Top4Hint.textContent = donut.hint ? donut.hint : (isValidNum(donut.top4_share) ? `四大行佔 ${fmtNum(donut.top4_share)}%` : `五大行合計`);

    // 渲染五大發卡行水平長條競爭排名列表 (00 戰情室)
    const c00PeerList = document.getElementById("c00-peer-list");
    if (c00PeerList && donut.peers) {
      const validPeers = donut.peers.filter(p => isValidNum(p.share) && p.share > 0);
      const maxShare = validPeers.length > 0 ? Math.max(...validPeers.map(p => Number(p.share))) : 26.3;

      c00PeerList.innerHTML = donut.peers.map((p, idx) => {
        const rank = idx + 1;
        const rankClass = rank === 1 ? 'rank-1' : (rank === 2 ? 'rank-2' : (rank === 3 ? 'rank-3' : ''));
        const barWidth = isValidNum(p.share) && maxShare > 0 ? Math.min(100, (Number(p.share) / maxShare) * 100).toFixed(1) : 0;
        const isCathay = p.is_cathay;
        const valText = isValidNum(p.amount) ? `${fmtNum(p.amount, 1)} ${p.unit || '億元'}` : '-';
        const shareText = isValidNum(p.share) ? `${fmtNum(p.share, 1)}%` : '-';
        const yoyText = isValidNum(p.yoy) ? fmtSign(p.yoy) : '-';

        return `
          <div class="bar-row-item ${isCathay ? 'highlight' : ''}">
            <div class="b-rank-badge ${rankClass}">${rank}</div>
            <div class="b-bank-name ${isCathay ? 'cathay' : ''}">
              <span class="peer-color-dot" style="background:${p.color || '#64748b'};"></span>${p.name}
            </div>
            <div class="b-track-container">
              <div class="b-track-bar-bg">
                <div class="b-track-bar-fill" style="width: ${barWidth}%; background: ${p.color || '#009e73'};"></div>
              </div>
              <div class="b-track-meta">
                <span class="b-track-val" ${isCathay ? 'style="color:#009e73; font-weight:900;"' : ''}>${valText}</span>
                <span class="b-track-share" ${isCathay ? 'style="color:#009e73; font-weight:900;"' : ''}>${shareText}</span>
              </div>
            </div>
            <div class="b-yoy-val ${semCls(p.yoy)}">${yoyText}</div>
          </div>
        `;
      }).join("");
    }

    // 渲染動態 SVG Donut 切片
    const donutWrap = document.getElementById("c00-donut-wrap");
    if (donutWrap && donut.peers && donut.peers.some(p => isValidNum(p.share) && p.share > 0)) {
      let cumulativeAngle = 0;
      const radiusOuter = 52;
      const radiusInner = 32;
      const cx = 60, cy = 60;
      
      const paths = donut.peers.filter(p => isValidNum(p.share) && p.share > 0).map(p => {
        const sliceAngle = (p.share / 100) * 360;
        const startAngle = cumulativeAngle;
        const endAngle = cumulativeAngle + sliceAngle;
        cumulativeAngle = endAngle;

        const startRad = (startAngle - 90) * Math.PI / 180;
        const endRad = (endAngle - 90) * Math.PI / 180;

        const x1 = (cx + radiusOuter * Math.cos(startRad)).toFixed(2);
        const y1 = (cy + radiusOuter * Math.sin(startRad)).toFixed(2);
        const x2 = (cx + radiusOuter * Math.cos(endRad)).toFixed(2);
        const y2 = (cy + radiusOuter * Math.sin(endRad)).toFixed(2);

        const x3 = (cx + radiusInner * Math.cos(endRad)).toFixed(2);
        const y3 = (cy + radiusInner * Math.sin(endRad)).toFixed(2);
        const x4 = (cx + radiusInner * Math.cos(startRad)).toFixed(2);
        const y4 = (cy + radiusInner * Math.sin(startRad)).toFixed(2);

        const largeArc = sliceAngle > 180 ? 1 : 0;
        const pathData = `M ${x1} ${y1} A ${radiusOuter} ${radiusOuter} 0 ${largeArc} 1 ${x2} ${y2} L ${x3} ${y3} A ${radiusInner} ${radiusInner} 0 ${largeArc} 0 ${x4} ${y4} Z`;

        return `<path class="cockpit-donut-slice" d="${pathData}" fill="${p.color}" stroke="#ffffff" stroke-width="1.5"><title>${p.name}: ${fmtNum(p.share)}% (${fmtNum(p.amount)} ${p.unit || '億元'})</title></path>`;
      }).join("\n");

      donutWrap.innerHTML = `
        <svg viewBox="0 0 120 120" width="88" height="88" style="display:block;">
          ${paths}
          <circle cx="60" cy="60" r="32" fill="#ffffff" />
        </svg>
      `;
    } else if (donutWrap) {
      donutWrap.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;width:88px;height:88px;color:#94a3b8;font-size:12px;">無數據</div>`;
    }

    // 6. 同步 1B 同業對標資料
    if (b1.peer_benchmark) {
      peerCategories.splice(0, peerCategories.length, ...b1.peer_benchmark);
      const cardMgmt = peerCategories.find(c => c.label === "卡量經營");
      if (cardMgmt && Array.isArray(cardMgmt.metrics)) {
        const desiredOrder = ["流通卡數", "有效卡數", "活卡率"];
        cardMgmt.metrics.sort((a, b) => {
          const ai = desiredOrder.indexOf(a.label);
          const bi = desiredOrder.indexOf(b.label);
          return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
        });
      }
      if (typeof renderYtd === 'function') {
        renderYtd();
      }
    }
  }

  
  // ============================================================================
  // 動態渲染 02 收單業務 (Block 02) 數據引擎
  // ============================================================================
  function renderBlock02FromData(data) {
    if (!data || !data.block02) return;
    const b2 = data.block02;
    const kpi = b2.monthly_kpis || {};
    const twqr = b2.twqr || {};

    const isValidNum = (v) => v !== null && v !== undefined && v !== '' && v !== '-' && !isNaN(Number(v));
    const fmtNum = (v, maxDigits = 2) => {
      if (!isValidNum(v)) return '-';
      return Number(v).toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: maxDigits
      });
    };
    const fmtSign = (v, sfx="%") => {
      if (!isValidNum(v)) return '-';
      const n = Number(v);
      const formatted = n.toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
      });
      return `${n > 0 ? "+" : ""}${formatted}${sfx}`;
    };
    const semCls = (v) => {
      if (!isValidNum(v)) return "number-neutral";
      return Number(v) >= 0 ? "number-positive" : "number-negative";
    };

    const channels = b2.online_channels || [];

    let eposAmt = 0, phAmt = 0, eposCnt = 0, phCnt = 0;
    channels.forEach(c => {
      const name = c.name || "";
      if (name.includes("EPOS")) {
        eposAmt += (Number(c.amount) || 0);
        eposCnt += (Number(c.count) || 0);
      } else if (name.includes("Payment Hub") || name.includes("PH") || name.includes("掃碼")) {
        phAmt += (Number(c.amount) || 0);
        phCnt += (Number(c.count) || 0);
      }
    });

    // 1. 收單交易金額
    const amt = kpi.acq_amt || {};
    const amtPhys = amt.physical || {};
    const amtOnl = amt.online || {};

    const amtValHtml = isValidNum(amt.total) ? `${fmtNum(amt.total)}<em>${amt.unit || '億元'}</em>` : `-`;
    const amtGrowthHtml = `
      <span class="${semCls(amt.yoy)}"><b>YoY</b>${fmtSign(amt.yoy)}</span>
      <span class="${semCls(amt.mom)}"><b>MoM</b>${fmtSign(amt.mom)}</span>
    `;

    if (eposAmt === 0 && phAmt === 0 && isValidNum(amtOnl.amount)) {
      eposAmt = Number(amtOnl.amount) || 0;
    }
    const amtTotalNum = Number(amt.total) || 0;
    const cpsAmt = (isValidNum(amt.total) && amtTotalNum > 0) ? Math.max(0, amtTotalNum - eposAmt - phAmt) : (Number(amtPhys.amount) || null);
    const cpsAmtShare = (isValidNum(amt.total) && amtTotalNum > 0) ? (cpsAmt / amtTotalNum) * 100 : (amtPhys.share ?? null);
    const eposAmtShare = (isValidNum(amt.total) && amtTotalNum > 0) ? (eposAmt / amtTotalNum) * 100 : null;
    const phAmtShare = (isValidNum(amt.total) && amtTotalNum > 0) ? (phAmt / amtTotalNum) * 100 : null;

    // Cockpit Col 2: Card 1 (收單交易金額)
    const c00AmtVal = document.getElementById("c00-acq-amt-val");
    if (c00AmtVal) {
      c00AmtVal.innerHTML = isValidNum(amt.total) ? `${fmtNum(amt.total)} <em>${amt.unit || '億元'}</em>` : `-`;
      const dVal = c00AmtVal.parentElement?.querySelector(".c-daily-stat .d-val");
      if (dVal && isValidNum(amt.total)) {
        dVal.textContent = `${(Number(amt.total) / 31).toFixed(2)} ${amt.unit || '億元'}`;
      }
    }
    const c00AmtGrowth = document.getElementById("c00-acq-amt-growth");
    if (c00AmtGrowth) {
      c00AmtGrowth.innerHTML = `
        <span class="${semCls(amt.yoy)}">YoY ${fmtSign(amt.yoy)}</span>
        <span class="${semCls(amt.mom)}">MoM ${fmtSign(amt.mom)}</span>
      `;
    }
    const c00AmtSegCps = document.getElementById("c00-acq-amt-seg-cps");
    if (c00AmtSegCps) {
      c00AmtSegCps.style.width = isValidNum(cpsAmtShare) ? `${cpsAmtShare}%` : `0%`;
      c00AmtSegCps.title = isValidNum(cpsAmtShare) ? `CPS其他通路: ${fmtNum(cpsAmtShare, 1)}% (${fmtNum(cpsAmt)} 億)` : `CPS其他通路: -`;
    }
    const c00AmtSegEpos = document.getElementById("c00-acq-amt-seg-epos");
    if (c00AmtSegEpos) {
      c00AmtSegEpos.style.width = isValidNum(eposAmtShare) ? `${eposAmtShare}%` : `0%`;
      c00AmtSegEpos.title = isValidNum(eposAmtShare) ? `EPOS: ${fmtNum(eposAmtShare, 1)}% (${fmtNum(eposAmt)} 億)` : `EPOS: -`;
    }
    const c00AmtSegPh = document.getElementById("c00-acq-amt-seg-ph");
    if (c00AmtSegPh) {
      c00AmtSegPh.style.width = isValidNum(phAmtShare) ? `${phAmtShare}%` : `0%`;
      c00AmtSegPh.title = isValidNum(phAmtShare) ? `PH: ${fmtNum(phAmtShare, 1)}% (${fmtNum(phAmt)} 億)` : `PH: -`;
    }
    const c00AmtCpsPct = document.getElementById("c00-acq-amt-cps-pct");
    if (c00AmtCpsPct) c00AmtCpsPct.textContent = isValidNum(cpsAmtShare) ? `(${fmtNum(cpsAmtShare, 1)}%)` : `(-%)`;
    const c00AmtCpsVal = document.getElementById("c00-acq-amt-cps-val");
    if (c00AmtCpsVal) c00AmtCpsVal.innerHTML = isValidNum(cpsAmt) ? `${fmtNum(cpsAmt)}<em>億</em>` : `-`;

    const c00AmtEposPct = document.getElementById("c00-acq-amt-epos-pct");
    if (c00AmtEposPct) c00AmtEposPct.textContent = isValidNum(eposAmtShare) ? `(${fmtNum(eposAmtShare, 1)}%)` : `(-%)`;
    const c00AmtEposVal = document.getElementById("c00-acq-amt-epos-val");
    if (c00AmtEposVal) c00AmtEposVal.innerHTML = isValidNum(eposAmt) ? `${fmtNum(eposAmt)}<em>億</em>` : `-`;

    const c00AmtPhPct = document.getElementById("c00-acq-amt-ph-pct");
    if (c00AmtPhPct) c00AmtPhPct.textContent = isValidNum(phAmtShare) ? `(${fmtNum(phAmtShare, 1)}%)` : `(-%)`;
    const c00AmtPhVal = document.getElementById("c00-acq-amt-ph-val");
    if (c00AmtPhVal) c00AmtPhVal.innerHTML = isValidNum(phAmt) ? `${fmtNum(phAmt)}<em>億</em>` : `-`;

    // 02 Section: Primary Card 1 (CPS其他通路, EPOS, PH)
    const b02AmtVal = document.getElementById("b02-amt-val");
    if (b02AmtVal) b02AmtVal.innerHTML = amtValHtml;
    const b02AmtGrowth = document.getElementById("b02-amt-growth");
    if (b02AmtGrowth) b02AmtGrowth.innerHTML = amtGrowthHtml;

    const b02AmtSegCps = document.getElementById("b02-amt-seg-cps");
    if (b02AmtSegCps) {
      b02AmtSegCps.style.width = isValidNum(cpsAmtShare) ? `${cpsAmtShare}%` : `0%`;
      b02AmtSegCps.title = isValidNum(cpsAmtShare) ? `CPS其他通路: ${fmtNum(cpsAmtShare, 1)}% (${fmtNum(cpsAmt)} 億)` : `CPS其他通路: -`;
    }
    const b02AmtSegEpos = document.getElementById("b02-amt-seg-epos");
    if (b02AmtSegEpos) {
      b02AmtSegEpos.style.width = isValidNum(eposAmtShare) ? `${eposAmtShare}%` : `0%`;
      b02AmtSegEpos.title = isValidNum(eposAmtShare) ? `EPOS: ${fmtNum(eposAmtShare, 1)}% (${fmtNum(eposAmt)} 億)` : `EPOS: -`;
    }
    const b02AmtSegPh = document.getElementById("b02-amt-seg-ph");
    if (b02AmtSegPh) {
      b02AmtSegPh.style.width = isValidNum(phAmtShare) ? `${phAmtShare}%` : `0%`;
      b02AmtSegPh.title = isValidNum(phAmtShare) ? `PH: ${fmtNum(phAmtShare, 1)}% (${fmtNum(phAmt)} 億)` : `PH: -`;
    }

    const b02AmtCpsPct = document.getElementById("b02-amt-cps-pct");
    if (b02AmtCpsPct) b02AmtCpsPct.textContent = isValidNum(cpsAmtShare) ? `(${fmtNum(cpsAmtShare, 1)}%)` : `(-%)`;
    const b02AmtCpsVal = document.getElementById("b02-amt-cps-val");
    if (b02AmtCpsVal) b02AmtCpsVal.innerHTML = isValidNum(cpsAmt) ? `${fmtNum(cpsAmt)}<em>億</em>` : `-`;

    const b02AmtEposPct = document.getElementById("b02-amt-epos-pct");
    if (b02AmtEposPct) b02AmtEposPct.textContent = isValidNum(eposAmtShare) ? `(${fmtNum(eposAmtShare, 1)}%)` : `(-%)`;
    const b02AmtEposVal = document.getElementById("b02-amt-epos-val");
    if (b02AmtEposVal) b02AmtEposVal.innerHTML = isValidNum(eposAmt) ? `${fmtNum(eposAmt)}<em>億</em>` : `-`;

    const b02AmtPhPct = document.getElementById("b02-amt-ph-pct");
    if (b02AmtPhPct) b02AmtPhPct.textContent = isValidNum(phAmtShare) ? `(${fmtNum(phAmtShare, 1)}%)` : `(-%)`;
    const b02AmtPhVal = document.getElementById("b02-amt-ph-val");
    if (b02AmtPhVal) b02AmtPhVal.innerHTML = isValidNum(phAmt) ? `${fmtNum(phAmt)}<em>億</em>` : `-`;

    // Backward compatibility guards for old IDs
    const c00AmtSegPhys = document.getElementById("c00-acq-amt-seg-phys");
    if (c00AmtSegPhys) {
      c00AmtSegPhys.style.width = isValidNum(amtPhys.share) ? `${amtPhys.share}%` : `0%`;
      c00AmtSegPhys.title = isValidNum(amtPhys.share) ? `實體收單: ${fmtNum(amtPhys.share)}% (${fmtNum(amtPhys.amount)} 億)` : `實體收單: -`;
    }
    const c00AmtSegOnl = document.getElementById("c00-acq-amt-seg-onl");
    if (c00AmtSegOnl) {
      c00AmtSegOnl.style.width = isValidNum(amtOnl.share) ? `${amtOnl.share}%` : `0%`;
      c00AmtSegOnl.title = isValidNum(amtOnl.share) ? `線上 EPOS+PH: ${fmtNum(amtOnl.share)}% (${fmtNum(amtOnl.amount)} 億)` : `線上 EPOS+PH: -`;
    }
    const c00AmtPhysPct = document.getElementById("c00-acq-amt-phys-pct");
    if (c00AmtPhysPct) c00AmtPhysPct.textContent = isValidNum(amtPhys.share) ? `(${fmtNum(amtPhys.share)}%)` : `(-%)`;
    const c00AmtPhysVal = document.getElementById("c00-acq-amt-phys-val");
    if (c00AmtPhysVal) c00AmtPhysVal.innerHTML = isValidNum(amtPhys.amount) ? `${fmtNum(amtPhys.amount)}<em>億</em>` : `-`;
    const c00AmtOnlPct = document.getElementById("c00-acq-amt-onl-pct");
    if (c00AmtOnlPct) c00AmtOnlPct.textContent = isValidNum(amtOnl.share) ? `(${fmtNum(amtOnl.share)}%)` : `(-%)`;
    const c00AmtOnlVal = document.getElementById("c00-acq-amt-onl-val");
    if (c00AmtOnlVal) c00AmtOnlVal.innerHTML = isValidNum(amtOnl.amount) ? `${fmtNum(amtOnl.amount)}<em>億</em>` : `-`;

    const b02AmtSegPhys = document.getElementById("b02-amt-seg-phys");
    if (b02AmtSegPhys) {
      b02AmtSegPhys.style.width = isValidNum(amtPhys.share) ? `${amtPhys.share}%` : `0%`;
      b02AmtSegPhys.title = isValidNum(amtPhys.share) ? `實體收單: ${fmtNum(amtPhys.share)}% (${fmtNum(amtPhys.amount)} 億)` : `實體收單: -`;
    }
    const b02AmtSegOnl = document.getElementById("b02-amt-seg-onl");
    if (b02AmtSegOnl) {
      b02AmtSegOnl.style.width = isValidNum(amtOnl.share) ? `${amtOnl.share}%` : `0%`;
      b02AmtSegOnl.title = isValidNum(amtOnl.share) ? `線上 EPOS+PH: ${fmtNum(amtOnl.share)}% (${fmtNum(amtOnl.amount)} 億)` : `線上 EPOS+PH: -`;
    }
    const b02AmtPhysPct = document.getElementById("b02-amt-phys-pct");
    if (b02AmtPhysPct) b02AmtPhysPct.textContent = isValidNum(amtPhys.share) ? `(${fmtNum(amtPhys.share)}%)` : `(-%)`;
    const b02AmtPhysVal = document.getElementById("b02-amt-phys-val");
    if (b02AmtPhysVal) b02AmtPhysVal.innerHTML = isValidNum(amtPhys.amount) ? `${fmtNum(amtPhys.amount)}<em>億</em>` : `-`;
    const b02AmtOnlPct = document.getElementById("b02-amt-onl-pct");
    if (b02AmtOnlPct) b02AmtOnlPct.textContent = isValidNum(amtOnl.share) ? `(${fmtNum(amtOnl.share)}%)` : `(-%)`;
    const b02AmtOnlVal = document.getElementById("b02-amt-onl-val");
    if (b02AmtOnlVal) b02AmtOnlVal.innerHTML = isValidNum(amtOnl.amount) ? `${fmtNum(amtOnl.amount)}<em>億</em>` : `-`;

    // 2. 收單交易筆數
    const cnt = kpi.acq_cnt || {};
    const cntPhys = cnt.physical || {};
    const cntOnl = cnt.online || {};

    const cntValHtml = isValidNum(cnt.total) ? `${fmtNum(cnt.total)}<em>${cnt.unit || '萬筆'}</em>` : `-`;
    const cntGrowthHtml = `
      <span class="${semCls(cnt.yoy)}"><b>YoY</b>${fmtSign(cnt.yoy)}</span>
      <span class="${semCls(cnt.mom)}"><b>MoM</b>${fmtSign(cnt.mom)}</span>
    `;

    if (eposCnt === 0 && phCnt === 0 && isValidNum(cntOnl.count)) {
      eposCnt = Number(cntOnl.count) || 0;
    }
    const cntTotalNum = Number(cnt.total) || 0;
    const cpsCnt = (isValidNum(cnt.total) && cntTotalNum > 0) ? Math.max(0, cntTotalNum - eposCnt - phCnt) : (Number(cntPhys.count) || null);
    const cpsCntShare = (isValidNum(cnt.total) && cntTotalNum > 0) ? (cpsCnt / cntTotalNum) * 100 : (cntPhys.share ?? null);
    const eposCntShare = (isValidNum(cnt.total) && cntTotalNum > 0) ? (eposCnt / cntTotalNum) * 100 : null;
    const phCntShare = (isValidNum(cnt.total) && cntTotalNum > 0) ? (phCnt / cntTotalNum) * 100 : null;

    // Cockpit Col 2: Card 2 (收單交易筆數)
    const c00CntVal = document.getElementById("c00-acq-cnt-val");
    if (c00CntVal) {
      c00CntVal.innerHTML = isValidNum(cnt.total) ? `${fmtNum(cnt.total)} <em>${cnt.unit || '萬筆'}</em>` : `-`;
      const dVal = c00CntVal.parentElement?.querySelector(".c-daily-stat .d-val");
      if (dVal && isValidNum(cnt.total)) {
        dVal.textContent = `${(Number(cnt.total) / 31).toFixed(1)} ${cnt.unit || '萬筆'}`;
      }
    }
    const c00CntGrowth = document.getElementById("c00-acq-cnt-growth");
    if (c00CntGrowth) {
      c00CntGrowth.innerHTML = `
        <span class="${semCls(cnt.yoy)}">YoY ${fmtSign(cnt.yoy)}</span>
        <span class="${semCls(cnt.mom)}">MoM ${fmtSign(cnt.mom)}</span>
      `;
    }
    const c00CntSegCps = document.getElementById("c00-acq-cnt-seg-cps");
    if (c00CntSegCps) {
      c00CntSegCps.style.width = isValidNum(cpsCntShare) ? `${cpsCntShare}%` : `0%`;
      c00CntSegCps.title = isValidNum(cpsCntShare) ? `CPS其他通路: ${fmtNum(cpsCntShare, 1)}% (${fmtNum(cpsCnt)} 萬筆)` : `CPS其他通路: -`;
    }
    const c00CntSegEpos = document.getElementById("c00-acq-cnt-seg-epos");
    if (c00CntSegEpos) {
      c00CntSegEpos.style.width = isValidNum(eposCntShare) ? `${eposCntShare}%` : `0%`;
      c00CntSegEpos.title = isValidNum(eposCntShare) ? `EPOS: ${fmtNum(eposCntShare, 1)}% (${fmtNum(eposCnt)} 萬筆)` : `EPOS: -`;
    }
    const c00CntSegPh = document.getElementById("c00-acq-cnt-seg-ph");
    if (c00CntSegPh) {
      c00CntSegPh.style.width = isValidNum(phCntShare) ? `${phCntShare}%` : `0%`;
      c00CntSegPh.title = isValidNum(phCntShare) ? `PH: ${fmtNum(phCntShare, 1)}% (${fmtNum(phCnt)} 萬筆)` : `PH: -`;
    }
    const c00CntCpsPct = document.getElementById("c00-acq-cnt-cps-pct");
    if (c00CntCpsPct) c00CntCpsPct.textContent = isValidNum(cpsCntShare) ? `(${fmtNum(cpsCntShare, 1)}%)` : `(-%)`;
    const c00CntCpsVal = document.getElementById("c00-acq-cnt-cps-val");
    if (c00CntCpsVal) c00CntCpsVal.innerHTML = isValidNum(cpsCnt) ? `${fmtNum(cpsCnt)}<em>萬筆</em>` : `-`;

    const c00CntEposPct = document.getElementById("c00-acq-cnt-epos-pct");
    if (c00CntEposPct) c00CntEposPct.textContent = isValidNum(eposCntShare) ? `(${fmtNum(eposCntShare, 1)}%)` : `(-%)`;
    const c00CntEposVal = document.getElementById("c00-acq-cnt-epos-val");
    if (c00CntEposVal) c00CntEposVal.innerHTML = isValidNum(eposCnt) ? `${fmtNum(eposCnt)}<em>萬筆</em>` : `-`;

    const c00CntPhPct = document.getElementById("c00-acq-cnt-ph-pct");
    if (c00CntPhPct) c00CntPhPct.textContent = isValidNum(phCntShare) ? `(${fmtNum(phCntShare, 1)}%)` : `(-%)`;
    const c00CntPhVal = document.getElementById("c00-acq-cnt-ph-val");
    if (c00CntPhVal) c00CntPhVal.innerHTML = isValidNum(phCnt) ? `${fmtNum(phCnt)}<em>萬筆</em>` : `-`;

    // 02 Section: Primary Card 2 (CPS其他通路, EPOS, PH)
    const b02CntVal = document.getElementById("b02-cnt-val");
    if (b02CntVal) b02CntVal.innerHTML = cntValHtml;
    const b02CntGrowth = document.getElementById("b02-cnt-growth");
    if (b02CntGrowth) b02CntGrowth.innerHTML = cntGrowthHtml;

    const b02CntSegCps = document.getElementById("b02-cnt-seg-cps");
    if (b02CntSegCps) {
      b02CntSegCps.style.width = isValidNum(cpsCntShare) ? `${cpsCntShare}%` : `0%`;
      b02CntSegCps.title = isValidNum(cpsCntShare) ? `CPS其他通路: ${fmtNum(cpsCntShare, 1)}% (${fmtNum(cpsCnt)} 萬筆)` : `CPS其他通路: -`;
    }
    const b02CntSegEpos = document.getElementById("b02-cnt-seg-epos");
    if (b02CntSegEpos) {
      b02CntSegEpos.style.width = isValidNum(eposCntShare) ? `${eposCntShare}%` : `0%`;
      b02CntSegEpos.title = isValidNum(eposCntShare) ? `EPOS: ${fmtNum(eposCntShare, 1)}% (${fmtNum(eposCnt)} 萬筆)` : `EPOS: -`;
    }
    const b02CntSegPh = document.getElementById("b02-cnt-seg-ph");
    if (b02CntSegPh) {
      b02CntSegPh.style.width = isValidNum(phCntShare) ? `${phCntShare}%` : `0%`;
      b02CntSegPh.title = isValidNum(phCntShare) ? `PH: ${fmtNum(phCntShare, 1)}% (${fmtNum(phCnt)} 萬筆)` : `PH: -`;
    }

    const b02CntCpsPct = document.getElementById("b02-cnt-cps-pct");
    if (b02CntCpsPct) b02CntCpsPct.textContent = isValidNum(cpsCntShare) ? `(${fmtNum(cpsCntShare, 1)}%)` : `(-%)`;
    const b02CntCpsVal = document.getElementById("b02-cnt-cps-val");
    if (b02CntCpsVal) b02CntCpsVal.innerHTML = isValidNum(cpsCnt) ? `${fmtNum(cpsCnt)}<em>萬筆</em>` : `-`;

    const b02CntEposPct = document.getElementById("b02-cnt-epos-pct");
    if (b02CntEposPct) b02CntEposPct.textContent = isValidNum(eposCntShare) ? `(${fmtNum(eposCntShare, 1)}%)` : `(-%)`;
    const b02CntEposVal = document.getElementById("b02-cnt-epos-val");
    if (b02CntEposVal) b02CntEposVal.innerHTML = isValidNum(eposCnt) ? `${fmtNum(eposCnt)}<em>萬筆</em>` : `-`;

    const b02CntPhPct = document.getElementById("b02-cnt-ph-pct");
    if (b02CntPhPct) b02CntPhPct.textContent = isValidNum(phCntShare) ? `(${fmtNum(phCntShare, 1)}%)` : `(-%)`;
    const b02CntPhVal = document.getElementById("b02-cnt-ph-val");
    if (b02CntPhVal) b02CntPhVal.innerHTML = isValidNum(phCnt) ? `${fmtNum(phCnt)}<em>萬筆</em>` : `-`;

    // Backward compatibility guards for old IDs
    const c00CntSegPhys = document.getElementById("c00-acq-cnt-seg-phys");
    if (c00CntSegPhys) {
      c00CntSegPhys.style.width = isValidNum(cntPhys.share) ? `${cntPhys.share}%` : `0%`;
      c00CntSegPhys.title = isValidNum(cntPhys.share) ? `實體收單: ${fmtNum(cntPhys.share)}% (${fmtNum(cntPhys.count)} 萬筆)` : `實體收單: -`;
    }
    const c00CntSegOnl = document.getElementById("c00-acq-cnt-seg-onl");
    if (c00CntSegOnl) {
      c00CntSegOnl.style.width = isValidNum(cntOnl.share) ? `${cntOnl.share}%` : `0%`;
      c00CntSegOnl.title = isValidNum(cntOnl.share) ? `線上 EPOS+PH: ${fmtNum(cntOnl.share)}% (${fmtNum(cntOnl.count)} 萬筆)` : `線上 EPOS+PH: -`;
    }
    const c00CntPhysPct = document.getElementById("c00-acq-cnt-phys-pct");
    if (c00CntPhysPct) c00CntPhysPct.textContent = isValidNum(cntPhys.share) ? `(${fmtNum(cntPhys.share)}%)` : `(-%)`;
    const c00CntPhysVal = document.getElementById("c00-acq-cnt-phys-val");
    if (c00CntPhysVal) c00CntPhysVal.innerHTML = isValidNum(cntPhys.count) ? `${fmtNum(cntPhys.count)}<em>萬筆</em>` : `-`;
    const c00CntOnlPct = document.getElementById("c00-acq-cnt-onl-pct");
    if (c00CntOnlPct) c00CntOnlPct.textContent = isValidNum(cntOnl.share) ? `(${fmtNum(cntOnl.share)}%)` : `(-%)`;
    const c00CntOnlVal = document.getElementById("c00-acq-cnt-onl-val");
    if (c00CntOnlVal) c00CntOnlVal.innerHTML = isValidNum(cntOnl.count) ? `${fmtNum(cntOnl.count)}<em>萬筆</em>` : `-`;

    const b02CntSegPhys = document.getElementById("b02-cnt-seg-phys");
    if (b02CntSegPhys) {
      b02CntSegPhys.style.width = isValidNum(cntPhys.share) ? `${cntPhys.share}%` : `0%`;
      b02CntSegPhys.title = isValidNum(cntPhys.share) ? `實體收單: ${fmtNum(cntPhys.share)}% (${fmtNum(cntPhys.count)} 萬筆)` : `實體收單: -`;
    }
    const b02CntSegOnl = document.getElementById("b02-cnt-seg-onl");
    if (b02CntSegOnl) {
      b02CntSegOnl.style.width = isValidNum(cntOnl.share) ? `${cntOnl.share}%` : `0%`;
      b02CntSegOnl.title = isValidNum(cntOnl.share) ? `線上 EPOS+PH: ${fmtNum(cntOnl.share)}% (${fmtNum(cntOnl.count)} 萬筆)` : `線上 EPOS+PH: -`;
    }
    const b02CntPhysPct = document.getElementById("b02-cnt-phys-pct");
    if (b02CntPhysPct) b02CntPhysPct.textContent = isValidNum(cntPhys.share) ? `(${fmtNum(cntPhys.share)}%)` : `(-%)`;
    const b02CntPhysVal = document.getElementById("b02-cnt-phys-val");
    if (b02CntPhysVal) b02CntPhysVal.innerHTML = isValidNum(cntPhys.count) ? `${fmtNum(cntPhys.count)}<em>萬筆</em>` : `-`;
    const b02CntOnlPct = document.getElementById("b02-cnt-onl-pct");
    if (b02CntOnlPct) b02CntOnlPct.textContent = isValidNum(cntOnl.share) ? `(${fmtNum(cntOnl.share)}%)` : `(-%)`;
    const b02CntOnlVal = document.getElementById("b02-cnt-onl-val");
    if (b02CntOnlVal) b02CntOnlVal.innerHTML = isValidNum(cntOnl.count) ? `${fmtNum(cntOnl.count)}<em>萬筆</em>` : `-`;

    // 3. 收單特店總數
    const mcht = kpi.acq_mcht || {};
    const mchtPhys = mcht.physical || {};
    const mchtOnl = mcht.online || {};

    const mchtValHtml = isValidNum(mcht.total) ? `${fmtNum(mcht.total)}<em>${mcht.unit || '家'}</em>` : `-`;
    const mchtGrowthHtml = `
      <span class="${semCls(mcht.yoy)}"><b>YoY</b>${fmtSign(mcht.yoy)}</span>
      <span class="${semCls(mcht.mom)}"><b>MoM</b>${fmtSign(mcht.mom)}</span>
    `;

    // Cockpit Col 2: Card 3
    const c00MchtVal = document.getElementById("c00-acq-mcht-val");
    if (c00MchtVal) c00MchtVal.innerHTML = isValidNum(mcht.total) ? `${fmtNum(mcht.total)} <em>${mcht.unit || '家'}</em>` : `-`;
    const c00MchtGrowth = document.getElementById("c00-acq-mcht-growth");
    if (c00MchtGrowth) {
      c00MchtGrowth.innerHTML = `<span class="${semCls(mcht.yoy)}">YoY ${fmtSign(mcht.yoy)}</span><span class="c-hint" id="c00-acq-mcht-hint" style="display:none;"></span>`;
    }
    const c00MchtSegPhys = document.getElementById("c00-acq-mcht-seg-phys");
    if (c00MchtSegPhys) {
      c00MchtSegPhys.style.width = isValidNum(mchtPhys.share) ? `${mchtPhys.share}%` : `0%`;
      c00MchtSegPhys.title = isValidNum(mchtPhys.share) ? `實體特店: ${fmtNum(mchtPhys.share)}% (${fmtNum(mchtPhys.count)} 家)` : `實體特店: -`;
    }
    const c00MchtSegOnl = document.getElementById("c00-acq-mcht-seg-onl");
    if (c00MchtSegOnl) {
      c00MchtSegOnl.style.width = isValidNum(mchtOnl.share) ? `${mchtOnl.share}%` : `0%`;
      c00MchtSegOnl.title = isValidNum(mchtOnl.share) ? `線上特店: ${fmtNum(mchtOnl.share)}% (${fmtNum(mchtOnl.count)} 家)` : `線上特店: -`;
    }
    const c00MchtPhysPct = document.getElementById("c00-acq-mcht-phys-pct");
    if (c00MchtPhysPct) c00MchtPhysPct.textContent = isValidNum(mchtPhys.share) ? `(${fmtNum(mchtPhys.share)}%)` : `(-%)`;
    const c00MchtPhysVal = document.getElementById("c00-acq-mcht-phys-val");
    if (c00MchtPhysVal) c00MchtPhysVal.innerHTML = isValidNum(mchtPhys.count) ? `${fmtNum(mchtPhys.count)}<em>家</em>` : `-`;
    const c00MchtOnlPct = document.getElementById("c00-acq-mcht-onl-pct");
    if (c00MchtOnlPct) c00MchtOnlPct.textContent = isValidNum(mchtOnl.share) ? `(${fmtNum(mchtOnl.share)}%)` : `(-%)`;
    const c00MchtOnlVal = document.getElementById("c00-acq-mcht-onl-val");
    if (c00MchtOnlVal) c00MchtOnlVal.innerHTML = isValidNum(mchtOnl.count) ? `${fmtNum(mchtOnl.count)}<em>家</em>` : `-`;

    // 02 Section: Primary Card 3
    const b02MchtVal = document.getElementById("b02-mcht-val");
    if (b02MchtVal) b02MchtVal.innerHTML = mchtValHtml;
    const b02MchtGrowth = document.getElementById("b02-mcht-growth");
    if (b02MchtGrowth) b02MchtGrowth.innerHTML = mchtGrowthHtml;

    // 子特店總數 (單位: 萬家)
    const submcht = mcht.submcht || {};
    const b02SubmchtVal = document.getElementById("b02-submcht-total-val");
    if (b02SubmchtVal) {
      b02SubmchtVal.innerHTML = isValidNum(submcht.total) ? `${fmtNum(submcht.total)}<em>${submcht.unit || '萬家'}</em>` : `-<em>${submcht.unit || '萬家'}</em>`;
    }
    const b02SubmchtGrowth = document.getElementById("b02-submcht-total-growth");
    if (b02SubmchtGrowth) {
      const hasSubGrowth = isValidNum(submcht.yoy) || isValidNum(submcht.mom);
      if (hasSubGrowth) {
        b02SubmchtGrowth.style.display = "flex";
        b02SubmchtGrowth.innerHTML = `
          <span class="${semCls(submcht.yoy)}"><b>YoY</b>${fmtSign(submcht.yoy)}</span>
          <span class="${semCls(submcht.mom)}"><b>MoM</b>${fmtSign(submcht.mom)}</span>
        `;
      } else {
        b02SubmchtGrowth.style.display = "none";
      }
    }
    const b02MchtSegPhys = document.getElementById("b02-mcht-seg-phys");
    if (b02MchtSegPhys) {
      b02MchtSegPhys.style.width = isValidNum(mchtPhys.share) ? `${mchtPhys.share}%` : `0%`;
      b02MchtSegPhys.title = isValidNum(mchtPhys.share) ? `實體特店: ${fmtNum(mchtPhys.share)}% (${fmtNum(mchtPhys.count)} 家)` : `實體特店: -`;
    }
    const b02MchtSegOnl = document.getElementById("b02-mcht-seg-onl");
    if (b02MchtSegOnl) {
      b02MchtSegOnl.style.width = isValidNum(mchtOnl.share) ? `${mchtOnl.share}%` : `0%`;
      b02MchtSegOnl.title = isValidNum(mchtOnl.share) ? `線上特店: ${fmtNum(mchtOnl.share)}% (${fmtNum(mchtOnl.count)} 家)` : `線上特店: -`;
    }
    const b02MchtPhysPct = document.getElementById("b02-mcht-phys-pct");
    if (b02MchtPhysPct) b02MchtPhysPct.textContent = isValidNum(mchtPhys.share) ? `(${fmtNum(mchtPhys.share)}%)` : `(-%)`;
    const b02MchtPhysVal = document.getElementById("b02-mcht-phys-val");
    if (b02MchtPhysVal) b02MchtPhysVal.innerHTML = isValidNum(mchtPhys.count) ? `${fmtNum(mchtPhys.count)}<em>家</em>` : `-`;
    const b02MchtOnlPct = document.getElementById("b02-mcht-onl-pct");
    if (b02MchtOnlPct) b02MchtOnlPct.textContent = isValidNum(mchtOnl.share) ? `(${fmtNum(mchtOnl.share)}%)` : `(-%)`;
    const b02MchtOnlVal = document.getElementById("b02-mcht-onl-val");
    if (b02MchtOnlVal) b02MchtOnlVal.innerHTML = isValidNum(mchtOnl.count) ? `${fmtNum(mchtOnl.count)}<em>家</em>` : `-`;

    // 4. 次要指標 (4 Cards)
    const sec = kpi.secondary || {};
    const erm = sec.erm_cnt || sec.penetration_rate || {};
    const portal = sec.portal_mcht || sec.active_mcht || {};
    const estmt = sec.estatement_rate || {};
    const fee = sec.fee_income || {};

    // Card 1: ERM電簽交易筆數 (萬筆)
    const b02ErmVal = document.getElementById("b02-erm-cnt-val") || document.getElementById("b02-penetration-val");
    if (b02ErmVal) {
      b02ErmVal.innerHTML = isValidNum(erm.value) ? `${fmtNum(erm.value)}<em>${erm.unit || '萬筆'}</em>` : `-<em>萬筆</em>`;
    }
    const b02ErmGrowth = document.getElementById("b02-erm-cnt-growth") || document.getElementById("b02-penetration-growth");
    if (b02ErmGrowth) {
      const hasErmGrowth = isValidNum(erm.yoy) || isValidNum(erm.mom);
      if (hasErmGrowth) {
        b02ErmGrowth.innerHTML = `
          <span class="${semCls(erm.yoy)}"><b>YoY</b>${fmtSign(erm.yoy)}</span>
          <span class="${semCls(erm.mom)}"><b>MoM</b>${fmtSign(erm.mom)}</span>
        `;
      } else {
        b02ErmGrowth.textContent = "-";
      }
    }

    // Card 2: Merchant Portal商戶數 (家)
    const b02PortalVal = document.getElementById("b02-portal-mcht-val") || document.getElementById("b02-active-mcht-val");
    if (b02PortalVal) {
      const pVal = portal.value ?? portal.count;
      b02PortalVal.innerHTML = isValidNum(pVal) ? `${fmtNum(pVal)}<em>${portal.unit || '家'}</em>` : `-<em>家</em>`;
    }
    const b02PortalGrowth = document.getElementById("b02-portal-mcht-growth") || document.getElementById("b02-active-mcht-growth");
    if (b02PortalGrowth) {
      const hasPortalGrowth = isValidNum(portal.yoy) || isValidNum(portal.mom);
      if (hasPortalGrowth) {
        b02PortalGrowth.innerHTML = `
          <span class="${semCls(portal.yoy)}"><b>YoY</b>${fmtSign(portal.yoy)}</span>
          <span class="${semCls(portal.mom)}"><b>MoM</b>${fmtSign(portal.mom)}</span>
        `;
      } else {
        b02PortalGrowth.textContent = "-";
      }
    }

    const b02EstmtVal = document.getElementById("b02-estatement-val");
    if (b02EstmtVal) b02EstmtVal.textContent = isValidNum(estmt.value) ? `${fmtNum(estmt.value)}%` : `-`;

    const submchtApi = sec.submcht_api || {};
    const b02SubmchtApiVal = document.getElementById("b02-submcht-api-val");
    if (b02SubmchtApiVal) {
      b02SubmchtApiVal.innerHTML = isValidNum(submchtApi.count ?? submchtApi.value) ? `${fmtNum(submchtApi.count ?? submchtApi.value)}<em>件</em>` : `-<em>件</em>`;
    }

    const b02FeeVal = document.getElementById("b02-fee-val");
    if (b02FeeVal) b02FeeVal.innerHTML = isValidNum(fee.value) ? `${fmtNum(fee.value)}<em>${fee.unit || '億元'}</em>` : `-<em>${fee.unit || '億元'}</em>`;
    const b02FeeGrowth = document.getElementById("b02-fee-growth");
    if (b02FeeGrowth) {
      const hasFeeGrowth = isValidNum(fee.yoy) || isValidNum(fee.mom);
      if (hasFeeGrowth) {
        b02FeeGrowth.innerHTML = `
          <span class="${semCls(fee.yoy)}"><b>YoY</b>${fmtSign(fee.yoy)}</span>
          <span class="${semCls(fee.mom)}"><b>MoM</b>${fmtSign(fee.mom)}</span>
        `;
      } else {
        b02FeeGrowth.textContent = "-";
      }
    }

    // 5. 2B TAB 0: 線上交易型態 (比照 03 分期產品結構分析：3 張並排獨立雙軸 MoM 對比圖)
    if (channels.length > 0) {
      const structBar = document.getElementById("b02-online-struct-bar");
      if (structBar) {
        const colors = ["#003b5c", "#3b82f6", "#ea580c"];
        structBar.innerHTML = channels.map((c, idx) => `
          <div style="background:${colors[idx % colors.length]}; width:${isValidNum(c.amount_share) ? c.amount_share : 0}%;" title="${c.name} (${isValidNum(c.amount_share) ? fmtNum(c.amount_share) + '%' : '-'})">
            <span>${c.name} (${isValidNum(c.amount_share) ? fmtNum(c.amount_share) + '%' : '-'})</span>
          </div>
        `).join("");
      }

      const tableBody = document.getElementById("b02-online-table-body");
      if (tableBody) {
        tableBody.innerHTML = channels.map(c => `
          <tr>
            <td><strong>${c.name}</strong></td>
            <td style="text-align:right;"><strong style="color:var(--blue-dark); font-size:15.5px;">${isValidNum(c.amount) ? fmtNum(c.amount) + ' 億元' : '-'}</strong></td>
            <td style="text-align:right;" class="${semCls(c.amount_mom ?? c.amount_yoy)}"><strong>${fmtSign(c.amount_mom ?? c.amount_yoy)}</strong></td>
            <td style="text-align:right;">${isValidNum(c.count) ? fmtNum(c.count) + ' 萬筆' : '-'}</td>
            <td style="text-align:right;" class="${semCls(c.count_mom ?? c.count_yoy)}"><strong>${fmtSign(c.count_mom ?? c.count_yoy)}</strong></td>
            <td style="text-align:right;">${isValidNum(c.avg_ticket) ? fmtNum(c.avg_ticket) + ' 元' : '-'}</td>
            <td style="text-align:right;" class="${semCls(c.avg_ticket_yoy)}"><strong>${fmtSign(c.avg_ticket_yoy)}</strong></td>
          </tr>
        `).join("");
      }

      const b02OnlineSvgWrapper = document.getElementById("b02-online-svg-wrapper");
      if (b02OnlineSvgWrapper && channels.length >= 3) {
        b02OnlineSvgWrapper.className = "acq-channel-dual-grid";
        b02OnlineSvgWrapper.style.display = "grid";
        b02OnlineSvgWrapper.style.gridTemplateColumns = "repeat(2, 1fr)";
        b02OnlineSvgWrapper.style.gap = "14px";
        b02OnlineSvgWrapper.style.marginBottom = "14px";

        // 依使用者指示排序：三個通路 (EPOS 地端、EPOS 雲端、Payment Hub 掃碼交易)
        const cGround = channels.find(c => c.code === "channel_ground") || channels[1] || {};
        const cCloud = channels.find(c => c.code === "channel_cloud") || channels[0] || {};
        const cHub = channels.find(c => c.code === "channel_hub") || channels[2] || {};
        const displayChannels = [
          { ...cGround, name: cGround.name || "EPOS - 地端", cNum: 2 },
          { ...cCloud, name: cCloud.name || "EPOS - 雲端", cNum: 1 },
          { ...cHub, name: cHub.name || "Payment Hub掃碼交易", cNum: 3 }
        ];

        // 計算尺度最大值 (Max)，保留適當視覺呼吸空間
        const allAmts = displayChannels.flatMap(c => [Number(c.amount) || 0, Number(c.prev_amount) || 0]);
        const maxAmt = Math.max(...allAmts, 0.1) * 1.05;

        const allCnts = displayChannels.flatMap(c => [Number(c.count) || 0, Number(c.prev_count) || 0]);
        const maxCnt = Math.max(...allCnts, 1) * 1.05;

        const calcBarW = (val, max) => {
          if (!isValidNum(val) || Number(val) <= 0) return 0;
          return Math.max(((Number(val) / max) * 100), 5).toFixed(1);
        };

        // 1. 左側圖表：交易金額 (單位：億元 ｜ 本月 vs 前月)
        const amtRowsHtml = displayChannels.map(c => {
          const currW = calcBarW(c.amount, maxAmt);
          const prevW = calcBarW(c.prev_amount, maxAmt);
          const momVal = c.amount_mom ?? c.amount_yoy;
          const momClass = semCls(momVal);
          const momText = isValidNum(momVal) ? fmtSign(momVal) : "-";
          const currTxt = isValidNum(c.amount) ? fmtNum(c.amount, 2) : "-";
          const prevTxt = isValidNum(c.prev_amount) ? fmtNum(c.prev_amount, 2) : "-";

          return `
            <div class="acq-channel-row">
              <div class="acq-channel-name">${c.name}</div>
              <div class="acq-channel-bars">
                <div class="acq-bar-line" title="本月：${currTxt} 億元">
                  <span class="acq-bar-subtag">本月</span>
                  <div class="acq-bar-track">
                    <div class="acq-bar-fill curr-amt" style="width: ${currW}%;">
                      <span id="b02-onl-c${c.cNum}-amt">${currTxt}</span>
                    </div>
                  </div>
                </div>
                <div class="acq-bar-line" title="前月：${prevTxt} 億元">
                  <span class="acq-bar-subtag">前月</span>
                  <div class="acq-bar-track">
                    <div class="acq-bar-fill prev ${prevW == 0 ? 'zero-val' : ''}" style="width: ${prevW}%;">
                      ${prevW > 0 ? `<span>${prevTxt}</span>` : ''}
                    </div>
                  </div>
                </div>
              </div>
              <div class="acq-channel-mom ${momClass}">${momText}</div>
            </div>
          `;
        }).join("");

        const leftCardHtml = `
          <div class="chart-box acq-channel-card">
            <div class="chart-box-header">
              <div>
                <h3 style="color:var(--blue-dark);">交易金額</h3>
              </div>
              <div style="display:flex; align-items:center; gap:12px; font-size:11px; font-weight:800; color:#68767b;">
                <div style="display:flex; align-items:center; gap:8px;">
                  <span style="display:inline-flex; align-items:center; gap:4px;"><i style="width:9px; height:9px; border-radius:2px; background:#003b5c; display:inline-block;"></i> 本月</span>
                  <span style="display:inline-flex; align-items:center; gap:4px;"><i style="width:9px; height:9px; border-radius:2px; background:#94a3b8; display:inline-block;"></i> 前月</span>
                </div>
                <span>單位：億元 ｜ MoM</span>
              </div>
            </div>
            <div class="acq-channel-rows">
              ${amtRowsHtml}
            </div>
          </div>
        `;

        // 2. 右側圖表：交易筆數 (單位：萬筆 ｜ 本月 vs 前月)
        const cntRowsHtml = displayChannels.map(c => {
          const currW = calcBarW(c.count, maxCnt);
          const prevW = calcBarW(c.prev_count, maxCnt);
          const momVal = c.count_mom ?? c.count_yoy;
          const momClass = semCls(momVal);
          const momText = isValidNum(momVal) ? fmtSign(momVal) : "-";
          const currTxt = isValidNum(c.count) ? fmtNum(c.count, 2) : "-";
          const prevTxt = isValidNum(c.prev_count) ? fmtNum(c.prev_count, 2) : "-";

          return `
            <div class="acq-channel-row">
              <div class="acq-channel-name">${c.name}</div>
              <div class="acq-channel-bars">
                <div class="acq-bar-line" title="本月：${currTxt} 萬筆">
                  <span class="acq-bar-subtag">本月</span>
                  <div class="acq-bar-track">
                    <div class="acq-bar-fill curr-cnt" style="width: ${currW}%;">
                      <span id="b02-onl-c${c.cNum}-cnt">${currTxt}</span>
                    </div>
                  </div>
                </div>
                <div class="acq-bar-line" title="前月：${prevTxt} 萬筆">
                  <span class="acq-bar-subtag">前月</span>
                  <div class="acq-bar-track">
                    <div class="acq-bar-fill prev ${prevW == 0 ? 'zero-val' : ''}" style="width: ${prevW}%;">
                      ${prevW > 0 ? `<span>${prevTxt}</span>` : ''}
                    </div>
                  </div>
                </div>
              </div>
              <div class="acq-channel-mom ${momClass}">${momText}</div>
            </div>
          `;
        }).join("");

        const rightCardHtml = `
          <div class="chart-box acq-channel-card">
            <div class="chart-box-header">
              <div>
                <h3 style="color:var(--blue-dark);">交易筆數</h3>
              </div>
              <div style="display:flex; align-items:center; gap:12px; font-size:11px; font-weight:800; color:#68767b;">
                <div style="display:flex; align-items:center; gap:8px;">
                  <span style="display:inline-flex; align-items:center; gap:4px;"><i style="width:9px; height:9px; border-radius:2px; background:#009e73; display:inline-block;"></i> 本月</span>
                  <span style="display:inline-flex; align-items:center; gap:4px;"><i style="width:9px; height:9px; border-radius:2px; background:#94a3b8; display:inline-block;"></i> 前月</span>
                </div>
                <span>單位：萬筆 ｜ MoM</span>
              </div>
            </div>
            <div class="acq-channel-rows">
              ${cntRowsHtml}
            </div>
          </div>
        `;

        b02OnlineSvgWrapper.innerHTML = leftCardHtml + rightCardHtml;
      }
    }

    // 6. 2B TAB 1: 特店集中度與 2x2 矩陣
    const conc = b2.merchant_concentration || {};
    const top10ShareElem = document.getElementById("b02-top10-share");
    if (top10ShareElem) top10ShareElem.textContent = isValidNum(conc.top10_share) ? `${fmtNum(conc.top10_share)}%` : `-`;
    const top10YoyElem = document.getElementById("b02-top10-yoy");
    if (top10YoyElem) top10YoyElem.textContent = isValidNum(conc.top10_yoy) ? `YoY ${fmtSign(conc.top10_yoy, 'pp')}` : `YoY -`;

    const topMchts = conc.top_merchants || [];
    const topMchtList = document.getElementById("b02-top-merchants-list");
    if (topMchtList && topMchts.length > 0) {
      const maxMchtAmt = Math.max(...topMchts.map(m => Number(m.amount) || 0), 1);
      topMchtList.innerHTML = topMchts.map(m => {
        const amtNum = Number(m.amount) || 0;
        const widthPct = isValidNum(m.amount) && maxMchtAmt > 0 ? ((amtNum / maxMchtAmt) * 100).toFixed(1) : 0;
        const isNeg = Number(m.yoy) < 0;
        const grad = isNeg ? 'linear-gradient(90deg, #d97706, #f59e0b)' : 'linear-gradient(90deg, #003b5c, #0284c7)';
        return `
          <div style="display:grid; grid-template-columns: 150px 1fr 130px; gap:12px; align-items:center;">
            <span style="font-size:14px; font-weight:800; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${m.name}（${m.sub}）">${m.name} <small style="color:#64748b; font-weight:600; font-size:12.5px;">(${m.sub})</small></span>
            <div style="height:11px; background:#e8eeee; border-radius:6px; overflow:hidden;">
              <div style="width:${widthPct}%; height:100%; background:${grad}; border-radius:6px;"></div>
            </div>
            <div style="text-align:right; white-space:nowrap;">
              <strong style="font-size:15px; font-weight:800; color:var(--blue-dark);">${isValidNum(m.amount) ? fmtNum(m.amount) + ' 億' : '-'}</strong>
              <span class="${semCls(m.yoy)}" style="font-size:12.5px; font-weight:800; margin-left:4px;">${fmtSign(m.yoy)}</span>
            </div>
          </div>
        `;
      }).join("");
    }

    const reps = conc.matrix_reps || {};
    const repCore = document.getElementById("b02-rep-core");
    if (repCore && reps.core) repCore.textContent = reps.core;
    const repPot = document.getElementById("b02-rep-potential");
    if (repPot && reps.potential) repPot.textContent = reps.potential;
    const repMain = document.getElementById("b02-rep-maintain");
    if (repMain && reps.maintain) repMain.textContent = reps.maintain;
    const repGen = document.getElementById("b02-rep-general");
    if (repGen && reps.general) repGen.textContent = reps.general;

    // 7. 2B TAB 2: 特店產業結構蝴蝶圖
    const indList = b2.industry_structure || [];
    const butterflyWrap = document.getElementById("b02-butterfly-list");
    if (butterflyWrap && indList.length > 0) {
      const maxMchtCount = Math.max(...indList.map(i => Number(i.merchant_count) || 0), 1);
      const maxAmount = Math.max(...indList.map(i => Number(i.amount) || 0), 1);

      butterflyWrap.innerHTML = indList.map(i => {
        const leftWidth = isValidNum(i.merchant_count) && maxMchtCount > 0 ? ((Number(i.merchant_count) / maxMchtCount) * 100).toFixed(1) : 0;
        const rightWidth = isValidNum(i.amount) && maxAmount > 0 ? ((Number(i.amount) / maxAmount) * 100).toFixed(1) : 0;
        return `
          <div class="acq-butterfly-row">
            <div class="acq-b-left-wing">
              <span class="acq-b-val-left">${isValidNum(i.merchant_count) ? fmtNum(i.merchant_count) + ' 家' : '-'} (${isValidNum(i.merchant_share) ? fmtNum(i.merchant_share) + '%' : '-'})</span>
              <div class="acq-b-bar-track-left">
                <div class="acq-b-bar-fill-left" style="width: ${leftWidth}%; background:${i.color || '#003b5c'};"></div>
              </div>
            </div>
            <div class="acq-b-center-axis">
              <span class="acq-b-axis-title">${i.label || i.name}</span>
            </div>
            <div class="acq-b-right-wing">
              <div class="acq-b-bar-track-right">
                <div class="acq-b-bar-fill-right" style="width: ${rightWidth}%; background:${i.color || '#003b5c'};"></div>
              </div>
              <span class="acq-b-val-right">${isValidNum(i.amount) ? fmtNum(i.amount) + ' 億' : '-'} (${isValidNum(i.amount_share) ? fmtNum(i.amount_share) + '%' : '-'})</span>
            </div>
            <div class="acq-b-avg-col">
              <span class="acq-b-avg-badge">${isValidNum(i.avg_per_merchant) ? fmtNum(i.avg_per_merchant) + ' 萬/店' : '-'}</span>
            </div>
          </div>
        `;
      }).join("");
    }

    // 8. TWQR 業務數據更新
    const c00TwApply = document.getElementById("c00-twqr-apply-cnt");
    if (c00TwApply) c00TwApply.innerHTML = isValidNum(twqr.apply_count) ? `${fmtNum(twqr.apply_count)} <em>件</em>` : `-`;
    const c00TwPass = document.getElementById("c00-twqr-pass-rate");
    if (c00TwPass) c00TwPass.textContent = isValidNum(twqr.pass_rate) ? `審查通過率 ${fmtNum(twqr.pass_rate)}%` : `-`;
    const c00TwNew = document.getElementById("c00-twqr-new-mcht");
    if (c00TwNew) c00TwNew.innerHTML = isValidNum(twqr.new_merchants) ? `${fmtNum(twqr.new_merchants)} <em>家</em>` : `-`;
    const c00TwTotM = document.getElementById("c00-twqr-total-mcht");
    if (c00TwTotM) c00TwTotM.innerHTML = isValidNum(twqr.total_merchants) ? `${fmtNum(twqr.total_merchants)} <em>家</em>` : `-`;
    const c00TwTotMom = document.getElementById("c00-twqr-total-mom");
    if (c00TwTotMom) c00TwTotMom.textContent = isValidNum(twqr.total_merchants_mom) ? `MoM ${fmtSign(twqr.total_merchants_mom)}` : `-`;

    const c00TwAmt = document.getElementById("c00-twqr-tx-amt");
    if (c00TwAmt) c00TwAmt.innerHTML = isValidNum(twqr.tx_amount) ? `${fmtNum(twqr.tx_amount)} <em>${twqr.tx_amount_unit || '元'}</em>` : `-`;
    const c00TwAmtMom = document.getElementById("c00-twqr-amt-mom");
    if (c00TwAmtMom) c00TwAmtMom.textContent = isValidNum(twqr.tx_amount_mom) ? `MoM ${fmtSign(twqr.tx_amount_mom)}` : `-`;
    const c00TwCnt = document.getElementById("c00-twqr-tx-cnt");
    if (c00TwCnt) c00TwCnt.innerHTML = isValidNum(twqr.tx_count) ? `${fmtNum(twqr.tx_count)} <em>${twqr.tx_count_unit || '筆'}</em>` : `-`;
    const c00TwCntMom = document.getElementById("c00-twqr-cnt-mom");
    if (c00TwCntMom) c00TwCntMom.textContent = isValidNum(twqr.tx_count_mom) ? `MoM ${fmtSign(twqr.tx_count_mom)}` : `-`;
    const c00TwActRate = document.getElementById("c00-twqr-active-rate");
    if (c00TwActRate) c00TwActRate.innerHTML = isValidNum(twqr.active_mcht_rate) ? `${fmtNum(twqr.active_mcht_rate)}<em>%</em>` : `-`;

    // 02 Section: TWQR Panel
    const b02TwApply = document.getElementById("b02-twqr-apply-cnt");
    if (b02TwApply) b02TwApply.textContent = isValidNum(twqr.apply_count) ? `${fmtNum(twqr.apply_count)} 件` : `-`;
    const b02TwPass = document.getElementById("b02-twqr-pass-rate");
    if (b02TwPass) b02TwPass.textContent = isValidNum(twqr.pass_rate) ? `審查通過率 ${fmtNum(twqr.pass_rate)}%` : `-`;
    const b02TwNew = document.getElementById("b02-twqr-new-mcht");
    if (b02TwNew) b02TwNew.textContent = isValidNum(twqr.new_merchants) ? `${fmtNum(twqr.new_merchants)} 家` : `-`;
    const b02TwTotM = document.getElementById("b02-twqr-total-mcht");
    if (b02TwTotM) b02TwTotM.textContent = isValidNum(twqr.total_merchants) ? `${fmtNum(twqr.total_merchants)} 家` : `-`;
    const b02TwTotMom = document.getElementById("b02-twqr-total-mom");
    if (b02TwTotMom) b02TwTotMom.textContent = isValidNum(twqr.total_merchants_mom) ? `MoM ${fmtSign(twqr.total_merchants_mom)}` : `-`;

    const b02TwAmt = document.getElementById("b02-twqr-tx-amt");
    if (b02TwAmt) b02TwAmt.textContent = isValidNum(twqr.tx_amount) ? `${fmtNum(twqr.tx_amount)} ${twqr.tx_amount_unit || '元'}` : `-`;
    const b02TwAmtMom = document.getElementById("b02-twqr-amt-mom");
    if (b02TwAmtMom) b02TwAmtMom.textContent = isValidNum(twqr.tx_amount_mom) ? `MoM ${fmtSign(twqr.tx_amount_mom)}` : `-`;
    const b02TwCnt = document.getElementById("b02-twqr-tx-cnt");
    if (b02TwCnt) b02TwCnt.textContent = isValidNum(twqr.tx_count) ? `${fmtNum(twqr.tx_count)} ${twqr.tx_count_unit || '筆'}` : `-`;
    const b02TwCntMom = document.getElementById("b02-twqr-cnt-mom");
    if (b02TwCntMom) b02TwCntMom.textContent = isValidNum(twqr.tx_count_mom) ? `MoM ${fmtSign(twqr.tx_count_mom)}` : `-`;
    const b02TwAvgTicket = document.getElementById("b02-twqr-avg-ticket");
    if (b02TwAvgTicket) b02TwAvgTicket.textContent = isValidNum(twqr.avg_ticket) ? `${fmtNum(twqr.avg_ticket)} 元` : `-`;
    const b02TwMchtAvgAmt = document.getElementById("b02-twqr-mcht-avg-amt");
    if (b02TwMchtAvgAmt) b02TwMchtAvgAmt.textContent = isValidNum(twqr.mcht_avg_amount) ? `${fmtNum(twqr.mcht_avg_amount)} 萬元` : `-`;
    const b02TwActRate = document.getElementById("b02-twqr-active-rate");
    if (b02TwActRate) b02TwActRate.textContent = isValidNum(twqr.active_mcht_rate) ? `${fmtNum(twqr.active_mcht_rate)}%` : `-`;
  }

  // ============================================================================
  // 動態渲染 03 發卡業務 (Block 03) 數據引擎
  // ============================================================================
  function renderBlock03FromData(data) {
    if (!data || !data.block03) return;
    const b3 = data.block03;
    const kpi = b3.monthly_kpis || {};
    const appFlow = b3.application_approval || {};
    const billCenter = b3.billing_center || {};
    const bonus = b3.bonus_points || {};
    const inst = b3.installment_structure || {};
    const colLoss = b3.collection_asset || {};

    const isValidNum = (v) => v !== null && v !== undefined && v !== '' && v !== '-' && !isNaN(Number(v));
    const fmtNum = (v, maxDigits = 2) => {
      if (!isValidNum(v)) return '-';
      return Number(v).toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: maxDigits
      });
    };
    const fmtSign = (v, sfx="%") => {
      if (!isValidNum(v)) return '-';
      const n = Number(v);
      const formatted = n.toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
      });
      return `${n > 0 ? "+" : ""}${formatted}${sfx}`;
    };
    const semCls = (v) => {
      if (!isValidNum(v)) return "number-neutral";
      return Number(v) >= 0 ? "number-positive" : "number-negative";
    };

    // ---------------------------------------------------------
    // 1. 申辦進件總量 (Card 1)
    // ---------------------------------------------------------
    const apply = kpi.apply_total || {};
    const applyDig = apply.digital || {};
    const applyPhy = apply.physical || {};

    // Cockpit Col 3: Card 1
    const c00ApplyGrowth = document.getElementById("c00-iss-apply-growth");
    if (c00ApplyGrowth) {
      c00ApplyGrowth.innerHTML = `
        <span class="${semCls(apply.yoy)}">YoY ${fmtSign(apply.yoy)}</span>
        <span class="${semCls(apply.mom)}">MoM ${fmtSign(apply.mom)}</span>
      `;
    }
    const c00ApplyVal = document.getElementById("c00-iss-apply-val");
    if (c00ApplyVal) {
      c00ApplyVal.innerHTML = isValidNum(apply.value) ? `${Number(apply.value).toLocaleString()} <em>${apply.unit || '件'}</em>` : `-`;
      const dVal = c00ApplyVal.parentElement?.querySelector(".c-daily-stat .d-val");
      if (dVal && isValidNum(apply.value)) {
        dVal.textContent = `${Math.round(Number(apply.value) / 31).toLocaleString()} ${apply.unit || '件'}`;
      }
    }

    const c00ApplySegDig = document.getElementById("c00-iss-apply-seg-dig");
    if (c00ApplySegDig) {
      c00ApplySegDig.style.width = isValidNum(applyDig.share) ? `${applyDig.share}%` : `0%`;
      c00ApplySegDig.title = isValidNum(applyDig.share) ? `數位進件: ${applyDig.share}% (${fmtNum(applyDig.amount, 0)} 件)` : `數位進件: -`;
    }
    const c00ApplySegPhy = document.getElementById("c00-iss-apply-seg-phy");
    if (c00ApplySegPhy) {
      c00ApplySegPhy.style.width = isValidNum(applyPhy.share) ? `${applyPhy.share}%` : `0%`;
      c00ApplySegPhy.title = isValidNum(applyPhy.share) ? `實體進件: ${applyPhy.share}% (${fmtNum(applyPhy.amount, 0)} 件)` : `實體進件: -`;
    }
    const c00ApplyDigPct = document.getElementById("c00-iss-apply-dig-pct");
    if (c00ApplyDigPct) c00ApplyDigPct.textContent = isValidNum(applyDig.share) ? `(${applyDig.share}%)` : `(-%)`;
    const c00ApplyDigVal = document.getElementById("c00-iss-apply-dig-val");
    if (c00ApplyDigVal) c00ApplyDigVal.innerHTML = isValidNum(applyDig.amount) ? `${Number(applyDig.amount).toLocaleString()}<em>件</em>` : `-`;
    const c00ApplyPhyPct = document.getElementById("c00-iss-apply-phy-pct");
    if (c00ApplyPhyPct) c00ApplyPhyPct.textContent = isValidNum(applyPhy.share) ? `(${applyPhy.share}%)` : `(-%)`;
    const c00ApplyPhyVal = document.getElementById("c00-iss-apply-phy-val");
    if (c00ApplyPhyVal) c00ApplyPhyVal.innerHTML = isValidNum(applyPhy.amount) ? `${Number(applyPhy.amount).toLocaleString()}<em>件</em>` : `-`;

    // 03 Section: Primary Card 1
    const b03ApplyVal = document.getElementById("b03-apply-val");
    if (b03ApplyVal) b03ApplyVal.innerHTML = isValidNum(apply.value) ? `${Number(apply.value).toLocaleString()}<em>${apply.unit || '件'}</em>` : `-`;
    const b03ApplyGrowth = document.getElementById("b03-apply-growth");
    if (b03ApplyGrowth) {
      b03ApplyGrowth.innerHTML = `
        <span class="${semCls(apply.yoy)}"><b>YoY</b>${fmtSign(apply.yoy)}</span>
        <span class="${semCls(apply.mom)}"><b>MoM</b>${fmtSign(apply.mom)}</span>
      `;
    }
    const b03ApplySegDig = document.getElementById("b03-apply-seg-dig");
    if (b03ApplySegDig) {
      b03ApplySegDig.style.width = isValidNum(applyDig.share) ? `${applyDig.share}%` : `0%`;
      b03ApplySegDig.title = isValidNum(applyDig.share) ? `數位進件: ${applyDig.share}% (${fmtNum(applyDig.amount, 0)} 件)` : `數位進件: -`;
    }
    const b03ApplySegPhy = document.getElementById("b03-apply-seg-phy");
    if (b03ApplySegPhy) {
      b03ApplySegPhy.style.width = isValidNum(applyPhy.share) ? `${applyPhy.share}%` : `0%`;
      b03ApplySegPhy.title = isValidNum(applyPhy.share) ? `實體進件: ${applyPhy.share}% (${fmtNum(applyPhy.amount, 0)} 件)` : `實體進件: -`;
    }
    const b03ApplyDigPct = document.getElementById("b03-apply-dig-pct");
    if (b03ApplyDigPct) b03ApplyDigPct.textContent = isValidNum(applyDig.share) ? `(${applyDig.share}%)` : `(-%)`;
    const b03ApplyDigVal = document.getElementById("b03-apply-dig-val");
    if (b03ApplyDigVal) b03ApplyDigVal.innerHTML = isValidNum(applyDig.amount) ? `${Number(applyDig.amount).toLocaleString()}<em>件</em>` : `-`;
    const b03ApplyPhyPct = document.getElementById("b03-apply-phy-pct");
    if (b03ApplyPhyPct) b03ApplyPhyPct.textContent = isValidNum(applyPhy.share) ? `(${applyPhy.share}%)` : `(-%)`;
    const b03ApplyPhyVal = document.getElementById("b03-apply-phy-val");
    if (b03ApplyPhyVal) b03ApplyPhyVal.innerHTML = isValidNum(applyPhy.amount) ? `${Number(applyPhy.amount).toLocaleString()}<em>件</em>` : `-`;

    // ---------------------------------------------------------
    // 2. 授權交易總數 (Card 2)
    // ---------------------------------------------------------
    const auth = kpi.auth_total || {};
    const authCrd = auth.credit || {};
    const authDbt = auth.debit || {};

    // Cockpit Col 3: Card 2
    const c00AuthGrowth = document.getElementById("c00-iss-auth-growth");
    if (c00AuthGrowth) {
      c00AuthGrowth.innerHTML = `
        <span class="${semCls(auth.yoy)}">YoY ${fmtSign(auth.yoy)}</span>
        <span class="${semCls(auth.mom)}">MoM ${fmtSign(auth.mom)}</span>
      `;
    }
    const c00AuthVal = document.getElementById("c00-iss-auth-val");
    if (c00AuthVal) {
      c00AuthVal.innerHTML = isValidNum(auth.value) ? `${fmtNum(auth.value, 0)} <em>${auth.unit || '萬筆'}</em>` : `-`;
      const dVal = c00AuthVal.parentElement?.querySelector(".c-daily-stat .d-val");
      if (dVal && isValidNum(auth.value)) {
        dVal.textContent = `${(Number(auth.value) / 31).toFixed(1)} ${auth.unit || '萬筆'}`;
      }
    }

    const c00AuthSegCrd = document.getElementById("c00-iss-auth-seg-crd");
    if (c00AuthSegCrd) {
      c00AuthSegCrd.style.width = isValidNum(authCrd.share) ? `${authCrd.share}%` : `0%`;
      c00AuthSegCrd.title = isValidNum(authCrd.share) ? `信用卡: ${authCrd.share}% (${fmtNum(authCrd.amount, 0)} 萬筆)` : `信用卡: -`;
    }
    const c00AuthSegDbt = document.getElementById("c00-iss-auth-seg-dbt");
    if (c00AuthSegDbt) {
      c00AuthSegDbt.style.width = isValidNum(authDbt.share) ? `${authDbt.share}%` : `0%`;
      c00AuthSegDbt.title = isValidNum(authDbt.share) ? `簽帳卡: ${authDbt.share}% (${fmtNum(authDbt.amount, 0)} 萬筆)` : `簽帳卡: -`;
    }
    const c00AuthCrdPct = document.getElementById("c00-iss-auth-crd-pct");
    if (c00AuthCrdPct) c00AuthCrdPct.textContent = isValidNum(authCrd.share) ? `(${authCrd.share}%)` : `(-%)`;
    const c00AuthCrdVal = document.getElementById("c00-iss-auth-crd-val");
    if (c00AuthCrdVal) c00AuthCrdVal.innerHTML = isValidNum(authCrd.amount) ? `${fmtNum(authCrd.amount, 0)}<em>萬筆</em>` : `-`;
    const c00AuthDbtPct = document.getElementById("c00-iss-auth-dbt-pct");
    if (c00AuthDbtPct) c00AuthDbtPct.textContent = isValidNum(authDbt.share) ? `(${authDbt.share}%)` : `(-%)`;
    const c00AuthDbtVal = document.getElementById("c00-iss-auth-dbt-val");
    if (c00AuthDbtVal) c00AuthDbtVal.innerHTML = isValidNum(authDbt.amount) ? `${fmtNum(authDbt.amount, 0)}<em>萬筆</em>` : `-`;

    // 03 Section: Primary Card 2
    const b03AuthVal = document.getElementById("b03-auth-val");
    if (b03AuthVal) b03AuthVal.innerHTML = isValidNum(auth.value) ? `${fmtNum(auth.value, 0)}<em>${auth.unit || '萬筆'}</em>` : `-`;
    const b03AuthGrowth = document.getElementById("b03-auth-growth");
    if (b03AuthGrowth) {
      b03AuthGrowth.innerHTML = `
        <span class="${semCls(auth.yoy)}"><b>YoY</b>${fmtSign(auth.yoy)}</span>
        <span class="${semCls(auth.mom)}"><b>MoM</b>${fmtSign(auth.mom)}</span>
      `;
    }
    const b03AuthSegCrd = document.getElementById("b03-auth-seg-crd");
    if (b03AuthSegCrd) {
      b03AuthSegCrd.style.width = isValidNum(authCrd.share) ? `${authCrd.share}%` : `0%`;
      b03AuthSegCrd.title = isValidNum(authCrd.share) ? `信用卡: ${authCrd.share}% (${fmtNum(authCrd.amount, 0)} 萬筆)` : `信用卡: -`;
    }
    const b03AuthSegDbt = document.getElementById("b03-auth-seg-dbt");
    if (b03AuthSegDbt) {
      b03AuthSegDbt.style.width = isValidNum(authDbt.share) ? `${authDbt.share}%` : `0%`;
      b03AuthSegDbt.title = isValidNum(authDbt.share) ? `簽帳卡: ${authDbt.share}% (${fmtNum(authDbt.amount, 0)} 萬筆)` : `簽帳卡: -`;
    }
    const b03AuthCrdPct = document.getElementById("b03-auth-crd-pct");
    if (b03AuthCrdPct) b03AuthCrdPct.textContent = isValidNum(authCrd.share) ? `(${authCrd.share}%)` : `(-%)`;
    const b03AuthCrdVal = document.getElementById("b03-auth-crd-val");
    if (b03AuthCrdVal) b03AuthCrdVal.innerHTML = isValidNum(authCrd.amount) ? `${fmtNum(authCrd.amount, 0)}<em>萬筆</em>` : `-`;
    const b03AuthDbtPct = document.getElementById("b03-auth-dbt-pct");
    if (b03AuthDbtPct) b03AuthDbtPct.textContent = isValidNum(authDbt.share) ? `(${authDbt.share}%)` : `(-%)`;
    const b03AuthDbtVal = document.getElementById("b03-auth-dbt-val");
    if (b03AuthDbtVal) b03AuthDbtVal.innerHTML = isValidNum(authDbt.amount) ? `${fmtNum(authDbt.amount, 0)}<em>萬筆</em>` : `-`;

    // ---------------------------------------------------------
    // 3. 分期交易總額 (Card 3)
    // ---------------------------------------------------------
    const instTot = kpi.install_total || {};
    const instSgl = instTot.single || {};
    const instBil = instTot.bill || {};
    const instMcht = instTot.merchant || {};

    const b03InstVal = document.getElementById("b03-inst-val");
    if (b03InstVal) b03InstVal.innerHTML = isValidNum(instTot.value) ? `${fmtNum(instTot.value, 2)}<em>${instTot.unit || '億元'}</em>` : `-`;
    const b03InstGrowth = document.getElementById("b03-inst-growth");
    if (b03InstGrowth) {
      b03InstGrowth.innerHTML = `
        <span class="${semCls(instTot.yoy)}"><b>YoY</b>${fmtSign(instTot.yoy)}</span>
        <span class="${semCls(instTot.mom)}"><b>MoM</b>${fmtSign(instTot.mom)}</span>
      `;
    }
    const b03InstSegSgl = document.getElementById("b03-inst-seg-sgl");
    if (b03InstSegSgl) {
      b03InstSegSgl.style.width = isValidNum(instSgl.share) ? `${instSgl.share}%` : `0%`;
      b03InstSegSgl.title = isValidNum(instSgl.share) ? `單筆分期: ${instSgl.share}% (${fmtNum(instSgl.amount, 2)} ${instSgl.unit || '億元'})` : `單筆分期: -`;
    }
    const b03InstSegBil = document.getElementById("b03-inst-seg-bil");
    if (b03InstSegBil) {
      b03InstSegBil.style.width = isValidNum(instBil.share) ? `${instBil.share}%` : `0%`;
      b03InstSegBil.title = isValidNum(instBil.share) ? `帳單分期: ${instBil.share}% (${fmtNum(instBil.amount, 2)} ${instBil.unit || '億元'})` : `帳單分期: -`;
    }
    const b03InstSegMcht = document.getElementById("b03-inst-seg-mcht");
    if (b03InstSegMcht) {
      b03InstSegMcht.style.width = isValidNum(instMcht.share) ? `${instMcht.share}%` : `0%`;
      b03InstSegMcht.title = isValidNum(instMcht.share) ? `特店分期: ${instMcht.share}% (${fmtNum(instMcht.amount, 2)} ${instMcht.unit || '億元'})` : `特店分期: -`;
    }
    const b03InstSglPct = document.getElementById("b03-inst-sgl-pct");
    if (b03InstSglPct) b03InstSglPct.textContent = isValidNum(instSgl.share) ? `(${instSgl.share}%)` : `(-%)`;
    const b03InstSglVal = document.getElementById("b03-inst-sgl-val");
    if (b03InstSglVal) b03InstSglVal.innerHTML = isValidNum(instSgl.amount) ? `${fmtNum(instSgl.amount, 2)}<em>${instSgl.unit || '億元'}</em>` : `-`;
    const b03InstBilPct = document.getElementById("b03-inst-bil-pct");
    if (b03InstBilPct) b03InstBilPct.textContent = isValidNum(instBil.share) ? `(${instBil.share}%)` : `(-%)`;
    const b03InstBilVal = document.getElementById("b03-inst-bil-val");
    if (b03InstBilVal) b03InstBilVal.innerHTML = isValidNum(instBil.amount) ? `${fmtNum(instBil.amount, 2)}<em>${instBil.unit || '億元'}</em>` : `-`;
    const b03InstMchtPct = document.getElementById("b03-inst-mcht-pct");
    if (b03InstMchtPct) b03InstMchtPct.textContent = isValidNum(instMcht.share) ? `(${instMcht.share}%)` : `(-%)`;
    const b03InstMchtVal = document.getElementById("b03-inst-mcht-val");
    if (b03InstMchtVal) b03InstMchtVal.innerHTML = isValidNum(instMcht.amount) ? `${fmtNum(instMcht.amount, 2)}<em>${instMcht.unit || '億元'}</em>` : `-<em>億元</em>`;
    const b03InstFoot = document.getElementById("b03-inst-foot");
    if (b03InstFoot && instTot.split_foot) b03InstFoot.title = instTot.split_foot;

    // ---------------------------------------------------------
    // 4. 次要指標 (4 Cards)
    // ---------------------------------------------------------
    const appRate = kpi.auto_approve_rate || {};
    const ebill = kpi.ebill_card || {};
    const bonusSum = kpi.bonus_summary || {};

    const b03AppRateVal = document.getElementById("b03-app-rate-val");
    if (b03AppRateVal) b03AppRateVal.textContent = isValidNum(appRate.value) ? `${appRate.value}%` : `-`;
    const b03AppRateGrowth = document.getElementById("b03-app-rate-growth");
    if (b03AppRateGrowth) {
      b03AppRateGrowth.innerHTML = `
        <div style="display: flex; flex-direction: column; gap: 6px;">
          <div class="monthly-kpi-title">新戶</div>
          <div class="monthly-kpi-value" style="margin: 0;">${isValidNum(appRate.new_rate) ? fmtNum(appRate.new_rate, 2) + '%' : '-'}</div>
        </div>
        <div style="display: flex; flex-direction: column; gap: 6px; border-left: 1px solid #e4ebe8; padding-left: 16px;">
          <div class="monthly-kpi-title">舊戶</div>
          <div class="monthly-kpi-value" style="margin: 0;">${isValidNum(appRate.old_rate) ? fmtNum(appRate.old_rate, 2) + '%' : '-'}</div>
        </div>
      `;
    }
    const b03AppRateNote = document.getElementById("b03-app-rate-note");
    if (b03AppRateNote) b03AppRateNote.textContent = `全行自動審查率 ${isValidNum(appRate.review_rate) ? appRate.review_rate + '%' : '-'}`;

    const b03EbillVal = document.getElementById("b03-ebill-val");
    if (b03EbillVal) b03EbillVal.textContent = isValidNum(ebill.value) ? `${fmtNum(ebill.value, 2)}%` : `-`;
    const b03EbillGrowth = document.getElementById("b03-ebill-growth");
    if (b03EbillGrowth) {
      b03EbillGrowth.innerHTML = `
        <span class="number-positive"><b>總量</b>${isValidNum(ebill.total) ? fmtNum(ebill.total, 2) + '萬份' : '-'}</span>
      `;
    }
    const b03EbillNote = document.getElementById("b03-ebill-note");
    if (b03EbillNote) {
      b03EbillNote.textContent = `紙本帳單 YoY ${fmtSign(ebill.paper_yoy)}`;
      b03EbillNote.title = `紙本帳單 YoY ${fmtSign(ebill.paper_yoy)}`;
    }

    const b03BonusRateVal = document.getElementById("b03-bonus-rate-val");
    if (b03BonusRateVal) b03BonusRateVal.textContent = isValidNum(bonusSum.redeem_rate) ? `${fmtNum(bonusSum.redeem_rate, 2)}%` : `-`;
    const b03BonusRateGrowth = document.getElementById("b03-bonus-rate-growth");
    if (b03BonusRateGrowth) {
      b03BonusRateGrowth.innerHTML = `
        <span class="number-positive"><b>新增</b>${isValidNum(bonusSum.grant_month) ? fmtNum(bonusSum.grant_month, 2) + '百萬點' : '-'}</span>
        <span class="number-positive"><b>兌換</b>${isValidNum(bonusSum.redeem_month) ? fmtNum(bonusSum.redeem_month, 2) + '百萬點' : '-'}</span>
      `;
    }
    const b03BonusRateNote = document.getElementById("b03-bonus-rate-note");
    if (b03BonusRateNote) {
      b03BonusRateNote.textContent = `兌換量 YoY ${fmtSign(bonusSum.redeem_yoy)}`;
      b03BonusRateNote.title = `兌換量 YoY ${fmtSign(bonusSum.redeem_yoy)}`;
    }

    const b03BonusBalVal = document.getElementById("b03-bonus-bal-val");
    if (b03BonusBalVal) b03BonusBalVal.innerHTML = isValidNum(bonusSum.balance) ? `${fmtNum(bonusSum.balance, 2)}<em>百萬點</em>` : `-`;
    const b03BonusBalGrowth = document.getElementById("b03-bonus-bal-growth");
    if (b03BonusBalGrowth) b03BonusBalGrowth.innerHTML = `<span class="${semCls(bonusSum.balance_yoy)}"><b>YoY</b>${fmtSign(bonusSum.balance_yoy)}</span>`;
    const b03BonusBalNote = document.getElementById("b03-bonus-bal-note");
    if (b03BonusBalNote) {
      b03BonusBalNote.textContent = `流通未兌負債約 ${isValidNum(bonusSum.liability) ? fmtNum(bonusSum.liability, 2) : '-'} 億元`;
      b03BonusBalNote.title = `流通未兌負債約 ${isValidNum(bonusSum.liability) ? fmtNum(bonusSum.liability, 2) : '-'} 億元`;
    }

    const intInc = kpi.interest_income || {};
    const instInt = intInc.installment || {};
    const revInt = intInc.revolving || {};
    const b03InterestGrowth = document.getElementById("b03-interest-growth");
    if (b03InterestGrowth) {
      b03InterestGrowth.innerHTML = `
        <div style="display: flex; flex-direction: column; gap: 4px;">
          <div class="monthly-kpi-title">分期利息</div>
          <div class="monthly-kpi-value" style="margin: 0; font-size: 26px;">${isValidNum(instInt.value) ? fmtNum(instInt.value, 2) : '-'}<em>${instInt.unit || '億元'}</em></div>
          <div style="display: flex; gap: 8px; font-size: 11.5px; font-weight: 800; margin-top: 2px; white-space: nowrap;">
            <span class="${semCls(instInt.yoy)}"><b>YoY</b>${fmtSign(instInt.yoy)}</span>
            <span class="${semCls(instInt.mom)}"><b>MoM</b>${fmtSign(instInt.mom)}</span>
          </div>
        </div>
        <div style="display: flex; flex-direction: column; gap: 4px; border-left: 1px solid #e4ebe8; padding-left: 14px;">
          <div class="monthly-kpi-title">循環息</div>
          <div class="monthly-kpi-value" style="margin: 0; font-size: 26px;">${isValidNum(revInt.value) ? fmtNum(revInt.value, 2) : '-'}<em>${revInt.unit || '億元'}</em></div>
          <div style="display: flex; gap: 8px; font-size: 11.5px; font-weight: 800; margin-top: 2px; white-space: nowrap;">
            <span class="${semCls(revInt.yoy)}"><b>YoY</b>${fmtSign(revInt.yoy)}</span>
            <span class="${semCls(revInt.mom)}"><b>MoM</b>${fmtSign(revInt.mom)}</span>
          </div>
        </div>
      `;
    }

    // ---------------------------------------------------------
    // 5. 帳單中心 (Cockpit & Tab 1)
    // ---------------------------------------------------------
    const totBills = billCenter.total_bills || {};
    const overallE = billCenter.overall_erate || {};
    const deliv = billCenter.delivery_rate || {};
    const green = billCenter.green_saving || {};
    const trCard = billCenter.track_card || {};
    const trBank = billCenter.track_bank || {};
    const trNotif = billCenter.track_notif || {};

    // Cockpit billing track
    const c00BillTag = document.getElementById("c00-iss-bill-tag");
    if (c00BillTag) c00BillTag.textContent = isValidNum(overallE.value) ? `電子率 ${overallE.value}%` : `-`;

    const c00BillCardHead = document.getElementById("c00-iss-bill-card-head");
    if (c00BillCardHead) {
      const tot = Number(totBills.value) || 0;
      const cardVal = Number(trCard.value) || 0;
      const cardShare = tot > 0 ? ((cardVal / tot) * 100).toFixed(1) : '-';
      c00BillCardHead.textContent = `${isValidNum(trCard.value) ? fmtNum(trCard.value, 2) + ' 萬份' : '-'} (佔 ${cardShare}%)`;
    }
    const c00BillCardSegDig = document.getElementById("c00-iss-bill-card-seg-dig");
    if (c00BillCardSegDig) c00BillCardSegDig.style.width = isValidNum(trCard.share) ? `${trCard.share}%` : `0%`;
    const c00BillCardSegPhy = document.getElementById("c00-iss-bill-card-seg-phy");
    if (c00BillCardSegPhy) c00BillCardSegPhy.style.width = isValidNum(trCard.share) ? `${(100 - trCard.share).toFixed(1)}%` : `0%`;
    const c00BillCardDigPct = document.getElementById("c00-iss-bill-card-dig-pct");
    if (c00BillCardDigPct) c00BillCardDigPct.textContent = isValidNum(trCard.share) ? `(${Math.round(trCard.share)}%)` : `(-%)`;
    const c00BillCardDigVal = document.getElementById("c00-iss-bill-card-dig-val");
    if (c00BillCardDigVal) c00BillCardDigVal.innerHTML = isValidNum(trCard.col1) ? `${fmtNum(trCard.col1, 2)}<em>萬份</em>` : `-`;
    const c00BillCardPhyPct = document.getElementById("c00-iss-bill-card-phy-pct");
    if (c00BillCardPhyPct) c00BillCardPhyPct.textContent = isValidNum(trCard.share) ? `(${Math.round(100 - trCard.share)}%)` : `(-%)`;
    const c00BillCardPhyVal = document.getElementById("c00-iss-bill-card-phy-val");
    if (c00BillCardPhyVal) c00BillCardPhyVal.innerHTML = isValidNum(trCard.col2) ? `${fmtNum(trCard.col2, 2)}<em>萬份</em>` : `-`;

    const c00BillBankHead = document.getElementById("c00-iss-bill-bank-head");
    if (c00BillBankHead) {
      const tot = Number(totBills.value) || 0;
      const bankVal = Number(trBank.value) || 0;
      const bankShare = tot > 0 ? ((bankVal / tot) * 100).toFixed(1) : '-';
      c00BillBankHead.textContent = `${isValidNum(trBank.value) ? fmtNum(trBank.value, 2) + ' 萬份' : '-'} (佔 ${bankShare}%)`;
    }
    const c00BillBankSegDig = document.getElementById("c00-iss-bill-bank-seg-dig");
    if (c00BillBankSegDig) c00BillBankSegDig.style.width = isValidNum(trBank.share) ? `${trBank.share}%` : `0%`;
    const c00BillBankSegPhy = document.getElementById("c00-iss-bill-bank-seg-phy");
    if (c00BillBankSegPhy) c00BillBankSegPhy.style.width = isValidNum(trBank.share) ? `${(100 - trBank.share).toFixed(1)}%` : `0%`;
    const c00BillBankDigPct = document.getElementById("c00-iss-bill-bank-dig-pct");
    if (c00BillBankDigPct) c00BillBankDigPct.textContent = isValidNum(trBank.share) ? `(${Math.round(trBank.share)}%)` : `(-%)`;
    const c00BillBankDigVal = document.getElementById("c00-iss-bill-bank-dig-val");
    if (c00BillBankDigVal) c00BillBankDigVal.innerHTML = isValidNum(trBank.col1) ? `${fmtNum(trBank.col1, 2)}<em>萬份</em>` : `-`;
    const c00BillBankPhyPct = document.getElementById("c00-iss-bill-bank-phy-pct");
    if (c00BillBankPhyPct) c00BillBankPhyPct.textContent = isValidNum(trBank.share) ? `(${Math.round(100 - trBank.share)}%)` : `(-%)`;
    const c00BillBankPhyVal = document.getElementById("c00-iss-bill-bank-phy-val");
    if (c00BillBankPhyVal) c00BillBankPhyVal.innerHTML = isValidNum(trBank.col2) ? `${fmtNum(trBank.col2, 2)}<em>萬份</em>` : `-`;

    // Tab 1 KPI Cards
    const b03BillTotVal = document.getElementById("b03-bill-tot-val");
    if (b03BillTotVal) b03BillTotVal.innerHTML = isValidNum(totBills.value) ? `${fmtNum(totBills.value, 2)} <em style="font-size:13px; font-style:normal; font-weight:700;">${totBills.unit || '萬份'}</em>` : `-`;
    const b03BillTotGrowth = document.getElementById("b03-bill-tot-growth");
    if (b03BillTotGrowth) b03BillTotGrowth.innerHTML = `<span class="${semCls(totBills.yoy)}">YoY ${fmtSign(totBills.yoy)}</span>`;

    const b03BillErateVal = document.getElementById("b03-bill-erate-val");
    if (b03BillErateVal) b03BillErateVal.innerHTML = isValidNum(overallE.value) ? `${fmtNum(overallE.value, 2)}<em style="font-size:13px; font-style:normal; font-weight:700;">%</em>` : `-`;
    const b03BillErateGrowth = document.getElementById("b03-bill-erate-growth");
    if (b03BillErateGrowth) {
      b03BillErateGrowth.innerHTML = `<span class="${semCls(overallE.yoy)}">YoY ${fmtSign(overallE.yoy)}</span> <span class="c-hint" id="b03-bill-erate-hint" style="color:#64748b;">(電子 ${isValidNum(totBills.col1) ? fmtNum(totBills.col1, 2) + '萬份' : '-'})</span>`;
    }

    const b03BillDelivVal = document.getElementById("b03-bill-deliv-val");
    if (b03BillDelivVal) b03BillDelivVal.innerHTML = isValidNum(deliv.value) ? `${fmtNum(deliv.value, 2)}<em style="font-size:13px; font-style:normal; font-weight:700;">%</em>` : `-`;
    const b03BillDelivPos = document.getElementById("b03-bill-deliv-pos");
    if (b03BillDelivPos) {
      b03BillDelivPos.textContent = isValidNum(deliv.col1) ? `${fmtNum(deliv.col1, 2)}%` : `-`;
    }
    const b03BillDelivHint = document.getElementById("b03-bill-deliv-hint");
    if (b03BillDelivHint) {
      b03BillDelivHint.textContent = isValidNum(deliv.col2) ? `${fmtNum(deliv.col2, 2)}%` : `-`;
    }
    const b03BillGreenVal = document.getElementById("b03-bill-green-val");
    if (b03BillGreenVal) b03BillGreenVal.innerHTML = isValidNum(green.value) ? `${Number(green.value).toLocaleString()} <em style="font-size:13px; font-style:normal; font-weight:700;">${green.unit || '萬元'}</em>` : `-`;

    // Tab 1 Dual Tracks
    const b03BillCardTot = document.getElementById("b03-bill-card-tot");
    if (b03BillCardTot) b03BillCardTot.innerHTML = isValidNum(trCard.value) ? `${fmtNum(trCard.value, 2)} <em style="font-size:14px; font-style:normal; font-weight:700;">${trCard.unit || '萬份'}</em>` : `-`;
    const b03BillCardErate = document.getElementById("b03-bill-card-erate");
    if (b03BillCardErate) b03BillCardErate.textContent = isValidNum(trCard.share) ? `${trCard.share}%` : `-`;
    const b03BillCardSegElec = document.getElementById("b03-bill-card-seg-elec");
    if (b03BillCardSegElec) {
      b03BillCardSegElec.style.width = isValidNum(trCard.share) ? `${trCard.share}%` : `0%`;
      b03BillCardSegElec.title = isValidNum(trCard.share) ? `電子帳單: ${trCard.share}% (${isValidNum(trCard.col1) ? fmtNum(trCard.col1, 2) + '萬份' : '-'})` : `電子帳單: -`;
    }
    const b03BillCardSegPapr = document.getElementById("b03-bill-card-seg-papr");
    if (b03BillCardSegPapr) {
      const paprShare = isValidNum(trCard.share) ? (100 - trCard.share).toFixed(1) : 0;
      b03BillCardSegPapr.style.width = `${paprShare}%`;
      b03BillCardSegPapr.title = isValidNum(trCard.share) ? `紙本帳單: ${paprShare}% (${isValidNum(trCard.col2) ? fmtNum(trCard.col2, 2) + '萬份' : '-'})` : `紙本帳單: -`;
    }
    const b03BillCardLblElec = document.getElementById("b03-bill-card-lbl-elec");
    if (b03BillCardLblElec) b03BillCardLblElec.textContent = `● 電子帳單 ${isValidNum(trCard.share) ? trCard.share + '%' : '-'} (${isValidNum(trCard.col1) ? fmtNum(trCard.col1, 2) + ' 萬份' : '-'})`;
    const b03BillCardLblPapr = document.getElementById("b03-bill-card-lbl-papr");
    if (b03BillCardLblPapr) {
      const paprShare = isValidNum(trCard.share) ? (100 - trCard.share).toFixed(1) : '-';
      b03BillCardLblPapr.textContent = `● 紙本帳單 ${paprShare}% (${isValidNum(trCard.col2) ? fmtNum(trCard.col2, 2) + ' 萬份' : '-'})`;
    }

    const b03BillBankTot = document.getElementById("b03-bill-bank-tot");
    if (b03BillBankTot) b03BillBankTot.innerHTML = isValidNum(trBank.value) ? `${fmtNum(trBank.value, 2)} <em style="font-size:14px; font-style:normal; font-weight:700;">${trBank.unit || '萬份'}</em>` : `-`;
    const b03BillBankErate = document.getElementById("b03-bill-bank-erate");
    if (b03BillBankErate) b03BillBankErate.textContent = isValidNum(trBank.share) ? `${trBank.share}%` : `-`;
    const b03BillBankSegElec = document.getElementById("b03-bill-bank-seg-elec");
    if (b03BillBankSegElec) {
      b03BillBankSegElec.style.width = isValidNum(trBank.share) ? `${trBank.share}%` : `0%`;
      b03BillBankSegElec.title = isValidNum(trBank.share) ? `電子帳單: ${trBank.share}% (${isValidNum(trBank.col1) ? fmtNum(trBank.col1, 2) + '萬份' : '-'})` : `電子帳單: -`;
    }
    const b03BillBankSegPapr = document.getElementById("b03-bill-bank-seg-papr");
    if (b03BillBankSegPapr) {
      const paprShare = isValidNum(trBank.share) ? (100 - trBank.share).toFixed(1) : 0;
      b03BillBankSegPapr.style.width = `${paprShare}%`;
      b03BillBankSegPapr.title = isValidNum(trBank.share) ? `紙本帳單: ${paprShare}% (${isValidNum(trBank.col2) ? fmtNum(trBank.col2, 2) + '萬份' : '-'})` : `紙本帳單: -`;
    }
    const b03BillBankLblElec = document.getElementById("b03-bill-bank-lbl-elec");
    if (b03BillBankLblElec) b03BillBankLblElec.textContent = `● 電子帳單 ${isValidNum(trBank.share) ? trBank.share + '%' : '-'} (${isValidNum(trBank.col1) ? fmtNum(trBank.col1, 2) + ' 萬份' : '-'})`;
    const b03BillBankLblPapr = document.getElementById("b03-bill-bank-lbl-papr");
    if (b03BillBankLblPapr) {
      const paprShare = isValidNum(trBank.share) ? (100 - trBank.share).toFixed(1) : '-';
      b03BillBankLblPapr.textContent = `● 紙本帳單 ${paprShare}% (${isValidNum(trBank.col2) ? fmtNum(trBank.col2, 2) + ' 萬份' : '-'})`;
    }

    const b03BillNotifTot = document.getElementById("b03-bill-notif-tot");
    if (b03BillNotifTot) b03BillNotifTot.innerHTML = isValidNum(trNotif.value) ? `${fmtNum(trNotif.value, 2)} <em style="font-size:14px; font-style:normal; font-weight:700;">${trNotif.unit || '萬份'}</em>` : `-`;
    const b03BillNotifErate = document.getElementById("b03-bill-notif-erate");
    if (b03BillNotifErate) b03BillNotifErate.textContent = isValidNum(trNotif.share) ? `${trNotif.share}%` : `-`;
    const b03BillNotifSegElec = document.getElementById("b03-bill-notif-seg-elec");
    if (b03BillNotifSegElec) {
      b03BillNotifSegElec.style.width = isValidNum(trNotif.share) ? `${trNotif.share}%` : `0%`;
      b03BillNotifSegElec.title = isValidNum(trNotif.share) ? `電子帳單: ${trNotif.share}% (${isValidNum(trNotif.col1) ? fmtNum(trNotif.col1, 2) + '萬份' : '-'})` : `電子帳單: -`;
    }
    const b03BillNotifSegPapr = document.getElementById("b03-bill-notif-seg-papr");
    if (b03BillNotifSegPapr) {
      const paprShare = isValidNum(trNotif.share) ? (100 - trNotif.share).toFixed(1) : 0;
      b03BillNotifSegPapr.style.width = `${paprShare}%`;
      b03BillNotifSegPapr.title = isValidNum(trNotif.share) ? `紙本帳單: ${paprShare}% (${isValidNum(trNotif.col2) ? fmtNum(trNotif.col2, 2) + '萬份' : '-'})` : `紙本帳單: -`;
    }
    const b03BillNotifLblElec = document.getElementById("b03-bill-notif-lbl-elec");
    if (b03BillNotifLblElec) b03BillNotifLblElec.textContent = `● 電子帳單 ${isValidNum(trNotif.share) ? trNotif.share + '%' : '-'} (${isValidNum(trNotif.col1) ? fmtNum(trNotif.col1, 2) + ' 萬份' : '-'})`;
    const b03BillNotifLblPapr = document.getElementById("b03-bill-notif-lbl-papr");
    if (b03BillNotifLblPapr) {
      const paprShare = isValidNum(trNotif.share) ? (100 - trNotif.share).toFixed(1) : '-';
      b03BillNotifLblPapr.textContent = `● 紙本帳單 ${paprShare}% (${isValidNum(trNotif.col2) ? fmtNum(trNotif.col2, 2) + ' 萬份' : '-'})`;
    }

    // ---------------------------------------------------------
    // 6. 小樹點經營與瀑布圖 (Cockpit & Tab 2)
    // ---------------------------------------------------------
    const wf = bonus.waterfall || [];
    const c00BonusTag = document.getElementById("c00-iss-bonus-tag");
    if (c00BonusTag) c00BonusTag.textContent = isValidNum(bonus.net_increase) ? `淨增存量 ${fmtSign(bonus.net_increase, " 百萬點")}` : `-`;
    const b03BonusNetPill = document.getElementById("b03-bonus-net-pill");
    if (b03BonusNetPill) b03BonusNetPill.textContent = `單位: 百萬點`;
    const b03BonusRedeemPill = document.getElementById("b03-bonus-redeem-pill");
    if (b03BonusRedeemPill) b03BonusRedeemPill.textContent = `當月兌換 ${isValidNum(bonus.total_redeem) ? fmtNum(bonus.total_redeem, 2) + ' 百萬點' : '-'}`;

    // 7 Waterfall Bars (03 發卡業務維持 7 柱不變)
    for (let i = 0; i < 7; i++) {
      const item = wf[i];
      if (!item) continue;
      const b03El = document.getElementById(`b03-wf-bar${i + 1}-val`);
      let valText = "-";
      if (isValidNum(item.value)) {
        if (i === 2 || i === 3) {
          valText = fmtSign(item.value, "");
        } else if (i === 4 || i === 5) {
          valText = `-${fmtNum(Math.abs(item.value), 2)}`;
        } else {
          valText = `${fmtNum(item.value, 2)}`;
        }
      }
      if (b03El) b03El.textContent = valText;
    }

    // 00block: 5 Waterfall Bars (總覽精簡：去年同月、上月餘額、本月增加(新增+贈送)、本月減少(兌換+失效)、本月餘額)
    const c00Wf1 = document.getElementById("c00-wf-bar1-val");
    if (c00Wf1 && wf[0] && isValidNum(wf[0].value)) {
      c00Wf1.textContent = fmtNum(wf[0].value, 2);
    }
    const c00Wf2 = document.getElementById("c00-wf-bar2-val");
    if (c00Wf2 && wf[1] && isValidNum(wf[1].value)) {
      c00Wf2.textContent = fmtNum(wf[1].value, 2);
    }
    const c00WfInc = document.getElementById("c00-wf-inc-val") || document.getElementById("c00-wf-bar3-val");
    if (c00WfInc) {
      const incVal = (wf[2] && isValidNum(wf[2].value) ? wf[2].value : 0) + (wf[3] && isValidNum(wf[3].value) ? wf[3].value : 0);
      c00WfInc.textContent = fmtSign(incVal, "");
    }
    const c00WfDec = document.getElementById("c00-wf-dec-val");
    if (c00WfDec) {
      const decVal = (wf[4] && isValidNum(wf[4].value) ? Math.abs(wf[4].value) : 0) + (wf[5] && isValidNum(wf[5].value) ? Math.abs(wf[5].value) : 0);
      c00WfDec.textContent = `-${fmtNum(decVal, 2)}`;
    }
    const c00Wf7 = document.getElementById("c00-wf-bar7-val");
    if (c00Wf7 && wf[6] && isValidNum(wf[6].value)) {
      c00Wf7.textContent = fmtNum(wf[6].value, 2);
    }

    // 5 折抵通路排行動態渲染
    const channels = bonus.channels || [];
    const chContainer = document.getElementById("b03-bonus-channels-container");
    if (chContainer && channels.length > 0) {
      const bgColors = ["#eef2ff", "#eef2ff", "#f5f3ff", "#f5f3ff", "#f4f4f5"];
      const barColors = ["#4f46e5", "#6366f1", "#7c3aed", "#8b5cf6", "#a1a1aa"];
      const txtColors = ["#4f46e5", "#6366f1", "#7c3aed", "#8b5cf6", "#71717a"];
      chContainer.innerHTML = channels.map((ch, idx) => {
        const bCol = ch.color || barColors[idx % barColors.length];
        const tCol = (idx === 4 && bCol === "#a1a1aa") ? "#71717a" : bCol;
        return `
        <div style="display:grid; grid-template-columns: 110px 1fr 164px; align-items:center; gap:16px;">
          <span style="font-size:14px; font-weight:800; color:#1e293b; display:flex; align-items:center; gap:8px;">
            <span style="width:24px; height:24px; border-radius:5px; background:${bgColors[idx % bgColors.length]}; color:${tCol}; font-size:12px; font-weight:900; display:inline-flex; align-items:center; justify-content:center;">${idx + 1}</span>${ch.name}
          </span>
          <div style="height:15px; background:#eef2f6; border-radius:8px; overflow:hidden;">
            <div style="width:${isValidNum(ch.share) ? ch.share : 0}%; height:100%; background:${bCol}; border-radius:8px;"></div>
          </div>
          <div style="display:flex; justify-content:flex-end; align-items:baseline; text-align:right; font-variant-numeric:tabular-nums; white-space:nowrap;">
            <b style="font-size:15px; color:#1e293b; font-weight:900; text-align:right;">${isValidNum(ch.value) ? Number(ch.value).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ' + (ch.unit || '百萬點') : '-'}</b>
            <span style="font-size:13px; font-weight:800; color:${tCol}; display:inline-block; width:48px; text-align:right; margin-left:6px;">${isValidNum(ch.share) ? Number(ch.share).toFixed(1) + '%' : '-%'}</span>
          </div>
        </div>
      `;
      }).join("");
    }

    // ---------------------------------------------------------
    // 7. 3B TAB 0: 申辦自動徵審分析 (Sankey Flow)
    // ---------------------------------------------------------
    const s1Old = appFlow.stage1_old || {};
    const s1New = appFlow.stage1_new || {};
    const s2Hub = appFlow.stage2_hub || {};
    const s3Pass = appFlow.stage3_auto_pass || {};
    const s3Man = appFlow.stage3_manual || {};

    const b03Tab0OldVal = document.getElementById("b03-tab0-old-val");
    if (b03Tab0OldVal) b03Tab0OldVal.innerHTML = `${isValidNum(s1Old.value) ? Number(s1Old.value).toLocaleString() : '-'} <tspan font-size="10.5" font-weight="normal" fill="#667a76">件 (${isValidNum(s1Old.share) ? s1Old.share : '-'}%)</tspan>`;
    const b03Tab0OldAutoRate = document.getElementById("b03-tab0-old-auto-rate");
    if (b03Tab0OldAutoRate) {
      const oRate = isValidNum(s1Old.auto_rate) ? s1Old.auto_rate : (isValidNum(s2Hub.share) ? s2Hub.share : '-');
      b03Tab0OldAutoRate.textContent = `自動審查率 ${oRate}%`;
    }

    const b03Tab0NewVal = document.getElementById("b03-tab0-new-val");
    if (b03Tab0NewVal) b03Tab0NewVal.innerHTML = `${isValidNum(s1New.value) ? Number(s1New.value).toLocaleString() : '-'} <tspan font-size="10.5" font-weight="normal" fill="#667a76">件 (${isValidNum(s1New.share) ? s1New.share : '-'}%)</tspan>`;
    const b03Tab0NewAutoRate = document.getElementById("b03-tab0-new-auto-rate");
    if (b03Tab0NewAutoRate) {
      const nRate = isValidNum(s1New.auto_rate) ? s1New.auto_rate : (isValidNum(s2Hub.share) ? s2Hub.share : '-');
      b03Tab0NewAutoRate.textContent = `自動審查率 ${nRate}%`;
    }

    const b03Tab0HubVal = document.getElementById("b03-tab0-hub-val");
    if (b03Tab0HubVal) b03Tab0HubVal.innerHTML = `${isValidNum(s2Hub.value) ? Number(s2Hub.value).toLocaleString() : '-'} <tspan font-size="10" font-weight="normal" fill="#667a76">件 (${isValidNum(s2Hub.share) ? s2Hub.share : '-'}%)</tspan>`;

    const b03Tab0OldPassRate = document.getElementById("b03-tab0-old-pass-rate");
    if (b03Tab0OldPassRate) b03Tab0OldPassRate.textContent = `通過率 ${isValidNum(appRate.old_rate) ? appRate.old_rate + '%' : '-'}`;
    const b03Tab0OldPassVal = document.getElementById("b03-tab0-old-pass-val");
    if (b03Tab0OldPassVal) b03Tab0OldPassVal.textContent = `直接核准 ${isValidNum(s1Old.col1) ? Number(s1Old.col1).toLocaleString() : '-'} 件`;

    const b03Tab0NewPassRate = document.getElementById("b03-tab0-new-pass-rate");
    if (b03Tab0NewPassRate) b03Tab0NewPassRate.textContent = `通過率 ${isValidNum(appRate.new_rate) ? appRate.new_rate + '%' : '-'}`;
    const b03Tab0NewPassVal = document.getElementById("b03-tab0-new-pass-val");
    if (b03Tab0NewPassVal) b03Tab0NewPassVal.textContent = `直接核准 ${isValidNum(s1New.col1) ? Number(s1New.col1).toLocaleString() : '-'} 件`;

    const b03Tab0PassTotVal = document.getElementById("b03-tab0-pass-tot-val");
    if (b03Tab0PassTotVal) b03Tab0PassTotVal.innerHTML = `${isValidNum(s3Pass.value) ? Number(s3Pass.value).toLocaleString() : '-'} <tspan font-size="11" font-weight="normal" fill="#007a5e">件 (${isValidNum(s3Pass.share) ? s3Pass.share : '-'}%)</tspan>`;
    const b03Tab0PassSubVal = document.getElementById("b03-tab0-pass-sub-val");
    if (b03Tab0PassSubVal) b03Tab0PassSubVal.textContent = `舊戶 ${isValidNum(s3Pass.col1) ? Number(s3Pass.col1).toLocaleString() : '-'} ｜ 新戶 ${isValidNum(s3Pass.col2) ? Number(s3Pass.col2).toLocaleString() : '-'}`;

    const b03Tab0ManTotVal = document.getElementById("b03-tab0-man-tot-val");
    if (b03Tab0ManTotVal) b03Tab0ManTotVal.innerHTML = `${isValidNum(s3Man.value) ? Number(s3Man.value).toLocaleString() : '-'} <tspan font-size="11" font-weight="normal" fill="#9a6518">件 (${isValidNum(s3Man.share) ? s3Man.share : '-'}%)</tspan>`;

    // ---------------------------------------------------------
    // 8. 3B TAB 4: 分期產品結構分析 (雙橫向長條圖：分期金額與分期筆數分流)
    // ---------------------------------------------------------
    const prods = inst.products || [];
    const b03InstSvgWrapper = document.getElementById("b03-inst-svg-wrapper");
    if (b03InstSvgWrapper && prods.length >= 3) {
      b03InstSvgWrapper.style.display = "grid";
      b03InstSvgWrapper.style.gridTemplateColumns = "repeat(2, 1fr)";
      b03InstSvgWrapper.style.gap = "14px";

      const p3 = prods[3] || { name: "特店分期", amount: null, prev_month: null, mom: null, count: null, prev_count: null, count_mom: null };
      const instProducts = [
        {
          pNum: 1,
          name: prods[0]?.name || "授權單筆分期",
          amount: prods[0]?.amount,
          prev_amount: prods[0]?.prev_month,
          amount_mom: prods[0]?.mom,
          count: prods[0]?.count,
          prev_count: prods[0]?.prev_count,
          count_mom: prods[0]?.count_mom,
          share: prods[0]?.share,
          yoy: prods[0]?.yoy,
          avg_ticket: prods[0]?.avg_ticket
        },
        {
          pNum: 2,
          name: prods[1]?.name || "請款單筆分期",
          amount: prods[1]?.amount,
          prev_amount: prods[1]?.prev_month,
          amount_mom: prods[1]?.mom,
          count: prods[1]?.count,
          prev_count: prods[1]?.prev_count,
          count_mom: prods[1]?.count_mom,
          share: prods[1]?.share,
          yoy: prods[1]?.yoy,
          avg_ticket: prods[1]?.avg_ticket
        },
        {
          pNum: 3,
          name: prods[2]?.name || "帳單分期",
          amount: prods[2]?.amount,
          prev_amount: prods[2]?.prev_month,
          amount_mom: prods[2]?.mom,
          count: prods[2]?.count,
          prev_count: prods[2]?.prev_count,
          count_mom: prods[2]?.count_mom,
          share: prods[2]?.share,
          yoy: prods[2]?.yoy,
          avg_ticket: prods[2]?.avg_ticket
        },
        {
          pNum: 4,
          name: p3?.name || "特店分期",
          amount: p3?.amount,
          prev_amount: p3?.prev_month,
          amount_mom: p3?.mom,
          count: p3?.count,
          prev_count: p3?.prev_count,
          count_mom: p3?.count_mom,
          share: p3?.share,
          yoy: p3?.yoy,
          avg_ticket: p3?.avg_ticket
        }
      ];

      // 計算尺度最大值 (Max)，保留適當視覺呼吸空間
      const allAmts = instProducts.flatMap(p => [Number(p.amount) || 0, Number(p.prev_amount) || 0]);
      const maxAmt = Math.max(...allAmts, 0.1) * 1.05;

      const allCnts = instProducts.flatMap(p => [Number(p.count) || 0, Number(p.prev_count) || 0]);
      const maxCnt = Math.max(...allCnts, 0.1) * 1.05;

      const calcBarW = (val, max) => {
        if (!isValidNum(val) || Number(val) <= 0) return 0;
        return Math.max(((Number(val) / max) * 100), 12).toFixed(1);
      };

      // 1. 左側圖表：分期金額 (單位：億元 ｜ 本月 vs 前月)
      const amtRowsHtml = instProducts.map(p => {
        const currW = calcBarW(p.amount, maxAmt);
        const prevW = calcBarW(p.prev_amount, maxAmt);
        const momVal = p.amount_mom;
        const momClass = semCls(momVal);
        const momText = isValidNum(momVal) ? fmtSign(momVal) : "-";
        const currTxt = isValidNum(p.amount) ? fmtNum(p.amount, 2) : "-";
        const prevTxt = isValidNum(p.prev_amount) ? fmtNum(p.prev_amount, 2) : "-";

        return `
          <div class="acq-channel-row">
            <span id="b03-inst-p${p.pNum}-avg" style="display:none;">平均客單：${isValidNum(p.avg_ticket) ? '$' + Number(Math.round(p.avg_ticket)).toLocaleString() : '-'}</span>
            <span id="b03-inst-p${p.pNum}-sub" style="display:none;">佔 ${fmtNum(p.share, 1)}% ｜ YoY ${fmtSign(p.yoy)}</span>
            <div class="acq-channel-name">${p.name}</div>
            <div class="acq-channel-bars">
              <div class="acq-bar-line" title="本月：${currTxt} 億元">
                <span class="acq-bar-subtag">本月</span>
                <div class="acq-bar-track">
                  ${currW > 0 ? `
                    <div class="acq-bar-fill curr-amt" style="width: ${currW}%;">
                      <span id="b03-inst-p${p.pNum}-amt">${currTxt}</span>
                    </div>
                  ` : `
                    <div class="acq-bar-fill curr-amt zero-val" style="width: 0%;"></div>
                    <span id="b03-inst-p${p.pNum}-amt" class="acq-bar-dash">-</span>
                  `}
                </div>
              </div>
              <div class="acq-bar-line" title="前月：${prevTxt} 億元">
                <span class="acq-bar-subtag">前月</span>
                <div class="acq-bar-track">
                  ${prevW > 0 ? `
                    <div class="acq-bar-fill prev" style="width: ${prevW}%;">
                      <span>${prevTxt}</span>
                    </div>
                  ` : `
                    <div class="acq-bar-fill prev zero-val" style="width: 0%;"></div>
                    <span class="acq-bar-dash">-</span>
                  `}
                </div>
              </div>
            </div>
            <div class="acq-channel-mom ${momClass}">${momText}</div>
          </div>
        `;
      }).join("");

      const leftCardHtml = `
        <div class="chart-box acq-channel-card">
          <div class="chart-box-header">
            <div>
              <h3 style="color:var(--blue-dark);">分期金額</h3>
            </div>
            <div style="display:flex; align-items:center; gap:12px; font-size:11px; font-weight:800; color:#68767b;">
              <div style="display:flex; align-items:center; gap:8px;">
                <span style="display:inline-flex; align-items:center; gap:4px;"><i style="width:9px; height:9px; border-radius:2px; background:#003b5c; display:inline-block;"></i> 本月</span>
                <span style="display:inline-flex; align-items:center; gap:4px;"><i style="width:9px; height:9px; border-radius:2px; background:#94a3b8; display:inline-block;"></i> 前月</span>
              </div>
              <span>單位：億元 ｜ MoM</span>
            </div>
          </div>
          <div class="acq-channel-rows">
            ${amtRowsHtml}
          </div>
        </div>
      `;

      // 2. 右側圖表：分期筆數 (單位：萬筆 ｜ 本月 vs 前月)
      const cntRowsHtml = instProducts.map(p => {
        const currW = calcBarW(p.count, maxCnt);
        const prevW = calcBarW(p.prev_count, maxCnt);
        const momVal = p.count_mom;
        const momClass = semCls(momVal);
        const momText = isValidNum(momVal) ? fmtSign(momVal) : "-";
        const currTxt = isValidNum(p.count) ? fmtNum(p.count, 2) : "-";
        const prevTxt = isValidNum(p.prev_count) ? fmtNum(p.prev_count, 2) : "-";

        return `
          <div class="acq-channel-row">
            <div class="acq-channel-name">${p.name}</div>
            <div class="acq-channel-bars">
              <div class="acq-bar-line" title="本月：${currTxt} 萬筆">
                <span class="acq-bar-subtag">本月</span>
                <div class="acq-bar-track">
                  ${currW > 0 ? `
                    <div class="acq-bar-fill curr-cnt" style="width: ${currW}%;">
                      <span id="b03-inst-p${p.pNum}-cnt">${currTxt}</span>
                    </div>
                  ` : `
                    <div class="acq-bar-fill curr-cnt zero-val" style="width: 0%;"></div>
                    <span id="b03-inst-p${p.pNum}-cnt" class="acq-bar-dash">-</span>
                  `}
                </div>
              </div>
              <div class="acq-bar-line" title="前月：${prevTxt} 萬筆">
                <span class="acq-bar-subtag">前月</span>
                <div class="acq-bar-track">
                  ${prevW > 0 ? `
                    <div class="acq-bar-fill prev" style="width: ${prevW}%;">
                      <span>${prevTxt}</span>
                    </div>
                  ` : `
                    <div class="acq-bar-fill prev zero-val" style="width: 0%;"></div>
                    <span class="acq-bar-dash">-</span>
                  `}
                </div>
              </div>
            </div>
            <div class="acq-channel-mom ${momClass}">${momText}</div>
          </div>
        `;
      }).join("");

      const rightCardHtml = `
        <div class="chart-box acq-channel-card">
          <div class="chart-box-header">
            <div>
              <h3 style="color:var(--blue-dark);">分期筆數</h3>
            </div>
            <div style="display:flex; align-items:center; gap:12px; font-size:11px; font-weight:800; color:#68767b;">
              <div style="display:flex; align-items:center; gap:8px;">
                <span style="display:inline-flex; align-items:center; gap:4px;"><i style="width:9px; height:9px; border-radius:2px; background:#009e73; display:inline-block;"></i> 本月</span>
                <span style="display:inline-flex; align-items:center; gap:4px;"><i style="width:9px; height:9px; border-radius:2px; background:#94a3b8; display:inline-block;"></i> 前月</span>
              </div>
              <span>單位：萬筆 ｜ MoM</span>
            </div>
          </div>
          <div class="acq-channel-rows">
            ${cntRowsHtml}
          </div>
        </div>
      `;

      b03InstSvgWrapper.innerHTML = leftCardHtml + rightCardHtml;
    }

    // ---------------------------------------------------------
    // 9. 3B TAB 4: 催收與呆帳分析
    // ---------------------------------------------------------
    const m1Def = colLoss.m1_defense || {};
    const colEntry = m1Def.col_m1_entry || {};
    const colCure = m1Def.col_cure_rate || {};
    const colM2 = m1Def.col_to_m2 || {};

    const b03ColM1Pill = document.getElementById("b03-col-m1-pill");
    if (b03ColM1Pill) {
      if (isValidNum(colEntry.count) || isValidNum(colEntry.value)) {
        b03ColM1Pill.textContent = `當期進案 ${isValidNum(colEntry.count) ? Number(colEntry.count).toLocaleString() + ' 戶' : ''} (${isValidNum(colEntry.value) ? fmtNum(colEntry.value, 2) + ' ' + (colEntry.unit || '億元') : ''})`.replace(/\(\s*\)/, '').trim();
      } else {
        b03ColM1Pill.textContent = '當期進案 -';
      }
    }
    const b03ColCureRate = document.getElementById("b03-col-cure-rate");
    if (b03ColCureRate) b03ColCureRate.textContent = isValidNum(colCure.value) ? `${colCure.value}%` : `-`;
    const b03ColCureDetail = document.getElementById("b03-col-cure-detail");
    if (b03ColCureDetail) {
      if (isValidNum(colCure.count) || isValidNum(colCure.value)) {
        b03ColCureDetail.textContent = `成功繳款回復正常：${isValidNum(colCure.count) ? Number(colCure.count).toLocaleString() + ' 戶' : ''} ${isValidNum(colCure.value) ? '(' + colCure.value + '%)' : ''}`.trim();
      } else {
        b03ColCureDetail.textContent = '成功繳款回復正常：-';
      }
    }
    const b03ColM2Detail = document.getElementById("b03-col-m2-detail");
    if (b03ColM2Detail) {
      if (isValidNum(colM2.value) || isValidNum(colM2.count)) {
        b03ColM2Detail.textContent = `${isValidNum(colM2.value) ? colM2.value + '%' : '-'} (${isValidNum(colM2.count) ? Number(colM2.count).toLocaleString() + ' 戶' : ''})`.replace(/\(\s*\)/, '').trim();
      } else {
        b03ColM2Detail.textContent = '-';
      }
    }

    // Aging Buckets
    const buckets = colLoss.aging_buckets || [];
    if (buckets.length >= 3) {
      const bk0 = buckets[0];
      const bk1 = buckets[1];
      const bk2 = buckets[2];

      const b03AgingM1Lbl = document.getElementById("b03-aging-m1-lbl");
      if (b03AgingM1Lbl) {
        if (isValidNum(bk0.amount) || isValidNum(bk0.count)) {
          b03AgingM1Lbl.textContent = `${bk0.name || 'M1 (1–30天)'} ${isValidNum(bk0.amount) ? fmtNum(bk0.amount, 2) + ' ' + (bk0.unit || '億元') : ''} (${isValidNum(bk0.count) ? Number(bk0.count).toLocaleString() + ' 戶' : ''})`.replace(/\(\s*\)/, '').trim();
        } else {
          b03AgingM1Lbl.textContent = `${bk0.name || 'M1 (1–30天)'} -`;
        }
      }
      const b03AgingM1Rec = document.getElementById("b03-aging-m1-rec");
      if (b03AgingM1Rec) b03AgingM1Rec.textContent = isValidNum(bk0.rec_ratio) ? `${bk0.rec_ratio}% 應收` : `-`;
      const b03AgingM1Bar = document.getElementById("b03-aging-m1-bar");
      if (b03AgingM1Bar) b03AgingM1Bar.style.width = isValidNum(bk0.share) ? `${bk0.share}%` : `0%`;

      const b03AgingM2Lbl = document.getElementById("b03-aging-m2-lbl");
      if (b03AgingM2Lbl) {
        if (isValidNum(bk1.amount) || isValidNum(bk1.count)) {
          b03AgingM2Lbl.textContent = `${bk1.name || 'M2 (31–60天)'} ${isValidNum(bk1.amount) ? fmtNum(bk1.amount, 2) + ' ' + (bk1.unit || '億元') : ''} (${isValidNum(bk1.count) ? Number(bk1.count).toLocaleString() + ' 戶' : ''})`.replace(/\(\s*\)/, '').trim();
        } else {
          b03AgingM2Lbl.textContent = `${bk1.name || 'M2 (31–60天)'} -`;
        }
      }
      const b03AgingM2Rec = document.getElementById("b03-aging-m2-rec");
      if (b03AgingM2Rec) b03AgingM2Rec.textContent = isValidNum(bk1.rec_ratio) ? `${bk1.rec_ratio}% 應收` : `-`;
      const b03AgingM2Bar = document.getElementById("b03-aging-m2-bar");
      if (b03AgingM2Bar) b03AgingM2Bar.style.width = isValidNum(bk1.share) ? `${bk1.share}%` : `0%`;

      const b03AgingM3Lbl = document.getElementById("b03-aging-m3-lbl");
      if (b03AgingM3Lbl) {
        if (isValidNum(bk2.amount) || isValidNum(bk2.count)) {
          b03AgingM3Lbl.textContent = `${bk2.name || 'M3+ (61天以上)'} ${isValidNum(bk2.amount) ? fmtNum(bk2.amount, 2) + ' ' + (bk2.unit || '億元') : ''} (${isValidNum(bk2.count) ? Number(bk2.count).toLocaleString() + ' 戶' : ''})`.replace(/\(\s*\)/, '').trim();
        } else {
          b03AgingM3Lbl.textContent = `${bk2.name || 'M3+ (61天以上)'} -`;
        }
      }
      const b03AgingM3Rec = document.getElementById("b03-aging-m3-rec");
      if (b03AgingM3Rec) b03AgingM3Rec.textContent = isValidNum(bk2.rec_ratio) ? `${bk2.rec_ratio}% 應收` : `-`;
      const b03AgingM3Bar = document.getElementById("b03-aging-m3-bar");
      if (b03AgingM3Bar) b03AgingM3Bar.style.width = isValidNum(bk2.share) ? `${bk2.share}%` : `0%`;
    }

    // 呆帳淨損失結算
    const loss = colLoss.loss_settlement || {};
    const b03LossWriteoff = document.getElementById("b03-loss-writeoff-val");
    if (b03LossWriteoff) b03LossWriteoff.textContent = isValidNum(loss.loss_writeoff?.value) ? `${fmtNum(loss.loss_writeoff.value, 2)} ${loss.loss_writeoff.unit || '億元'}` : `-`;
    const b03LossRecovery = document.getElementById("b03-loss-recovery-val");
    if (b03LossRecovery) b03LossRecovery.textContent = isValidNum(loss.loss_recovery?.value) ? `${fmtSign(loss.loss_recovery.value, ' ' + (loss.loss_recovery.unit || '億元'))}` : `-`;
    const b03LossNet = document.getElementById("b03-loss-net-val");
    if (b03LossNet) b03LossNet.textContent = isValidNum(loss.loss_net?.value) ? `${fmtNum(loss.loss_net.value, 2)} ${loss.loss_net.unit || '億元'}` : `-`;
  }

  // ========================================================
  // 方案一：04 系統韌性 數據動態灌溉引擎 (Data Hydration Engine)
  // ========================================================
  function renderBlock04FromData(data) {
    if (!data || !data.block04) return;
    const b4 = data.block04;
    const kpi = b4.monthly_kpis || {};
    const events = b4.cloud_events || [];
    const fraud = b4.fraud_defense || {};
    const ms = b4.microservices || {};

    const isValidNum = (v) => v !== null && v !== undefined && v !== '' && v !== '-' && !isNaN(Number(v));
    const fmtNum = (v, maxDigits = 2) => {
      if (!isValidNum(v)) return '-';
      return Number(v).toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: maxDigits
      });
    };
    const fmtSign = (v, sfx="%") => {
      if (!isValidNum(v)) return '-';
      const n = Number(v);
      const formatted = n.toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
      });
      return `${n > 0 ? "+" : ""}${formatted}${sfx}`;
    };
    const semCls = (v) => {
      if (!isValidNum(v)) return "number-neutral";
      return Number(v) >= 0 ? "number-positive" : "number-negative";
    };

    // ---------------------------------------------------------
    // 1. CardPool 授權核心主機 (Cockpit & Section 04 Primary 1)
    // ---------------------------------------------------------
    const cpResp = kpi.sys_cardpool_resp || {};
    const cpVol = kpi.sys_cardpool_vol || {};
    const cpSucc = kpi.sys_cardpool_succ || {};

    // Cockpit
    const c00CpRespVal = document.getElementById("c00-cp-resp-val");
    if (c00CpRespVal) c00CpRespVal.innerHTML = `${isValidNum(cpResp.value) ? cpResp.value : '-'} <em>${cpResp.unit || 'ms'}</em>`;
    const c00CpRespSub = document.getElementById("c00-cp-resp-sub");
    if (c00CpRespSub) c00CpRespSub.textContent = cpResp.note ? cpResp.note.split('；')[0] : '零超時 (0筆)';
    const c00CpVolVal = document.getElementById("c00-cp-vol-val");
    if (c00CpVolVal) c00CpVolVal.innerHTML = `${isValidNum(cpVol.value) ? Number(cpVol.value).toLocaleString() : '-'} <em>${cpVol.unit || '萬筆'}</em>`;
    const c00CpVolSub = document.getElementById("c00-cp-vol-sub");
    if (c00CpVolSub) c00CpVolSub.textContent = `成功率 ${isValidNum(cpSucc.value) ? cpSucc.value + '%' : '-'}`;

    // Section 04
    const b04CpRespVal = document.getElementById("b04-cp-resp-val");
    if (b04CpRespVal) b04CpRespVal.innerHTML = `${isValidNum(cpResp.value) ? cpResp.value : '-'}<em>${cpResp.unit || 'ms'}</em>`;
    const b04CpAvailTag = document.getElementById("b04-cp-avail-tag");
    if (b04CpAvailTag) b04CpAvailTag.innerHTML = `<b>可用率</b>${cpSucc.sub1 || (isValidNum(cpSucc.value) ? '99.999%' : '-')}`;
    const b04CpSlaTag = document.getElementById("b04-cp-sla-tag");
    if (b04CpSlaTag) b04CpSlaTag.innerHTML = `<b>SLA</b>${cpResp.sub2 || '100% 達標'}`;

    const b04CpVolVal = document.getElementById("b04-cp-vol-val");
    if (b04CpVolVal) b04CpVolVal.innerHTML = `${isValidNum(cpVol.value) ? Number(cpVol.value).toLocaleString() : '-'}<em>${cpVol.unit || '萬筆'}</em>`;
    const b04CpVolTag = document.getElementById("b04-cp-vol-tag");
    if (b04CpVolTag) b04CpVolTag.textContent = '零超時';
    const b04CpVolTt = document.getElementById("b04-cp-vol-tt");
    if (b04CpVolTt) {
      b04CpVolTt.innerHTML = `
        <strong>授權核心負載</strong>
        <span>授權筆數：${isValidNum(cpVol.value) ? Number(cpVol.value).toLocaleString() : '-'} 萬筆</span>
        <span>超時筆數：${cpVol.sub1 !== undefined && cpVol.sub1 !== null ? cpVol.sub1 : 0} 筆</span>
        <span>P99 延遲：${cpVol.sub2 || '< 120ms'}</span>
      `;
    }

    const b04CpSuccVal = document.getElementById("b04-cp-succ-val");
    if (b04CpSuccVal) b04CpSuccVal.innerHTML = `${isValidNum(cpSucc.value) ? cpSucc.value : '-'}%<em></em>`;
    const b04CpSuccTag = document.getElementById("b04-cp-succ-tag");
    if (b04CpSuccTag) b04CpSuccTag.textContent = `可用率 ${cpSucc.sub1 || '99.999%'}`;
    const b04CpSuccTt = document.getElementById("b04-cp-succ-tt");
    if (b04CpSuccTt) {
      b04CpSuccTt.innerHTML = `
        <strong>系統可用率</strong>
        <span>成功率：${isValidNum(cpSucc.value) ? cpSucc.value + '%' : '-'}</span>
        <span>系統可用：${cpSucc.sub1 || '99.999%'}</span>
        <span>無中斷運行：${cpSucc.sub2 || '744 小時'}</span>
      `;
    }

    // ---------------------------------------------------------
    // 2. CardLink 核心帳務主機 (Cockpit & Section 04 Primary 2)
    // ---------------------------------------------------------
    const clVol = kpi.sys_cardlink_vol || {};
    const clAvail = kpi.sys_cardlink_avail || {};
    const clTps = kpi.sys_cardlink_tps || {};
    const clBatchTime = kpi.sys_cardlink_batch_time || {};
    const clBatchLimit = kpi.sys_cardlink_batch_limit || {};
    const clAcc = kpi.sys_cardlink_batch_accounts || {};

    // Cockpit
    const c00ClVolVal = document.getElementById("c00-cl-vol-val");
    if (c00ClVolVal) c00ClVolVal.innerHTML = `${isValidNum(clVol.value) ? clVol.value : '-'} <em>${clVol.unit || '億筆'}</em>`;
    const c00ClVolSub = document.getElementById("c00-cl-vol-sub");
    if (c00ClVolSub) c00ClVolSub.textContent = '高可靠運作';
    const c00ClAvailVal = document.getElementById("c00-cl-avail-val");
    if (c00ClAvailVal) c00ClAvailVal.textContent = `${isValidNum(clAvail.value) ? Number(clAvail.value).toFixed(1) + '%' : '-'}`;
    const c00ClTpsSub = document.getElementById("c00-cl-tps-sub");
    if (c00ClTpsSub) c00ClTpsSub.textContent = `峰值 ${isValidNum(clTps.value) ? Number(clTps.value).toLocaleString() : '-'} TPS`;

    // Section 04
    const b04ClTimeVal = document.getElementById("b04-cl-time-val");
    if (b04ClTimeVal) {
      const tVal = clBatchTime.value ? String(clBatchTime.value).replace(/\s*AM|\s*PM/i, '') : '03:20';
      const tSfx = clBatchTime.value && /PM/i.test(String(clBatchTime.value)) ? 'PM' : 'AM';
      b04ClTimeVal.innerHTML = `${tVal}<em>${tSfx}</em>`;
    }
    const b04ClPuncTag = document.getElementById("b04-cl-punc-tag");
    if (b04ClPuncTag) b04ClPuncTag.innerHTML = `<b>批次準點率</b>${clBatchTime.sub1 || '100%'}`;
    const b04ClEarlyTag = document.getElementById("b04-cl-early-tag");
    if (b04ClEarlyTag) b04ClEarlyTag.innerHTML = `<b>提前</b>${clBatchTime.sub2 || '40 分鐘'}`;

    const b04ClLimitVal = document.getElementById("b04-cl-limit-val");
    if (b04ClLimitVal) {
      const lVal = clBatchLimit.value ? String(clBatchLimit.value).replace(/\s*AM|\s*PM/i, '') : '04:00';
      const lSfx = clBatchLimit.value && /PM/i.test(String(clBatchLimit.value)) ? 'PM' : 'AM';
      b04ClLimitVal.innerHTML = `${lVal}<em>${lSfx}</em>`;
    }
    const b04ClLimitTag = document.getElementById("b04-cl-limit-tag");
    if (b04ClLimitTag) b04ClLimitTag.textContent = clBatchLimit.sub1 || '安全裕度足';
    const b04ClLimitTt = document.getElementById("b04-cl-limit-tt");
    if (b04ClLimitTt) {
      b04ClLimitTt.innerHTML = `
        <strong>清算作業窗口</strong>
        <span>排程上限：${clBatchLimit.value || '04:00 AM'}</span>
        <span>平均完成：${clBatchTime.value || '03:20 AM'}</span>
        <span>裕度時間：${clBatchLimit.sub2 || '40 分鐘'}</span>
      `;
    }

    const b04ClAccVal = document.getElementById("b04-cl-acc-val");
    if (b04ClAccVal) b04ClAccVal.innerHTML = `${isValidNum(clAcc.value) ? clAcc.value : '-'}<em>${clAcc.unit || '萬戶'}</em>`;
    const b04ClAccTag = document.getElementById("b04-cl-acc-tag");
    if (b04ClAccTag) b04ClAccTag.textContent = `平帳 ${clAcc.sub1 || '100%'}`;
    const b04ClAccTt = document.getElementById("b04-cl-acc-tt");
    if (b04ClAccTt) {
      b04ClAccTt.innerHTML = `
        <strong>日均結帳量</strong>
        <span>帳單戶數：${isValidNum(clAcc.value) ? clAcc.value : '-'} 萬戶/日</span>
        <span>平帳率：${clAcc.sub1 || '100.0%'}</span>
        <span>批次作業${clAcc.sub2 || '零延宕'}</span>
      `;
    }

    // ---------------------------------------------------------
    // 3. 資安防詐成效 (Cockpit & Section 04 Primary 3 & Tab 1)
    // ---------------------------------------------------------
    const channels = fraud.channels || [];
    const tot = fraud.total || {};
    const subtotals = fraud.subtotals || {};
    const sfm = subtotals.sfm || {};
    const tds = subtotals.tds || {};

    const tx = channels.find(c => c.code === 'fraud_sfm_tx') || {};
    const apply = channels.find(c => c.code === 'fraud_sfm_apply') || {};
    const online = channels.find(c => c.code === 'fraud_3ds_online') || {};

    // Cockpit
    const c00FrPill = document.getElementById("c00-fr-pill");
    if (c00FrPill) c00FrPill.textContent = `全月防堵 ${isValidNum(tot.amount) ? Number(tot.amount).toLocaleString() : '-'} 萬`;
    const c00FrAmtVal = document.getElementById("c00-fr-amt-val");
    if (c00FrAmtVal) c00FrAmtVal.innerHTML = `${isValidNum(tot.amount) ? Number(tot.amount).toLocaleString() : '-'} <em>${tot.unit || '萬元'}</em>`;
    const c00FrCntVal = document.getElementById("c00-fr-cnt-val");
    if (c00FrCntVal) c00FrCntVal.innerHTML = `${isValidNum(tot.count) ? Number(tot.count).toLocaleString() : '-'} <em>張</em>`;

    const c00FrLinesList = document.getElementById("c00-fr-lines-list");
    if (c00FrLinesList) {
      c00FrLinesList.innerHTML = `
        <div class="f-line-item">
          <span class="f-tag sfm">SFM</span>
          <span class="f-name">交易詐欺</span>
          <span class="f-amt">${isValidNum(tx.amount) ? Number(tx.amount).toLocaleString() + ' 萬元' : '-'}</span>
          <span class="f-cnt">${isValidNum(tx.count) ? Number(tx.count).toLocaleString() + ' 張' : '-'}</span>
        </div>
        <div class="f-line-item">
          <span class="f-tag sfm">SFM</span>
          <span class="f-name">申請詐欺</span>
          <span class="f-amt">${isValidNum(apply.amount) ? Number(apply.amount).toLocaleString() + ' 萬元' : '-'}</span>
          <span class="f-cnt">${isValidNum(apply.count) ? Number(apply.count).toLocaleString() + ' 張' : '-'}</span>
        </div>
        <div class="f-line-item">
          <span class="f-tag tds">3DS</span>
          <span class="f-name">線上交易</span>
          <span class="f-amt">${isValidNum(online.amount) ? Number(online.amount).toLocaleString() + ' 萬元' : '-'}</span>
          <span class="f-cnt">${isValidNum(online.count) ? Number(online.count).toLocaleString() + ' 張' : '-'}</span>
        </div>
      `;
    }

    // Section 04 Primary Card 3
    const b04FrAmtVal = document.getElementById("b04-fr-amt-val");
    if (b04FrAmtVal) b04FrAmtVal.innerHTML = `${isValidNum(tot.amount) ? Number(tot.amount).toLocaleString() : '-'}<em>${tot.unit || '萬元'}</em>`;
    const b04FrCntTag = document.getElementById("b04-fr-cnt-tag");
    if (b04FrCntTag) b04FrCntTag.innerHTML = `<b>防堵總卡數</b>${isValidNum(tot.count) ? Number(tot.count).toLocaleString() + ' 張' : '-'}`;

    const b04FrSfmAmt = document.getElementById("b04-fr-sfm-amt");
    if (b04FrSfmAmt) b04FrSfmAmt.innerHTML = `${isValidNum(sfm.amount) ? Number(sfm.amount).toLocaleString() : '-'}<em>萬元</em>`;
    const b04FrSfmCnt = document.getElementById("b04-fr-sfm-cnt");
    if (b04FrSfmCnt) b04FrSfmCnt.textContent = `${isValidNum(sfm.count) ? Number(sfm.count).toLocaleString() + ' 張' : '-'}`;
    const b04FrSfmTt = document.getElementById("b04-fr-sfm-tt");
    if (b04FrSfmTt) {
      const sfmPct = isValidNum(tot.amount) && tot.amount > 0 ? Math.round(sfm.amount / tot.amount * 100) : '-';
      b04FrSfmTt.innerHTML = `
        <strong>智慧偵測 SFM 系統</strong>
        <span>防堵金額：${isValidNum(sfm.amount) ? Number(sfm.amount).toLocaleString() : '-'} 萬元（${sfmPct}%）</span>
        <span>• 申請詐欺：${isValidNum(apply.amount) ? Number(apply.amount).toLocaleString() : '-'} 萬 ｜ ${isValidNum(apply.count) ? Number(apply.count).toLocaleString() : '-'} 張</span>
        <span>• 交易詐欺：${isValidNum(tx.amount) ? Number(tx.amount).toLocaleString() : '-'} 萬 ｜ ${isValidNum(tx.count) ? Number(tx.count).toLocaleString() : '-'} 張</span>
      `;
    }

    const b04FrTdsAmt = document.getElementById("b04-fr-tds-amt");
    if (b04FrTdsAmt) b04FrTdsAmt.innerHTML = `${isValidNum(tds.amount) ? Number(tds.amount).toLocaleString() : '-'}<em>萬元</em>`;
    const b04FrTdsCnt = document.getElementById("b04-fr-tds-cnt");
    if (b04FrTdsCnt) b04FrTdsCnt.textContent = `${isValidNum(tds.count) ? Number(tds.count).toLocaleString() + ' 張' : '-'}`;
    const b04FrTdsTt = document.getElementById("b04-fr-tds-tt");
    if (b04FrTdsTt) {
      const tdsPct = isValidNum(tot.amount) && tot.amount > 0 ? Math.round(tds.amount / tot.amount * 100) : '-';
      b04FrTdsTt.innerHTML = `
        <strong>線上交易 3DS 驗證</strong>
        <span>防堵金額：${isValidNum(tds.amount) ? Number(tds.amount).toLocaleString() : '-'} 萬元（${tdsPct}%）</span>
        <span>防堵卡數：${isValidNum(tds.count) ? Number(tds.count).toLocaleString() + ' 張' : '-'}</span>
        <span>OTP 異常攔阻率：99.6%</span>
      `;
    }

    // Section 04 Tab 1 Table
    const b04FraudTableBody = document.getElementById("b04-fraud-table-body");
    if (b04FraudTableBody) {
      b04FraudTableBody.innerHTML = `
        <tr>
          <td><strong>SFM 交易詐欺防堵</strong></td>
          <td><strong>${isValidNum(tx.count) ? Number(tx.count).toLocaleString() + ' 張' : '-'}</strong></td>
          <td><strong style="color:var(--ink);">${isValidNum(tx.amount) ? Number(tx.amount).toLocaleString() + ' 萬元' : '-'}</strong></td>
          <td><strong>${isValidNum(tx.avg_per_card) ? tx.avg_per_card + ' 萬元 / 張' : '-'}</strong></td>
          <td><strong>${isValidNum(tx.share) ? tx.share.toFixed(1) + '%' : '-%'}</strong></td>
        </tr>
        <tr>
          <td><strong>SFM 申請詐欺防堵</strong></td>
          <td><strong>${isValidNum(apply.count) ? Number(apply.count).toLocaleString() + ' 張' : '-'}</strong></td>
          <td><strong style="color:var(--ink);">${isValidNum(apply.amount) ? Number(apply.amount).toLocaleString() + ' 萬元' : '-'}</strong></td>
          <td><strong>${isValidNum(apply.avg_per_card) ? apply.avg_per_card + ' 萬元 / 張' : '-'}</strong></td>
          <td><strong>${isValidNum(apply.share) ? apply.share.toFixed(1) + '%' : '-%'}</strong></td>
        </tr>
        <tr>
          <td><strong>3DS 系統防堵</strong></td>
          <td><strong>${isValidNum(online.count) ? Number(online.count).toLocaleString() + ' 張' : '-'}</strong></td>
          <td><strong style="color:var(--ink);">${isValidNum(online.amount) ? Number(online.amount).toLocaleString() + ' 萬元' : '-'}</strong></td>
          <td><strong>${isValidNum(online.avg_per_card) ? online.avg_per_card + ' 萬元 / 張' : '-'}</strong></td>
          <td><strong>${isValidNum(online.share) ? online.share.toFixed(1) + '%' : '-%'}</strong></td>
        </tr>
        <tr style="background:#f0f7f5; font-weight:700;">
          <td><strong>${tot.name || '全行防詐防堵合計'}</strong></td>
          <td><strong style="color:var(--orange-dark);">${isValidNum(tot.count) ? Number(tot.count).toLocaleString() + ' 張' : '-'}</strong></td>
          <td><strong style="color:var(--orange-dark);">${isValidNum(tot.amount) ? Number(tot.amount).toLocaleString() + ' 萬元' : '-'}</strong></td>
          <td><strong>${isValidNum(tot.avg_per_card) ? tot.avg_per_card + ' 萬元 / 張' : '-'}</strong></td>
          <td><strong>${isValidNum(tot.share) ? tot.share.toFixed(1) + '%' : '100.0%'}</strong></td>
        </tr>
      `;
    }

    // Section 03 Tab 3 (SFM/3DS): 雙橫向長條圖 (防堵金額與防堵卡數分流)
    const b04FraudSvgWrapper = document.getElementById("b04-fraud-svg-wrapper");
    if (b04FraudSvgWrapper) {
      b04FraudSvgWrapper.style.display = "grid";
      b04FraudSvgWrapper.style.gridTemplateColumns = "repeat(2, 1fr)";
      b04FraudSvgWrapper.style.gap = "14px";

      const fraudChannels = [
        {
          cNum: 1,
          name: tx.name || "SFM 交易詐欺防堵",
          amount: tx.amount,
          prev_amount: tx.prev_month,
          amount_mom: tx.mom,
          count: tx.count,
          prev_count: tx.prev_count,
          count_mom: tx.count_mom
        },
        {
          cNum: 2,
          name: apply.name || "SFM 申請詐欺防堵",
          amount: apply.amount,
          prev_amount: apply.prev_month,
          amount_mom: apply.mom,
          count: apply.count,
          prev_count: apply.prev_count,
          count_mom: apply.count_mom
        },
        {
          cNum: 3,
          name: online.name || "3DS 系統防堵",
          amount: online.amount,
          prev_amount: online.prev_month,
          amount_mom: online.mom,
          count: online.count,
          prev_count: online.prev_count,
          count_mom: online.count_mom
        }
      ];

      // 計算尺度最大值 (Max)，保留適當視覺呼吸空間
      const allAmts = fraudChannels.flatMap(c => [Number(c.amount) || 0, Number(c.prev_amount) || 0]);
      const maxAmt = Math.max(...allAmts, 1) * 1.05;

      const allCnts = fraudChannels.flatMap(c => [Number(c.count) || 0, Number(c.prev_count) || 0]);
      const maxCnt = Math.max(...allCnts, 1) * 1.05;

      const calcBarW = (val, max) => {
        if (!isValidNum(val) || Number(val) <= 0) return 0;
        return Math.max(((Number(val) / max) * 100), 12).toFixed(1);
      };

      // 1. 左側圖表：防堵金額 (單位：萬元 ｜ 本月 vs 前月)
      const amtRowsHtml = fraudChannels.map(c => {
        const currW = calcBarW(c.amount, maxAmt);
        const prevW = calcBarW(c.prev_amount, maxAmt);
        const momVal = c.amount_mom;
        const momClass = semCls(momVal);
        const momText = isValidNum(momVal) ? fmtSign(momVal) : "-";
        const currTxt = isValidNum(c.amount) ? fmtNum(c.amount) : "-";
        const prevTxt = isValidNum(c.prev_amount) ? fmtNum(c.prev_amount) : "-";

        return `
          <div class="acq-channel-row">
            <div class="acq-channel-name">${c.name}</div>
            <div class="acq-channel-bars">
              <div class="acq-bar-line" title="本月：${currTxt} 萬元">
                <span class="acq-bar-subtag">本月</span>
                <div class="acq-bar-track">
                  <div class="acq-bar-fill curr-amt ${currW == 0 ? 'zero-val' : ''}" style="width: ${currW}%;">
                    <span id="b03-fraud-c${c.cNum}-amt">${currTxt}</span>
                  </div>
                </div>
              </div>
              <div class="acq-bar-line" title="前月：${prevTxt} 萬元">
                <span class="acq-bar-subtag">前月</span>
                <div class="acq-bar-track">
                  <div class="acq-bar-fill prev ${prevW == 0 ? 'zero-val' : ''}" style="width: ${prevW}%;">
                    ${prevW > 0 ? `<span>${prevTxt}</span>` : ''}
                  </div>
                </div>
              </div>
            </div>
            <div class="acq-channel-mom ${momClass}">${momText}</div>
          </div>
        `;
      }).join("");

      const leftCardHtml = `
        <div class="chart-box acq-channel-card">
          <div class="chart-box-header">
            <div>
              <h3 style="color:var(--blue-dark);">防堵金額</h3>
            </div>
            <div style="display:flex; align-items:center; gap:12px; font-size:11px; font-weight:800; color:#68767b;">
              <div style="display:flex; align-items:center; gap:8px;">
                <span style="display:inline-flex; align-items:center; gap:4px;"><i style="width:9px; height:9px; border-radius:2px; background:#003b5c; display:inline-block;"></i> 本月</span>
                <span style="display:inline-flex; align-items:center; gap:4px;"><i style="width:9px; height:9px; border-radius:2px; background:#94a3b8; display:inline-block;"></i> 前月</span>
              </div>
              <span>單位：萬元 ｜ MoM</span>
            </div>
          </div>
          <div class="acq-channel-rows">
            ${amtRowsHtml}
          </div>
        </div>
      `;

      // 2. 右側圖表：防堵卡數 (單位：張 ｜ 本月 vs 前月)
      const cntRowsHtml = fraudChannels.map(c => {
        const currW = calcBarW(c.count, maxCnt);
        const prevW = calcBarW(c.prev_count, maxCnt);
        const momVal = c.count_mom;
        const momClass = semCls(momVal);
        const momText = isValidNum(momVal) ? fmtSign(momVal) : "-";
        const currTxt = isValidNum(c.count) ? fmtNum(c.count) : "-";
        const prevTxt = isValidNum(c.prev_count) ? fmtNum(c.prev_count) : "-";

        return `
          <div class="acq-channel-row">
            <div class="acq-channel-name">${c.name}</div>
            <div class="acq-channel-bars">
              <div class="acq-bar-line" title="本月：${currTxt} 張">
                <span class="acq-bar-subtag">本月</span>
                <div class="acq-bar-track">
                  <div class="acq-bar-fill curr-cnt ${currW == 0 ? 'zero-val' : ''}" style="width: ${currW}%;">
                    <span id="b03-fraud-c${c.cNum}-cnt">${currTxt}</span>
                  </div>
                </div>
              </div>
              <div class="acq-bar-line" title="前月：${prevTxt} 張">
                <span class="acq-bar-subtag">前月</span>
                <div class="acq-bar-track">
                  <div class="acq-bar-fill prev ${prevW == 0 ? 'zero-val' : ''}" style="width: ${prevW}%;">
                    ${prevW > 0 ? `<span>${prevTxt}</span>` : ''}
                  </div>
                </div>
              </div>
            </div>
            <div class="acq-channel-mom ${momClass}">${momText}</div>
          </div>
        `;
      }).join("");

      const rightCardHtml = `
        <div class="chart-box acq-channel-card">
          <div class="chart-box-header">
            <div>
              <h3 style="color:var(--blue-dark);">防堵卡數</h3>
            </div>
            <div style="display:flex; align-items:center; gap:12px; font-size:11px; font-weight:800; color:#68767b;">
              <div style="display:flex; align-items:center; gap:8px;">
                <span style="display:inline-flex; align-items:center; gap:4px;"><i style="width:9px; height:9px; border-radius:2px; background:#009e73; display:inline-block;"></i> 本月</span>
                <span style="display:inline-flex; align-items:center; gap:4px;"><i style="width:9px; height:9px; border-radius:2px; background:#94a3b8; display:inline-block;"></i> 前月</span>
              </div>
              <span>單位：張 ｜ MoM</span>
            </div>
          </div>
          <div class="acq-channel-rows">
            ${cntRowsHtml}
          </div>
        </div>
      `;

      b04FraudSvgWrapper.innerHTML = leftCardHtml + rightCardHtml;
    }

    // ---------------------------------------------------------
    // 4. Section 04 Tab 0: 活動日雲端服務監控
    // ---------------------------------------------------------
    const b04EventsTableBody = document.getElementById("b04-events-table-body");
    if (b04EventsTableBody && events.length > 0) {
      b04EventsTableBody.innerHTML = events.map(ev => `
        <tr>
          <td><strong>${ev.date || '-'}</strong> ｜ ${ev.name || '-'}</td>
          <td>${ev.peak_time || '-'}</td>
          <td>${ev.spec || '-'}</td>
          <td><strong style="color:var(--orange-dark);">${isValidNum(ev.peak_tps) ? Number(ev.peak_tps).toLocaleString() : '-'} TPS</strong></td>
          <td><strong class="is-good">${isValidNum(ev.cpu_load) ? ev.cpu_load + '%' : '-'}</strong></td>
          <td>${ev.note || '-'}</td>
        </tr>
      `).join("");
    }

    // ---------------------------------------------------------
    // 5. 紅利微服務量能監控 (Cockpit & Section 04 Tab 2)
    // ---------------------------------------------------------
    const services = ms.services || [];
    const s0 = services[0] || {};
    const s1 = services[1] || {};
    const s2 = services[2] || {};
    const s3 = services[3] || {};

    // Cockpit 4 BMS cards
    const c00BmsC1Yoy = document.getElementById("c00-bms-c1-yoy");
    if (c00BmsC1Yoy) c00BmsC1Yoy.textContent = `YoY ${fmtSign(s0.yoy)}`;
    const c00BmsC1Val = document.getElementById("c00-bms-c1-val");
    if (c00BmsC1Val) c00BmsC1Val.innerHTML = `${isValidNum(s0.calls) ? Number(s0.calls).toLocaleString() : '-'} <em>${s0.unit || '萬次'}</em>`;
    const c00BmsC1Mom = document.getElementById("c00-bms-c1-mom") || document.getElementById("c00-bms-c1-tps");
    if (c00BmsC1Mom) {
      c00BmsC1Mom.className = (isValidNum(s0.mom) && Number(s0.mom) < 0) ? 'number-negative' : 'number-positive';
      c00BmsC1Mom.textContent = fmtSign(s0.mom);
    }

    const c00BmsC2Yoy = document.getElementById("c00-bms-c2-yoy");
    if (c00BmsC2Yoy) c00BmsC2Yoy.textContent = `YoY ${fmtSign(s1.yoy)}`;
    const c00BmsC2Val = document.getElementById("c00-bms-c2-val");
    if (c00BmsC2Val) c00BmsC2Val.innerHTML = `${isValidNum(s1.calls) ? Number(s1.calls).toLocaleString() : '-'} <em>${s1.unit || '萬次'}</em>`;
    const c00BmsC2Mom = document.getElementById("c00-bms-c2-mom") || document.getElementById("c00-bms-c2-tps");
    if (c00BmsC2Mom) {
      c00BmsC2Mom.className = (isValidNum(s1.mom) && Number(s1.mom) < 0) ? 'number-negative' : 'number-positive';
      c00BmsC2Mom.textContent = fmtSign(s1.mom);
    }

    const c00BmsC3Yoy = document.getElementById("c00-bms-c3-yoy");
    if (c00BmsC3Yoy) c00BmsC3Yoy.textContent = `YoY ${fmtSign(s2.yoy)}`;
    const c00BmsC3Val = document.getElementById("c00-bms-c3-val");
    if (c00BmsC3Val) c00BmsC3Val.innerHTML = `${isValidNum(s2.calls) ? Number(s2.calls).toLocaleString() : '-'} <em>${s2.unit || '萬次'}</em>`;
    const c00BmsC3Mom = document.getElementById("c00-bms-c3-mom") || document.getElementById("c00-bms-c3-tps");
    if (c00BmsC3Mom) {
      c00BmsC3Mom.className = (isValidNum(s2.mom) && Number(s2.mom) < 0) ? 'number-negative' : 'number-positive';
      c00BmsC3Mom.textContent = fmtSign(s2.mom);
    }

    const c00BmsC4Yoy = document.getElementById("c00-bms-c4-yoy");
    if (c00BmsC4Yoy) c00BmsC4Yoy.textContent = `YoY ${fmtSign(s3.yoy)}`;
    const c00BmsC4Val = document.getElementById("c00-bms-c4-val");
    if (c00BmsC4Val) c00BmsC4Val.innerHTML = `${isValidNum(s3.calls) ? Number(s3.calls).toLocaleString() : '-'} <em>${s3.unit || '萬次'}</em>`;
    const c00BmsC4Mom = document.getElementById("c00-bms-c4-mom") || document.getElementById("c00-bms-c4-tps");
    if (c00BmsC4Mom) {
      c00BmsC4Mom.className = (isValidNum(s3.mom) && Number(s3.mom) < 0) ? 'number-negative' : 'number-positive';
      c00BmsC4Mom.textContent = fmtSign(s3.mom);
    }

    // Section 04 Tab 2 Overview 4 Cards (全面調整為 MoM 月增率與峰值TPS，符合全儀表板標準)
    const b04MsC1Val = document.getElementById("b04-ms-c1-val");
    if (b04MsC1Val) b04MsC1Val.innerHTML = `${isValidNum(s0.calls) ? Number(s0.calls).toLocaleString() : '-'}<em>${s0.unit || '萬次'}</em>`;
    const b04MsC1Yoy = document.getElementById("b04-ms-c1-yoy");
    if (b04MsC1Yoy) b04MsC1Yoy.innerHTML = `<b>YoY</b>${fmtSign(s0.yoy)}`;
    const b04MsC1Mom = document.getElementById("b04-ms-c1-mom");
    if (b04MsC1Mom) {
      b04MsC1Mom.className = (isValidNum(s0.mom) && Number(s0.mom) < 0) ? 'number-negative' : 'number-positive';
      b04MsC1Mom.innerHTML = `<b>MoM</b>${fmtSign(s0.mom)}`;
    }
    const b04MsC1Tps = document.getElementById("b04-ms-c1-tps");
    if (b04MsC1Tps) {
      b04MsC1Tps.innerHTML = `峰值TPS: <b>${isValidNum(s0.peak_tps) ? Number(s0.peak_tps).toLocaleString() : '-'}</b>`;
    }

    const b04MsC2Val = document.getElementById("b04-ms-c2-val");
    if (b04MsC2Val) b04MsC2Val.innerHTML = `${isValidNum(s1.calls) ? Number(s1.calls).toLocaleString() : '-'}<em>${s1.unit || '萬次'}</em>`;
    const b04MsC2Yoy = document.getElementById("b04-ms-c2-yoy");
    if (b04MsC2Yoy) b04MsC2Yoy.innerHTML = `<b>YoY</b>${fmtSign(s1.yoy)}`;
    const b04MsC2Mom = document.getElementById("b04-ms-c2-mom");
    if (b04MsC2Mom) {
      b04MsC2Mom.className = (isValidNum(s1.mom) && Number(s1.mom) < 0) ? 'number-negative' : 'number-positive';
      b04MsC2Mom.innerHTML = `<b>MoM</b>${fmtSign(s1.mom)}`;
    }
    const b04MsC2Tps = document.getElementById("b04-ms-c2-tps");
    if (b04MsC2Tps) {
      b04MsC2Tps.innerHTML = `峰值TPS: <b>${isValidNum(s1.peak_tps) ? Number(s1.peak_tps).toLocaleString() : '-'}</b>`;
    }

    const b04MsC3Val = document.getElementById("b04-ms-c3-val");
    if (b04MsC3Val) b04MsC3Val.innerHTML = `${isValidNum(s2.calls) ? Number(s2.calls).toLocaleString() : '-'}<em>${s2.unit || '萬次'}</em>`;
    const b04MsC3Yoy = document.getElementById("b04-ms-c3-yoy");
    if (b04MsC3Yoy) b04MsC3Yoy.innerHTML = `<b>YoY</b>${fmtSign(s2.yoy)}`;
    const b04MsC3Mom = document.getElementById("b04-ms-c3-mom");
    if (b04MsC3Mom) {
      b04MsC3Mom.className = (isValidNum(s2.mom) && Number(s2.mom) < 0) ? 'number-negative' : 'number-positive';
      b04MsC3Mom.innerHTML = `<b>MoM</b>${fmtSign(s2.mom)}`;
    }
    const b04MsC3Tps = document.getElementById("b04-ms-c3-tps");
    if (b04MsC3Tps) {
      b04MsC3Tps.innerHTML = `峰值TPS: <b>${isValidNum(s2.peak_tps) ? Number(s2.peak_tps).toLocaleString() : '-'}</b>`;
    }

    const b04MsC4Val = document.getElementById("b04-ms-c4-val");
    if (b04MsC4Val) b04MsC4Val.innerHTML = `${isValidNum(s3.calls) ? Number(s3.calls).toLocaleString() : '-'}<em>${s3.unit || '萬次'}</em>`;
    const b04MsC4Yoy = document.getElementById("b04-ms-c4-yoy");
    if (b04MsC4Yoy) b04MsC4Yoy.innerHTML = `<b>YoY</b>${fmtSign(s3.yoy)}`;
    const b04MsC4Mom = document.getElementById("b04-ms-c4-mom");
    if (b04MsC4Mom) {
      b04MsC4Mom.className = (isValidNum(s3.mom) && Number(s3.mom) < 0) ? 'number-negative' : 'number-positive';
      b04MsC4Mom.innerHTML = `<b>MoM</b>${fmtSign(s3.mom)}`;
    }
    const b04MsC4Tps = document.getElementById("b04-ms-c4-tps");
    if (b04MsC4Tps) {
      b04MsC4Tps.innerHTML = `峰值TPS: <b>${isValidNum(s3.peak_tps) ? Number(s3.peak_tps).toLocaleString() : '-'}</b>`;
    }

    // Section 04 Tab 2 Grouped Bars Chart (雙軌中置 Y 軸架構 - 依版面優化調整)
    const b04MsBarsSvgWrapper = document.getElementById("b04-ms-bars-svg-wrapper");
    if (b04MsBarsSvgWrapper && services.length >= 4) {
      // 左軸 (小樹點查詢專屬): 0 ~ 14,000 萬次
      const msMaxLeft = 14000;
      const bH_left = (v) => isValidNum(v) ? Math.min(160, (Number(v) / msMaxLeft) * 160) : 0;
      const bY_left = (v) => 185 - bH_left(v);

      // 中置次軸 (其他三大服務專屬): 0 ~ 1,200 萬次
      const msMaxRight = 1200;
      const bH_right = (v) => isValidNum(v) ? Math.min(160, (Number(v) / msMaxRight) * 160) : 0;
      const bY_right = (v) => 185 - bH_right(v);

      const xOffsets = [80, 235, 350, 465];
      const centers = [111, 266, 381, 496];

      let groupsSvg = '';
      services.slice(0, 4).forEach((s, idx) => {
        const isLeft = (idx === 0);
        const bH = isLeft ? bH_left : bH_right;
        const bY = isLeft ? bY_left : bY_right;

        const xBase = xOffsets[idx];
        const cx = centers[idx];
        const h_ly = bH(s.last_year);
        const y_ly = bY(s.last_year);
        const h_pm = bH(s.prev_month);
        const y_pm = bY(s.prev_month);
        const h_c = bH(s.calls);
        const y_c = bY(s.calls);
        const badgeY = y_c - 21.8;

        const hasYoy = isValidNum(s.yoy);
        const isPos = hasYoy && Number(s.yoy) >= 0;
        const badgeSvg = hasYoy ? `
          <rect x="${xBase}" y="${badgeY.toFixed(1)}" width="62" height="16" rx="3" fill="${isPos ? '#eaf7f2' : '#fef2f2'}" stroke="${isPos ? '#c2ebd9' : '#fecaca'}"/>
          <text x="${cx}" y="${(badgeY + 12).toFixed(1)}" font-size="9.5" font-weight="900" fill="${isPos ? '#007a5e' : '#b91c1c'}" text-anchor="middle">YoY ${fmtSign(s.yoy)}</text>
        ` : '';

        groupsSvg += `
          <!-- Group ${idx + 1}: ${s.name} (${isLeft ? '左軸 0~1.4億' : '中軸 0~1,200萬'}) -->
          <rect x="${xBase}" y="${y_ly.toFixed(1)}" width="18" height="${h_ly.toFixed(1)}" rx="3" fill="#cbd5e1"/>
          <rect x="${xBase + 22}" y="${y_pm.toFixed(1)}" width="18" height="${h_pm.toFixed(1)}" rx="3" fill="#4a7c98"/>
          <rect x="${xBase + 44}" y="${y_c.toFixed(1)}" width="18" height="${h_c.toFixed(1)}" rx="3" fill="#009e73"/>
          ${badgeSvg}
          <text x="${cx}" y="202" font-size="12" font-weight="800" fill="#12344d" text-anchor="middle">${s.name}</text>
        `;
      });

      b04MsBarsSvgWrapper.innerHTML = `
        <svg viewBox="0 0 580 220" style="width:100%; height:auto; display:block;" font-family="inherit">
          <!-- Grid Lines -->
          <line x1="65" y1="25" x2="555" y2="25" stroke="#edf2f0" stroke-dasharray="3 3"/>
          <line x1="65" y1="65" x2="555" y2="65" stroke="#edf2f0" stroke-dasharray="3 3"/>
          <line x1="65" y1="105" x2="555" y2="105" stroke="#edf2f0" stroke-dasharray="3 3"/>
          <line x1="65" y1="145" x2="555" y2="145" stroke="#edf2f0" stroke-dasharray="3 3"/>
          <line x1="65" y1="185" x2="555" y2="185" stroke="#cbd5e1" stroke-width="1.2"/>

          <!-- Left Y Axis Scale (小樹點查詢專屬: 0 ~ 14,000 萬次) -->
          <text x="65" y="15" font-size="9.5" fill="#007a5e" font-weight="900" text-anchor="end">量能(萬次)</text>
          <text x="65" y="29" font-size="10" fill="#007a5e" font-weight="bold" text-anchor="end">14,000萬</text>
          <text x="65" y="69" font-size="10" fill="#667a76" text-anchor="end">10,500萬</text>
          <text x="65" y="109" font-size="10" fill="#667a76" text-anchor="end">7,000萬</text>
          <text x="65" y="149" font-size="10" fill="#667a76" text-anchor="end">3,500萬</text>
          <text x="65" y="188" font-size="10" fill="#667a76" text-anchor="end">0</text>

          <!-- Middle Dividing Y Axis (其他三大服務專屬: 0 ~ 1,200 萬次) -->
          <line x1="215" y1="20" x2="215" y2="185" stroke="#cbd5e1" stroke-width="1" stroke-dasharray="3 2"/>
          <text x="210" y="15" font-size="9.5" fill="#4a7c98" font-weight="900" text-anchor="end">量能(萬次)</text>
          <text x="210" y="29" font-size="10" fill="#4a7c98" font-weight="bold" text-anchor="end">1,200萬</text>
          <text x="210" y="69" font-size="10" fill="#667a76" text-anchor="end">900萬</text>
          <text x="210" y="109" font-size="10" fill="#667a76" text-anchor="end">600萬</text>
          <text x="210" y="149" font-size="10" fill="#667a76" text-anchor="end">300萬</text>
          <text x="210" y="188" font-size="10" fill="#667a76" text-anchor="end">0</text>

          ${groupsSvg}
        </svg>
      `;
    }

    // Section 04 Tab 1 TPS Peak Ranking Progress Bars (純以現有 TPS 呈現相對排名進度條，不考慮容量)
    const b04TpsRankList = document.getElementById("b04-tps-rank-list");
    if (b04TpsRankList && services.length > 0) {
      const serviceGradients = {
        'ms_bonus_query': 'linear-gradient(90deg, #009e73, #007a5e)',
        'ms_reward_overview': 'linear-gradient(90deg, #003b5c, #002b49)',
        'ms_bonus_redeem': 'linear-gradient(90deg, #c9892e, #a46d1b)',
        'ms_ticket_service': 'linear-gradient(90deg, #7c4dff, #5e35b1)'
      };
      const fallbackColors = [
        'linear-gradient(90deg, #7c4dff, #5e35b1)',
        'linear-gradient(90deg, #009e73, #007a5e)',
        'linear-gradient(90deg, #003b5c, #002b49)',
        'linear-gradient(90deg, #c9892e, #a46d1b)'
      ];

      // 依現有 peak_tps 由高至低排序，形成真實排名
      const rankedServices = [...services].sort((a, b) => (Number(b.peak_tps) || 0) - (Number(a.peak_tps) || 0));
      const maxTps = Math.max(...rankedServices.map(s => Number(s.peak_tps) || 0), 1);

      b04TpsRankList.innerHTML = rankedServices.map((s, idx) => {
        const tpsVal = isValidNum(s.peak_tps) ? Number(s.peak_tps) : 0;
        const relativePct = (maxTps > 0 && isValidNum(s.peak_tps)) ? Math.max(((tpsVal / maxTps) * 100), 2).toFixed(1) : 0;
        const barColor = serviceGradients[s.code] || fallbackColors[idx % fallbackColors.length];
        return `
        <div class="tps-rank-item"${idx === rankedServices.length - 1 ? ' style="margin-bottom:0;"' : ''}>
          <div class="tps-rank-labels">
            <span><strong>${idx + 1}. ${s.name}</strong></span>
            <b>${isValidNum(s.peak_tps) ? Number(s.peak_tps).toLocaleString() : '-'} TPS</b>
          </div>
          <div class="tps-bar-track">
            <div class="tps-bar-fill" style="width: ${relativePct}%; background: ${barColor};"></div>
          </div>
        </div>
      `;
      }).join("");
    }
  }

  // 全儀表板通用：小數部分微縮階層美化函數 (涵蓋 00 戰情室與 01~04 各業務區塊)
  // 規則：僅金額、筆數等絕對量需要縮小小數位；百分比(%)、YoY/MoM成長率及標籤/次要註解維持原樣不縮小
  function applyDashboardDecimals() {
    if (typeof document === "undefined" || typeof document.querySelectorAll !== "function" || typeof document.createTreeWalker !== "function") return;
    const mainSections = document.querySelectorAll(".main-section");
    if (!mainSections || mainSections.length === 0) return;

    const excludedParentSelectors = [
      ".peer-bar-track",
      ".acq-bar-track",
      ".acq-channel-card",
      ".c-kpi-growth",
      ".monthly-growth",
      ".monthly-tps",
      ".r-pct",
      ".p-share",
      ".p-yoy",
      ".c-market-stat-sub",
      ".c-hint",
      ".c-tag-green",
      ".cockpit-tag-pill",
      ".secondary-note",
      ".panel-note",
      "#c00-cl-avail-val",
      "#c00-twqr-active-rate",
      "#b01-active-rate-val",
      "#b01-delinq-val",
      "#b01-coverage-val",
      "#b02-penetration-val",
      "#b02-erm-cnt-val",
      "#b02-portal-mcht-val",
      "#b02-estatement-val",
      "#b02-active-rate",
      "#b02-twqr-pass-rate",
      "#b02-twqr-active-rate",
      "#b03-app-rate-val",
      "#b03-app-rate-growth",
      "#b03-tab0-old-pass-rate",
      "#b03-tab0-new-pass-rate",
      "#b03-tab0-old-auto-rate",
      "#b03-tab0-new-auto-rate",
      "#b03-ebill-val",
      "#b03-bonus-rate-val",
      "#b03-bill-erate-val",
      "#b03-bill-deliv-val",
      "#b04-cp-succ-val",
      "#b04-cl-avail-val"
    ];

    mainSections.forEach(section => {
      const walker = document.createTreeWalker(
        section,
        NodeFilter.SHOW_TEXT,
        {
          acceptNode(node) {
            const parent = node.parentElement;
            if (!parent) return NodeFilter.FILTER_REJECT;
            const tag = parent.tagName.toLowerCase();
            if (tag === "script" || tag === "style" || tag === "title") return NodeFilter.FILTER_REJECT;
            if (parent.classList && parent.classList.contains("decimal-part")) return NodeFilter.FILTER_REJECT;
            
            if (parent.closest && parent.closest(excludedParentSelectors.join(","))) {
              return NodeFilter.FILTER_REJECT;
            }

            if (/(\d+)\.(\d+)(?!\d)(?!\s*(%|pp|‰))/.test(node.nodeValue)) {
              return NodeFilter.FILTER_ACCEPT;
            }
            return NodeFilter.FILTER_SKIP;
          }
        }
      );

      const nodesToProcess = [];
      while (walker.nextNode()) {
        nodesToProcess.push(walker.currentNode);
      }

      nodesToProcess.forEach(node => {
        const parent = node.parentElement;
        if (!parent) return;

        const isSvg = (typeof SVGElement !== "undefined" && parent instanceof SVGElement) || 
                      (parent.namespaceURI === "http://www.w3.org/2000/svg") ||
                      (parent.closest && parent.closest("svg") !== null);
        const text = node.nodeValue;
        const regex = /(\d+)\.(\d+)(?!\d)(?!\s*(%|pp|‰))/g;
        if (!regex.test(text)) return;
        regex.lastIndex = 0;

        const fragment = document.createDocumentFragment();
        let lastIndex = 0;
        let match;

        while ((match = regex.exec(text)) !== null) {
          const matchStart = match.index;
          const intPart = match[1];
          const decDigits = match[2];

          const beforeText = text.substring(lastIndex, matchStart) + intPart;
          if (beforeText) {
            fragment.appendChild(document.createTextNode(beforeText));
          }

          if (isSvg) {
            const tspan = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
            tspan.setAttribute("class", "decimal-part");
            tspan.setAttribute("font-size", "0.78em");
            tspan.textContent = "." + decDigits;
            fragment.appendChild(tspan);
          } else {
            const span = document.createElement("span");
            span.className = "decimal-part";
            span.textContent = "." + decDigits;
            fragment.appendChild(span);
          }

          lastIndex = regex.lastIndex;
        }

        if (lastIndex < text.length) {
          fragment.appendChild(document.createTextNode(text.substring(lastIndex)));
        }

        parent.replaceChild(fragment, node);
      });
    });
  }

  function applyCockpitDecimals() {
    applyDashboardDecimals();
  }

  document.addEventListener("DOMContentLoaded", () => {
    if (window.DASHBOARD_DATA) {
      renderBlock01FromData(window.DASHBOARD_DATA);
      renderBlock02FromData(window.DASHBOARD_DATA);
      renderBlock03FromData(window.DASHBOARD_DATA);
      renderBlock04FromData(window.DASHBOARD_DATA);
    }

    renderYtd();
    resizeCockpitCanvas();
    applyDashboardDecimals();
  });
  window.addEventListener("resize", resizeCockpitCanvas);
